#!/opt/pyvenv/bin/python
from __future__ import annotations
import collections, hashlib, io, json, math, os, random, struct, subprocess, tempfile, time, zipfile, zlib
from pathlib import Path
import xml.etree.ElementTree as ET
import numpy as np
import torch
from torch import nn
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import balanced_accuracy_score, accuracy_score

SEED_DATA = 20260930
SEED_MODEL = 20261005
WINDOW_BYTES = 64
EMBED_DIM = 128
CARRIER_HIDDEN = 32
ROOT = Path('/mnt/data/selective_expansion_probe')
ARCHIVE_ROOT = Path('/mnt/data/conscience64_probe_work/original')
C_BINARY = ARCHIVE_ROOT / 'compressed_text_ai_probe'
TEXTBLOB_ROOT = Path('/opt/pyvenv/lib/python3.13/site-packages/textblob/en')
SENT_XML = TEXTBLOB_ROOT / 'en-sentiment.xml'
POS_LEX = TEXTBLOB_ROOT / 'en-lexicon.txt'
ORIGINAL_ARCHIVE = Path('/mnt/data/conscience64_probe_inputs/compressed_text_ai_five_experiments_2026-09-30.zip')
RERUN_ARCHIVE = Path('/mnt/data/conscience64_probe_inputs/compressed_text_ai_rerun_2026-09-30.zip')

# One bounded probe only. No model-width/window-size/seed sweep.
torch.set_num_threads(min(8, os.cpu_count() or 1))
torch.manual_seed(SEED_MODEL)
np.random.seed(SEED_MODEL)
random.seed(SEED_MODEL)
torch.use_deterministic_algorithms(True)


def sha256_file(path: Path) -> str:
    h=hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda:f.read(1<<20),b''): h.update(chunk)
    return h.hexdigest()

def stable_rank(domain: str, key: str) -> bytes:
    return hashlib.sha256(f'{SEED_DATA}|{domain}|{key}'.encode('utf-8')).digest()

def u32(x: int) -> int: return x & 0xffffffff

def ngram_hash(bs: bytes) -> int:
    n=len(bs)
    h=u32(2166136261 ^ u32(0x9e3779b9*n))
    for b in bs: h=u32((h ^ b)*16777619)
    h=u32(h ^ (h>>16)); h=u32(h*0x7feb352d); h=u32(h ^ (h>>15)); h=u32(h*0x846ca68b); h=u32(h ^ (h>>16))
    return h

def exact_embedding(data: bytes) -> np.ndarray:
    # Bit-for-bit float32 match to the retained C 1/2/3-gram carrier on tested fixtures.
    v=np.zeros(EMBED_DIM,dtype=np.float32)
    n=len(data)
    for gram in (1,2,3):
        for i in range(n-gram+1):
            h=ngram_hash(data[i:i+gram])
            v[h & (EMBED_DIM-1)] += np.float32(-1.0 if (h & 0x100) else 1.0)
    grams=n + (n-1 if n>=2 else 0) + (n-2 if n>=3 else 0)
    denom=np.float32(np.log1p(np.float32(grams if grams>0 else 1.0)))
    out=np.sign(v)*np.log1p(np.abs(v)).astype(np.float32)/denom
    return out.astype(np.float32)

class CarrierMLP(nn.Module):
    def __init__(self):
        super().__init__(); self.fc1=nn.Linear(EMBED_DIM,CARRIER_HIDDEN); self.fc2=nn.Linear(CARRIER_HIDDEN,1)
    def forward(self,x): return self.fc2(torch.tanh(self.fc1(x))).squeeze(-1)

class LocalCNN(nn.Module):
    # Same 4,573-float / 18,292-byte architecture as the separately labeled CNN reconstruction,
    # but newly trained here only on one bounded logical prefix window. It is not the historical CNN.
    def __init__(self):
        super().__init__(); self.emb=nn.Embedding(256,8); self.c1=nn.Conv1d(8,24,3); self.c2=nn.Conv1d(24,26,3); self.out=nn.Linear(26,1)
    def forward(self,x,lengths):
        z=self.emb(x).transpose(1,2)
        z=torch.relu(self.c1(z)); z=torch.relu(self.c2(z))
        # Two valid k=3 convolutions -> logical valid output positions max(length-4,1).
        valid=torch.clamp(lengths-4,min=1,max=z.shape[-1])
        idx=torch.arange(z.shape[-1],device=z.device)[None,:]
        z=z.masked_fill((idx>=valid[:,None])[:,None,:], -1e9)
        z=z.max(dim=-1).values
        return self.out(z).squeeze(-1)

def model_float_count(m: nn.Module) -> int:
    return sum(p.numel() for p in m.parameters())

def metrics(y, p):
    y=np.asarray(y,dtype=np.int64); p=np.asarray(p,dtype=float); pred=(p>=.5).astype(np.int64)
    return {'n':int(len(y)),'accuracy':float(accuracy_score(y,pred)),'balanced_accuracy':float(balanced_accuracy_score(y,pred))}

def build_sentiment():
    root=ET.parse(SENT_XML).getroot(); groups=collections.defaultdict(list)
    for node in root.findall('.//word'):
        a=node.attrib
        if a.get('pos')=='JJ': groups[a['form'].lower()].append(a)
    rows=[]
    for form, senses in groups.items():
        pol=sum(float(s.get('polarity',0) or 0) for s in senses)/len(senses)
        if abs(pol)<1e-12: continue
        seen=set(); desc=[]
        for s in senses:
            d=' '.join((s.get('sense') or '').split())
            if d and d not in seen: seen.add(d); desc.append(d)
        # New canonical reconstruction encoding; source order retained.
        text=(form+'\n'+' | '.join(desc)).rstrip().encode('utf-8')
        rows.append({'id':form,'text':text,'y':int(pol>0)})
    # Historical selection code is unrecovered. Match the retained documented count without using labels.
    rows=sorted(rows,key=lambda r:stable_rank('sentiment-count-match',r['id']))[:1059]
    rows=sorted(rows,key=lambda r:stable_rank('sentiment-outer-split',r['id']))
    return rows[:795], rows[795:]

def build_pos():
    tags=collections.defaultdict(set)
    with POS_LEX.open(encoding='utf-8') as f:
        for line in f:
            line=line.strip()
            if not line or line.startswith(';'): continue
            parts=line.split()
            if len(parts)>=2: tags[parts[0].lower()].update(parts[1:])
    noun_tags={'NN','NNS'}; verb_tags={'VB','VBD','VBG','VBN','VBP','VBZ'}; proper={'NNP','NNPS'}
    nouns=[]; verbs=[]
    for word,t in tags.items():
        if not word.isascii() or not word.isalpha() or (t & proper): continue
        hn=bool(t & noun_tags); hv=bool(t & verb_tags)
        if hn==hv: continue
        (nouns if hn else verbs).append(word)
    nouns=sorted(nouns,key=lambda w:stable_rank('pos-noun-select',w))[:2500]
    verbs=sorted(verbs,key=lambda w:stable_rank('pos-verb-select',w))[:2500]
    nouns=sorted(nouns,key=lambda w:stable_rank('pos-noun-split',w)); verbs=sorted(verbs,key=lambda w:stable_rank('pos-verb-split',w))
    train=[{'id':w,'text':w.encode(),'y':0} for w in nouns[:1875]] + [{'id':w,'text':w.encode(),'y':1} for w in verbs[:1875]]
    test=[{'id':w,'text':w.encode(),'y':0} for w in nouns[1875:]] + [{'id':w,'text':w.encode(),'y':1} for w in verbs[1875:]]
    train=sorted(train,key=lambda r:stable_rank('pos-train-order',r['id'])); test=sorted(test,key=lambda r:stable_rank('pos-test-order',r['id']))
    return train,test

def fit_cal_split(train):
    by=collections.defaultdict(list)
    for r in train: by[r['y']].append(r)
    fit=[]; cal=[]
    for y,rs in sorted(by.items()):
        rs=sorted(rs,key=lambda r:stable_rank(f'fit-cal-{y}',r['id']))
        cut=round(.8*len(rs)); fit.extend(rs[:cut]); cal.extend(rs[cut:])
    fit=sorted(fit,key=lambda r:stable_rank('fit-order',r['id'])); cal=sorted(cal,key=lambda r:stable_rank('cal-order',r['id']))
    return fit,cal

def arrays(rows):
    X=np.stack([exact_embedding(r['text']) for r in rows]); y=np.array([r['y'] for r in rows],dtype=np.float32)
    return X,y

def window_arrays(rows):
    x=np.zeros((len(rows),WINDOW_BYTES),dtype=np.int64); lengths=np.zeros(len(rows),dtype=np.int64)
    for i,r in enumerate(rows):
        b=r['text'][:WINDOW_BYTES]; n=len(b); x[i,:n]=np.frombuffer(b,dtype=np.uint8); lengths[i]=n
    return x,lengths,np.array([r['y'] for r in rows],dtype=np.float32)

def train_carrier(fit,cal):
    Xf,yf=arrays(fit); Xc,yc=arrays(cal)
    mean=Xf.mean(0,dtype=np.float64).astype(np.float32); std=Xf.std(0,dtype=np.float64).astype(np.float32); std=np.where(std>1e-4,std,1.0).astype(np.float32)
    Xf=(Xf-mean)/std; Xc=(Xc-mean)/std
    torch.manual_seed(SEED_MODEL)
    m=CarrierMLP(); opt=torch.optim.AdamW(m.parameters(),lr=0.01,weight_decay=1e-5); lossf=nn.BCEWithLogitsLoss()
    tx=torch.tensor(Xf); ty=torch.tensor(yf); m.train()
    for _ in range(80):
        opt.zero_grad(); loss=lossf(m(tx),ty); loss.backward(); opt.step()
    m.eval()
    with torch.no_grad(): cp=torch.sigmoid(m(torch.tensor(Xc))).numpy()
    return m,mean,std,metrics(yc,cp)

def train_cnn(fit,cal):
    xf,lf,yf=window_arrays(fit); xc,lc,yc=window_arrays(cal)
    torch.manual_seed(SEED_MODEL)
    m=LocalCNN(); opt=torch.optim.AdamW(m.parameters(),lr=0.004,weight_decay=1e-4); lossf=nn.BCEWithLogitsLoss()
    tx=torch.tensor(xf); tl=torch.tensor(lf); ty=torch.tensor(yf)
    m.train()
    for _ in range(60):
        opt.zero_grad(); loss=lossf(m(tx,tl),ty); loss.backward(); opt.step()
    m.eval()
    with torch.no_grad(): cp=torch.sigmoid(m(torch.tensor(xc),torch.tensor(lc))).numpy()
    return m,metrics(yc,cp)

def carrier_logits(m,mean,std,rows):
    X,_=arrays(rows); X=(X-mean)/std
    with torch.no_grad(): return m(torch.tensor(X)).numpy()

def cnn_logits(m,rows):
    x,l,_=window_arrays(rows)
    with torch.no_grad(): return m(torch.tensor(x),torch.tensor(l)).numpy()

def sigmoid(x):
    x=np.asarray(x,dtype=float); return np.where(x>=0,1/(1+np.exp(-x)),np.exp(x)/(1+np.exp(x)))

def gate_thresholds(cal_rows, carrier_prob):
    u=1.0-np.abs(2*carrier_prob-1)
    costs=np.array([min(WINDOW_BYTES,len(r['text'])) for r in cal_rows],dtype=float)
    denom=sum(len(r['text']) for r in cal_rows)
    order=np.argsort(-u,kind='stable')
    cum=np.cumsum(costs[order])/denom
    max_fraction=float(cum[-1]) if len(cum) else 0.0
    targets=[0.0,0.05,0.10,0.25,0.50,1.0]
    out=[]
    for t in targets:
        if t<=0: out.append({'target_fraction':t,'threshold':float('inf')}); continue
        if t>=max_fraction: out.append({'target_fraction':t,'threshold':float('-inf')}); continue
        k=int(np.searchsorted(cum,t,side='left'))
        out.append({'target_fraction':t,'threshold':float(u[order[k]])})
    # Deduplicate equal thresholds while preserving endpoints.
    uniq=[]; seen=set()
    for row in out:
        key=row['threshold']
        if key not in seen: seen.add(key); uniq.append(row)
    return uniq,max_fraction

def evaluate_curve(rows,y,carrier_logit,cnn_logit,fusion,thresholds):
    cp=sigmoid(carrier_logit); u=1.0-np.abs(2*cp-1)
    local_features=np.c_[carrier_logit,cnn_logit]
    fp=fusion.predict_proba(local_features)[:,1]
    total=sum(len(r['text']) for r in rows)
    curve=[]
    for spec in thresholds:
        th=spec['threshold']; gate=np.zeros(len(rows),dtype=bool) if math.isinf(th) and th>0 else (np.ones(len(rows),dtype=bool) if math.isinf(th) and th<0 else u>=th)
        p=cp.copy(); p[gate]=fp[gate]
        expanded=sum(min(WINDOW_BYTES,len(rows[i]['text'])) for i in np.where(gate)[0])
        row={**metrics(y,p),'requested_calibration_byte_fraction':spec['target_fraction'],'carrier_uncertainty_threshold':None if math.isinf(th) else th,'expanded_samples':int(gate.sum()),'expanded_logical_bytes':int(expanded),'total_logical_bytes':int(total),'expanded_fraction':float(expanded/total if total else 0)}
        curve.append(row)
    return curve

def raw_zip(data: bytes, level=6, strategy=zlib.Z_DEFAULT_STRATEGY, chunk=None, flush=None, stored=False) -> bytes:
    if stored: payload=data; method=0
    else:
        co=zlib.compressobj(level,zlib.DEFLATED,-15,8,strategy); pieces=[]
        if chunk is None: pieces.append(co.compress(data))
        else:
            for pos in range(0,len(data),chunk):
                pieces.append(co.compress(data[pos:pos+chunk]));
                if flush is not None: pieces.append(co.flush(flush))
        pieces.append(co.flush()); payload=b''.join(pieces); method=8
    name=b'probe.txt'; crc=zlib.crc32(data); n=len(data); c=len(payload)
    local=struct.pack('<IHHHHHIIIHH',0x04034b50,20,0,method,0,0,crc,c,n,len(name),0)+name+payload
    central=struct.pack('<IHHHHHHIIIHHHHHII',0x02014b50,20,20,0,method,0,0,crc,c,n,len(name),0,0,0,0,0,0)+name
    return local+central+struct.pack('<IHHHHIIH',0x06054b50,0,0,1,1,len(central),len(local),0)

def c_embed(zip_path: Path, stream=False):
    cmd=[str(C_BINARY),'stream-embed' if stream else 'embed',str(zip_path),'probe.txt']
    return json.loads(subprocess.check_output(cmd,text=True))

def carrier_prob_from_embedding(model,mean,std,embedding):
    x=(np.asarray(embedding,dtype=np.float32)-mean)/std
    with torch.no_grad(): return float(torch.sigmoid(model(torch.tensor(x[None,:]))).item())

def recompression_counterprobe(task,rows,carrier,mean,std,thresholds):
    variants=[
        ('stored',dict(stored=True)),
        ('level1',dict(level=1)),('level6',dict(level=6)),('level9',dict(level=9)),
        ('filtered',dict(level=6,strategy=zlib.Z_FILTERED)),
        ('huffman',dict(level=6,strategy=zlib.Z_HUFFMAN_ONLY)),
        ('fixed',dict(level=6,strategy=zlib.Z_FIXED)),
        ('fullflush17',dict(level=6,chunk=17,flush=zlib.Z_FULL_FLUSH)),
    ]
    picks=sorted(rows,key=lambda r:stable_rank(f'{task}-recompression',r['id']))[:16]
    max_embed_drift=0.0; max_stream_drift=0.0; trigger_mismatch=0; expansion_mismatch=0; cases=0
    with tempfile.TemporaryDirectory() as td:
        zp=Path(td)/'x.zip'
        for r in picks:
            baseline=None
            for name,kw in variants:
                zp.write_bytes(raw_zip(r['text'],**kw)); a=c_embed(zp,False); b=c_embed(zp,True)
                emb=np.asarray(a['embedding'],dtype=np.float32); semb=np.asarray(b['embedding'],dtype=np.float32)
                max_stream_drift=max(max_stream_drift,float(np.max(np.abs(emb-semb))))
                p=carrier_prob_from_embedding(carrier,mean,std,emb); u=1.0-abs(2*p-1)
                decisions=tuple(False if (s['threshold']>0 and math.isinf(s['threshold'])) else True if (s['threshold']<0 and math.isinf(s['threshold'])) else u>=s['threshold'] for s in thresholds)
                expansions=tuple((0,min(WINDOW_BYTES,len(r['text']))) if d else None for d in decisions)
                if baseline is None: baseline=(emb,p,decisions,expansions)
                else:
                    max_embed_drift=max(max_embed_drift,float(np.max(np.abs(emb-baseline[0]))))
                    trigger_mismatch += sum(x!=y for x,y in zip(decisions,baseline[2]))
                    expansion_mismatch += sum(x!=y for x,y in zip(expansions,baseline[3]))
                cases+=1
    return {'logical_documents':len(picks),'recompressions_per_document':len(variants),'cases':cases,'max_exact_embedding_drift':max_embed_drift,'max_whole_vs_stream_embedding_drift':max_stream_drift,'trigger_mismatches':trigger_mismatch,'logical_expansion_mismatches':expansion_mismatch,'window_definition':'prefix logical bytes [0,min(64,len(text)))','variants':[v[0] for v in variants]}

def run_task(name,train,test):
    fit,cal=fit_cal_split(train)
    carrier,mean,std,carrier_cal=train_carrier(fit,cal)
    cnn,cnn_cal=train_cnn(fit,cal)
    cl_cal=carrier_logits(carrier,mean,std,cal); nl_cal=cnn_logits(cnn,cal); ycal=np.array([r['y'] for r in cal])
    fusion=LogisticRegression(random_state=SEED_MODEL,solver='lbfgs',C=1.0,max_iter=1000).fit(np.c_[cl_cal,nl_cal],ycal)
    thresholds,max_cal=gate_thresholds(cal,sigmoid(cl_cal))
    cl_test=carrier_logits(carrier,mean,std,test); nl_test=cnn_logits(cnn,test); ytest=np.array([r['y'] for r in test])
    curve=evaluate_curve(test,ytest,cl_test,nl_test,fusion,thresholds)
    all_fused=fusion.predict_proba(np.c_[cl_test,nl_test])[:,1]
    probe=recompression_counterprobe(name,test,carrier,mean,std,thresholds)
    return {
      'dataset':{'train_n':len(train),'test_n':len(test),'fit_n':len(fit),'calibration_n':len(cal),'train_positive':sum(r['y'] for r in train),'test_positive':sum(r['y'] for r in test),'logical_bytes_test':sum(len(r['text']) for r in test),'mean_test_bytes':float(np.mean([len(r['text']) for r in test]))},
      'models':{'closed_carrier':{'carrier':'exact associative 128-D signed hashed byte 1/2/3-gram summary','head':'128 -> tanh(32) -> 1','trainable_float_parameters':model_float_count(carrier),'trainable_parameter_bytes':4*model_float_count(carrier),'calibration_metrics':carrier_cal,'test_metrics':metrics(ytest,sigmoid(cl_test))},'bounded_local_cnn':{'architecture':'Embedding(256,8)->Conv1d(8,24,k=3)->ReLU->Conv1d(24,26,k=3)->ReLU->masked global max->Linear(26,1)','window_bytes':WINDOW_BYTES,'trainable_float_parameters':model_float_count(cnn),'trainable_parameter_bytes':4*model_float_count(cnn),'calibration_metrics':cnn_cal,'test_metrics_standalone_local_window':metrics(ytest,sigmoid(nl_test))},'fusion':{'type':'logistic residual fusion over [closed_carrier_logit, bounded_local_cnn_logit]','coef':fusion.coef_.tolist(),'intercept':fusion.intercept_.tolist(),'test_metrics_if_all_samples_gate':metrics(ytest,all_fused)}},
      'gate':{'uncertainty':'u = 1 - abs(2*p_closed - 1)','threshold_source':'calibration split only; thresholds target logical-byte fractions without test tuning','max_calibration_expandable_fraction':max_cal,'curve':curve},
      'recompression_counterprobe':probe,
    }

def main():
    started=time.time()
    if not C_BINARY.exists(): raise SystemExit(f'missing {C_BINARY}')
    selftest=subprocess.run([str(C_BINARY),'selftest'],capture_output=True,text=True)
    if selftest.returncode: raise SystemExit(selftest.stderr+selftest.stdout)
    st,sv=build_sentiment(); pt,pv=build_pos()
    result={
      'experiment':'bounded_uncertainty_triggered_selective_expansion_2026-10-05',
      'scope':'ONE_NONLINEAR_RESIDUAL_PROBE_ONLY',
      'claim_ceilings':['RECONSTRUCTION != ORIGINAL_IDENTITY','TASK_RECONSTRUCTION != HISTORICAL_SPLIT_IDENTITY','PRESERVED_RESULT != REPRODUCIBLE_EXPERIMENT','NO_TEST_TUNING','NO_COMPRESSION_LAYOUT_TRIGGER'],
      'protocol':{'window_bytes':WINDOW_BYTES,'window_location':'logical prefix offset 0','trigger':'closed exact-carrier head uncertainty only','expanded_reader':'one bounded local CNN with the separately reported reconstruction architecture and same 18,292-byte parameter count; newly trained here','combination':'logistic residual fusion only after gate fires','seeds':{'data':SEED_DATA,'model':SEED_MODEL},'stop_rule':'stop after sentiment + POS curves and recompression counterprobes; no width/window/seed sweep'},
      'identity':{'original_archive_sha256':sha256_file(ORIGINAL_ARCHIVE),'rerun_archive_sha256':sha256_file(RERUN_ARCHIVE),'retained_c_source_sha256':sha256_file(ARCHIVE_ROOT/'compressed_text_ai.c'),'textblob_sentiment_xml_sha256':sha256_file(SENT_XML),'textblob_pos_lexicon_sha256':sha256_file(POS_LEX),'historical_experiment4_python_source':'UNRECOVERED','historical_exact_sample_encoding_and_split':'UNRECOVERED','cnn_original_identity':'UNRECOVERED'},
      'retained_reference_baselines':{
        'affine_family_rerun_balanced_accuracy':{'sentiment':{'aaa4':0.58963133640553,'aaa8':0.5785714285714285,'aaa12':0.583294930875576,'aaa16':0.5975806451612904},'pos':{'aaa4':0.7544,'aaa8':0.7792,'aaa12':0.7808}},
        'cnn_reconstruction_balanced_accuracy_ranges':{'sentiment':[0.6331797235,0.6945852535],'pos':[0.824,0.8336]},
        'comparison_boundary':'Reference results are retained historical/rerun records. The missing Experiment-4 generator means they are not numerically rank-comparable to this deterministic count-matched task reconstruction.'
      },
      'inherited_selftest':{'returncode':selftest.returncode,'stdout':selftest.stdout.strip(),'stderr':selftest.stderr.strip()},
    }
    result['tasks']={'sentiment':run_task('sentiment',st,sv),'pos':run_task('pos',pt,pv)}
    result['elapsed_s']=time.time()-started
    out=ROOT/'results.json'; out.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print(json.dumps(result,indent=2,sort_keys=True))

if __name__=='__main__': main()
