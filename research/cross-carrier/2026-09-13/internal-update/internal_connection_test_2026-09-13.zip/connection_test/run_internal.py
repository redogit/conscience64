"""Internal connection probe against recovered, unmodified project code."""
from pathlib import Path
import hashlib, importlib.util, json, sys, tempfile, time, os

ROOT = Path(__file__).resolve().parents[1]
FW = ROOT/'internal_run/cooperative_ecs_project/cooperative_ecs_project/framework'
if os.environ.get('CONNECTION_USE_REPAIR') == '1':
    FW = Path(__file__).resolve().parent/'repaired_framework'
WAVE = ROOT/'internal_run/cross_carrier_field_wavelet_experiments_v1_2/cross_carrier_field_wavelet_experiments_v1_2/experiment_suite.py'
sys.path.insert(0, str(FW/'src'))
from ecs_world.carriers import LocalFileCarrierAdapter, ComputationCarrierAdapter
from ecs_world.bridge import JsonlHostBridgeAdapter, append_host_response, pending_host_requests
from ecs_world.intake import decompose_request, load_branch_catalog

def main():
    spec = importlib.util.spec_from_file_location('recovered_wave', WAVE)
    wave = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = wave
    spec.loader.exec_module(wave)
    results = []
    for n in list(range(14))+[16]:
        row = getattr(wave, f'experiment_e{n}')()
        results.append(row)
        print(row['id'], row['verdict'], flush=True)
    catalog = load_branch_catalog(FW/'world')
    domains = []
    for branch in catalog:
        req = dict(subject='Internal cross-carrier connection',
                   motivator='Locate whether existing tools preserve receiving context.',
                   request='Transport this bounded test through existing internal interfaces.',
                   obligation='Preserve provenance, boundary, and unresolved remainder.', branch=branch)
        value = decompose_request(req, catalog)
        domains.append({'branch':branch,'key':value['key'], 'criteria':len(value['criteria']),
                        'boundary':value['boundary'],
                        'deterministic':value == decompose_request(req, catalog)})
    bridges=[]
    with tempfile.TemporaryDirectory() as temp:
        temp=Path(temp)
        for carrier in ['library','research','scientific-compute','model','human-queue']:
            outbox,inbox=temp/(carrier+'-out.jsonl'),temp/(carrier+'-in.jsonl')
            bridge=JsonlHostBridgeAdapter(carrier,outbox,inbox)
            request={'problem_key':'INTERNAL-CONNECTION','action':{'method':'restart-contract'},
                     'boundary':['Internal synthetic fixture; no external observation'],
                     'acceptance':['Exact fixture returned'],'sources':[],
                     'target_output':'Carry UTF-8: café, Ελληνικά, 日本語, العربية, 🌊', 'cycle':1}
            first=bridge.execute(request)
            retry=bridge.execute({**request,'cycle':99})
            append_host_response(inbox,{'request_id':first['request_id'],'ok':True,
                'result':request['target_output'],'artifact':request,
                'evidence_kind':'internal-test','scope_kind':'internal',
                'substantive':False,'evidence':[], 'satisfies':[]})
            resumed=JsonlHostBridgeAdapter(carrier,outbox,inbox).execute(request)
            bridges.append({'carrier':carrier,'fixture_only':True,
                'retry_identity_preserved':first['request_id']==retry['request_id'],
                'outbox_rows':len(outbox.read_text().splitlines()),
                'response_preserved':resumed['artifact']==request,
                'internal_scope_preserved':resumed['scope_kind']=='internal',
                'pending_after_response':len(pending_host_requests(outbox,inbox))})
    lookup=LocalFileCarrierAdapter([WAVE.parent])
    recovered=lookup.execute({'sources':['experiment_suite.py'],'acceptance':[]})
    missing=lookup.execute({'sources':['deliberately_missing_source.py'],'acceptance':[]})
    mixed=lookup.execute({'sources':['experiment_suite.py','deliberately_missing_source.py'],'acceptance':[]})
    checks={
        'wave_outcomes_match_expected':all(x['verdict']==({'E5':'COUNTEREXAMPLE_FOUND','E8':'EXPECTED_BOUNDARY_FOUND','E10':'EXPECTED_BOUNDARY_FOUND'}.get(x['id'],'PASS')) for x in results),
        'all_domain_intakes_deterministic':all(x['deterministic'] for x in domains),
        'all_bridges_roundtrip':all(x['retry_identity_preserved'] and x['outbox_rows']==1 and x['response_preserved'] and x['internal_scope_preserved'] and x['pending_after_response']==0 for x in bridges),
        'source_hash_matches':recovered['artifact']['matches'][0]['sha256']==hashlib.sha256(WAVE.read_bytes()).hexdigest(),
        'missing_source_reported':bool(missing['unresolved']),
        'mixed_missing_source_reported':bool(mixed['unresolved']),
    }
    report={'executed_unix':time.time(),'scope':'Internal recovered snapshot, not live sites or all historical implementations',
        'source_hashes':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [WAVE,FW/'src/ecs_world/bridge.py',FW/'src/ecs_world/carriers.py',FW/'src/ecs_world/intake.py']},
        'checks':checks,'wave_results':results,'domain_intakes':domains,'bridge_results':bridges,
        'recovery_negative_control':{'missing':missing,'mixed':mixed},
        'not_executed':['E14 numerical equilibrium','E15 billion-identity stress','live site/domain connections','separate runtime of each catalogued project'],
        'interpretation':'A catalog entry or bridge fixture is not execution of the named external tool. Local verifier fingerprints do not establish independent corroboration.'}
    name = 'repaired_results.json' if os.environ.get('CONNECTION_USE_REPAIR') == '1' else 'results.json'
    (Path(__file__).parent/name).write_text(json.dumps(report,indent=2))
    print(json.dumps(checks,indent=2))

if __name__=='__main__': main()
