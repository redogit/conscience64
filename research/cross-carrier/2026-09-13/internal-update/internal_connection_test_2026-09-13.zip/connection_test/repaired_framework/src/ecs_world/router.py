from __future__ import annotations

import uuid
from dataclasses import asdict
from typing import Any

from .carriers import CarrierAdapter
from .components import (
    Budget, Carrier, CostProfile, DispatchPolicy, Identity, RoutingTable,
)
from .core import World


class CarrierRouter:
    def __init__(self, adapters: dict[str, CarrierAdapter] | None = None):
        self.adapters: dict[str, CarrierAdapter] = dict(adapters or {})

    def register(self, executor_key: str, adapter: CarrierAdapter) -> None:
        self.adapters[executor_key] = adapter

    def _routing(self, world: World, method: str) -> dict[str, Any]:
        rows = list(world.query(RoutingTable))
        if not rows:
            return {}
        return rows[0][1].methods.get(method, rows[0][1].methods.get("*", {}))

    def _policy(self, world: World) -> DispatchPolicy:
        rows = list(world.query(DispatchPolicy))
        return rows[0][1] if rows else DispatchPolicy()

    @staticmethod
    def _within_budget(cost: CostProfile, budget: Budget) -> bool:
        return (
            cost.attention <= budget.attention
            and cost.compute <= budget.compute
            and cost.money <= budget.money
        )

    def _candidates(
        self,
        world: World,
        required: set[str],
        preferred: list[str],
        budget: Budget,
        allow_human: bool,
        exclude_keys: set[str] | None = None,
    ) -> list[tuple[float, int, Identity, Carrier, CostProfile]]:
        policy = self._policy(world)
        exclude_keys = exclude_keys or set()
        rows: list[tuple[float, int, Identity, Carrier, CostProfile]] = []
        for eid, ident, carrier, cost in world.query(Identity, Carrier, CostProfile):
            if not carrier.enabled or carrier.executor_key not in self.adapters or carrier.executor_key in exclude_keys:
                continue
            if carrier.requires_human and not (allow_human and policy.allow_human_queue):
                continue
            if not self._within_budget(cost, budget):
                continue
            coverage = 1.0 if not required else len(required & carrier.capabilities) / len(required)
            if coverage < policy.min_capability_coverage and carrier.executor_key != "reference":
                continue
            preference = 0.20 if carrier.executor_key in preferred else 0.0
            diversity = len(required & carrier.capabilities) * 0.01
            score = coverage * 0.60 + carrier.reliability * 0.20 + preference + diversity
            rows.append((score, eid, ident, carrier, cost))
        rows.sort(key=lambda x: (x[0], x[3].reliability, x[2].key), reverse=True)
        return rows

    def dispatch(
        self,
        world: World,
        problem_key: str,
        action: dict[str, Any],
        budget: Budget,
        context: dict[str, Any],
    ) -> dict[str, Any]:
        route = self._routing(world, action.get("method", ""))
        policy = self._policy(world)
        required = set(route.get("required_capabilities", []))
        preferred = list(route.get("preferred", []))
        verifier_preferred = list(route.get("verifier_preferred", ["rule"]))
        allow_human = bool(route.get("allow_human", False))
        dispatch_id = str(uuid.uuid4())
        attempts: list[dict[str, Any]] = []

        candidates = self._candidates(world, required, preferred, budget, allow_human)
        primary: dict[str, Any] | None = None
        primary_key: str | None = None
        for _, _, ident, carrier, cost in candidates[: policy.max_attempts]:
            request = dict(context)
            request.update({
                "dispatch_id": dispatch_id,
                "problem_key": problem_key,
                "action": action,
                "mode": "execute",
            })
            try:
                result = self.adapters[carrier.executor_key].execute(request)
            except Exception as exc:  # failure is data; routing continues
                result = {"ok": False, "result": f"carrier exception: {type(exc).__name__}", "evidence": []}
            attempts.append({
                "dispatch_id": dispatch_id,
                "carrier_entity": ident.key,
                "executor_key": carrier.executor_key,
                "mode": "execute",
                "cost": asdict(cost),
                "ok": bool(result.get("ok")),
                "pending": bool(result.get("pending")),
                "request_id": result.get("request_id"),
                "evidence_kind": result.get("evidence_kind"),
            })
            if result.get("ok") or result.get("pending"):
                primary = result
                primary_key = carrier.executor_key
                break

        if primary is None:
            return {
                "ok": False,
                "result": "No eligible carrier completed the bounded action.",
                "evidence": [],
                "evidence_kind": "dispatch-failure",
                "scope_kind": "internal",
                "substantive": False,
                "dispatch_id": dispatch_id,
                "carrier": None,
                "attempts": attempts,
                "verification": None,
            }

        verification: dict[str, Any] | None = None
        if policy.verify_with_second_carrier and primary.get("ok") and not primary.get("pending"):
            verifier_required = set(route.get("verifier_capabilities", []))
            verifiers = self._candidates(
                world,
                verifier_required,
                verifier_preferred,
                budget,
                allow_human=False,
                exclude_keys={primary_key} if primary_key else set(),
            )
            if verifiers:
                _, _, ident, carrier, cost = verifiers[0]
                request = dict(context)
                request.update({
                    "dispatch_id": dispatch_id,
                    "problem_key": problem_key,
                    "action": action,
                    "mode": "verify",
                    "primary_result": primary,
                })
                try:
                    verification = self.adapters[carrier.executor_key].execute(request)
                except Exception as exc:
                    verification = {"ok": False, "result": f"verifier exception: {type(exc).__name__}", "evidence": []}
                attempts.append({
                    "dispatch_id": dispatch_id,
                    "carrier_entity": ident.key,
                    "executor_key": carrier.executor_key,
                    "mode": "verify",
                    "cost": asdict(cost),
                    "ok": bool(verification.get("ok")),
                    "pending": bool(verification.get("pending")),
                    "request_id": verification.get("request_id"),
                    "evidence_kind": verification.get("evidence_kind"),
                })

        merged = dict(primary)
        merged.update({
            "dispatch_id": dispatch_id,
            "carrier": primary_key,
            "attempts": attempts,
            "verification": verification,
        })
        if verification and verification.get("ok"):
            merged["evidence"] = list(primary.get("evidence", [])) + list(verification.get("evidence", []))
            merged["corroborated"] = True
        else:
            merged["corroborated"] = False
        return merged
