# Internal cross-carrier connection test — 2026-09-13

The recovered internal machinery was exercised. This is a bounded baseline, not a claim that every historical tool or live site is connected.

## Executed observations

- Original Cooperative ECS package: 87 manifest entries matched; 45 existing tests passed.
- Separate repaired framework: 46 tests passed, including partial source-recovery regression.
- Fifteen original wave probes rerun: 12 PASS, one intended counterexample, two expected boundaries. E14 numerical equilibrium and E15 billion-identity stress were not rerun.
- E12: 1,048,576 identities, 16 chunks, failure injected at chunk 5, 11 chunks rerouted, zero identity or obligation errors.
- E13: synthetic relation removal disconnected Reason and Method; restoring the relation reconnected them. This is not evidence about the complete human phenomenon of Knowledge Decay.
- All 39 recorded branch intake paths produced deterministic specifications carrying their boundaries.
- Five local JSONL fixtures (library, research, scientific-compute, model, human-queue) retained retry identity, UTF-8 payload, internal scope, and restart response. These are internal protocol fixtures, not actual calls to those services or human observations.

## Defect found and repaired

LocalFileCarrierAdapter omitted missing filenames from `unresolved` whenever at least one requested source was found. The separate repaired copy now tracks each missing name. Original `results.json` preserves the failing control; `repaired_results.json` records its passing rerun. Source lookup still uses basenames; this repair does not establish full path or version disambiguation.

## What remains

The 39-branch inventory is a recovered September 12 snapshot, not a current account-wide tool census. Its per-branch coverage and claim ceilings are retained in `internal_sources/ALL_PATHS_STATE.md`. OLU/Airlock discipline is represented through the existing admission boundaries; separate OLU Surface/Context, Orbit, TBCL, SHADOW, float64, and other project implementations were not independently wired into this run. Live cross-site and network-domain transfers remain untested by design. The next integration work is to resolve a concrete runtime and adapter contract for each applicable branch, recording unsupported entries explicitly.

Existing carrier text describes local verification fingerprints as independent checks. This run treats them only as internal structural checks: hashing a primary result does not independently corroborate it. No source authority or scientific conclusion transfers merely because branch links or carrier roundtrips succeed.

## Reproduce

From the extracted bundle root, with Python, NumPy, and pytest available:

```bash
python3 connection_test/run_internal.py
CONNECTION_USE_REPAIR=1 python3 connection_test/run_internal.py
cd connection_test/repaired_framework
PYTHONPATH=src python3 -m pytest -q
```

Original ZIPs, extracted source, source identities, script, results, and the repaired copy are included. `BASELINE_MANIFEST.sha256` in the repaired copy is historical; `REPAIRED_MANIFEST.sha256` records its current files. No repository changes were published.
