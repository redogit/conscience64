# Cross Carrier Field Wavelet Experiments — Completion Run v1

## Status

**BOUNDED EXPERIMENT CAMPAIGN COMPLETE.**

This run completes the current finite experiment program and deliberately includes positive results, counterexamples, and boundary failures. It does **not** establish a universal physical field, a universal identifier, a theorem about all carrier systems, or equivalence to trained Liquid Time-Constant, DEQ, or Monotone Operator networks.

The computational contract is: preserve canonical identity and a declared obligation while carriers, coordinate charts, transform paths, and routing state change; expose when a lossy transform destroys future distinguishability; preserve failures rather than hiding them.

## High-value results

- **Large exact stress:** 1,073,741,824 canonical identities were exhaustively streamed through three affine charts, for **3,221,225,472 exact round-trip checks with 0 errors**. Runtime for E15 was 28.80 s.
- **Collision countercontrol:** the deliberate even-multiplier map over 2^20 addresses produced 524,288 unique coordinates out of 1,048,576, a collision fraction of 0.500.
- **Future-capability boundary:** projecting 2^20 identities to 16 local bits preserved the declared low-bit current obligation with 0 errors, but collapsed up to 16 canonical objects per local coordinate.
- **Order matters:** Project16∘Rotate20 and Rotate16∘Project16 disagreed on 983,040 of 1,048,576 inputs (93.750%).
- **Full wave failure/recovery:** E12 processed 1,048,576 identities, injected a route failure, rerouted 11 chunks, and finished with 0 identity errors and 0 obligation errors while retaining the failure record.
- **Knowledge-decay integration:** the synthetic human-history test retained all fragments, removed only a relation, observed disconnection from the Common Point, and restored connectivity when the relation was recovered. This validates reconstruction machinery only; it does not reduce the human phenomenon to graph connectivity.

## Equilibrium wavelet stress

A localized zero-mean Haar-like disturbance was placed on a 4,096-site periodic field. Three numerical routes solved the **same linear equilibrium equation**:

`z = rho*S(z) + (1-rho)*u`

where `S` is the symmetric nearest-neighbor averaging operator.

- `DEQ_PICARD` is a contractive fixed-point surrogate.
- `LIQUID_RELAXATION_SURROGATE` is first-order relaxation `dz/dt = b-Az` discretized by Euler.
- `MONOTONE_CG_SURROGATE` solves the same SPD linear system by conjugate gradient.
- FFT diagonalization supplies an independent numerical reference.

| rho | exact cond(A) | solver | iterations | relative residual | relative error vs FFT | seconds |
| ---: | ---: | --- | ---: | ---: | ---: | ---: |
| 0.2 | 1.5 | DEQ_PICARD | 14 | 1.469e-10 | 1.480e-10 | 0.0023 |
| 0.2 | 1.5 | LIQUID_RELAXATION_SURROGATE | 18 | 1.014e-10 | 1.021e-10 | 0.0013 |
| 0.2 | 1.5 | MONOTONE_CG_SURROGATE | 9 | 5.033e-10 | 4.185e-10 | 0.0004 |
| 0.8 | 9.0 | DEQ_PICARD | 92 | 8.572e-10 | 8.926e-10 | 0.0087 |
| 0.8 | 9.0 | LIQUID_RELAXATION_SURROGATE | 104 | 7.690e-10 | 8.013e-10 | 0.0078 |
| 0.8 | 9.0 | MONOTONE_CG_SURROGATE | 30 | 5.393e-10 | 2.501e-10 | 0.0017 |
| 0.95 | 39.0 | DEQ_PICARD | 388 | 9.423e-10 | 1.039e-09 | 0.0272 |
| 0.95 | 39.0 | LIQUID_RELAXATION_SURROGATE | 432 | 9.539e-10 | 1.052e-09 | 0.0275 |
| 0.95 | 39.0 | MONOTONE_CG_SURROGATE | 64 | 8.523e-10 | 3.298e-10 | 0.0033 |
| 0.99 | 199.0 | DEQ_PICARD | 1880 | 9.814e-10 | 1.311e-09 | 0.1141 |
| 0.99 | 199.0 | LIQUID_RELAXATION_SURROGATE | 2088 | 9.997e-10 | 1.335e-09 | 0.1326 |
| 0.99 | 199.0 | MONOTONE_CG_SURROGATE | 149 | 9.495e-10 | 2.366e-10 | 0.0065 |
| 0.999 | 1999.0 | DEQ_PICARD | 17264 | 9.987e-10 | 2.897e-09 | 1.0119 |
| 0.999 | 1999.0 | LIQUID_RELAXATION_SURROGATE | 19182 | 9.998e-10 | 2.900e-09 | 1.3722 |
| 0.999 | 1999.0 | MONOTONE_CG_SURROGATE | 484 | 9.514e-10 | 2.985e-10 | 0.0220 |

As rho approaches 1, the exact condition number `(1+rho)/(1-rho)` rises sharply. The fixed-point and first-order relaxation iterations rise correspondingly. At `rho=1`, the constant mode gives a zero eigenvalue, so this setup does not certify a unique equilibrium. At `rho=1.01`, the minimum eigenvalue is negative and the SPD/contraction assumptions fail.

This is a useful structural boundary: **adaptive motion is not enough; the admissible operator class matters.**

## Experiment verdicts

- **E0 — Single-boundary faithful carriage: PASS**. Within this fixed two-record/rule carrier, explicit rule carriage is required to reproduce the declared obligation; data retention alone is insufficient.
- **E1 — Transform composition: PASS**. Chosen affine chart transforms compose faithfully over the complete admitted 2^20 object domain.
- **E2 — Retained mapping versus executable capability: PASS**. A retained transform description and an executable resolving capability are distinct states.
- **E3 — Routing-priority failure and fallback: PASS**. A stale route preference can fail while an alternate verified route remains reachable.
- **E4 — Applicability shift: PASS**. An unchanged carrier can remain internally valid while no longer answering the current obligation.
- **E5 — Claim-scope contraction by counterexample: COUNTEREXAMPLE_FOUND**. The score-only claim is refuted for the admitted rule domain; it may be retained only on the no-tie subdomain.
- **E6 — Valid but nonpreferred carrier: PASS**. For this fixed schema, both carriers are valid; the packed carrier is smaller and can be preferred under a byte-cost criterion without invalidating the older carrier.
- **E7 — Reconstruction-path loss: PASS**. Stored source persistence does not imply reconstructible executable capability.
- **E8 — Future-capability loss under lossy projection: EXPECTED_BOUNDARY_FOUND**. The projection is sufficient for the declared current low-bit obligation but destroys exact future identity unless omitted field context is carried separately.
- **E9 — Redundancy and hidden shared dependency: PASS**. Multiple topological paths provide edge redundancy but are not independent when they share a required source dependency.
- **E10 — Transform order / noncommutativity: EXPECTED_BOUNDARY_FOUND**. Projection and a high/low-bit mixing transform do not commute on this complete finite domain; path order is consequential.
- **E11 — Recovery by rerouting: PASS**. Within the admitted 2^20 affine-chart field, the alternate route fully restores exact identity carriage after the selected edge loss.
- **E12 — Full cross-carrier wave with injected route failure: PASS**. The bounded wave detects the injected route failure, retains it, reroutes, and preserves the selected identity and obligation across the full finite run.
- **E13 — Knowledge-decay reconnection integration: PASS**. This tests the reconstruction machinery for relational loss; it does not claim that a synthetic graph models the full human phenomenon of Knowledge Decay.
- **E14 — Localized equilibrium-wavelet controller stress: PASS_WITH_BOUNDARY**. For this linear surrogate and rho<1, all three dynamic solvers converge to the same FFT-verified equilibrium; iteration cost rises sharply near rho=1. At rho=1 uniqueness is not certified; at rho>1 the selected SPD/contraction assumptions fail. This is not a test of a trained LTC, DEQ, or MON network.
- **E15 — Exhaustive large-coordinate stress: PASS**. The chosen affine charts round-trip exactly over the entire 2^30 admitted finite domain in this implementation. This is a finite implementation stress result, not a proof about arbitrary carrier systems.
- **E16 — Hierarchical coordinate compression: PASS**. Exact compact local coordinates are possible when the omitted high-order field context is carried by the surrounding chart; local compactness is contextual, not global identity magic.

## What is established in this run

Within the explicitly admitted finite domains and implementations:

1. Exact carrier coordinates can change while canonical identity is preserved.
2. Chosen invertible chart transforms compose without identity loss.
3. Data preservation alone does not preserve an obligation when the governing rule is removed.
4. An unchanged carrier can cease to answer the current obligation when applicability changes.
5. Lossy projection can preserve a present task while destroying future identity/reconstruction capacity.
6. Multiple routes are useful but are not independent redundancy when they share a hidden dependency.
7. Transform order can be consequential.
8. A route failure can be detected, retained, rerouted, and recovered without identity or selected-obligation error in the bounded full-wave run.
9. A moving/equilibrating topology can be analyzed separately from fixed identity.
10. Near an equilibrium stability boundary, compute cost can rise dramatically even while memory/state representation remains compact.

## What is NOT established

- No universal theorem about arbitrary carriers or all knowledge.
- No physical-wave or physical-field claim.
- No claim that a graph fully models human Knowledge Decay.
- No claim that the liquid relaxation surrogate is a Liquid Time-Constant neural network.
- No claim that Picard or CG results reproduce trained DEQ/MON model behavior.
- No proof that 30 bits, 64 bits, 128 bits, or any fixed width is universally sufficient for identity.
- No proof that today's protected obligation set contains all future human questions.
- No justification for silently discarding richer historical records.

## Current research decision

The surviving core is narrower and stronger:

**Anchor identity. Transform coordinates. Carry explicit obligations. Preserve lineage. Treat lossy compression as task-relative. Reroute around witnessed failures. Let the Common Point move without rewriting what came before.**

The next frontier is no longer “does the bounded mechanism work?” It does in these tests. The frontier is **adversarial generalization**: heterogeneous/noninvertible carriers, concurrent conflicting transforms, distributed partial knowledge, and admission of relations whose truth cannot be decided by a simple exact resolver.

## Independent cross-checks

After the primary run, Wolfram independently reproduced the load-bearing arithmetic used in the interpretation:

- `EulerPhi[2^20] = 524288` and `EulerPhi[2^30] = 536870912`.
- `gcd(40503,2^16)=1`, while the deliberate even counterexample has `gcd(40502,2^16)=2`.
- `40503^-1 mod 2^16 = 30599`.
- For the 4,096-site periodic equilibrium operator, the independently computed condition numbers are `1.5, 9, 39, 199, 1999` for `rho = 0.2, 0.8, 0.95, 0.99, 0.999`.
- At `rho=1`, the minimum eigenvalue is exactly `0`; at `rho=1.01` it is `-0.01`.

SciSpace literature calibration was used only to keep model families distinct. The literature supports treating Liquid Time-Constant dynamics, closed-form continuous-time networks, ordinary DEQ fixed points, and monotone-operator equilibrium models as related but non-identical mechanisms with different guarantees and costs. None is imported as proof of the Cross Carrier Field model.

## E17 — Full 32-bit regime boundary

The final scale push enumerated **all 4,294,967,296 possible 32-bit canonical coordinates** through one affine chart and its exact modular inverse.

- Multiplier: `2654435761` (odd; gcd with 2^32 = 1)
- Offset: `19088743`
- Modular inverse multiplier: `244002641`
- Exact round-trip checks: **4,294,967,296**
- Errors: **0**
- Runtime: **42.68 seconds**

This is a stronger implementation result than a random or sampled stress test because every 32-bit coordinate was exercised. It still says nothing by itself about 64-bit domains, arbitrary transforms, heterogeneous distributed carriers, or semantic faithfulness beyond the declared identity invariant.
