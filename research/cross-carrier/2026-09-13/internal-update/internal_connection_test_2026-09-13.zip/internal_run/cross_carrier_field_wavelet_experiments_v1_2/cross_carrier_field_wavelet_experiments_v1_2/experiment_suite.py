from __future__ import annotations
import csv
import io
import json
import math
import os
import platform
import sys
import time
from collections import deque
from dataclasses import dataclass
from pathlib import Path

import numpy as np

SEED = 20260910
rng = np.random.default_rng(SEED)

def result(exp_id, name, manipulation, observations, verdict, claim_ceiling, kind="BOUNDED_COMPUTATION"):
    return {
        "id": exp_id,
        "name": name,
        "kind": kind,
        "manipulation": manipulation,
        "observations": observations,
        "verdict": verdict,
        "claim_ceiling": claim_ceiling,
    }

def winner(records, rule):
    A, B = records
    if rule == "score_then_cost":
        ka = (A["score"], -A["cost"])
        kb = (B["score"], -B["cost"])
        return A["id"] if ka > kb else B["id"] if kb > ka else "TIE"
    if rule == "cost_then_score":
        ka = (-A["cost"], A["score"])
        kb = (-B["cost"], B["score"])
        return A["id"] if ka > kb else B["id"] if kb > ka else "TIE"
    raise ValueError(rule)

def experiment_e0():
    records = [{"id":"A","score":9,"cost":4},{"id":"B","score":8,"cost":2}]
    source_rule = "score_then_cost"
    source = {"records":records,"rule":source_rule}
    source_out = winner(records, source_rule)

    # JSON -> CSV carrier that explicitly carries the rule.
    buf = io.StringIO()
    w = csv.DictWriter(buf, fieldnames=["id","score","cost"])
    w.writeheader(); w.writerows(records)
    csv_text = f"# rule={source_rule}\n" + buf.getvalue()
    lines = csv_text.splitlines()
    carried_rule = lines[0].split("=",1)[1]
    parsed = list(csv.DictReader(io.StringIO("\n".join(lines[1:]))))
    parsed = [{"id":r["id"],"score":int(r["score"]),"cost":int(r["cost"])} for r in parsed]
    carried_out = winner(parsed, carried_rule)

    # Countercontrol: preserve records, omit the rule.
    counter_data_preserved = parsed == records
    counter_obligation_carried = False  # no declared comparison rule exists in the carrier

    ok = source_out == "A" and carried_out == source_out and counter_data_preserved and not counter_obligation_carried
    return result(
        "E0", "Single-boundary faithful carriage",
        "JSON-like record+rule -> CSV-like carrier; countercontrol removes only the comparison rule.",
        {
            "source_winner": source_out,
            "carried_winner": carried_out,
            "countercontrol_data_preserved": counter_data_preserved,
            "countercontrol_obligation_carried": counter_obligation_carried,
        },
        "PASS" if ok else "FAIL",
        "Within this fixed two-record/rule carrier, explicit rule carriage is required to reproduce the declared obligation; data retention alone is insufficient."
    )

def affine_params(bits):
    m = 1 << bits
    raw = [
        (0x09E3779B1, 0x12345),
        (0x085EBCA77, 0x23456),
        (0x0C2B2AE3D, 0x34567),
        (0x027D4EB2F, 0x45678),
    ]
    out = []
    for a,b in raw:
        a = (a & (m-1)) | 1
        b = b & (m-1)
        out.append((a,b,pow(a,-1,m)))
    return out

def coord(q, p, mask):
    a,b,_ = p
    return (q * np.uint64(a) + np.uint64(b)) & np.uint64(mask)

def invcoord(x, p, mask):
    _,b,ainv = p
    return ((x - np.uint64(b)) * np.uint64(ainv)) & np.uint64(mask)

def experiment_e1(bits=20):
    n = 1 << bits
    mask = n-1
    pA,pB,pC,_ = affine_params(bits)
    q = np.arange(n, dtype=np.uint64)
    xA = coord(q,pA,mask)
    # A -> B via canonical identity recovery, then B -> C.
    qAB = invcoord(xA,pA,mask)
    xB = coord(qAB,pB,mask)
    qBC = invcoord(xB,pB,mask)
    xC = coord(qBC,pC,mask)
    directC = coord(q,pC,mask)
    errors = int(np.count_nonzero(xC != directC))
    identity_errors = int(np.count_nonzero(qBC != q))
    return result(
        "E1", "Transform composition",
        f"Exhaustive A->B->C composition over 2^{bits} canonical identities.",
        {"objects":n,"end_to_end_coordinate_errors":errors,"identity_errors":identity_errors},
        "PASS" if errors == 0 and identity_errors == 0 else "FAIL",
        f"Chosen affine chart transforms compose faithfully over the complete admitted 2^{bits} object domain."
    )

def experiment_e2():
    retained = {"a":40503,"b":7919,"inverse":30599}
    runtime = {"resolver_enabled":False}
    execution_available = runtime["resolver_enabled"]
    ok = bool(retained) and not execution_available
    return result(
        "E2", "Retained mapping versus executable capability",
        "Disable the resolver while retaining the exact mapping parameters.",
        {"mapping_parameters_retained":True,"resolver_execution_available":execution_available},
        "PASS" if ok else "FAIL",
        "A retained transform description and an executable resolving capability are distinct states."
    )

def bfs(graph, start, goal, disabled=frozenset()):
    q = deque([(start,[start])]); seen={start}
    while q:
        node,path=q.popleft()
        if node==goal: return path
        for nxt in graph.get(node,()):
            edge=(node,nxt)
            if edge in disabled or (nxt,node) in disabled: continue
            if nxt not in seen:
                seen.add(nxt); q.append((nxt,path+[nxt]))
    return None

def experiment_e3():
    graph={"A":["B","C"],"B":["A","D"],"C":["A","D"],"D":["B","C"]}
    priority=[("A","B","D"),("A","C","D")]
    dead={("B","D")}
    auto = None
    for p in priority:
        edges=list(zip(p,p[1:]))
        if all(e not in dead and (e[1],e[0]) not in dead for e in edges):
            auto=p; break
    stale_priority_only = priority[0]
    manual = bfs(graph,"A","D",dead)
    ok = tuple(manual)==("A","C","D") and auto==("A","C","D") and stale_priority_only != auto
    return result(
        "E3", "Routing-priority failure and fallback",
        "Invalidate the formerly preferred B->D edge while leaving the A->C->D route intact.",
        {"stale_preferred_route":stale_priority_only,"fallback_route":auto,"manual_reachable_route":manual},
        "PASS" if ok else "FAIL",
        "A stale route preference can fail while an alternate verified route remains reachable."
    )

def experiment_e4():
    records=[{"id":"A","score":9,"cost":4},{"id":"B","score":8,"cost":2}]
    old=winner(records,"score_then_cost")
    new=winner(records,"cost_then_score")
    return result(
        "E4", "Applicability shift",
        "Keep the records unchanged; change the governing obligation from score-first to cost-first.",
        {"old_rule_winner":old,"new_rule_winner":new,"records_changed":False},
        "PASS" if old=="A" and new=="B" else "FAIL",
        "An unchanged carrier can remain internally valid while no longer answering the current obligation."
    )

def experiment_e5():
    training_cases=[
        ([{"id":"A","score":9,"cost":9},{"id":"B","score":8,"cost":1}],"A"),
        ([{"id":"A","score":2,"cost":9},{"id":"B","score":7,"cost":8}],"B"),
    ]
    score_only_pass=all(max(rs,key=lambda r:r["score"])["id"]==expected for rs,expected in training_cases)
    counter=[{"id":"A","score":8,"cost":4},{"id":"B","score":8,"cost":2}]
    full=winner(counter,"score_then_cost")
    score_only="UNRESOLVED" if counter[0]["score"]==counter[1]["score"] else max(counter,key=lambda r:r["score"])["id"]
    ok=score_only_pass and full=="B" and score_only=="UNRESOLVED"
    return result(
        "E5", "Claim-scope contraction by counterexample",
        "Candidate rule 'score alone always determines the winner' passes no-tie fixtures; add one tie case.",
        {"old_fixtures_pass":score_only_pass,"counterexample_score_only":score_only,"full_rule_result":full},
        "COUNTEREXAMPLE_FOUND" if ok else "FAIL",
        "The score-only claim is refuted for the admitted rule domain; it may be retained only on the no-tie subdomain."
    )

def experiment_e6():
    obj={"id":123456,"score":9,"cost":4}
    verbose=json.dumps(obj,sort_keys=True,separators=(",",":")).encode()
    # Packed: id uint32, score uint16, cost uint16
    packed=(obj["id"].to_bytes(4,"little")+obj["score"].to_bytes(2,"little")+obj["cost"].to_bytes(2,"little"))
    unpacked={
        "id":int.from_bytes(packed[0:4],"little"),
        "score":int.from_bytes(packed[4:6],"little"),
        "cost":int.from_bytes(packed[6:8],"little"),
    }
    ok=unpacked==obj and len(packed)<len(verbose)
    return result(
        "E6", "Valid but nonpreferred carrier",
        "Compare exact verbose JSON bytes with an exact fixed-width packed carrier.",
        {"json_bytes":len(verbose),"packed_bytes":len(packed),"roundtrip_equal":unpacked==obj},
        "PASS" if ok else "FAIL",
        "For this fixed schema, both carriers are valid; the packed carrier is smaller and can be preferred under a byte-cost criterion without invalidating the older carrier."
    )

def experiment_e7():
    nodes={"Source","Build","Config","Dependency","Executable"}
    edges={("Source","Build"),("Build","Config"),("Config","Dependency"),("Dependency","Executable")}
    def reachable(edgeset):
        g={n:[] for n in nodes}
        for a,b in edgeset:g[a].append(b)
        q=deque(["Source"]); seen={"Source"}
        while q:
            x=q.popleft()
            for y in g[x]:
                if y not in seen:seen.add(y);q.append(y)
        return "Executable" in seen
    before=reachable(edges)
    broken=edges-{("Config","Dependency")}
    after=reachable(broken)
    ok=before and not after and "Source" in nodes
    return result(
        "E7", "Reconstruction-path loss",
        "Remove exactly the Config->Dependency edge from an otherwise retained reconstruction chain.",
        {"source_still_exists":True,"executable_reachable_before":before,"executable_reachable_after":after},
        "PASS" if ok else "FAIL",
        "Stored source persistence does not imply reconstructible executable capability."
    )

def experiment_e8(bits=20, local_bits=16):
    n=1<<bits
    q=np.arange(n,dtype=np.uint32)
    low=q & ((1<<local_bits)-1)
    current_obligation=((q & 0xFF) < 128)
    current_from_low=((low & 0xFF) < 128)
    current_errors=int(np.count_nonzero(current_obligation!=current_from_low))
    buckets=np.bincount(low,minlength=1<<local_bits)
    max_bucket=int(buckets.max())
    unique_local=int(np.count_nonzero(buckets))
    high=(q>>local_bits)
    # future obligation: exact canonical identity/high field must be distinguishable
    future_distinguishable = max_bucket == 1
    return result(
        "E8", "Future-capability loss under lossy projection",
        f"Project 2^{bits} canonical identities to {local_bits} local bits; current obligation depends only on low 8 bits.",
        {
            "objects":n,
            "current_obligation_errors":current_errors,
            "unique_local_coordinates":unique_local,
            "objects_per_local_coordinate_max":max_bucket,
            "future_exact_identity_distinguishable":future_distinguishable,
            "high_context_values":int(high.max()+1),
        },
        "EXPECTED_BOUNDARY_FOUND" if current_errors==0 and max_bucket==(1<<(bits-local_bits)) and not future_distinguishable else "FAIL",
        "The projection is sufficient for the declared current low-bit obligation but destroys exact future identity unless omitted field context is carried separately."
    )

def experiment_e9():
    graph={"A":["B","C"],"B":["A","D"],"C":["A","D"],"D":["B","C"]}
    p0=bfs(graph,"A","D")
    p1=bfs(graph,"A","D",{("B","D")})
    # Hidden shared dependency is the source chart resolver A itself.
    source_resolver_alive=False
    reachable_with_two_paths_but_no_source = p1 is not None and source_resolver_alive
    ok=p0 is not None and p1==["A","C","D"] and not reachable_with_two_paths_but_no_source
    return result(
        "E9", "Redundancy and hidden shared dependency",
        "Break one diamond edge, then separately remove the common source resolver.",
        {"route_before":p0,"route_after_one_edge_loss":p1,"survives_shared_source_loss":reachable_with_two_paths_but_no_source},
        "PASS" if ok else "FAIL",
        "Multiple topological paths provide edge redundancy but are not independent when they share a required source dependency."
    )

def experiment_e10(bits=20):
    n=1<<bits; mask=n-1
    q=np.arange(n,dtype=np.uint32)
    # R = rotate-right by 4 over the full 20-bit word.
    R=((q>>4)|((q & 0xF)<<(bits-4))) & mask
    P_after_R=R & 0xFFFF
    # Project to 16 bits first, then rotate-right by 4 in the 16-bit space.
    p=q & 0xFFFF
    R16=((p>>4)|((p & 0xF)<<12)) & 0xFFFF
    mismatches=int(np.count_nonzero(P_after_R != R16))
    return result(
        "E10", "Transform order / noncommutativity",
        "Compare Project16∘Rotate20 with Rotate16∘Project16 over all 2^20 inputs.",
        {"objects":n,"order_mismatches":mismatches,"mismatch_fraction":mismatches/n},
        "EXPECTED_BOUNDARY_FOUND" if mismatches>0 else "FAIL",
        "Projection and a high/low-bit mixing transform do not commute on this complete finite domain; path order is consequential."
    )

def apply_chart_path(q, charts, path, mask):
    # Start from canonical q only for experiment construction; each hop resolves then re-encodes.
    x=coord(q,charts[path[0]],mask)
    for a,b in zip(path,path[1:]):
        q2=invcoord(x,charts[a],mask)
        x=coord(q2,charts[b],mask)
    return x

def experiment_e11(bits=20):
    n=1<<bits; mask=n-1
    ps=affine_params(bits)
    charts={k:p for k,p in zip(["A","B","C","D"],ps)}
    q=np.arange(n,dtype=np.uint64)
    graph={"A":["B","C"],"B":["A","D"],"C":["A","D"],"D":["B","C"]}
    failed={("B","D")}
    route=bfs(graph,"A","D",failed)
    xD=apply_chart_path(q,charts,route,mask)
    qD=invcoord(xD,charts["D"],mask)
    identity_errors=int(np.count_nonzero(qD!=q))
    return result(
        "E11", "Recovery by rerouting",
        "Destroy B->D, recompute A->D reachability, then execute the alternate A->C->D path over all identities.",
        {"objects":n,"recovery_route":route,"identity_errors_after_recovery":identity_errors},
        "PASS" if route==["A","C","D"] and identity_errors==0 else "FAIL",
        f"Within the admitted 2^{bits} affine-chart field, the alternate route fully restores exact identity carriage after the selected edge loss."
    )

def experiment_e12(bits=20, chunk_bits=16):
    n=1<<bits; mask=n-1; chunk=1<<chunk_bits
    ps=affine_params(bits)
    charts={k:p for k,p in zip(["A","B","C","D"],ps)}
    graph={"A":["B","C"],"B":["A","D"],"C":["A","D"],"D":["B","C"]}
    failure_chunk=5
    identity_errors=0; obligation_errors=0; rerouted_chunks=0; failure_records=[]
    for idx,start in enumerate(range(0,n,chunk)):
        q=np.arange(start,min(start+chunk,n),dtype=np.uint64)
        disabled=set()
        if idx>=failure_chunk:
            disabled.add(("B","D"))
        preferred=["A","B","D"]
        if disabled:
            route=bfs(graph,"A","D",disabled); rerouted_chunks += 1
            if idx==failure_chunk:
                failure_records.append({"edge":"B->D","chunk":idx,"status":"FAILED_ROUTE_RETAINED"})
        else:
            route=preferred
        xD=apply_chart_path(q,charts,route,mask)
        q2=invcoord(xD,charts["D"],mask)
        identity_errors += int(np.count_nonzero(q2!=q))
        # Obligation surrogate: a stable deterministic classification of canonical identity.
        omega=((q*1103515245 + 12345) & 0x3FF) < 512
        omega2=((q2*1103515245 + 12345) & 0x3FF) < 512
        obligation_errors += int(np.count_nonzero(omega!=omega2))
    total_chunks=math.ceil(n/chunk)
    ok=identity_errors==0 and obligation_errors==0 and rerouted_chunks==total_chunks-failure_chunk and len(failure_records)==1
    return result(
        "E12", "Full cross-carrier wave with injected route failure",
        f"Process 2^{bits} identities in chunks; inject B->D failure at chunk {failure_chunk}; retain failure and reroute subsequent wavelets through C.",
        {
            "objects":n,"chunks":total_chunks,"failure_chunk":failure_chunk,
            "rerouted_chunks":rerouted_chunks,"identity_errors":identity_errors,
            "obligation_errors":obligation_errors,"failure_records":failure_records
        },
        "PASS" if ok else "FAIL",
        "The bounded wave detects the injected route failure, retains it, reroutes, and preserves the selected identity and obligation across the full finite run."
    )

def experiment_e13():
    # Synthetic human-history reconnection integration test: all fragments survive, only a relation is lost.
    nodes={"Method","Reason","Result","Failure","LaterWork","CP"}
    edges={
        ("Method","Reason"),("Reason","Result"),("Result","LaterWork"),
        ("Failure","Result"),("LaterWork","CP")
    }
    def conn(es,start):
        g={n:[] for n in nodes}
        for a,b in es:
            g[a].append(b);g[b].append(a)
        q=deque([start]);seen={start}
        while q:
            x=q.popleft()
            if x=="CP":return True
            for y in g[x]:
                if y not in seen:seen.add(y);q.append(y)
        return False
    before={n:conn(edges,n) for n in nodes if n!="CP"}
    broken=edges-{("Reason","Result")}
    after={n:conn(broken,n) for n in nodes if n!="CP"}
    recovered=broken|{("Reason","Result")}
    final={n:conn(recovered,n) for n in nodes if n!="CP"}
    lost=[n for n,v in after.items() if not v]
    ok=all(before.values()) and len(lost)>0 and all(final.values())
    return result(
        "E13", "Knowledge-decay reconnection integration",
        "Synthetic history: keep every fragment, remove one relation, measure disconnection from CP, then restore the verified relation.",
        {"all_fragments_retained":True,"connected_before":before,"disconnected_after_relation_loss":lost,"connected_after_recovery":final},
        "PASS" if ok else "FAIL",
        "This tests the reconstruction machinery for relational loss; it does not claim that a synthetic graph models the full human phenomenon of Knowledge Decay."
    )

def neighbor(z):
    # symmetric periodic nearest-neighbor average
    return 0.5*(np.roll(z,1)+np.roll(z,-1))

def rel_residual(z,u,rho):
    b=(1-rho)*u
    r=z-rho*neighbor(z)-b
    denom=max(np.linalg.norm(b),1e-300)
    return float(np.linalg.norm(r)/denom)

def exact_equilibrium(u,rho):
    n=len(u)
    k=np.arange(n)
    lam=np.cos(2*np.pi*k/n)  # eigenvalues of symmetric neighbor-average operator
    uh=np.fft.fft(u)
    zh=(1-rho)*uh/(1-rho*lam)
    return np.fft.ifft(zh).real

def solve_picard(u,rho,tol=1e-9,maxit=100000):
    z=np.zeros_like(u); b=(1-rho)*u
    for i in range(1,maxit+1):
        z=rho*neighbor(z)+b
        if i % 2 == 0 or i < 10:
            rr=rel_residual(z,u,rho)
            if rr<tol:return z,i,rr
    return z,maxit,rel_residual(z,u,rho)

def solve_liquid(u,rho,dt=0.9,tol=1e-9,maxit=100000):
    # First-order continuous relaxation surrogate discretized by explicit Euler:
    # dz/dt = b - A z, A = I-rho*S.
    z=np.zeros_like(u); b=(1-rho)*u
    for i in range(1,maxit+1):
        Az=z-rho*neighbor(z)
        z=z+dt*(b-Az)
        if i % 2 == 0 or i < 10:
            rr=rel_residual(z,u,rho)
            if rr<tol:return z,i,rr
    return z,maxit,rel_residual(z,u,rho)

def solve_cg(u,rho,tol=1e-9,maxit=100000):
    # Same equilibrium A z=b, using SPD conjugate gradient for 0<=rho<1.
    b=(1-rho)*u
    z=np.zeros_like(u)
    r=b.copy()
    p=r.copy()
    rs=float(np.dot(r,r))
    bnorm=float(np.linalg.norm(b))
    if bnorm==0:return z,0,0.0
    for i in range(1,maxit+1):
        Ap=p-rho*neighbor(p)
        denom=float(np.dot(p,Ap))
        if denom<=0:
            return z,i,float("inf")
        alpha=rs/denom
        z=z+alpha*p
        r=r-alpha*Ap
        rr=float(np.dot(r,r))
        rel=math.sqrt(rr)/bnorm
        if rel<tol:return z,i,rel
        p=r+(rr/rs)*p
        rs=rr
    return z,maxit,rel

def experiment_e14(n=4096):
    # Localized zero-mean Haar-like wavelet disturbance.
    u=np.zeros(n,dtype=np.float64)
    start=311; width=64
    u[start:start+width//2]=1.0
    u[start+width//2:start+width]=-1.0
    rhos=[0.2,0.8,0.95,0.99,0.999]
    rows=[]
    all_ok=True
    for rho in rhos:
        ref=exact_equilibrium(u,rho)
        refnorm=max(np.linalg.norm(ref),1e-300)
        cond=(1+rho)/(1-rho)
        for name,solver in [
            ("DEQ_PICARD",solve_picard),
            ("LIQUID_RELAXATION_SURROGATE",solve_liquid),
            ("MONOTONE_CG_SURROGATE",solve_cg),
        ]:
            t=time.perf_counter()
            z,it,res=solver(u,rho)
            elapsed=time.perf_counter()-t
            err=float(np.linalg.norm(z-ref)/refnorm)
            passrow=(res<1.1e-9 and err<5e-8)
            all_ok &= passrow
            rows.append({
                "rho":rho,"condition_number_exact":cond,"solver":name,
                "iterations":it,"relative_residual":res,"relative_error_vs_fft":err,
                "seconds":elapsed,"pass":passrow
            })
    # Boundary attacks.
    rho1=1.0
    # Eigenvalues A=I-rho*S are 1-rho*cos(2pi k/n). At rho=1, k=0 eigenvalue is exactly 0.
    min_eig_rho1=0.0
    rho_bad=1.01
    min_eig_bad=1-rho_bad  # k=0
    boundary_ok=(min_eig_rho1==0.0 and min_eig_bad<0)
    all_ok &= boundary_ok
    return result(
        "E14", "Localized equilibrium-wavelet controller stress",
        "Drive a 4096-site periodic field with a localized Haar-like disturbance. Solve the same linear equilibrium with Picard, first-order liquid relaxation, and SPD conjugate gradient while rho approaches the contraction boundary.",
        {
            "sites":n,"wavelet_support":width,"rows":rows,
            "rho_1_min_eigenvalue":min_eig_rho1,
            "rho_1_unique_equilibrium_certificate":False,
            "rho_1_01_min_eigenvalue":min_eig_bad,
            "rho_1_01_spd":False
        },
        "PASS_WITH_BOUNDARY" if all_ok else "FAIL",
        "For this linear surrogate and rho<1, all three dynamic solvers converge to the same FFT-verified equilibrium; iteration cost rises sharply near rho=1. At rho=1 uniqueness is not certified; at rho>1 the selected SPD/contraction assumptions fail. This is not a test of a trained LTC, DEQ, or MON network."
    )

def experiment_e15(bits=30, chunk_bits=20):
    n=1<<bits; mask=n-1; chunk=1<<chunk_bits
    charts=affine_params(bits)[:3]
    start_t=time.perf_counter()
    errors=0
    checks=0
    for start in range(0,n,chunk):
        q=np.arange(start,min(start+chunk,n),dtype=np.uint64)
        for p in charts:
            x=coord(q,p,mask)
            q2=invcoord(x,p,mask)
            errors += int(np.count_nonzero(q2!=q))
            checks += len(q)
    elapsed=time.perf_counter()-start_t

    # Orthogonal exhaustive uniqueness check at 20 bits, where materializing all coordinates is cheap.
    sbits=20; sn=1<<sbits; smask=sn-1
    sq=np.arange(sn,dtype=np.uint64)
    unique_counts=[]
    for p in affine_params(sbits)[:3]:
        unique_counts.append(int(np.unique(coord(sq,p,smask)).size))
    # Deliberate bad map: even multiplier 2 mod 2^20.
    bad=(2,7,None)
    badx=(sq*np.uint64(2)+np.uint64(7)) & np.uint64(smask)
    bad_unique=int(np.unique(badx).size)
    expected_bad=sn//math.gcd(2,sn)

    ok=errors==0 and all(x==sn for x in unique_counts) and bad_unique==expected_bad
    return result(
        "E15", "Exhaustive large-coordinate stress",
        f"Stream every canonical identity in a 2^{bits} field through three independent odd-multiplier affine charts and exact inverses; independently materialize 2^20 uniqueness and an even-multiplier collision countercontrol.",
        {
            "canonical_objects":n,
            "charts":3,
            "roundtrip_checks":checks,
            "roundtrip_errors":errors,
            "seconds":elapsed,
            "small_exhaustive_domain":sn,
            "good_chart_unique_counts":unique_counts,
            "bad_even_multiplier_unique_count":bad_unique,
            "bad_even_multiplier_expected_unique_count":expected_bad,
            "bad_collision_fraction":1-bad_unique/sn,
        },
        "PASS" if ok else "FAIL",
        f"The chosen affine charts round-trip exactly over the entire 2^{bits} admitted finite domain in this implementation. This is a finite implementation stress result, not a proof about arbitrary carrier systems."
    )

def experiment_e16(bits=20, local_bits=16):
    # Exact hierarchical packing: 4-bit field + 16-bit local coordinate.
    n=1<<bits
    q=np.arange(n,dtype=np.uint32)
    field=(q>>local_bits).astype(np.uint8)
    local=(q & ((1<<local_bits)-1)).astype(np.uint16)
    restored=(field.astype(np.uint32)<<local_bits)|local.astype(np.uint32)
    errors=int(np.count_nonzero(restored!=q))
    theoretical_bits=bits
    practical_bytes_individual=3  # 20 bits needs 3 whole bytes if not bit-packed across entries
    local_only_bytes=2
    fields=1<<(bits-local_bits)
    return result(
        "E16", "Hierarchical coordinate compression",
        f"Split a {bits}-bit canonical coordinate into {bits-local_bits}-bit field context plus {local_bits}-bit local coordinate.",
        {
            "objects":n,"fields":fields,"local_space":1<<local_bits,
            "reconstruction_errors":errors,
            "theoretical_bits_per_individual_reference":theoretical_bits,
            "practical_bytes_if_individually_byte_packed":practical_bytes_individual,
            "local_bytes_when_field_context_is_shared":local_only_bytes
        },
        "PASS" if errors==0 else "FAIL",
        "Exact compact local coordinates are possible when the omitted high-order field context is carried by the surrounding chart; local compactness is contextual, not global identity magic."
    )

def run_all():
    funcs=[
        experiment_e0, experiment_e1, experiment_e2, experiment_e3,
        experiment_e4, experiment_e5, experiment_e6, experiment_e7,
        experiment_e8, experiment_e9, experiment_e10, experiment_e11,
        experiment_e12, experiment_e13, experiment_e14, experiment_e15,
        experiment_e16
    ]
    started=time.time()
    results=[]
    for f in funcs:
        t=time.perf_counter()
        r=f()
        r["runtime_seconds"]=time.perf_counter()-t
        results.append(r)
        print(f"{r['id']}: {r['verdict']} — {r['name']} ({r['runtime_seconds']:.3f}s)", flush=True)
    return {
        "suite":"Cross Carrier Field Wavelet Experiments v1",
        "seed":SEED,
        "started_unix":started,
        "environment":{
            "python":sys.version,
            "numpy":np.__version__,
            "platform":platform.platform(),
        },
        "results":results,
        "suite_runtime_seconds":time.time()-started,
    }

if __name__=="__main__":
    out=run_all()
    p=Path(__file__).with_name("results.json")
    p.write_text(json.dumps(out,indent=2),encoding="utf-8")
    print(f"WROTE {p}")
