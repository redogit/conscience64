# Cross Carrier Field Wavelet Experiments v1

Run:

```bash
python experiment_suite.py
```

Outputs:

- `results.json` — full machine-readable observations.
- `summary.json` — one row per experiment.
- `REPORT.md` — interpreted bounded research report.
- `computation_manifest.json` — provenance, bounds, environment, hashes, and claim ceiling.

The run is deterministic except for runtime measurements. It uses no external network calls.

The term **wavelet** here means a localized finite disturbance / transformation unit inside the Cross Carrier Field experiment. It is not a claim that this is a classical wavelet transform or a physical wave.
