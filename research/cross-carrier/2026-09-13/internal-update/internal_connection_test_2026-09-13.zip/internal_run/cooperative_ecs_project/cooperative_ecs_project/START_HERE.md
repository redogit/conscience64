# Cooperative ECS Project — Start Here

This is a new project seeded from **Data-Driven ECS World v0.5.0** without rewriting that predecessor's lineage.

## Purpose

Use a data-driven Entity Component System to coordinate bounded agents, tools, humans, evidence, and reusable research capabilities against real problems while preserving project boundaries, provenance, uncertainty, costs, ethics, accessibility, privacy, and unresolved remainder.

## Working rule

A path being known or available does **not** make it active. A cross-project relation may inform, pressure, test, locate, or supply a reusable method; it does not automatically transfer evidence, authority, identity, or applicability.

## Begin a problem

1. Put the real request in `project/inbox/` or use the framework intake contract.
2. State at minimum: **Subject, Motivator, Request, Obligation**.
3. Let intake derive bounded criteria, evidence requirements, dependencies, carrier needs, and claim ceilings.
4. Execute only criteria that are ready and whose required evidence can actually be obtained.
5. Preserve observations, failures, evidence, and unresolved remainder in project history.

## Structure

- `framework/` — frozen imported v0.5.0 framework and its tests.
- `project/inbox/` — new problem inputs.
- `project/evidence/` — project-specific evidence and provenance records.
- `project/outputs/` — usable project outputs.
- `project/history/` — append-only project continuation records.
- `PROJECT_STATE.json` — current project-level state.
- `SOURCE_LINEAGE.json` — source/provenance boundary.

The imported framework remains independently recoverable. New project work should be written outside `framework/` unless an explicit framework change is being tested.
