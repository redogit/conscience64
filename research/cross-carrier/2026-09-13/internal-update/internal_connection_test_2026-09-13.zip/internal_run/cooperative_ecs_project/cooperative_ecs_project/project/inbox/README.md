# Inbox

Add one problem per JSON or Markdown file.

Minimum fields:
- Subject
- Motivator
- Request
- Obligation

Useful optional fields:
- Boundary
- Known inputs
- Desired output
- Acceptance criteria
- Costs / limits
- Evidence requirements
- Human or external dependencies
- Privacy exclusions
