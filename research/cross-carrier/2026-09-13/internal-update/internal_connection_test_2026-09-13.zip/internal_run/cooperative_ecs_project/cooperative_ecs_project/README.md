# Cooperative ECS Project

A clean project shell containing the complete Data-Driven ECS World v0.5.0 as an imported framework dependency.

The project carries the current 39-path portfolio, 20-agent capability pool, criterion-driven scheduler, dynamic intake, host/carrier boundary, evidence gates, human/physical stop conditions, restart support, and cross-project authority separation.

See `START_HERE.md` first. The imported implementation lives under `framework/` and keeps its own README, tests, world data, evidence-frontier documents, and checksum manifest.

## Project boundary

This project may use prior skills, research, code, methods, and evidence as inputs. It does not retroactively alter their original status. New claims require evidence appropriate to the new problem and declared acceptance criterion.
