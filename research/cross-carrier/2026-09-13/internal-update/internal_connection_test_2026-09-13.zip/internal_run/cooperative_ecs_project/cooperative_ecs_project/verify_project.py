from pathlib import Path
import os, subprocess, sys, hashlib
ROOT = Path(__file__).resolve().parent
FW = ROOT / 'framework'
env = os.environ.copy()
env['PYTHONPATH'] = str(FW / 'src') + (os.pathsep + env['PYTHONPATH'] if env.get('PYTHONPATH') else '')
print('Verifying imported framework tests...')
subprocess.run([sys.executable, '-m', 'pytest', '-q'], cwd=FW, env=env, check=True)
manifest = ROOT / 'PROJECT_MANIFEST.sha256'
if manifest.exists():
    bad=[]
    for line in manifest.read_text(encoding='utf-8').splitlines():
        if not line.strip():
            continue
        expected, rel = line.split('  ',1)
        p=ROOT/rel
        actual=hashlib.sha256(p.read_bytes()).hexdigest() if p.exists() else None
        if actual != expected:
            bad.append(rel)
    if bad:
        raise SystemExit(f'Manifest mismatch: {bad}')
print('Project verification PASS')
