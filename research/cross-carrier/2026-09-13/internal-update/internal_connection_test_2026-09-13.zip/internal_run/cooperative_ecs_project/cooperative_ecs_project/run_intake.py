from pathlib import Path
import os, subprocess, sys
ROOT=Path(__file__).resolve().parent
FW=ROOT/'framework'
env=os.environ.copy()
env['PYTHONPATH']=str(FW/'src') + (os.pathsep + env['PYTHONPATH'] if env.get('PYTHONPATH') else '')
raise SystemExit(subprocess.call([sys.executable, str(FW/'intake_cli.py'), *sys.argv[1:]], cwd=FW, env=env))
