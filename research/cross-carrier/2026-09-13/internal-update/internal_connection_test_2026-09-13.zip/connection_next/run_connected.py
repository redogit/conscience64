"""Execute existing TBCL, C++ RRI, Orbit and ECS interfaces on bounded packets."""
from pathlib import Path
import base64, copy, hashlib, importlib.util, json, subprocess, sys, tempfile

ROOT=Path(__file__).resolve().parent
ORBIT=ROOT/'extracted/orbit_lab_reflow_1_0/engine'
# Use the last verified ECS baseline. Strict corroboration patch stays separate.
FW=ROOT.parent/'connection_test/repaired_framework'
sys.path[:0]=[str(ORBIT),str(FW/'src')]
from orbit_lab import OrbitLab
from connections import ConnectionMap
from checks.tbcl_active_carrier_probe import run as compact_probe, corpus, compile_carrier, evaluate_compact
from ecs_world.bridge import JsonlHostBridgeAdapter, append_host_response
from ecs_world.intake import load_branch_catalog, decompose_request

def load_module(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    mod=importlib.util.module_from_spec(spec);sys.modules[name]=mod;spec.loader.exec_module(mod)
    return mod

def main():
    tbcl=load_module('recovered_tbcl',ROOT/'sources/tbcl.py')
    out=ROOT/'outputs';out.mkdir(exist_ok=True)
    build=subprocess.run(['c++','-std=c++23','-O2','-Wall','-Wextra',str(ROOT/'index_bridge.cpp'),'-o',str(out/'index_bridge')],capture_output=True,text=True)
    (out/'build.log').write_text(build.stdout+build.stderr)
    build.check_returncode()
    domains=load_branch_catalog(FW/'world')
    rows=[]
    with tempfile.TemporaryDirectory() as td:
        td=Path(td);db=td/'orbit.db';lab=OrbitLab(db)
        for branch in domains:
            request={'subject':'Internal wave connection','motivator':'Preserve the receiving task across carriers',
                'request':'Carry the bounded packet and report any lost distinctions',
                'obligation':'Preserve source, boundary, authorship, chronology and unresolved remainder',
                'branch':branch}
            packet={'intake':decompose_request(request,domains),
                'surface':{'user':'Please continue','assistant':'Bounded integration implementation', 'roles_distinct':True},
                'context':{'branch':branch,'source_revision':'recovered-snapshot','knowledge_decay':'active dependency'},
                'chronology':['user-request','assistant-implementation','executed-observation'],
                'obligation':request['obligation'],'unresolved':['Full project runtime coverage is not established'],
                'payload':'café | Ελληνικά | 日本語 | العربية | 🌊 | e\u0301',
                'authority_transfer':False}
            raw=tbcl.canon(packet);digest=hashlib.sha256(raw).hexdigest()
            artifact=tbcl.Artifact('packet.json',digest,len(raw),raw)
            records=[('meta',{'origin':'internal connection fixture','scope':'software only'}),
                ('subject',{'id':packet['intake']['key']}),('obligation',{'text':request['obligation']}),
                ('execution',{'status':'carrier-test','not_domain_execution':True})]
            program=tbcl.Program(records,'','','',[artifact]);encoded=tbcl.render(program)
            decoded=tbcl.parse_bytes(encoded)
            assert decoded.artifacts[0].payload==raw
            assert tbcl.render(decoded)==encoded
            # Change bytes without recomputing declared roots/checksum.
            tampered=encoded.replace(b'Please continue',b'Please contInue',1)
            try:tbcl.parse_bytes(tampered);tamper_rejected=False
            except ValueError:tamper_rejected=True
            assert tamper_rejected
            routes=subprocess.check_output([str(out/'index_bridge'),'surface','interaction',digest],text=True).splitlines()
            assert routes[0].split('\t')[0]=='interaction' and len(routes)==2
            record={'packet_base64':base64.b64encode(decoded.artifacts[0].payload).decode(),
                    'sha256':digest,'candidate_routes':routes,'authority_transfer':False}
            oid=lab.add('Artifact','Internal packet '+branch,data=record,
                provenance_class='CURRENT_CONVERSATION',provenance='run_connected.py',
                identity_key='internal-wave:'+branch,lifecycle='QUARANTINED')
            # Real close/reopen exercises the existing SQLite boundary.
            lab.close();lab=OrbitLab(db);stored=lab.get(oid).data
            assert stored==record
            assert base64.b64decode(stored['packet_base64'])==raw
            assert lab.admission_status(oid)['status']=='QUARANTINED'
            bridge=JsonlHostBridgeAdapter('internal-orbit',td/'out.jsonl',td/'in.jsonl')
            req={'problem_key':packet['intake']['key'],'action':{'method':'internal-packet-transfer'},
                 'boundary':packet['intake']['boundary'],'sources':['sha256:'+digest],
                 'target_output':'Exact packet reconstruction','acceptance':[]}
            pending=bridge.execute(req)
            # This response is derived from the just-read Orbit object, not a mock service result.
            append_host_response(td/'in.jsonl',{'request_id':pending['request_id'],'ok':True,
                'result':'Recovered internal Orbit packet','artifact':stored,
                'evidence':['sha256:'+digest],'evidence_kind':'internal-test',
                'scope_kind':'internal','substantive':False,'satisfies':[]})
            received=JsonlHostBridgeAdapter('internal-orbit',td/'out.jsonl',td/'in.jsonl').execute(req)
            reconstructed=json.loads(base64.b64decode(received['artifact']['packet_base64']))
            assert reconstructed==packet
            assert received['scope_kind']=='internal' and not received['substantive']
            rows.append({'branch':branch,'sha256':digest,'bytes':len(raw),'roundtrip':True,
                'tamper_rejected':tamper_rejected,'scope_candidates_retained':len(routes),
                'orbit_quarantined':True,'roles_preserved':True,'unresolved_preserved':True})
        audit=lab.alpha_audit();lab.close()
    connection_check=ConnectionMap().check()
    compact=compact_probe()
    # The recovered probe's A6 only checked valid pointer ranges. Actually remove
    # the provenance table here and observe failed reconstruction, then recover.
    original_compact=compile_carrier(corpus())
    broken_compact=copy.deepcopy(original_compact)
    broken_compact['provenance_table']=[]
    try:
        evaluate_compact(broken_compact)
        relation_loss_detected=False
    except IndexError:
        relation_loss_detected=True
    broken_compact['provenance_table']=original_compact['provenance_table']
    relation_restored=evaluate_compact(broken_compact)==evaluate_compact(original_compact)
    assert relation_loss_detected and relation_restored
    sources=[ROOT/'sources/tbcl.py',ROOT/'index_bridge.cpp',
       ROOT/'extracted/runtime_relation_index_non_corrupting_v1/relation_index_runtime_non_corrupting_v1.cpp',
       ORBIT/'orbit_lab.py',FW/'src/ecs_world/bridge.py']
    report={'scope':'39 synthetic domain-labelled packets through four actual local runtimes; not 39 domain implementations',
      'passed':all(x['roundtrip'] and x['tamper_rejected'] for x in rows) and audit['passed'] and connection_check['passed'] and compact['passed'] and relation_loss_detected and relation_restored,
      'packets':rows,'orbit_audit':audit,'orbit_connection_check':connection_check,'compact_carrier_probe':compact,
      'actual_provenance_table_ablation':{'loss_detected':relation_loss_detected,'recovery_exact':relation_restored},
      'source_hashes':{str(p.relative_to(ROOT.parent)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources},
      'limitations':['C++ index normalization is ASCII-oriented; only ASCII lookup keys exercised',
        'Unicode payloads were carried exactly, not semantically translated',
        'TBCL compile_program was not invoked; serialization only',
        'Strict corroboration candidate has legacy regression failures and is not used for this chain',
        'Carrier roots verify supplied bytes, not authorship authenticity or domain truth']}
    (out/'connected_results.json').write_text(json.dumps(report,indent=2))
    print(json.dumps({'passed':report['passed'],'packets':len(rows),'orbit_connections':connection_check,'compact_cases':compact['cases']},indent=2))

if __name__=='__main__':main()
