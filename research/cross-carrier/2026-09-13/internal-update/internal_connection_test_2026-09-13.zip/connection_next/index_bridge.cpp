// Thin task adapter over the recovered, unmodified C++ relation index.
#define main recovered_demo_main
#include "extracted/runtime_relation_index_non_corrupting_v1/relation_index_runtime_non_corrupting_v1.cpp"
#undef main

int main(int argc, char** argv) {
    using namespace relation_index;
    if (argc != 4) return 2;
    RelationIndexBuilder builder;
    for (auto scope : {"interaction", "geometry"}) {
        auto added = builder.add({
            .surface="surface", .target=argv[3],
            .kind=RelationKind::RecoveryReference, .scope=scope,
            .provenance="internal-connection-fixture", .confidence=1.0, .utility=1.0});
        if (!added) return 3;
    }
    auto index=std::move(builder).build();
    for (const auto& c : lookup(index, argv[1], argv[2])) {
        std::cout << c.entry->scope << '\t' << kind_name(c.entry->kind)
                  << '\t' << c.entry->target << '\t' << c.entry->provenance << '\n';
    }
}
