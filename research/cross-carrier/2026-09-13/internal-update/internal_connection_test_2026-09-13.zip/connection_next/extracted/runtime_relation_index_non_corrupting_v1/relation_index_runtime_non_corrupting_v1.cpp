// relation_index_runtime_non_corrupting_v1.cpp
// Build: c++ -std=c++23 -O2 -Wall -Wextra -pedantic relation_index_runtime_non_corrupting_v1.cpp -o relation_index

#include <algorithm>
#include <cctype>
#include <expected>
#include <iostream>
#include <span>
#include <string>
#include <string_view>
#include <unordered_map>
#include <vector>

namespace relation_index {

enum class RelationKind {
    Alias,
    Vernacular,
    Jargon,
    TaskLocalDefinition,
    ProjectReference,
    RecoveryReference,
    EvidenceReference,
    ClaimBoundary,
    BridgeCandidate,
    Warning,
    FailureMode,
    Obsolete
};

struct RelationEntry {
    std::string key;
    std::string surface;
    std::string target;
    RelationKind kind{};
    std::string scope;
    std::string provenance;
    double confidence{};
    double utility{};
};

struct BuildError {
    std::string message;
};

struct Candidate {
    const RelationEntry* entry{};
    double score{};
};

static char lower_ascii(char c) noexcept {
    return static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
}

static bool is_word_char(char c) noexcept {
    unsigned char uc = static_cast<unsigned char>(c);
    return std::isalnum(uc) || c == '\'' || c == '-';
}

static std::string normalize(std::string_view input) {
    std::string out;
    out.reserve(input.size());
    bool pending_space = false;

    for (char c : input) {
        if (is_word_char(c)) {
            if (pending_space && !out.empty()) out.push_back(' ');
            out.push_back(lower_ascii(c));
            pending_space = false;
        } else {
            pending_space = true;
        }
    }

    return out;
}

static std::string_view kind_name(RelationKind kind) noexcept {
    switch (kind) {
        case RelationKind::Alias: return "Alias";
        case RelationKind::Vernacular: return "Vernacular";
        case RelationKind::Jargon: return "Jargon";
        case RelationKind::TaskLocalDefinition: return "TaskLocalDefinition";
        case RelationKind::ProjectReference: return "ProjectReference";
        case RelationKind::RecoveryReference: return "RecoveryReference";
        case RelationKind::EvidenceReference: return "EvidenceReference";
        case RelationKind::ClaimBoundary: return "ClaimBoundary";
        case RelationKind::BridgeCandidate: return "BridgeCandidate";
        case RelationKind::Warning: return "Warning";
        case RelationKind::FailureMode: return "FailureMode";
        case RelationKind::Obsolete: return "Obsolete";
    }
    return "Unknown";
}

class RelationIndex {
public:
    std::span<const RelationEntry> entries() const noexcept {
        return entries_;
    }

    std::span<const std::size_t> find_ids(std::string_view normalized_key) const noexcept {
        auto it = key_to_entries_.find(std::string(normalized_key));
        if (it == key_to_entries_.end()) return {};
        return std::span<const std::size_t>{it->second.data(), it->second.size()};
    }

private:
    friend class RelationIndexBuilder;
    std::vector<RelationEntry> entries_;
    std::unordered_map<std::string, std::vector<std::size_t>> key_to_entries_;
};

class RelationIndexBuilder {
public:
    std::expected<void, BuildError> add(RelationEntry entry) {
        entry.key = normalize(entry.key.empty() ? entry.surface : entry.key);

        if (entry.key.empty()) {
            return std::unexpected(BuildError{"relation key normalizes to empty"});
        }
        if (entry.surface.empty()) {
            return std::unexpected(BuildError{"surface is required"});
        }
        if (entry.target.empty()) {
            return std::unexpected(BuildError{"target is required"});
        }
        if (entry.scope.empty()) {
            return std::unexpected(BuildError{"scope is required"});
        }
        if (entry.provenance.empty()) {
            return std::unexpected(BuildError{"provenance is required"});
        }
        if (entry.confidence < 0.0 || entry.confidence > 1.0) {
            return std::unexpected(BuildError{"confidence must be in [0, 1]"});
        }
        if (entry.utility < 0.0 || entry.utility > 1.0) {
            return std::unexpected(BuildError{"utility must be in [0, 1]"});
        }

        const std::size_t id = index_.entries_.size();
        index_.entries_.push_back(std::move(entry));
        index_.key_to_entries_[index_.entries_.back().key].push_back(id);
        return {};
    }

    RelationIndex build() && {
        return std::move(index_);
    }

private:
    RelationIndex index_;
};

static double score_candidate(const RelationEntry& entry, std::string_view wanted_scope) noexcept {
    const double lexical_match = 1.0;
    const double scope_match = wanted_scope.empty() || entry.scope == wanted_scope ? 1.0 : 0.35;
    double score = 0.40 * lexical_match + 0.25 * scope_match + 0.20 * entry.confidence + 0.15 * entry.utility;

    if (entry.kind == RelationKind::Obsolete) score -= 0.40;
    if (entry.kind == RelationKind::BridgeCandidate) score -= 0.10;

    return score;
}

static std::vector<Candidate> lookup(
    const RelationIndex& index,
    std::string_view surface,
    std::string_view wanted_scope = {},
    std::size_t limit = 8
) {
    std::vector<Candidate> out;
    const std::string key = normalize(surface);
    if (key.empty()) return out;

    for (std::size_t id : index.find_ids(key)) {
        const RelationEntry& entry = index.entries()[id];
        out.push_back(Candidate{&entry, score_candidate(entry, wanted_scope)});
    }

    std::ranges::sort(out, [](const Candidate& a, const Candidate& b) {
        if (a.score != b.score) return a.score > b.score;
        return a.entry->scope < b.entry->scope;
    });

    if (out.size() > limit) out.resize(limit);
    return out;
}

} // namespace relation_index

int main() {
    using namespace relation_index;

    RelationIndexBuilder builder;

    auto add_or_die = [&](RelationEntry e) {
        auto ok = builder.add(std::move(e));
        if (!ok) {
            std::cerr << "build error: " << ok.error().message << '\n';
            std::exit(1);
        }
    };

    add_or_die({
        .surface = "hot fix",
        .target = "urgent patch / emergency fix; vernacular expansion only, not semantic proof",
        .kind = RelationKind::Jargon,
        .scope = "vernacular",
        .provenance = "runtime relation index non-corrupting v1",
        .confidence = 0.90,
        .utility = 0.80
    });

    add_or_die({
        .surface = "surface",
        .target = "observed expression or interaction surface within the current task boundary",
        .kind = RelationKind::TaskLocalDefinition,
        .scope = "TBCL/CSOL",
        .provenance = "runtime relation index non-corrupting v1",
        .confidence = 0.85,
        .utility = 0.95
    });

    add_or_die({
        .surface = "surface",
        .target = "geometric surface; separate from interaction-surface usage unless explicitly bridged",
        .kind = RelationKind::Warning,
        .scope = "geometry",
        .provenance = "runtime relation index non-corrupting v1",
        .confidence = 0.70,
        .utility = 0.75
    });

    add_or_die({
        .surface = "cubic fourfold",
        .target = "Hodge calibration family; ordinary cubic fourfold H^4 is not an open Hodge-conjecture instance",
        .kind = RelationKind::Warning,
        .scope = "Hodge",
        .provenance = "runtime relation index non-corrupting v1",
        .confidence = 0.95,
        .utility = 0.95
    });

    add_or_die({
        .surface = "bridge",
        .target = "candidate mapping requiring source, target, proposed map, test or obstruction, status, and provenance",
        .kind = RelationKind::BridgeCandidate,
        .scope = "Moonshot",
        .provenance = "runtime relation index non-corrupting v1",
        .confidence = 0.60,
        .utility = 0.90
    });

    RelationIndex index = std::move(builder).build();

    for (std::string_view q : {"surface", "cubic fourfold", "hot fix", "bridge"}) {
        std::cout << "query: " << q << '\n';
        for (const Candidate& c : lookup(index, q)) {
            const RelationEntry& e = *c.entry;
            std::cout << "  score=" << c.score
                      << " kind=" << kind_name(e.kind)
                      << " scope=" << e.scope
                      << " target=" << e.target
                      << " provenance=" << e.provenance
                      << '\n';
        }
        std::cout << '\n';
    }
}
