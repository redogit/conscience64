# TBCL — Context Language Lab

**Independent project boundary:** `project:tbcl`

## Subject

Portable context semantics and bounded native execution.

## Current I / R / P / O

### I — Input

TBCL native core, context records, quote/if/begin/define/lambda/let forms, primitives, active/preserved distinctions, and provenance-aware recovery.

### R — Relation / Scratch

Context and executable semantics must be explicit enough to transport without assuming that syntax alone carries meaning.

### P — Plan

```json
{
  "next": "Continue the smallest bounded evaluator/generator experiments and test whether new vocabulary can be formed from existing context while preserving exact provenance and unknowns.",
  "gate": "Promotion requires explicit user/project admission; context compression must remain reconstructible."
}
```

### O — Output Definition

A compact context-language laboratory with bounded semantics and portable execution, not a universal language theory.

## Boundary

This project owns its own claims, experiments, failures, artifacts, and unresolved remainder. Other projects may be referenced through typed cross-project links, but their state is **not imported as authority** and changes here do not silently update them.

## Immediate rule

Continue forward by appending evidence-qualified work. Preserve failed branches and historical states. Do not overwrite the project history to make a later result look inevitable.
