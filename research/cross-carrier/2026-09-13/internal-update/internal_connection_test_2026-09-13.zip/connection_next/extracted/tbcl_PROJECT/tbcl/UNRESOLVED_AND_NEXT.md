# Unresolved / Next

**Next bounded action:** Continue the smallest bounded evaluator/generator experiments and test whether new vocabulary can be formed from existing context while preserving exact provenance and unknowns.

**Promotion gate:** Promotion requires explicit user/project admission; context compression must remain reconstructible.

## Cross-project caution

External links are not completion evidence. If a dependency becomes necessary, import only the minimum verified carrier with provenance and an explicit admission decision.
