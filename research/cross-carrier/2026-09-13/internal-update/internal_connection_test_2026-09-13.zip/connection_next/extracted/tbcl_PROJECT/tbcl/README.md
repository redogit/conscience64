# TBCL — Context Language Lab

Standalone, repo-ready research project.

Start with [`START_HERE.md`](START_HERE.md).

Files:
- `START_HERE.md` — human-readable current state
- `IRPO.json` — current I/R/P/O
- `PROJECT_BOUNDARY.json` — independence and claim rules
- `SOURCE_AND_ARTIFACT_MAP.json` — direct recovered carriers and shared operations
- `CROSS_PROJECT_REFERENCES.json` — references to other independent projects
- `PROJECT_GRAPH.json` — bounded graph excerpt
- `UNRESOLVED_AND_NEXT.md` — next action and promotion gate
- `MANIFEST.sha256` — file integrity

This project does not inherit truth from another project merely because a relation exists.
