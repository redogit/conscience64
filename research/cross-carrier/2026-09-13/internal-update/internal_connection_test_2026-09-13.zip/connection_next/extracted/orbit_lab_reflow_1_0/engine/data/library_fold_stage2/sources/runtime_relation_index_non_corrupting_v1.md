# Runtime Relation Index — Non-Corrupting Version v1

## Purpose

This export preserves only the non-corrupting abstraction derived from the vernacular-expansion discussion:

> A runtime-built, scoped, provenance-bearing relation index.

It is not a rainbow table. It is not an evidence engine. It is not a theory validator. It is a compact helper layer for retrieving bounded candidate relations while preserving ambiguity, scope, provenance, and claim boundaries.

## Core Rule

A retrieved relation is a candidate relation, not a fact, proof, accepted theory, or executable substitute.

The index may help search, expand, route, classify, and recover prior terms. It must not silently upgrade resemblance, aliasing, phrase similarity, or project-local usage into evidence.

## Canonical Shape

```text
surface phrase / query span
    -> normalize
    -> lookup scoped candidate relation(s)
    -> rank using scope, confidence, utility, and provenance
    -> return bounded candidates with kind/status
```

## Minimal Data Model

```cpp
enum class RelationKind {
    Alias,
    Vernacular,
    Jargon,
    TaskLocalDefinition,
    ProjectReference,
    RecoveryReference,
    EvidenceReference,
    ClaimBoundary,
    BridgeCandidate,
    Warning,
    FailureMode,
    Obsolete
};

struct RelationEntry {
    std::string key;          // normalized lookup form
    std::string surface;      // original readable surface
    std::string target;       // expansion, canonical term, reference, warning, etc.
    RelationKind kind;        // relation class
    std::string scope;        // project/domain boundary
    std::string provenance;   // where this relation came from
    double confidence;        // retrieval confidence, not truth
    double utility;           // usefulness for routing/recovery/expansion
};
```

## Required Index Shape

Use one key to many entries:

```cpp
std::unordered_map<std::string, std::vector<std::size_t>> key_to_entries_;
```

Do not use one key to one entry as the general form, because ambiguity is meaningful.

Example:

```text
"surface"
    -> geometry surface
    -> interaction surface
    -> observed expression surface
    -> file/library surface
```

The index must preserve those distinctions instead of overwriting them.

## Builder Responsibilities

The runtime builder must:

1. Normalize phrases consistently.
2. Reject empty normalized keys.
3. Reject malformed weights.
4. Preserve scope and provenance.
5. Allow multiple scoped relations per key.
6. Mark conflicts as unresolved rather than merging them into one claim.
7. Keep bridge candidates separate from evidence references.
8. Keep obsolete records retrievable only when requested or historically relevant.

## Lookup Responsibilities

The lookup layer must:

1. Tokenize input into spans.
2. Normalize spans using the same function used during build.
3. Search spans up to `max_phrase_tokens`.
4. Return bounded candidates.
5. Rank candidates without erasing ambiguity.
6. Include kind, scope, provenance, confidence, and utility in results.

## Ranking Rule

A compact scoring model may be:

```text
score =
    0.40 * lexical_match
  + 0.25 * scope_match
  + 0.20 * confidence
  + 0.15 * utility
```

Then apply hard constraints:

```text
- Do not use obsolete entries unless requested or historically relevant.
- Do not treat bridge candidates as evidence.
- Do not merge subject-local terms into global ontology.
- Do not replace current constraints with older exports.
- Do not treat lexical reconstruction as executable behavioral proof.
```

## Project Applications

### Vernacular Tool

Stores slang, jargon, colloquial expansions, and phrase alternatives.

Must not claim semantic equivalence.

### TBCL / CSOL

Stores subject-local terms, task-local definitions, active distinctions, reconstruction-cost refinements, and interface principles.

Must not silently grow ontology.

### OLU / Airlock

Stores checkpoints, origin records, chronology, integrity notes, provenance boundaries, and ingress/egress constraints.

Must not merge legacy material into current work without provenance.

### Moonshot / Hodge

Stores bridge candidates, warnings, calibration targets, obstructions, and applicability records.

Must not treat resemblance as evidence.

Important Hodge guardrail:

```text
Smooth cubic fourfolds are useful calibration objects for codimension-2 / period / Hodge-locus work, but ordinary cubic fourfold H^4 should not be treated as an open Hodge-conjecture instance.
```

### SHADOW

Stores branch names, lexical basins, test panels, recovery terms, and preservation constraints.

Must not substitute index reconstruction for executable behavioral preservation.

### Recovery Library

Stores normalized names, declared references, association classes, file/conversation/library identifiers, and resolution status.

Must not infer missing links as facts.

## Relation Status Discipline

Recommended statuses:

```text
candidate
active
verified-reference
warning
obsolete
unresolved
blocked
```

Bridge candidates require:

```text
source idea
intended target
proposed mapping
test or obstruction
status
provenance
```

## Selected Architecture

```text
Normalizer
Tokenizer
RelationValidator
RelationIndexBuilder
RelationIndex
CandidateRetriever
Ranker
Expansion / Routing Consumer
```

## Non-Corruption Contract

This export is valid only under the following contract:

1. Lookup is not evidence.
2. Retrieval is not proof.
3. Resemblance is not applicability.
4. A bridge candidate is not a bridge result.
5. Project-local vocabulary is not global ontology.
6. Historical recovery is not current authority.
7. The index can preserve ambiguity but must not resolve it without evidence.
8. Every consequential relation must preserve scope and provenance.
9. Current project constraints override older unlabeled material.
10. Claims must be bounded by what was actually tested or sourced.

## Minimal C++23 Skeleton

```cpp
#include <algorithm>
#include <cctype>
#include <expected>
#include <optional>
#include <span>
#include <string>
#include <string_view>
#include <unordered_map>
#include <vector>

namespace relation_index {

enum class RelationKind {
    Alias,
    Vernacular,
    Jargon,
    TaskLocalDefinition,
    ProjectReference,
    RecoveryReference,
    EvidenceReference,
    ClaimBoundary,
    BridgeCandidate,
    Warning,
    FailureMode,
    Obsolete
};

struct RelationEntry {
    std::string key;
    std::string surface;
    std::string target;
    RelationKind kind{};
    std::string scope;
    std::string provenance;
    double confidence{};
    double utility{};
};

struct BuildError {
    std::string message;
};

static char lower_ascii(char c) noexcept {
    return static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
}

static bool is_word_char(char c) noexcept {
    unsigned char uc = static_cast<unsigned char>(c);
    return std::isalnum(uc) || c == '\'' || c == '-';
}

static std::string normalize(std::string_view input) {
    std::string out;
    out.reserve(input.size());
    bool pending_space = false;

    for (char c : input) {
        if (is_word_char(c)) {
            if (pending_space && !out.empty()) out.push_back(' ');
            out.push_back(lower_ascii(c));
            pending_space = false;
        } else {
            pending_space = true;
        }
    }
    return out;
}

class RelationIndex {
public:
    std::span<const RelationEntry> entries() const noexcept { return entries_; }

    std::span<const std::size_t> find_ids(std::string_view key) const noexcept {
        auto it = key_to_entries_.find(std::string(key));
        if (it == key_to_entries_.end()) return {};
        return it->second;
    }

private:
    friend class RelationIndexBuilder;
    std::vector<RelationEntry> entries_;
    std::unordered_map<std::string, std::vector<std::size_t>> key_to_entries_;
};

class RelationIndexBuilder {
public:
    std::expected<void, BuildError> add(RelationEntry entry) {
        entry.key = normalize(entry.key.empty() ? entry.surface : entry.key);
        if (entry.key.empty()) {
            return std::unexpected(BuildError{"relation key normalizes to empty"});
        }
        if (entry.confidence < 0.0 || entry.confidence > 1.0) {
            return std::unexpected(BuildError{"confidence must be in [0, 1]"});
        }
        if (entry.utility < 0.0 || entry.utility > 1.0) {
            return std::unexpected(BuildError{"utility must be in [0, 1]"});
        }
        if (entry.scope.empty()) {
            return std::unexpected(BuildError{"scope is required"});
        }
        if (entry.provenance.empty()) {
            return std::unexpected(BuildError{"provenance is required"});
        }

        const std::size_t id = index_.entries_.size();
        index_.entries_.push_back(std::move(entry));
        index_.key_to_entries_[index_.entries_.back().key].push_back(id);
        return {};
    }

    RelationIndex build() && { return std::move(index_); }

private:
    RelationIndex index_;
};

} // namespace relation_index
```

## Export Boundary

This file intentionally excludes:

- rainbow-table framing,
- cryptographic hash-chain language,
- claims that lookup is proof,
- claims that bridge candidates are evidence,
- claims that project-local terms are universal ontology,
- uncontrolled semantic expansion,
- unresolved relation merging.
