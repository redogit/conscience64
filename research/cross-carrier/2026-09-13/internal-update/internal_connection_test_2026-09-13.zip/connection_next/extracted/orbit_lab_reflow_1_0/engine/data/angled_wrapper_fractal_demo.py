import math
import matplotlib.pyplot as plt

def generate_paths(branches: int, max_depth: int):
    paths = [()]
    current = [()]
    for _ in range(max_depth):
        nxt = []
        for path in current:
            for i in range(branches):
                child = path + (i,)
                paths.append(child)
                nxt.append(child)
        current = nxt
    return paths

def path_to_u(path, branches):
    u = 0.0
    for j, c in enumerate(path, start=1):
        u += c / (branches ** j)
    return u

def path_to_angle(path, branches):
    return 2.0 * math.pi * path_to_u(path, branches)

def depth_to_radius(depth, max_depth, radius_scale=1.0):
    if max_depth == 0:
        return 0.0
    return radius_scale * depth / max_depth

def polar_to_xy(r, theta):
    return (r * math.cos(theta), r * math.sin(theta))

def beta_field(theta):
    sector1 = abs(((theta - math.radians(45) + math.pi) % (2 * math.pi)) - math.pi) < math.radians(25)
    sector2 = abs(((theta - math.radians(220) + math.pi) % (2 * math.pi)) - math.pi) < math.radians(20)
    if sector1:
        return math.radians(25) * math.sin(2 * theta)
    if sector2:
        return math.radians(-20) * math.cos(3 * theta)
    return 0.0

def reflect_direction(vx, vy, normal_angle):
    nx = math.cos(normal_angle)
    ny = math.sin(normal_angle)
    dot = vx * nx + vy * ny
    rx = vx - 2.0 * dot * nx
    ry = vy - 2.0 * dot * ny
    return rx, ry

def boundary_hit_time_circle(x0, y0, vx, vy, R):
    b = x0 * vx + y0 * vy
    c = x0 * x0 + y0 * y0 - R * R
    disc = b * b - c
    if disc < 0:
        return None
    t1 = -b - math.sqrt(disc)
    t2 = -b + math.sqrt(disc)
    candidates = [t for t in (t1, t2) if t >= -1e-12]
    if not candidates:
        return None
    return min(candidates)

def wrap_step(x0, y0, vx, vy, step_len, R, beta_threshold):
    xt = x0 + step_len * vx
    yt = y0 + step_len * vy
    if xt * xt + yt * yt <= R * R:
        return xt, yt, False, 0.0, 0.0

    t_hit = boundary_hit_time_circle(x0, y0, vx, vy, R)
    if t_hit is None or t_hit > step_len:
        return xt, yt, False, 0.0, 0.0

    xb = x0 + t_hit * vx
    yb = y0 + t_hit * vy
    theta_b = math.atan2(yb, xb) % (2.0 * math.pi)
    beta = beta_field(theta_b)
    active = abs(beta) >= beta_threshold

    remaining = step_len - t_hit
    if active:
        normal_angle = theta_b + beta
        vrx, vry = reflect_direction(vx, vy, normal_angle)
        x1 = xb + remaining * vrx
        y1 = yb + remaining * vry
        return x1, y1, True, theta_b, beta
    else:
        return xb, yb, False, theta_b, beta

def build_and_plot(branches=3, max_depth=6, outer_radius=1.0, overshoot_step=0.18, beta_threshold_deg=10):
    beta_threshold = math.radians(beta_threshold_deg)
    paths = generate_paths(branches, max_depth)
    coords = {}

    for p in paths:
        r = depth_to_radius(len(p), max_depth, outer_radius)
        theta = path_to_angle(p, branches)
        coords[p] = polar_to_xy(r, theta)

    edges = []
    gated_points = []

    for p in paths:
        if len(p) > 0:
            parent = p[:-1]
            edges.append((coords[parent], coords[p]))

    leaves = [p for p in paths if len(p) == max_depth]
    for p in leaves:
        x0, y0 = coords[p]
        theta = path_to_angle(p, branches)
        vx = math.cos(theta)
        vy = math.sin(theta)
        xw, yw, reflected, theta_b, beta = wrap_step(
            x0, y0, vx, vy, overshoot_step, outer_radius, beta_threshold
        )
        edges.append(((x0, y0), (xw, yw)))
        if reflected:
            gated_points.append((outer_radius * math.cos(theta_b), outer_radius * math.sin(theta_b), beta))

    fig, ax = plt.subplots(figsize=(8, 8))
    for (x1, y1), (x2, y2) in edges:
        ax.plot([x1, x2], [y1, y2], linewidth=0.8)

    circle = plt.Circle((0, 0), outer_radius, fill=False)
    ax.add_patch(circle)

    for xb, yb, beta in gated_points[:60]:
        theta_b = math.atan2(yb, xb)
        normal_angle = theta_b + beta
        seg_len = 0.08
        x2 = xb + seg_len * math.cos(normal_angle)
        y2 = yb + seg_len * math.sin(normal_angle)
        ax.plot([xb, x2], [yb, y2], linewidth=1.0)

    ax.set_aspect("equal")
    ax.set_title("Unrolled fractal with angle-gated mirrored outer wrapper")
    ax.set_xlabel("x")
    ax.set_ylabel("y")
    ax.grid(True, alpha=0.3)
    plt.show()

if __name__ == "__main__":
    build_and_plot()
