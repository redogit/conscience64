import tempfile
from pathlib import Path
import unittest

from human_lab import HumanLab, dispatch


class HumanLabTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.h = HumanLab(Path(self.tmp.name) / "human.db")

    def tearDown(self):
        self.h.close()
        self.tmp.cleanup()

    def test_research_card_maps_human_terms_to_kernel_types(self):
        dispatch(self.h,["start","Can this be simple?"])
        dispatch(self.h,["need","Preserve evidence."])
        dispatch(self.h,["limit","One factor at a time."])
        dispatch(self.h,["try","Run one probe."])
        dispatch(self.h,["saw","Probe completed."])
        dispatch(self.h,["left","Benefit to people is untested."])
        scan=self.h.lab.scan()
        self.assertEqual(scan["subject"][0]["type"],"Subject")
        self.assertEqual(scan["observation"][0]["epistemic"],"OBSERVED")
        self.assertEqual(scan["remainder"][0]["epistemic"],"UNEXPLAINED")
        self.assertIn("Question",self.h.card())
        self.assertNotIn(scan["subject"][0]["id"],self.h.card())

    def test_start_returns_previous_current_instead_of_erasing_history(self):
        first=self.h.start("First question")
        self.h.add("need","First need")
        self.h.start("Second question")
        self.assertEqual(self.h.lab.get(first).lifecycle,"RETURNED")
        self.assertEqual(self.h.lab.scan()["subject"][0]["title"],"Second question")
        self.assertGreater(len(self.h.lab.trail(limit=50)),0)

    def test_thought_is_separate_from_observation(self):
        self.h.start("Question")
        self.h.add("saw","Observed A")
        thought=self.h.think("A may imply B")
        self.assertEqual(self.h.lab.get(thought).type,"Inference")
        self.assertEqual(self.h.lab.scan()["observation"][0]["type"],"Observation")
        self.assertIn("Thought",self.h.recent_thoughts())

    def test_comparison_is_separate_from_observation_and_thought(self):
        self.h.start("Q")
        self.h.add("saw","Y0 = 1")
        self.h.add("saw","Y1 = 2")
        cid=self.h.compare("D = +1")
        tid=self.h.think("Maybe treatment helped")
        self.assertEqual(self.h.lab.get(cid).data["human_surface"],"Comparison")
        self.assertEqual(self.h.lab.get(tid).data["human_surface"],"Thought")
        self.assertEqual(len([r for r in self.h.lab.graph(cid)["outgoing"] if r["kind"]=="DERIVED_FROM"]),2)
        text=self.h.recent_thoughts()
        self.assertIn("Comparison:",text)
        self.assertIn("Thought:",text)

    def test_support_route_is_humanized_and_exact(self):
        text=self.h.support("language")
        self.assertIn("Smallest current helper set",text)
        self.assertIn("not independent replication",text)

    def test_connected_research_view_is_human_readable_and_quarantined(self):
        text=self.h.incoming()
        self.assertIn("quarantined review input",text)
        self.assertIn("CSOL",text)
        self.assertNotIn("file_",text)
        why=self.h.why_connected("human-interface")
        self.assertIn("CSOL",why)
        self.assertIn("separate provenance",why)

    def test_next_hint_progresses(self):
        self.assertIn("Question",self.h.next_hint())
        self.h.start("Q")
        self.assertIn("Need",self.h.next_hint())
        self.h.add("need","N")
        self.assertIn("Limit",self.h.next_hint())

if __name__ == "__main__":
    unittest.main()
