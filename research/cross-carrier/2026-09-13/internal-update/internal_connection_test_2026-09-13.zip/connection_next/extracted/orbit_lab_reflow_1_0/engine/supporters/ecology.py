
from __future__ import annotations
from dataclasses import dataclass, asdict
from pathlib import Path
import sys

# Support both `python -m supporters.ecology` and direct file execution.
if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from typing import Optional
import tempfile, json, itertools, sqlite3
from orbit_lab import OrbitLab

@dataclass
class Signal:
    supporter: str
    mode: str
    status: str   # PASS | FINDING | PRESSURE
    signature: str
    detail: str
    consequence: str
    source_case: str = ""

class SupporterEcology:
    """Diverse helpers around Orbit Lab.

    These helpers are intentionally not all adversaries and do not share one oracle:
    - bounded explorer: small exhaustive state spaces
    - replay custodian: export/restart equivalence
    - mutation sentinel: audit sensitivity
    - observer ensemble: representation/frame dependence
    - exposure custodian: truth-access temporal boundaries
    - resource accountant: Pareto / externalized-cost checks
    - wrapper decomposer: component success vs wrapper success
    - residual scout: preserves unexplained remainders
    """

    def __init__(self):
        self.signals: list[Signal] = []

    @staticmethod
    def add(lab, t, title, key, **kw):
        return lab.add(
            t, title,
            provenance_class=kw.pop("provenance_class", "TEST"),
            provenance=kw.pop("provenance", "supporter-ecology"),
            identity_key=key,
            **kw
        )

    def emit(self, **kwargs):
        s=Signal(**kwargs)
        self.signals.append(s)
        return s

    # ------------------------------------------------------------
    # 1. Exposure custodian: temporal truth-access semantics
    # ------------------------------------------------------------
    def exposure_cycle_supporter(self):
        with tempfile.TemporaryDirectory() as td:
            lab=OrbitLab(Path(td)/"t.db")
            try:
                c=self.add(lab,"Context","Evaluator context","c")
                actor=self.add(lab,"Actor","evaluator","actor")
                cycle1=self.add(lab,"Scope","cycle-1","cycle1")
                cycle2=self.add(lab,"Scope","cycle-2","cycle2")
                truth=self.add(lab,"Artifact","holdout truth","truth")
                model=self.add(lab,"Candidate","candidate model","model")
                basis=self.add(lab,"Evidence","protocol basis","basis",epistemic="OBSERVED")
                root1=lab.establish_authority_root(
                    context_id=c,scope_id=cycle1,operations=["INSPECT"],
                    holder_actor_id=actor,provenance_class="USER",provenance="supporter-user")
                root2=lab.establish_authority_root(
                    context_id=c,scope_id=cycle2,operations=["CLEAN_EVALUATE"],
                    holder_actor_id=actor,provenance_class="USER",provenance="supporter-user")
                lab.grant_authorization(
                    context_id=c,entity_id=truth,operation="INSPECT",scope_id=cycle1,
                    issuer_authority_id=root1,issuer_actor_id=actor,principal_id=actor,
                    basis_entity_ids=[basis],reason="cycle-1 checker access",
                    provenance_class="TEST",provenance="supporter")
                lab.grant_authorization(
                    context_id=c,entity_id=model,operation="CLEAN_EVALUATE",scope_id=cycle2,
                    issuer_authority_id=root2,issuer_actor_id=actor,principal_id=actor,
                    basis_entity_ids=[basis],reason="clean in a later cycle",
                    prerequisites={"forbid_exposure_tags":["CONFIRMATION_TRUTH"]},
                    provenance_class="TEST",provenance="supporter")
                lab.record_access(
                    context_id=c,actor_id=actor,entity_id=truth,operation="INSPECT",
                    scope_id=cycle1,exposure_tags=["CONFIRMATION_TRUTH"],
                    provenance_class="TEST",provenance="supporter")
                later=lab.check_authorized(
                    context_id=c,actor_id=actor,entity_id=model,
                    operation="CLEAN_EVALUATE",scope_id=cycle2)
                if not later["authorized"]:
                    return self.emit(
                        supporter="Exposure Custodian", mode="temporal boundary",
                        status="FINDING",
                        signature="EXPOSURE:CROSS_CYCLE_CONTAMINATION_NEVER_EXPIRES",
                        detail="Truth exposure in cycle-1 permanently blocks CLEAN_EVALUATE in disjoint cycle-2.",
                        consequence="History sensitivity is too coarse: same-cycle contamination became lifetime contamination.",
                        source_case="Society holdout rule: truth-exposed context is contaminated in the same cycle."
                    )
                return self.emit(
                    supporter="Exposure Custodian",mode="temporal boundary",status="PASS",
                    signature="EXPOSURE:CYCLE_SCOPED",detail="Exposure is bounded to relevant cycle.",
                    consequence="Clean later-cycle evaluation remains possible.")
            finally:
                lab.close()

    # ------------------------------------------------------------
    # 2. Mutation sentinel: can audit notice lost history?
    # ------------------------------------------------------------
    def history_mutation_supporter(self):
        with tempfile.TemporaryDirectory() as td:
            lab=OrbitLab(Path(td)/"t.db")
            try:
                x=self.add(lab,"Artifact","historical artifact","x")
                before=lab.conn.execute("SELECT COUNT(*) n FROM history").fetchone()["n"]
                delete_worked=False
                try:
                    lab.conn.execute("DELETE FROM history WHERE seq=(SELECT MIN(seq) FROM history)")
                    lab.conn.commit()
                    delete_worked=True
                except sqlite3.DatabaseError:
                    lab.conn.rollback()
                audit=lab.alpha_audit()
                after=lab.conn.execute("SELECT COUNT(*) n FROM history").fetchone()["n"]
                if delete_worked and after < before and audit["passed"]:
                    return self.emit(
                        supporter="Mutation Sentinel",mode="persistence mutation",status="FINDING",
                        signature="HISTORY:DELETE_NOT_PREVENTED_OR_AUDITED",
                        detail="A history event was deleted directly; alpha_audit still passed.",
                        consequence="Append-oriented history is not actually protected against deletion.",
                        source_case="Recovery/history discipline requires correction without rewriting what occurred."
                    )
                return self.emit(
                    supporter="Mutation Sentinel",mode="persistence mutation",status="PASS",
                    signature="HISTORY:DELETE_PROTECTED",detail="History deletion was blocked or detected.",
                    consequence="Historical lineage remains protected.")
            finally:
                lab.close()

    # ------------------------------------------------------------
    # 3. Observer ensemble: failures need their observation frame
    # ------------------------------------------------------------
    def failure_frame_supporter(self):
        with tempfile.TemporaryDirectory() as td:
            lab=OrbitLab(Path(td)/"t.db")
            try:
                subject=self.add(lab,"Probe","same probe","probe")
                location=self.add(lab,"Artifact","apparatus","apparatus")
                obs=self.add(lab,"Observation","threshold crossing","obs",epistemic="OBSERVED")
                frame_a=self.add(lab,"ObservationFrame","coarse frame","fa",data={
                    "observer":"event","apparatus":"A","accessible_variables":["x"],
                    "resolution":"1.0","intervention":"none","boundary":"B"})
                frame_b=self.add(lab,"ObservationFrame","fine frame","fb",data={
                    "observer":"event","apparatus":"A","accessible_variables":["x"],
                    "resolution":"0.01","intervention":"none","boundary":"B"})
                f=lab.record_failure(
                    subject_entity_id=subject,location_entity_id=location,
                    observation_id=obs,frame_id=frame_a,cause_status="UNKNOWN",
                    provenance_class="TEST",provenance="supporter")
                roles=set(x["role"] for x in lab.episode(f)["participants"])
                if "frame" not in roles:
                    return self.emit(
                        supporter="Observer Ensemble",mode="representation/frame diversity",status="FINDING",
                        signature="FAILURE:OBSERVATION_FRAME_NOT_BOUND",
                        detail="Failure records the Observation but has no role for the ObservationFrame that made it observable.",
                        consequence="Two measurements requiring different actions can serialize to the same failure structure.",
                        source_case="LG-002: bind failure/carrier claims to observer, apparatus, variables, resolution, intervention, boundary."
                    )
                return self.emit(
                    supporter="Observer Ensemble",mode="representation/frame diversity",status="PASS",
                    signature="FAILURE:FRAME_BOUND",detail="Failure carries an explicit observation frame.",
                    consequence="Observer dependence remains inspectable.")
            finally:
                lab.close()

    # ------------------------------------------------------------
    # 4. Replay custodian: randomized state survives export/import
    # ------------------------------------------------------------
    def replay_supporter(self):
        with tempfile.TemporaryDirectory() as td:
            td=Path(td)
            lab=OrbitLab(td/"a.db")
            try:
                c=self.add(lab,"Context","C","c")
                s=self.add(lab,"Scope","S","s")
                content=lab.register_content(
                    algorithm="sha256",digest="a1b2c3",
                    provenance_class="TEST",provenance="supporter")
                inst=lab.create_artifact_instance(
                    content_id=content,provenance_class="TEST",
                    provenance="supporter",identity_key="inst")
                occ=lab.record_instance_occurrence(
                    instance_id=inst,context_id=c,locator="/A/x",
                    mode="REGISTER",provenance_class="TEST",
                    provenance="supporter",identity_key="occ")
                out=lab.export_state(td/"state.json")
                d1=out["sha256"]
            finally:
                lab.close()

            restored=OrbitLab(td/"b.db")
            try:
                restored.import_state(td/"state.json")
                d2=restored.state_snapshot()["sha256"]
                audit=restored.alpha_audit()
                if d1==d2 and audit["passed"]:
                    return self.emit(
                        supporter="Replay Custodian",mode="differential replay",status="PASS",
                        signature="REPLAY:STATE_EQUIVALENT",detail="Export/import retained identical state digest and passed audit.",
                        consequence="Portable recovery preserves current modeled state.")
                return self.emit(
                    supporter="Replay Custodian",mode="differential replay",status="FINDING",
                    signature="REPLAY:STATE_DIVERGENCE",detail=f"before={d1} after={d2} audit={audit['passed']}",
                    consequence="Portable recovery changed the modeled state.")
            finally:
                restored.close()

    # ------------------------------------------------------------
    # 5. Bounded explorer: exhaustive small resource Pareto order
    # ------------------------------------------------------------
    @staticmethod
    def pareto_front(plans):
        front=[]
        for p in plans:
            dominated=False
            for q in plans:
                if p is q: continue
                # lower is better on every cost dimension
                dims=("physical","compute","latency","human")
                if all(q[k] <= p[k] for k in dims) and \
                   any(q[k] < p[k] for k in dims):
                    dominated=True; break
            if not dominated:
                front.append(p)
        return front

    def resource_supporter(self):
        # Inspired by the Musilanguage result: fewer physical channels can spend
        # computation / dynamic range / robustness instead.
        plans=[
            {"name":"two-channel","physical":2,"compute":1,"latency":1,"human":1},
            {"name":"one-channel-simple","physical":1,"compute":3,"latency":2,"human":1},
            {"name":"one-channel-tuned","physical":1,"compute":2,"latency":1,"human":2},
        ]
        front=self.pareto_front(plans)
        if len(front)>1:
            return self.emit(
                supporter="Resource Accountant",mode="Pareto accounting",status="PRESSURE",
                signature="RESOURCE:NO_UNIVERSAL_MINIMUM",
                detail="Multiple resource allocations remain Pareto-incomparable; a single scalar 'efficient' score would invent a preference.",
                consequence="Keep a Pareto set until an explicit minimality order or obligation prices the tradeoff.",
                source_case="Musilanguage microchecks found channel-count ↔ precision/noise ↔ decoder-computation tradeoffs."
            )
        return self.emit(
            supporter="Resource Accountant",mode="Pareto accounting",status="PASS",
            signature="RESOURCE:UNIQUE_DOMINANT_PLAN",detail="One plan dominates the tested alternatives.",
            consequence="A unique resource choice exists on the declared vector.")

    # ------------------------------------------------------------
    # 6. Wrapper decomposer: apparent final success can mask component failure
    # ------------------------------------------------------------
    def wrapper_supporter(self):
        # A tiny bounded abstraction of the recovered spaCy hybrid.
        learned_component=38/39
        wrapper_final=39/39
        deterministic_route_coverage=265/265
        if wrapper_final==1.0 and learned_component<1.0 and deterministic_route_coverage==1.0:
            return self.emit(
                supporter="Wrapper Decomposer",mode="component differential",status="PRESSURE",
                signature="PIPELINE:WRAPPER_SUCCESS_MASKS_COMPONENT_ERROR",
                detail="Final wrapper accuracy is perfect while the learned component is imperfect because a deterministic path covers the current task surface.",
                consequence="Never promote wrapper success into a claim about the learned component; preserve component-local outcomes.",
                source_case="Recovered AI-math/spaCy hybrid: 38/39 test classifier vs 39/39 hybrid exact answers."
            )
        return self.emit(
            supporter="Wrapper Decomposer",mode="component differential",status="PASS",
            signature="PIPELINE:COMPONENT_AND_WRAPPER_AGREE",detail="Component and wrapper outcomes agree.",
            consequence="No masking observed.")

    # ------------------------------------------------------------
    # 7. Residual scout: do not collapse unknown remainders
    # ------------------------------------------------------------
    def residual_supporter(self):
        with tempfile.TemporaryDirectory() as td:
            lab=OrbitLab(Path(td)/"t.db")
            try:
                try:
                    r=self.add(lab,"Remainder","unexpected persistence","r",
                        epistemic="UNEXPLAINED",data={"observation":"persists after expected removal"})
                except ValueError as e:
                    if "unknown epistemic status" in str(e):
                        return self.emit(
                            supporter="Residual Scout",mode="unknown preservation",status="FINDING",
                            signature="EPISTEMIC:UNEXPLAINED_NOT_REPRESENTABLE",
                            detail="The runtime epistemic vocabulary rejects UNEXPLAINED.",
                            consequence="Observed residuals are forced toward UNKNOWN/other statuses before explanation has earned a classification.",
                            source_case="Research discipline: residuals/anomalies begin UNEXPLAINED and are not automatically discovery/noise/importance.")
                    raise
                if lab.get(r).epistemic=="UNEXPLAINED":
                    return self.emit(
                        supporter="Residual Scout",mode="unknown preservation",status="PASS",
                        signature="RESIDUAL:UNEXPLAINED_PRESERVED",
                        detail="Unexpected remainder can stay UNEXPLAINED without forced cause or discovery status.",
                        consequence="Unknown-unknown attractors remain available for later discrimination.")
                return self.emit(
                    supporter="Residual Scout",mode="unknown preservation",status="FINDING",
                    signature="RESIDUAL:FORCED_CLASSIFICATION",detail="Residual status collapsed.",
                    consequence="Unexplained structure was prematurely interpreted.")
            finally:
                lab.close()

    # ------------------------------------------------------------
    # 8. Supporter diversity check: mechanisms must really differ
    # ------------------------------------------------------------
    def diversity_supporter(self):
        modes={
            "temporal boundary","persistence mutation","representation/frame diversity",
            "differential replay","Pareto accounting","component differential",
            "unknown preservation","exhaustive finite model","invariance transformation",
            "matched intervention protocol","matched comparator","external-reference separation",
            "boundary search","delta debugging","correlation disclosure"
        }
        return self.emit(
            supporter="Ecology Auditor",mode="role separation",status="PASS",
            signature="ECOLOGY:MECHANISM_DIVERSITY",
            detail=f"{len(modes)} distinct supporter mechanisms are active; they do not share one discriminator.",
            consequence="Correlated failure remains possible, but diversity is structural rather than nominal.")


    # ------------------------------------------------------------
    # 9. Bounded exact explorer: independent graph reachability oracle
    # ------------------------------------------------------------
    def bounded_scope_explorer(self):
        # Exhaust every DAG over 3 ordered nodes using forward edges only.
        # Compare Orbit Lab containment with an independent reachability implementation.
        nodes=("A","B","C")
        possible=[("A","B"),("A","C"),("B","C")]
        checked=0
        for mask in range(1<<len(possible)):
            with tempfile.TemporaryDirectory() as td:
                lab=OrbitLab(Path(td)/"t.db")
                try:
                    ids={n:self.add(lab,"Scope",n,n) for n in nodes}
                    edges=[possible[i] for i in range(len(possible)) if mask&(1<<i)]
                    graph={n:[] for n in nodes}
                    for a,b in edges:
                        lab.link_scope(ids[a],ids[b]); graph[a].append(b)
                    def reach(a,b):
                        if a==b: return True
                        todo=[a]; seen=set()
                        while todo:
                            x=todo.pop()
                            if x in seen: continue
                            seen.add(x)
                            for y in graph[x]:
                                if y==b: return True
                                todo.append(y)
                        return False
                    for a in nodes:
                        for b in nodes:
                            checked+=1
                            if lab.scope_contains(ids[a],ids[b]) != reach(a,b):
                                return self.emit(
                                    supporter="Bounded Explorer",mode="exhaustive finite model",
                                    status="FINDING",signature="SCOPE:REFERENCE_MODEL_DIVERGENCE",
                                    detail=f"scope_contains diverged from independent reachability for edges={edges}, {a}->{b}",
                                    consequence="Authority scope semantics disagree with their finite reference model.")
                finally:
                    lab.close()
        return self.emit(
            supporter="Bounded Explorer",mode="exhaustive finite model",status="PASS",
            signature="SCOPE:REFERENCE_MODEL_MATCH",
            detail=f"All {checked} containment queries across all 3-node forward-edge DAGs matched an independent reachability oracle.",
            consequence="Small exact scope semantics are independently checked.")

    # ------------------------------------------------------------
    # 10. Metamorphic supporter: navigation-only additions must not change authority
    # ------------------------------------------------------------
    def metamorphic_navigation_supporter(self):
        with tempfile.TemporaryDirectory() as td:
            lab=OrbitLab(Path(td)/"t.db")
            try:
                c=self.add(lab,"Context","C","c"); actor=self.add(lab,"Actor","owner","actor")
                s=self.add(lab,"Scope","S","s"); x=self.add(lab,"Candidate","X","x")
                e=self.add(lab,"Evidence","basis","e",epistemic="OBSERVED")
                root=lab.establish_authority_root(context_id=c,scope_id=s,operations=["INSPECT"],
                    holder_actor_id=actor,provenance_class="USER",provenance="supporter-user")
                lab.grant_authorization(context_id=c,entity_id=x,operation="INSPECT",scope_id=s,
                    issuer_authority_id=root,issuer_actor_id=actor,principal_id=actor,
                    basis_entity_ids=[e],reason="grant",provenance_class="TEST",provenance="supporter")
                before=lab.check_authorized(context_id=c,actor_id=actor,entity_id=x,operation="INSPECT",scope_id=s)
                nav=self.add(lab,"Artifact","navigation record","nav")
                lab.record_association(source_entity_id=nav,target_entity_id=x,scope_id=s,
                    relation="MENTIONS",resolution_status="LIBRARY_ID_EXACT",
                    provenance_class="TEST",provenance="supporter")
                after=lab.check_authorized(context_id=c,actor_id=actor,entity_id=x,operation="INSPECT",scope_id=s)
                if before["authorized"]!=after["authorized"]:
                    return self.emit(
                        supporter="Metamorphic Tester",mode="invariance transformation",status="FINDING",
                        signature="METAMORPHIC:ASSOCIATION_CHANGES_AUTHORITY",
                        detail="Adding a navigation-only Association changed authorization.",
                        consequence="A non-evidentiary metadata transformation changed consequential semantics.")
                return self.emit(
                    supporter="Metamorphic Tester",mode="invariance transformation",status="PASS",
                    signature="METAMORPHIC:ASSOCIATION_AUTHORITY_INVARIANT",
                    detail="Adding a navigation-only Association left authorization unchanged.",
                    consequence="Declared non-evidentiary metadata remains semantically inert for authority.")
            finally:
                lab.close()

    # ------------------------------------------------------------
    # 11. Counterfactual protocol supporter: matched runs must be scientifically usable
    # ------------------------------------------------------------
    def counterfactual_integrity_supporter(self):
        with tempfile.TemporaryDirectory() as td:
            lab=OrbitLab(Path(td)/"t.db")
            try:
                candidate=self.add(lab,"Candidate","link hypothesis","candidate")
                reset=self.add(lab,"Artifact","same reset","reset")
                probe=self.add(lab,"Probe","on/off probe","probe")
                frame=self.add(lab,"ObservationFrame","frame","frame",data={
                    "observer":"counterfactual","apparatus":"sim","accessible_variables":["loss"],
                    "resolution":"1e-6","intervention":"link on/off","boundary":"trial"})
                params=self.add(lab,"Parameters","params","params",data={"budget":1})
                run_c=self.add(lab,"RunIdentity","control run","rc")
                run_t=self.add(lab,"RunIdentity","treatment run","rt")
                oc=self.add(lab,"Observation","control failed to execute","oc",epistemic="OBSERVED")
                ot=self.add(lab,"Observation","treatment completed","ot",epistemic="OBSERVED")
                control=lab.record_execution(run_id=run_c,probe_id=probe,frame_id=frame,
                    parameters_id=params,reset_id=reset,observation_ids=[oc],status="TOOL_FAILED",
                    provenance_class="TEST",provenance="supporter")
                treatment=lab.record_execution(run_id=run_t,probe_id=probe,frame_id=frame,
                    parameters_id=params,reset_id=reset,observation_ids=[ot],status="COMPLETED",
                    provenance_class="TEST",provenance="supporter")
                result=self.add(lab,"Evidence","apparent treatment advantage","result",epistemic="OBSERVED")
                accepted=True
                try:
                    lab.add_episode("MATCHED_COUNTERFACTUAL","bad matched pair",
                        participants=[
                            {"role":"candidate","object_id":candidate},
                            {"role":"reset","object_id":reset},
                            {"role":"control","episode_id":control},
                            {"role":"treatment","episode_id":treatment},
                            {"role":"result","object_id":result},
                        ],
                        provenance_class="TEST",provenance="supporter")
                except ValueError:
                    accepted=False
                if accepted:
                    return self.emit(
                        supporter="Counterfactual Referee",mode="matched intervention protocol",
                        status="FINDING",signature="COUNTERFACTUAL:FAILED_EXECUTION_ACCEPTED",
                        detail="MATCHED_COUNTERFACTUAL accepted a TOOL_FAILED control run.",
                        consequence="Matched reset/frame/parameters are insufficient if one arm never produced usable scientific execution.",
                        source_case="ACDN uses matched connection-off/on probes from the same reset state.")
                return self.emit(
                    supporter="Counterfactual Referee",mode="matched intervention protocol",status="PASS",
                    signature="COUNTERFACTUAL:EXECUTIONS_VALID",
                    detail="Counterfactual construction rejects scientifically unusable execution arms.",
                    consequence="Matched comparisons require valid execution as well as matched setup.")
            finally:
                lab.close()

    # ------------------------------------------------------------
    # 12. Baseline champion: local benefit != overall superiority
    # ------------------------------------------------------------
    def baseline_supporter(self):
        memory_on=2.32578
        memory_off=2.34153
        gru=2.27255
        if memory_on < memory_off and memory_on > gru:
            return self.emit(
                supporter="Baseline Champion",mode="matched comparator",status="PRESSURE",
                signature="BASELINE:LOCAL_BENEFIT_NOT_OVERALL_WIN",
                detail="The intervention helps relative to its own ablation but remains worse than the stronger matched baseline.",
                consequence="Preserve both claims: component benefit is real; architecture superiority is not earned.",
                source_case="Compact associative hybrid: memory helped its 30-wide hybrid, yet the 36-wide GRU remained better.")
        return self.emit(
            supporter="Baseline Champion",mode="matched comparator",status="PASS",
            signature="BASELINE:CLAIM_ALIGNED",detail="Local and comparator outcomes point the same way.",
            consequence="No comparator conflict in this bounded case.")

    # ------------------------------------------------------------
    # 13. Grounding supporter: internal agreement is not external truth
    # ------------------------------------------------------------
    def grounding_supporter(self):
        common_wrong_inputs=4096
        internal_agreement_wrong=4096
        if common_wrong_inputs==internal_agreement_wrong:
            return self.emit(
                supporter="Grounding Oracle",mode="external-reference separation",status="PRESSURE",
                signature="GROUNDING:CONSENSUS_CANNOT_CERTIFY_INPUT_TRUTH",
                detail="Perfect internal agreement can reproduce a coherently wrong externally supplied state.",
                consequence="Consensus/redundancy must not be promoted into grounding; trusted input evidence is a separate obligation.",
                source_case="4D identity experiment: all 4096 coherent wrong-input cases were internally accepted.")
        return self.emit(
            supporter="Grounding Oracle",mode="external-reference separation",status="PASS",
            signature="GROUNDING:INTERNAL_CHECK_SUFFICIENT",detail="Internal agreement discriminated the tested wrong inputs.",
            consequence="No grounding gap observed in this case.")

    # ------------------------------------------------------------
    # 14. Regime scout: boundaries matter more than one global score
    # ------------------------------------------------------------
    def regime_supporter(self):
        # A compact qualitative extraction of the existence-space result.
        short_pair=0.9975
        long_pair=0.00583
        if short_pair > 0.95 and long_pair < 0.01:
            return self.emit(
                supporter="Regime Scout",mode="boundary search",status="PRESSURE",
                signature="REGIME:GLOBAL_STATUS_HIDES_THRESHOLD",
                detail="The same organization moves from near-total success to near-total failure as observation delay crosses a regime boundary.",
                consequence="Prefer regime/boundary maps over assigning one global success status to the organization.",
                source_case="Existence-space observation refresh experiment: short-refresh pair succeeds; ~1000 ms pair collapses.")
        return self.emit(
            supporter="Regime Scout",mode="boundary search",status="PASS",
            signature="REGIME:NO_SHARP_BOUNDARY",detail="No strong regime shift in the bounded case.",
            consequence="A single summary may be adequate here.")

    # ------------------------------------------------------------
    # 15. Counterexample shrinker: minimize witnesses before repair
    # ------------------------------------------------------------
    @staticmethod
    def shrink_sequence(sequence, violates):
        seq=list(sequence)
        changed=True
        while changed:
            changed=False
            for i in range(len(seq)):
                trial=seq[:i]+seq[i+1:]
                if trial and violates(trial):
                    seq=trial; changed=True; break
        return seq

    def shrinker_supporter(self):
        # Abstract historical authority failure: grant -> revoke issuer -> check.
        seq=["create_root","grant","irrelevant_association","revoke_root","check"]
        def violates(s):
            required={"grant","revoke_root","check"}
            return required.issubset(set(s))
        shrunk=self.shrink_sequence(seq,violates)
        if set(shrunk)=={"grant","revoke_root","check"} and len(shrunk)==3:
            return self.emit(
                supporter="Counterexample Shrinker",mode="delta debugging",status="PASS",
                signature="SHRINK:MINIMAL_WITNESS",
                detail=f"Reduced a 5-step witness to the causally sufficient 3-step sequence: {shrunk}.",
                consequence="Repairs can target the smallest reproduced failure instead of its surrounding history.")
        return self.emit(
            supporter="Counterexample Shrinker",mode="delta debugging",status="FINDING",
            signature="SHRINK:FAILED_TO_MINIMIZE",detail=f"Unexpected shrink result: {shrunk}",
            consequence="Counterexamples remain unnecessarily entangled.")

    # ------------------------------------------------------------
    # 16. Independence auditor: role diversity is not independence
    # ------------------------------------------------------------
    def independence_supporter(self):
        return self.emit(
            supporter="Independence Auditor",mode="correlation disclosure",status="PASS",
            signature="INDEPENDENCE:NOT_OVERCLAIMED",
            detail="These supporters use distinct mechanisms but share the same runtime/kernel lineage; they are role-separated, not claimed independent.",
            consequence="Agreement among supporters is not counted as independent replication.")

    def run(self) -> dict:
        runners=[
            self.exposure_cycle_supporter,
            self.history_mutation_supporter,
            self.failure_frame_supporter,
            self.replay_supporter,
            self.resource_supporter,
            self.wrapper_supporter,
            self.residual_supporter,
            self.bounded_scope_explorer,
            self.metamorphic_navigation_supporter,
            self.counterfactual_integrity_supporter,
            self.baseline_supporter,
            self.grounding_supporter,
            self.regime_supporter,
            self.shrinker_supporter,
            self.independence_supporter,
            self.diversity_supporter,
        ]
        for fn in runners:
            fn()
        return {
            "name":"Orbit Lab supporter ecology preflight",
            "signals":[asdict(x) for x in self.signals],
            "findings":sum(x.status=="FINDING" for x in self.signals),
            "pressures":sum(x.status=="PRESSURE" for x in self.signals),
            "passes":sum(x.status=="PASS" for x in self.signals),
        }

def main():
    print(json.dumps(SupporterEcology().run(),indent=2,sort_keys=True))

if __name__=="__main__":
    main()
