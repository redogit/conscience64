
import unittest
from checks.penny_monthly_attention_probe import run

class PennyMonthlyAttentionProbeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.r=run()

    def test_original_plan_fails_existing_drawdown_brake(self):
        self.assertTrue(self.r["observations"]["original_two_slot_breaches_preexisting_brake"])

    def test_withdrawal_is_not_principal_protection(self):
        self.assertTrue(self.r["observations"]["monthly_withdrawals_do_not_protect_original_20_from_later_losses"])

    def test_reduced_exposure_is_only_bounded_observation(self):
        self.assertTrue(self.r["observations"]["exposure_reduction_reduced_drawdown_in_this_panel"])
        self.assertTrue(self.r["observations"]["post_hoc_4_dollar_boundary_inside_brake_at_base_cost"])
        self.assertTrue(self.r["observations"]["post_hoc_4_dollar_boundary_fails_at_1pct_one_way_cost"])

    def test_claim_ceiling_preserves_development_status(self):
        text=" ".join(self.r["claim_ceiling"]).lower()
        self.assertIn("hand-selected",text)
        self.assertIn("post-hoc",text)
        self.assertIn("no future-return",text)

if __name__=="__main__":
    unittest.main()
