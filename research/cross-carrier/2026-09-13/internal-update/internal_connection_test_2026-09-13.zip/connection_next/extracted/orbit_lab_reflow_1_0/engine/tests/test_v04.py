
import tempfile, sqlite3
from pathlib import Path
import unittest
from orbit_lab import OrbitLab

class V04Tests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.lab=OrbitLab(Path(self.tmp.name)/"t.db")
    def tearDown(self):
        self.lab.close(); self.tmp.cleanup()
    def add(self,t,title,key,**kw):
        return self.lab.add(t,title,provenance_class="TEST",provenance="test",identity_key=key,**kw)

    def test_semantic_content_immutable(self):
        x=self.add("Artifact","v1","x",data={"semantics":"A"})
        with self.assertRaises(sqlite3.IntegrityError):
            self.lab.conn.execute("UPDATE objects SET title='v2' WHERE id=?",(x,))
        self.lab.conn.rollback()

    def test_revision_creates_new_snapshot(self):
        x=self.add("Artifact","v1","x",data={"semantics":"A"})
        y=self.lab.revise_object(
            x,title="v2",data={"semantics":"B"},
            provenance_class="TEST",provenance="test",
            identity_key="y",reason="behavior changed"
        )
        self.assertNotEqual(x,y)
        self.assertEqual(self.lab.get(x).data["semantics"],"A")
        self.assertEqual(self.lab.get(y).data["semantics"],"B")
        self.assertEqual(self.lab.graph(y)["outgoing"][0]["kind"],"SUPERSEDES")

    def test_claim_has_no_intrinsic_supported_status(self):
        with self.assertRaises(ValueError):
            self.add("Claim","C","c",epistemic="SUPPORTED")
        c=self.add("Claim","C","c2")
        with self.assertRaises(ValueError):
            self.lab.set_epistemic(c,"SUPPORTED")

    def test_scoped_claim_assessments_can_disagree(self):
        c=self.add("Claim","Adaptive > uniform","c")
        f1=self.add("ObservationFrame","peak frame","f1",data={"observer":"test","apparatus":"test","accessible_variables":["y"],"resolution":"fixed","intervention":"none","boundary":"peak"})
        f2=self.add("ObservationFrame","osc frame","f2",data={"observer":"test","apparatus":"test","accessible_variables":["y"],"resolution":"fixed","intervention":"none","boundary":"osc"})
        e1=self.add("Evidence","peak win","e1",epistemic="OBSERVED")
        e2=self.add("Evidence","osc loss","e2",epistemic="OBSERVED")
        self.lab.assess_claim(c,frame_id=f1,evidence_ids=[e1],verdict="SUPPORTED",
                              scope="peak",provenance_class="TEST",provenance="test")
        self.lab.assess_claim(c,frame_id=f2,evidence_ids=[e2],verdict="CONTRADICTED",
                              scope="osc",provenance_class="TEST",provenance="test")
        vals={x["data"]["verdict"] for x in self.lab.claim_assessments(c)}
        self.assertEqual(vals,{"SUPPORTED","CONTRADICTED"})
        self.assertEqual(self.lab.get(c).epistemic,"UNKNOWN")

if __name__=="__main__":
    unittest.main()
