# Library — Preserve, Retrieve, Support

## Role

The Library is the recoverable body of source material, evidence, history, failed attempts, contradictions,
methods, candidate ideas, work helpers, and unresolved material. It is not one ontology and it is not automatically active.

```text
PRESERVED != AVAILABLE != ACTIVE
AVAILABLE != ENTITLED_TO_ACCESS
RELATED != SUPPORTS
PRESERVED != ENDORSED
CURRENT != HISTORY
LOOKUP != EVIDENCE
RETRIEVAL != PROOF
```

## Staged fold result

The conversation's Library fold is retained in this simplified form:

1. Existing Orbit Incoming queue was resolved to History/current routing.
2. Named research roots were reviewed from compact current/recovery heads; only consequential deltas were imported.
3. Loose root artifacts were not bulk-ingested; they remain progressively searchable.
4. Private/ambiguous namespaces are minimum-access and excluded from automatic search by default.
5. Support retrieval was added.

There is no requirement to pre-read or pre-classify every preserved artifact.

## Support retrieval

Human command:

```text
find-support <item, claim, file, or concept>
```

Retrieval order:

```text
1. Resolve the target identity and what kind of support is being sought.
2. Follow exact IDs, hashes, paths, declared lineage, and known source edges first.
3. Search a bounded relevant neighborhood.
4. Inspect the candidate source itself.
5. Classify the relation.
6. Run evidence/authority qualification when the item is proposed as support.
7. Return the bounded result plus contradictions and unresolved gaps.
```

### Returned relation classes

- `PRIMARY_EVIDENCE` — directly bears on the tested relation under the declared scope;
- `CORROBORATING_RESULT` — independently tests materially comparable relation/conditions;
- `CONTRADICTION` — evidence/result that cuts against the target claim;
- `DEPENDENCY` — a prerequisite claim, theorem, identity, method, or source needed before support is valid;
- `BASELINE_OR_COMPARATOR` — useful for discriminating what changed but not itself support for the target claim;
- `METHOD_HELPER` — helps test, verify, measure, or reason;
- `PREDECESSOR_OR_SUCCESSOR` — lineage/context relation;
- `CANDIDATE_HELPER` — potentially useful imported idea/tool;
- `RELATED_ONLY` — nearby by topic/structure but not demonstrated support;
- `UNRESOLVED` — relation or identity cannot currently be established.

A candidate can occupy more than one role only when each role is independently justified.

## Seed and live search

Alpha 0.26 preserved a static seed from the MoonShot association work:

- 633 declared associations;
- 124 exact-resolved rows;
- 77 distinct resolved file IDs.

This is a routing seed, **not a complete Library index**. New or loose items use bounded live Library search.
The Runtime Relation Index contributes one-to-many, scoped, provenance-bearing candidate retrieval; it does not confer truth.

## Privacy

Automatic support search excludes the ambiguous/private namespaces identified during the fold (including `Homework`
and `Your job is you move things from a to b.`) unless a specific task explicitly requires access. Even then, retrieve the
minimum relevant material rather than sweeping the namespace.
