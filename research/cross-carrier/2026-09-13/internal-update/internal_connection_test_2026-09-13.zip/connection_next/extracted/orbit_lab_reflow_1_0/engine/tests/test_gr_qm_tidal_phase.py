
import unittest
from checks.gr_qm_tidal_phase_probe import run

class GRQMTidalPhaseTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.r=run()

    def test_structural_reconstruction(self):
        self.assertTrue(self.r["D2_affine_zero"])
        self.assertTrue(self.r["D2_quadratic_qh2"])
        self.assertTrue(self.r["recoil_tidal_formula_exact"])
        self.assertTrue(self.r["constant_potential_ablation_invariant"])
        self.assertTrue(self.r["linear_potential_ablation_invariant_for_tidal_difference"])
        self.assertTrue(self.r["Tzz_zero_kills_tidal_phase"])

    def test_curvature_transport_is_explicitly_convention_bound(self):
        self.assertTrue(self.r["curvature_transport_registered_convention"])

    def test_structural_and_empirical_witnesses_do_not_substitute(self):
        self.assertTrue(self.r["structural_only_cannot_certify_empirical_bridge"])
        self.assertTrue(self.r["empirical_only_cannot_certify_structural_bridge"])
        self.assertTrue(self.r["combined_structural_plus_empirical_supported"])

    def test_quantum_gravity_upgrade_is_blocked(self):
        self.assertTrue(self.r["same_evidence_cannot_certify_quantum_gravity"])

    def test_source_output_lineage_mismatch_preserved(self):
        self.assertTrue(self.r["finite_difference_source_executes"])
        self.assertFalse(self.r["finite_difference_archived_output_byte_identical"])

    def test_no_schema_growth_and_audit_clean(self):
        self.assertEqual(self.r["kernel_schema_additions"],0)
        self.assertTrue(self.r["audit_passed"])

if __name__=="__main__":
    unittest.main()
