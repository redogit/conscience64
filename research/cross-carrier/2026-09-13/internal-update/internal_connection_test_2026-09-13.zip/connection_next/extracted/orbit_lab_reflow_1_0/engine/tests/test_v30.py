
import tempfile
from pathlib import Path
import unittest
from orbit_lab import OrbitLab

class V30Tests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.lab=OrbitLab(Path(self.tmp.name)/"t.db")
    def tearDown(self): self.lab.close(); self.tmp.cleanup()
    def add(self,t,title,key,**kw):
        return self.lab.add(t,title,provenance_class="TEST",provenance="test",identity_key=key,**kw)

    def fixture(self):
        ctx=self.add("Context","Schema context","ctx"); actor=self.add("Actor","owner","actor")
        scope=self.add("Scope","Schema","scope")
        frame=self.add("ValidityFrame","frame","frame",data={"conditions":{"kernel":"v30"}})
        witness=self.add("Evidence","witness","w",epistemic="OBSERVED")
        gap=self.lab.record_schema_gap(gap_kind="LANGUAGE_COLLISION",current_term="Candidate",
            missing_distinction="new earned type",provenance_class="TEST",provenance="test")
        proposal=self.lab.propose_schema_object_type(gap_id=gap,type_name="EarnedType",
            definition="A type forced by a controlled collision.",
            provenance_class="TEST",provenance="test")
        root=self.lab.establish_authority_root(context_id=ctx,scope_id=scope,
            operations=["SCHEMA_CHANGE"],holder_actor_id=actor,
            provenance_class="USER",provenance="user")
        return ctx,actor,scope,frame,witness,gap,proposal,root

    def test_direct_schema_mutation_is_retired(self):
        with self.assertRaises(PermissionError):
            self.lab.admit_object_type_from_gap(gap_id="x",type_name="X",definition="x",
                reason="x",provenance_class="TEST",provenance="test")

    def test_promotion_without_authorization_cannot_mutate_schema(self):
        ctx,actor,scope,frame,witness,gap,proposal,root=self.fixture()
        promotion=self.lab.record_promotion(context_id=ctx,entity_id=proposal,scope_id=scope,
            validity_frame_id=frame,witness_entity_id=witness,basis_entity_ids=[witness],
            change_claim="earned",revalidation_rule="rerun collision",
            provenance_class="TEST",provenance="test")
        with self.assertRaises(PermissionError):
            self.lab.apply_schema_object_type(proposal_id=proposal,promotion_episode_id=promotion,
                context_id=ctx,actor_id=actor,scope_id=scope,reason="try",
                provenance_class="TEST",provenance="test")

    def test_authorization_without_promotion_cannot_mutate_schema(self):
        ctx,actor,scope,frame,witness,gap,proposal,root=self.fixture()
        self.lab.grant_authorization(context_id=ctx,entity_id=proposal,operation="SCHEMA_CHANGE",
            scope_id=scope,issuer_authority_id=root,issuer_actor_id=actor,principal_id=actor,
            basis_entity_ids=[witness],reason="authorized",
            provenance_class="TEST",provenance="test")
        fake=self.lab.add_episode("ASSOCIATION","not promotion",
            participants=[{"role":"source","object_id":proposal},{"role":"target","object_id":witness},{"role":"scope","object_id":scope}],
            provenance_class="TEST",provenance="test")
        with self.assertRaises(TypeError):
            self.lab.apply_schema_object_type(proposal_id=proposal,promotion_episode_id=fake,
                context_id=ctx,actor_id=actor,scope_id=scope,reason="try",
                provenance_class="TEST",provenance="test")

    def test_governed_schema_change_records_chain(self):
        ctx,actor,scope,frame,witness,gap,proposal,root=self.fixture()
        promotion=self.lab.record_promotion(context_id=ctx,entity_id=proposal,scope_id=scope,
            validity_frame_id=frame,witness_entity_id=witness,basis_entity_ids=[witness],
            change_claim="earned",revalidation_rule="rerun collision",
            provenance_class="TEST",provenance="test")
        auth=self.lab.grant_authorization(context_id=ctx,entity_id=proposal,operation="SCHEMA_CHANGE",
            scope_id=scope,issuer_authority_id=root,issuer_actor_id=actor,principal_id=actor,
            basis_entity_ids=[witness,promotion],reason="authorized",
            provenance_class="TEST",provenance="test")
        self.lab.apply_schema_object_type(proposal_id=proposal,promotion_episode_id=promotion,
            context_id=ctx,actor_id=actor,scope_id=scope,reason="apply earned repair",
            provenance_class="TEST",provenance="test")
        row=self.lab.conn.execute("SELECT * FROM schema_changes WHERE term_name='EarnedType'").fetchone()
        self.assertEqual(row["proposal_id"],proposal)
        self.assertEqual(row["promotion_episode_id"],promotion)
        self.assertEqual(row["authorization_episode_id"],auth)
        self.assertEqual(row["actor_id"],actor)

if __name__=="__main__": unittest.main()
