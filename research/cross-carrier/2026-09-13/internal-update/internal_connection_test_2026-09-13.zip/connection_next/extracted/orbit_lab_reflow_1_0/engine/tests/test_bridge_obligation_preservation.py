
import tempfile
from pathlib import Path
import unittest
from orbit_lab import OrbitLab

class BridgeObligationTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.lab=OrbitLab(Path(self.tmp.name)/"t.db")
    def tearDown(self):
        self.lab.close(); self.tmp.cleanup()
    def add(self,t,title,key,**kw):
        return self.lab.add(t,title,provenance_class="TEST",provenance="bridge-test",identity_key=key,**kw)

    def world(self):
        src=self.add("Context","Source arrangement","src")
        dst=self.add("Context","Target arrangement","dst")
        thing=self.add("Artifact","Converted thing","thing")
        ob=self.add("Obligation","Preserve exact identity","ob",
            data={"required_evidence_tags":["SAME_CONTENT_IDENTITY"]})
        weak=self.add("Evidence","Semantic resemblance","weak",epistemic="OBSERVED",
            data={"evidence_tags":["SEMANTIC_SIMILARITY"]})
        exact=self.add("Evidence","Digest identity check","exact",epistemic="OBSERVED",
            data={"evidence_tags":["SAME_CONTENT_IDENTITY"]})
        return src,dst,thing,ob,weak,exact

    def test_weak_evidence_cannot_certify_preserved_transfer(self):
        src,dst,thing,ob,weak,exact=self.world()
        with self.assertRaises(ValueError):
            self.lab.transfer(
                source_context_id=src,destination_context_id=dst,entity_id=thing,
                obligation_ids=[ob],evidence_entity_ids=[weak],
                requested_operations=["PRESERVE"],result="PRESERVED",
                reason="weak resemblance is not identity",
                provenance_class="TEST",provenance="bridge-test"
            )

    def test_qualified_evidence_can_certify_preserved_transfer(self):
        src,dst,thing,ob,weak,exact=self.world()
        ep=self.lab.transfer(
            source_context_id=src,destination_context_id=dst,entity_id=thing,
            obligation_ids=[ob],evidence_entity_ids=[exact],
            requested_operations=["PRESERVE"],result="PRESERVED",
            reason="identity checked",
            provenance_class="TEST",provenance="bridge-test"
        )
        self.assertEqual(self.lab.episode(ep)["data"]["result"],"PRESERVED")

    def test_unresolved_transfer_may_preserve_missing_qualification(self):
        src,dst,thing,ob,weak,exact=self.world()
        ep=self.lab.transfer(
            source_context_id=src,destination_context_id=dst,entity_id=thing,
            obligation_ids=[ob],evidence_entity_ids=[weak],
            requested_operations=["PRESERVE"],result="UNRESOLVED",
            reason="evidence not strong enough",
            provenance_class="TEST",provenance="bridge-test"
        )
        self.assertEqual(self.lab.episode(ep)["data"]["result"],"UNRESOLVED")

    def test_transfer_still_does_not_grant_destination_authority(self):
        src,dst,thing,ob,weak,exact=self.world()
        self.lab.transfer(
            source_context_id=src,destination_context_id=dst,entity_id=thing,
            obligation_ids=[ob],evidence_entity_ids=[exact],
            requested_operations=["ACTIVATE"],result="PRESERVED",
            reason="transport only",
            provenance_class="TEST",provenance="bridge-test"
        )
        actor=self.add("Actor","Actor","actor")
        scope=self.add("Scope","Scope","scope")
        auth=self.lab.check_authorized(
            context_id=dst,actor_id=actor,entity_id=thing,
            operation="ACTIVATE",scope_id=scope)
        self.assertFalse(auth["authorized"])

    def test_custody_reconstruction_respects_declared_evidence_kind(self):
        src=self.add("Context","A","csrc"); dst=self.add("Context","B","cdst")
        content=self.lab.register_content(algorithm="sha256",digest="aa11",
            provenance_class="TEST",provenance="bridge-test")
        inst=self.lab.create_artifact_instance(content_id=content,title="source",
            provenance_class="TEST",provenance="bridge-test",identity_key="cinst")
        occ=self.lab.record_instance_occurrence(instance_id=inst,context_id=src,locator="/A/x",
            mode="REGISTER",provenance_class="TEST",provenance="bridge-test",identity_key="cocc")
        other=self.lab.register_content(algorithm="sha256",digest="bb22",
            provenance_class="TEST",provenance="bridge-test")
        ob=self.add("Obligation","Preserve exact identity","cob",
            data={"required_evidence_tags":["SAME_CONTENT_IDENTITY"]})
        weak=self.add("Evidence","Looks equivalent","cweak",epistemic="OBSERVED",
            data={"evidence_tags":["SEMANTIC_SIMILARITY"]})
        with self.assertRaises(ValueError):
            self.lab.custody_transfer(
                source_context_id=src,destination_context_id=dst,
                source_occurrence_id=occ,destination_locator="/B/rebuilt",
                mode="RECONSTRUCT",reconstructed_content_id=other,
                obligation_ids=[ob],evidence_entity_ids=[weak],
                reason="cannot certify identity with resemblance",
                provenance_class="TEST",provenance="bridge-test"
            )

    def test_audit_detects_forged_preserved_transfer_qualification(self):
        src,dst,thing,ob,weak,exact=self.world()
        ep=self.lab.transfer(
            source_context_id=src,destination_context_id=dst,entity_id=thing,
            obligation_ids=[ob],evidence_entity_ids=[exact],
            requested_operations=["PRESERVE"],result="PRESERVED",
            reason="valid before corruption",
            provenance_class="TEST",provenance="bridge-test"
        )
        # Simulate hostile persistence corruption by disabling the participant-delete
        # trigger and swapping qualified evidence for weak evidence.
        self.lab.conn.execute("DROP TRIGGER trg_episode_participants_immutable_delete")
        self.lab.conn.execute(
            "DELETE FROM episode_participants WHERE episode_id=? AND role='evidence'",(ep,))
        self.lab.conn.execute(
            """INSERT INTO episode_participants
               (episode_id,role,participant_id,ordinal,required)
               VALUES(?,?,?,?,?)""",(ep,"evidence",weak,0,1))
        self.lab.conn.commit()
        audit=self.lab.alpha_audit()
        self.assertFalse(audit["passed"])
        self.assertTrue(any(
            f["check"]=="transfer_obligation_evidence" for f in audit["failures"]
        ))


if __name__=="__main__":
    unittest.main()
