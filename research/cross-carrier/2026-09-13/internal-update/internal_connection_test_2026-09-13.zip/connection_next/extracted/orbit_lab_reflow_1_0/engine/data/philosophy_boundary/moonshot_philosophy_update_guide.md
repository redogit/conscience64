# Next Update Guide — Moonshot Philosophy Separation

## Goal

Keep this export useful as Moonshot evolves without forcing future sessions to reload the full conversation.

## Preferred update path

1. Treat `02_MOONSHOT_PHILOSOPHY_BOUNDARY.md` as the compact reusable reference.
2. Keep `01_CONVERSATION_TRANSCRIPT.md` as immutable provenance for this decision.
3. Add or revise philosophical content in a dedicated philosophy artifact/folder rather than inserting it into active experimental ledgers.
4. Active research packets should cite/reference the philosophy layer only when it materially changes the current obligation, ethical constraint, question, or lens.
5. Do not rewrite historical evidence or theory to make the philosophy appear empirically established.

## Classification test for new material

Ask what function the material is performing **in the current relation**:

- Purpose/value/worldview/generative lens → Philosophy.
- Experimental procedure or comparison rule → Methodology.
- Observation/result/failure → Evidence.
- Supported explanation/generalization → Theory.
- Constructed mechanism/system → Engineering.

Classify the **tested relation or current role**, not the thing globally. The same concept may appear in philosophy as a lens and later appear in theory only if separately earned by evidence.

## Lightweight recovery contract

A future Moonshot session does not need this whole export merely to honor the separation. The minimum reconstructible state is:

> Moonshot has a separate `MOONSHOT_PHILOSOPHY/` foundation. Philosophy can motivate questions and values but cannot serve as evidence or theory. Operational research packets reference it rather than carrying it. Re-introduce philosophical material only when it is consequential to the current task, and label its role explicitly.

## What remains unresolved

- The final internal folder/file schema for the full philosophy corpus can evolve.
- Individual historical Moonshot materials may still contain mixed philosophy/evidence and can be separated progressively when they are touched.
- Separation is organizational and epistemic; it does not assert that philosophy is irrelevant to science or engineering.
