# Work — The Human Surface

The primary interface is the six-field Research Card:

```text
Question  What are we examining or trying to accomplish?
Need      What must be preserved or achieved?
Limit     What boundary, risk, privacy rule, authority, cost, or scope matters?
Try       What concrete probe/action will we perform?
Saw       What actually happened?
Left      What remains unresolved?
```

Additional distinctions are used only when needed:

- `compare` — derived comparison from observations;
- `think` — interpretation/hypothesis;
- `decide` — decision;
- `find-support` — search the Library for candidate support, contradictions, dependencies, baselines, or helpers;
- `gdsn` — non-persistent GDSN work triage;
- `health` / task verification — inspect verifier state.

## Default loop

```text
Question
→ Need
→ Limit
→ optional support search
→ Try
→ Saw
→ Compare / Think when useful
→ Verify
→ Decide or remain unresolved
→ preserve Left
```

No additional noun belongs on the human surface unless its absence forces consequential guessing.

## Mathematics

Orbit can do mathematics, but mathematics is treated as a helper under the same discipline:

```text
assumptions + definitions + derivation/computation + check + scope
```

A correct calculation does not by itself establish that the model, measurement, physical interpretation,
or business assumption feeding the calculation is correct. Mathematical support and empirical support remain separable.
