# Project Synthesis — From Recoverable Orbit to Selector Core

## 1. Purpose carried from the beginning

The work began from a practical orientation rather than a desire to create another large framework:

- keep the present small;
- keep what matters recoverable;
- preserve evidence, failures, contradictions, and chronology;
- separate observation from inference and decision;
- use the smallest structure that faithfully carries the current consequential distinction;
- let real research use expose what is missing;
- remain correctable;
- do not use completeness as a goal, gate, score, or stopping condition.

The library/orbit idea supplied the initial operational shape:

`Subject -> pull relevant orbit -> work -> observe -> return what was learned`

The Library is passive/recoverable. Current attention is selective.

## 2. What the research forced

Repeatedly feeding prior work into the small model produced a sequence of action-relevant failures. The important point is not the version numbers; it is the distinctions the failures earned.

### Research-state distinctions

- `Observation != Inference != Decision`
- `available != active != admitted != authorized for this use`
- authority is local to Context + Actor/Principal + Entity + Operation + Scope + issuer/basis/history;
- transfer can preserve an entity without transferring source authority;
- access/exposure can change later eligibility;
- history is append-oriented and current state is derived from history;
- successful transport does not imply global equivalence;
- method compliance and structural validity are different;
- historical support and current applicability are different;
- content identity, durable instance identity, and historical occurrence identity are different;
- custody/movement and derivation are different;
- association/navigation is not evidence, authority, movement, or applicability;
- reversible adaptation is not persistent promotion;
- failure location is not failure cause;
- residuals may remain `UNEXPLAINED` without being promoted into discovery/noise/importance.

### Language correction

Eventually the fixed ontology itself became the obstruction. The kernel therefore learned a bounded rule:

`action-relevant language collision / ontology leakage -> candidate distinction -> witness-backed promotion -> SCHEMA_CHANGE authorization -> admitted runtime schema repair -> rerun`

A schema proposal cannot approve itself. The old direct schema mutation path is retired.

## 3. Why Orbital GANs appeared

Single-feature regressions were no longer sufficient. Composition failures appeared at the joints between individually legal subsystems.

Orbital GANs were therefore implemented as structured adversarial history generators, not neural GANs. A generator wins only when the public API accepts a state that violates a higher-level invariant, or when the audit misses corrupted persistence.

Three generations found 12 distinct failures, including non-transitive revocation, expiry widening, revoked-issuer grants, schema-gap relinking, `AUTHORIZE` escalation, definition drift, scope cycles, weak promotion witnesses, legacy activation bypass, and Current-slot corruption. Each was preserved and turned into regression pressure.

The adversary cannot promote its own findings.

## 4. Why the supporters diversified

Adversarial generation is only one useful helper form. Other research failures require different instruments.

The supporter ecology now includes mechanisms for:

- finite exhaustive exploration;
- metamorphic invariance;
- differential replay/recovery;
- persistence mutation;
- observation-frame diversity;
- truth-exposure custody;
- matched counterfactuals;
- baseline comparison;
- Pareto/resource accounting;
- grounding against external reference;
- regime/boundary search;
- residual preservation;
- counterexample shrinking;
- component-vs-wrapper decomposition;
- correlation/independence disclosure.

These are different mechanisms, not claimed independent investigators.

## 5. Why selectors became the organizing center

The next complexity failure was caused by the helpers themselves: “test every part with every helper” recreates the complexity the project is meant to reduce.

The selector response is:

> State the obligation first. Use the weakest applicable selector. Escalate only while that obligation remains unresolved.

Current preorder:

`S0 -> S1 -> S2 -> S3 -> S4 -> S5`

This is deliberately similar to the earlier selector research: do not invoke stronger planning/search when a weaker policy already preserves the required consequence.

Supporter selection at S3 is now an **exact minimum-cost capability cover** over the current 16-helper catalog. The catalog is small enough that an approximate greedy optimizer is unnecessary. Cost here is a test-routing weight, not a universal economic value.

## 6. Current simplified project shape

The active project can now be understood as four pieces:

### Kernel

Stores and validates consequential research distinctions. It does not decide which helper deserves to run.

### Selector

Receives declared obligations and chooses/escalates verification paths.

### Supporters

Interchangeable capabilities selected because they can discriminate a current uncertainty or protect an obligation.

### Recoverable research/history

Supplies evidence, counterexamples, previous methods, failures, and dormant possibilities without becoming ambient authority.

So the active relation is:

`Research obligation -> Selector -> smallest adequate supporter/test set -> Kernel record/result -> History/Library`

not:

`all research -> all helpers -> all tests -> giant active ontology`.

## 7. Current bounded evidence

In the reorganized alpha 0.4 candidate:

- 99 current regression/invariant tests pass;
- 9 active components expose 29 declared obligations;
- selector run resolves all 29 with none unresolved;
- 29 historical stress probes are classified: 13 still pass, 16 are expected-stale under later invariants, 0 fail unexpectedly;
- 128 bounded seeded Orbital trials report 0 novel counterexamples and 0 harness errors in the selector run;
- supporter ecology reports 16 signals, 0 active findings, and 5 retained pressures;
- all six supporter profiles are fully covered by exact minimum-cost selection;
- bounded Scope reference checking matches 72 queries across all three-node forward-edge DAGs;
- navigation-only Association remains metamorphically inert for authorization;
- governed schema change, custody copy, scope-local exposure, unexplained residuals, audit, and state round-trip coexist in the integrated S5 scenario.

These are bounded implementation/research-kernel results. They are not completeness or universal-correctness claims.

## 8. Pressures deliberately not turned into more structure

The ecology currently keeps these as research pressures:

1. resource choices may remain Pareto-incomparable;
2. wrapper success may mask component error;
3. local intervention benefit may coexist with loss to a stronger baseline;
4. internal agreement cannot establish external grounding;
5. one global score may hide threshold/regime changes.

They change how work is tested and claimed, but have not yet forced a new kernel noun or layer.

## 9. What “use all helpers/tools” means now

It does **not** mean call every tool on every task.

It means:

- expose available capability;
- classify what obligation it can protect or uncertainty it can discriminate;
- account for cost/limitations/lineage;
- select it when applicable;
- escalate to a stronger or more independent helper only when the current evidence remains insufficient.

Unused capability remains available and recoverable; it is not evidence of neglect and does not need to pollute Current.

## 10. Forward direction

Do not design an imagined beta.

Point the selector at real recovered branches. Let actual tasks determine whether the next change belongs in:

- a supporter profile;
- a selector applicability rule;
- a regression/metamorphic relation;
- the kernel schema;
- or nowhere at all.

A change should earn its place by resolving an action-relevant failure that the smaller current form cannot preserve or expose.
