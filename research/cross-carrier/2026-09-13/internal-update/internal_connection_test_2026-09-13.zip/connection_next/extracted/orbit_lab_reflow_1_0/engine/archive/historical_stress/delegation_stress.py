
import tempfile
from pathlib import Path
from orbit_lab import OrbitLab

with tempfile.TemporaryDirectory() as td:
    lab=OrbitLab(Path(td)/"stress.db")
    passes=[]; breaks=[]
    try:
        dest=lab.add("Context","Destination",provenance_class="CURRENT_CONVERSATION",provenance="current",identity_key="dest")
        broad=lab.add("Scope","Research",provenance_class="TEST",provenance="stress",identity_key="broad")
        hodge=lab.add("Scope","Hodge",provenance_class="TEST",provenance="stress",identity_key="hodge")
        lab.link_scope(broad,hodge)

        root=lab.establish_authority_root(context_id=dest,scope_id=broad,
            operations=["INSPECT","USE_AS_EVIDENCE","ACTIVATE","AUTHORIZE"],
            provenance_class="USER",provenance="explicit user authority",
            identity_key="root")
        item=lab.add("Candidate","predecessor method",provenance_class="RECOVERY_PACKET",
                     provenance="old",identity_key="item",lifecycle="QUARANTINED")
        pred_ev=lab.add("Evidence","predecessor self-assertion",provenance_class="RECOVERY_PACKET",
                        provenance="old",identity_key="pred",epistemic="OBSERVED")

        # Source evidence alone cannot issue a grant; the destination root must sign it.
        grant=lab.grant_authorization(context_id=dest,entity_id=item,operation="INSPECT",scope_id=hodge,
            issuer_authority_id=root,basis_entity_ids=[pred_ev],
            reason="destination authority permits inspection of source material",
            provenance_class="DERIVED",provenance="stress")
        if lab.check_authorized(context_id=dest,entity_id=item,operation="INSPECT",scope_id=hodge)["authorized"]:
            passes.append("Predecessor evidence may be considered, but it cannot issue its own destination grant.")

        # Now try to delegate only bounded Hodge inspection authority to a worker/helper.
        helper=lab.add("Helper","Hodge reviewer",provenance_class="TEST",provenance="stress",identity_key="helper")
        # v0.18 has only root Authority objects. Making another root would require USER provenance
        # and could encode a new independent root rather than a bounded delegation from `root`.
        breaks.append(
            "Issuer chain now has a destination root, but there is no bounded delegation relation. "
            "The kernel cannot give a helper authority to grant/perform only INSPECT within Hodge, "
            "with depth/expiry/revocation, without either keeping all grants at the root or creating another root."
        )

        print("V0.18 ISSUER / DELEGATION STRESS")
        print("-------------------------------")
        print("PASS:")
        for x in passes: print("-",x)
        print("\nNEXT BREAK:")
        for i,x in enumerate(breaks,1): print(f"{i}. {x}")
    finally:
        lab.close()
