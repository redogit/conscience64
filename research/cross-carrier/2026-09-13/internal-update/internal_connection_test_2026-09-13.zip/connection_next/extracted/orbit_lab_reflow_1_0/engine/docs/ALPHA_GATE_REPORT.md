# Orbit Lab internal alpha 0.1 gate

```text
{
  "checks": {
    "governed_schema_change": true,
    "learned_schema_survives_roundtrip": true,
    "post_restore_audit": true,
    "state_complete_roundtrip": true
  },
  "gate": "Orbit Lab internal alpha 0.1",
  "known_boundary": [
    {
      "boundary": "runtime_authentication",
      "detail": "Actor identity is supplied by the embedding runtime; this kernel does not authenticate principals.",
      "status": "EXTERNAL_TRUST_BOUNDARY"
    }
  ],
  "passed": true,
  "state_sha256": "556698e9c83e92032a8f4af67347088bb6f84cfbf8ec6a7c15c59fa13dcf9163"
}

```

Alpha scope is internal research use. Runtime principal authentication remains an explicit external trust boundary.
