
import tempfile
from pathlib import Path
from orbit_lab import OrbitLab

with tempfile.TemporaryDirectory() as td:
    lab=OrbitLab(Path(td)/"stress.db")
    passes=[]; breaks=[]
    try:
        # Contracted Episode.
        s=lab.add("Artifact","src",provenance_class="TEST",provenance="stress",identity_key="s")
        t=lab.add("Artifact","dst",provenance_class="TEST",provenance="stress",identity_key="t")
        o=lab.add("Obligation","preserve behavior",provenance_class="TEST",provenance="stress",identity_key="o")
        e=lab.add("Evidence","comparison",provenance_class="TEST",provenance="stress",identity_key="e",epistemic="OBSERVED")
        try:
            lab.add_episode("FAITHFUL_TRANSPORT","bad",
                participants=[{"role":"source","object_id":s},{"role":"target","object_id":t}],
                provenance_class="TEST",provenance="stress")
            breaks.append("transport contract not enforced")
        except ValueError:
            passes.append("Known Episode kind rejects missing load-bearing roles.")

        # Typed unknown.
        try:
            lab.add("Remainder","cannot decide",provenance_class="TEST",provenance="stress",identity_key="r")
            breaks.append("untyped remainder accepted")
        except ValueError:
            passes.append("Remainder now requires a typed unknown.")

        # Real admission gate with ordinary evidence object.
        q=lab.add("Candidate","legacy link",provenance_class="RECOVERY_PACKET",
                  provenance="legacy",identity_key="q",lifecycle="QUARANTINED")
        try:
            lab.launch(q)
            breaks.append("quarantine bypassed")
        except PermissionError:
            passes.append("Quarantine blocks launch.")
        review=lab.add("Evidence","simple review evidence",provenance_class="TEST",
                       provenance="stress",identity_key="review",epistemic="OBSERVED")
        lab.admit(q,support_object_ids=[review],reason="test review",
                  provenance_class="TEST",provenance="stress")
        lab.launch(q)
        if lab.get(q).lifecycle=="ACTIVE":
            passes.append("Object can launch after explicit admission.")

        # --- Deeper attack: use a whole matched experiment as evidence for admission. ---
        cand=lab.add("Candidate","candidate connection",provenance_class="TEST",
                     provenance="stress",identity_key="cand")
        reset=lab.add("Artifact","reset R0",provenance_class="TEST",provenance="stress",identity_key="reset")
        off=lab.add("Probe","off",provenance_class="TEST",provenance="stress",identity_key="off")
        on=lab.add("Probe","on",provenance_class="TEST",provenance="stress",identity_key="on")
        result=lab.add("Observation","matched result",provenance_class="TEST",
                       provenance="stress",identity_key="result",epistemic="OBSERVED")
        matched=lab.add_episode(
            "MATCHED_COUNTERFACTUAL","matched link test",
            participants=[
                {"role":"candidate","object_id":cand},
                {"role":"reset","object_id":reset},
                {"role":"control","object_id":off},
                {"role":"treatment","object_id":on},
                {"role":"result","object_id":result},
            ],
            provenance_class="TEST",provenance="stress"
        )
        q2=lab.add("Candidate","legacy candidate requiring matched test",
                   provenance_class="RECOVERY_PACKET",provenance="legacy",
                   identity_key="q2",lifecycle="QUARANTINED")
        try:
            lab.admit(q2,support_object_ids=[matched],reason="matched experiment supports admission",
                      provenance_class="TEST",provenance="stress")
            breaks.append("Episode unexpectedly usable as object support.")
        except KeyError:
            breaks.append(
                "Higher-order Episode cannot itself participate in another Episode. "
                "Admission cannot cite the matched experiment as the evidence-bearing unit "
                "without flattening it into a duplicate Evidence object."
            )

        print("V0.5 DEPTH STRESS")
        print("-----------------")
        print("PASS:")
        for x in passes: print("-",x)
        print("\nDEEP BREAK:")
        for i,x in enumerate(breaks,1): print(f"{i}. {x}")
    finally:
        lab.close()
