# Alpha 0.23 — Low-Attention Penny-Stock Stress Replay

Question:
Can the proposed $20 penny-stock experiment be reduced to one monthly decision
without violating the existing risk controls?

Source:
`Moonshot_Penny_Stock_Research_System_v0.3.xlsx`, History sheet.
The source itself marks the eight-stock panel as hand-selected and exploratory,
not random or confirmatory.

Pre-existing control:
sleeve drawdown brake = -20%.

Development replay:
- $20 initial cash.
- monthly closes only;
- 3-month trailing momentum selector;
- positive signals only;
- monthly liquidation/reselection;
- 0.5% modeled one-way execution cost;
- missing next exchange price => zero under exit stress;
- withdraw 50% of cash above $20 after each monthly liquidation.

The selector/cost assumptions are development rules, not precommitted source rules.

Primary negative result:
the original two-slot / $10-per-slot version breached the pre-existing -20%
drawdown brake by a wide margin despite ending with positive total wealth.

Reduction probes:
one-slot $10 and one-slot $5 reduced drawdown but still breached the brake.
A post-hoc $4 slot landed just inside the brake at 0.5% one-way cost, but failed
when one-way cost was raised to 1%. It is therefore a candidate boundary, not
a promoted rule.

Critical distinction:
monthly withdrawal != principal protection.
The replay can distribute cash during profitable periods and later leave the
active account below the original $20.

No future-return or live-trading claim is made.
