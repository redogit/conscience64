from __future__ import annotations
from pathlib import Path
import json,tempfile,sys
ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path: sys.path.insert(0,str(ROOT))
from verification_carrier import audit_carrier, plan, PROFILES, ROW


def run():
    carrier=ROOT/'data'/'verification_carrier.bin'
    audit=audit_carrier(carrier)
    campaign=plan(PROFILES['campaign-integrity'],carrier)
    release_only=plan(['regression'],carrier)

    # Mutation witness: remove the sole provider edge for a consequential obligation.
    blob=bytearray(carrier.read_bytes())
    n=int.from_bytes(blob[:4],'little')
    header=json.loads(blob[4:4+n])
    target=header['obligations'].index('declared-denominator-linked')
    body=4+n
    removed=False
    for off in range(body,len(blob),ROW.size):
        oi,bits=ROW.unpack(bytes(blob[off:off+ROW.size]))
        if oi==target:
            blob[off:off+ROW.size]=ROW.pack(oi,0)
            removed=True
            break
    with tempfile.TemporaryDirectory() as td:
        mutant=Path(td)/'mut.bin'; mutant.write_bytes(blob)
        mutant_plan=plan(['declared-denominator-linked'],mutant)

    body_bytes=len(header['obligations'])*ROW.size
    return {
        'passed': all([
            audit['passed'],
            campaign['passed'],
            campaign['probes']==['core-sentinel','shadow-integrity'],
            not release_only['passed'],
            release_only.get('reason')=='UNCOVERED_OBLIGATION',
            removed and not mutant_plan['passed'],
        ]),
        'task_obligations':len(header['obligations']),
        'task_probes':len(header['probes']),
        'active_relation_body_bytes':body_bytes,
        'carrier_total_bytes':carrier.stat().st_size,
        'release_only_obligations':['regression'],
        'campaign_integrity_plan':campaign['probes'],
        'regression_not_task_certifiable':not release_only['passed'],
        'deleted_required_edge_refuses_pass':not mutant_plan['passed'],
        'source_registry_digest':header['registry_sha256'],
    }

if __name__=='__main__': print(json.dumps(run(),indent=2,sort_keys=True))
