# Orbit Lab Alpha 0.22 — Current

Alpha 0.22 closes the simple Research Card loop on a real unresolved MoonShot provenance question.

```text
Question  Where are the actual mutation/staleness code/results?
Need      Primary code/logs/outputs/hashes.
Limit     A bounded search failure is not proof of nonexistence.
Try       Search exact identity first; widen by behavior/source role.
Saw       Only recovery/index records were located; no primary Library artifact route was recovered.
Left      Whether the experiment ran, and what happened, remains unresolved.
```

Earned relation:

`not found in bounded search != never existed`.

The bounded search result may support a bounded provenance claim.
It cannot support the stronger historical nonexistence claim.

Human Lab now supports:

`python human_lab.py --demo-unresolved`

to demonstrate this workflow without exposing kernel plumbing.

Validation:
- 194/194 regressions PASS
- 28 selector components
- 103 declared obligations
- research-card task profile PASS
- direct S5 whole integration PASS
- strict path successor of Alpha 0.21
- zero new kernel object/Episode types

The historical R062/R063 reported metrics remain unverified and R064 remains OPEN.
