import unittest
from library_fold import stage1_status, lookup_stage1, candidate_import
from checks.library_fold_stage1_probe import run

class LibraryFoldStage1Tests(unittest.TestCase):
    def test_stage1_probe(self):
        self.assertTrue(run()["passed"])
    def test_new_candidate_routes(self):
        self.assertIsNotNone(candidate_import("harmonic-subspace-field"))
        self.assertIsNotNone(candidate_import("multifactorial-creativity"))
        self.assertTrue(lookup_stage1("PulseNet"))
        self.assertEqual(stage1_status()["kernel_schema_additions"],0)

if __name__=='__main__': unittest.main()
