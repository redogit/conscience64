Alpha 0.24 candidate: GDSN work helper. Task-local, non-persistent by default, no kernel schema additions.
