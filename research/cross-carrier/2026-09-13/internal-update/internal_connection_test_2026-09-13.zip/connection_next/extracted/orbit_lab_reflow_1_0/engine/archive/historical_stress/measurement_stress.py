
import tempfile
from pathlib import Path
from orbit_lab import OrbitLab

with tempfile.TemporaryDirectory() as td:
    lab=OrbitLab(Path(td)/"stress.db")
    passes=[]; breaks=[]
    try:
        order=lab.add("Order","bounded quality-efficiency order",data={"rule":"PARETO","metrics":[
            {"name":"active_state","direction":"MIN"},
            {"name":"nll","direction":"MIN","max_allowed":2.4},
            {"name":"latency","direction":"MIN"},
        ]},provenance_class="TEST",provenance="stress",identity_key="ord")
        compact=lab.add("Candidate","compact memory",data={"active_state":0.4,"nll":2.34,"latency":1.2},
                        provenance_class="TEST",provenance="stress",identity_key="compact")
        gru=lab.add("Candidate","GRU",data={"active_state":1.0,"nll":2.27,"latency":0.8},
                    provenance_class="TEST",provenance="stress",identity_key="gru")
        ev=lab.add("Evidence","experiment metrics",provenance_class="PRIMARY_ARTIFACT",
                   provenance="compact-memory-report",identity_key="ev",epistemic="OBSERVED")
        comp=lab.compare_candidates(order_id=order,candidate_ids=[compact,gru],evidence_ids=[ev],
                                    provenance_class="DERIVED",provenance="stress")
        result_id=[p["participant_id"] for p in lab.episode(comp)["participants"] if p["role"]=="result"][0]
        result=lab.get(result_id)
        if result.data["verdict"]=="PARETO_SET":
            passes.append("The kernel no longer invents one 'best' candidate when objectives conflict.")

        # Attack: Candidate metric fields are self-asserted data. Evidence exists but is not tied to each metric.
        fake=lab.add("Candidate","fake miracle",data={"active_state":0.01,"nll":0.1,"latency":0.01},
                     provenance_class="DERIVED",provenance="assistant-guess",identity_key="fake")
        comp2=lab.compare_candidates(order_id=order,candidate_ids=[fake,gru],evidence_ids=[ev],
                                     provenance_class="DERIVED",provenance="stress")
        result2_id=[p["participant_id"] for p in lab.episode(comp2)["participants"] if p["role"]=="result"][0]
        result2=lab.get(result2_id)
        if result2.data["chosen"]==fake:
            breaks.append(
                "Order is explicit, but comparison values are still trusted from Candidate.data. "
                "Unmeasured/self-asserted metrics can defeat real evidence. Measurement provenance must bind "
                "candidate + metric + value + frame/execution."
            )

        print("V0.13 ORDER STRESS")
        print("------------------")
        print("PASS:")
        for x in passes: print("-",x)
        print("\nNEXT BREAK:")
        for i,x in enumerate(breaks,1): print(f"{i}. {x}")
    finally:
        lab.close()
