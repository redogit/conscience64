# Orbit Lab Alpha 0.15 — Current

Default research verification is now obligation-local.

Examples:

```bash
python verify_task.py --profile campaign-integrity
python verify_task.py --profile claim-admission
python verify_task.py --obligation compile --obligation human-card
```

Promotion/release still runs the full suite:

```bash
python -m unittest discover -s tests -q
```

Validated state:
- 160/160 full regressions PASS
- 21/21 selector components resolved in bounded level validation
- 73/73 selector obligations resolved
- 68 obligations available to task-local carrier
- `regression` deliberately release-only
- 680-byte active obligation/probe incidence body
- zero new kernel schema types

Known orchestration remainder: the monolithic public selector process can exceed the host wrapper window; bounded selector levels are clean.
