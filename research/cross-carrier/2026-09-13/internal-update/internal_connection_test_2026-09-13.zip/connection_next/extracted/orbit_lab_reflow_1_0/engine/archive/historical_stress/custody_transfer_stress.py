
import tempfile
from pathlib import Path
from orbit_lab import OrbitLab
with tempfile.TemporaryDirectory() as td:
    lab=OrbitLab(Path(td)/"stress.db"); passes=[]; breaks=[]
    try:
        a=lab.add("Context","Source context",provenance_class="TEST",provenance="stress",identity_key="ctx:A")
        b=lab.add("Context","Destination context",provenance_class="TEST",provenance="stress",identity_key="ctx:B")
        content=lab.register_content(algorithm="sha256",digest="deadbeef",provenance_class="PRIMARY_ARTIFACT",provenance="hash")
        src=lab.record_occurrence(content_id=content,locator="/source/report.md",context_id=a,
                                  provenance_class="PRIMARY_ARTIFACT",provenance="source",identity_key="src")
        dst_copy=lab.record_occurrence(content_id=content,locator="/dest/report.md",context_id=b,
                                       provenance_class="PRIMARY_ARTIFACT",provenance="destination",identity_key="dst")
        if lab.same_content(src,dst_copy) and src!=dst_copy:
            passes.append("Same content and different historical occurrence are now first-class.")

        obligation=lab.add("Obligation","preserve bytes and provenance",provenance_class="TEST",provenance="stress",identity_key="ob")
        evidence=lab.add("Evidence","copy hash verified",provenance_class="TEST",provenance="stress",identity_key="ev",epistemic="OBSERVED")
        lab.transfer(source_context_id=a,destination_context_id=b,entity_id=src,
            obligation_ids=[obligation],evidence_entity_ids=[evidence],
            requested_operations=["PRESERVE"],result="PRESERVED",reason="copy completed",
            provenance_class="TEST",provenance="stress")

        breaks.append(
            "Identity is split, but TRANSFER still names only the source Entity and contexts. "
            "It does not bind the destination Occurrence, so it cannot distinguish COPY (new occurrence), "
            "MOVE (same occurrence changes custody/location), or CONTENT_RECONSTRUCTION (new occurrence with same content)."
        )
        breaks.append(
            "No custody chain exists. An Occurrence stores context/actor as immutable data, but later custody changes "
            "cannot be represented without either creating a new occurrence or inventing free-form history. "
            "The model has identity, but not possession/location transition semantics."
        )

        print("V0.23 IDENTITY / CUSTODY STRESS")
        print("-------------------------------")
        print("PASS:"); [print("-",x) for x in passes]
        print("\nNEXT BREAKS:"); [print(f"{i}. {x}") for i,x in enumerate(breaks,1)]
    finally: lab.close()
