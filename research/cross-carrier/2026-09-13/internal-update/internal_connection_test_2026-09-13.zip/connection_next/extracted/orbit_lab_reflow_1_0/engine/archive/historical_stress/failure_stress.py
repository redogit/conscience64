
import tempfile
from pathlib import Path
from orbit_lab import OrbitLab
with tempfile.TemporaryDirectory() as td:
    lab=OrbitLab(Path(td)/"stress.db"); passes=[]; breaks=[]
    try:
        c=lab.add("Context","C",provenance_class="TEST",provenance="stress",identity_key="c")
        a=lab.add("Actor","operator",provenance_class="TEST",provenance="stress",identity_key="a")
        s=lab.add("Scope","helper routing",provenance_class="TEST",provenance="stress",identity_key="s")
        x=lab.add("Candidate","helper relation",provenance_class="TEST",provenance="stress",identity_key="x")
        signal=lab.add("Evidence","recent anchored transient",provenance_class="TEST",provenance="stress",
                       identity_key="signal",epistemic="OBSERVED")
        lab.record_adaptation(context_id=c,actor_id=a,entity_id=x,scope_id=s,
            action="temporarily downweight helper",basis_entity_ids=[signal],
            rollback_condition="signal returns to baseline",max_exposure="one protected cycle",
            provenance_class="TEST",provenance="stress")
        frame=lab.add("ValidityFrame","current frame",data={"conditions":{"residual":"R1","interface":"I1"}},
                      provenance_class="TEST",provenance="stress",identity_key="frame")
        witness=lab.add("Evidence","persistent change witness",provenance_class="TEST",
                        provenance="stress",identity_key="witness",epistemic="OBSERVED")
        lab.record_promotion(context_id=c,entity_id=x,scope_id=s,validity_frame_id=frame,
            witness_entity_id=witness,basis_entity_ids=[witness],
            change_claim="helper relation persistently changed",
            revalidation_rule="revalidate on residual/interface change",
            provenance_class="TEST",provenance="stress")
        passes.append("Temporary reversible action and persistent scientific promotion are separate history Episodes.")

        # Failure pressure: a failed verification can occur in a tool/harness while its cause is
        # unknown or elsewhere. Current Remainder typed unknown is not enough to connect failed
        # action, location, hypothesized cause, and evidence.
        failed_probe=lab.add("Probe","verification",provenance_class="TEST",provenance="stress",identity_key="probe")
        failure_obs=lab.add("Observation","verification exited nonzero",
                            data={"location":"confirmation harness","exit_code":1},
                            provenance_class="TEST",provenance="stress",identity_key="obs",epistemic="OBSERVED")
        breaks.append(
            "Failure location and failure cause still collapse into free-form Observation data. "
            "The corpus explicitly requires them separate because cause may be unknown or multicausal. "
            "We need a failure record that can preserve observed location without inventing cause."
        )
        print("V0.27 CHANGE / FAILURE STRESS")
        print("-----------------------------")
        print("PASS:"); [print("-",x) for x in passes]
        print("\nNEXT PRESSURE:"); [print(f"{i}. {x}") for i,x in enumerate(breaks,1)]
    finally: lab.close()
