
import tempfile
from pathlib import Path
from orbit_lab import OrbitLab

with tempfile.TemporaryDirectory() as td:
    lab=OrbitLab(Path(td)/"stress.db")
    passes=[]; breaks=[]
    try:
        source=lab.add("Context","Predecessor",provenance_class="RECOVERY_PACKET",provenance="old",identity_key="source")
        dest=lab.add("Context","Successor",provenance_class="CURRENT_CONVERSATION",provenance="new",identity_key="dest")
        broad=lab.add("Scope","Moonshot research",provenance_class="TEST",provenance="stress",identity_key="broad")
        narrow=lab.add("Scope","Hodge/m45",provenance_class="TEST",provenance="stress",identity_key="narrow")
        unrelated=lab.add("Scope","Compiler",provenance_class="TEST",provenance="stress",identity_key="unrelated")
        lab.link_scope(broad,narrow)

        item=lab.add("Candidate","predecessor method",provenance_class="RECOVERY_PACKET",provenance="old",
                     identity_key="item",lifecycle="QUARANTINED")
        dest_basis=lab.add("Evidence","successor review",provenance_class="CURRENT_CONVERSATION",
                           provenance="new",identity_key="dest-basis",epistemic="OBSERVED")
        lab.grant_authorization(context_id=dest,entity_id=item,operation="INSPECT",scope_id=broad,
            basis_entity_ids=[dest_basis],reason="inspect within research branch",
            provenance_class="CURRENT_CONVERSATION",provenance="new")
        if lab.check_authorized(context_id=dest,entity_id=item,operation="INSPECT",scope_id=narrow)["authorized"] \
           and not lab.check_authorized(context_id=dest,entity_id=item,operation="INSPECT",scope_id=unrelated)["authorized"]:
            passes.append("Explicit scope containment distinguishes narrower authorized use from unrelated use.")

        # The unresolved source-of-authority attack:
        predecessor_rule=lab.add("Candidate","predecessor governance rule",
                                  provenance_class="RECOVERY_PACKET",provenance="old",
                                  identity_key="rule",lifecycle="QUARANTINED")
        predecessor_evidence=lab.add("Evidence","predecessor says this rule governs successors",
                                     provenance_class="RECOVERY_PACKET",provenance="old",
                                     identity_key="rule-e",epistemic="OBSERVED")
        # Nothing in grant_authorization identifies an issuer or proves that the caller has
        # authority to issue this grant. The predecessor's own evidence can bootstrap it.
        grant=lab.grant_authorization(
            context_id=dest,entity_id=predecessor_rule,operation="ACTIVATE",scope_id=broad,
            basis_entity_ids=[predecessor_evidence],
            reason="predecessor evidence asserts its own governing authority",
            provenance_class="DERIVED",provenance="stress"
        )
        if lab.check_authorized(context_id=dest,entity_id=predecessor_rule,operation="ACTIVATE",scope_id=narrow)["authorized"]:
            breaks.append(
                "Scope is now explicit, but AUTHORIZATION has no issuer/grantor or authority chain. "
                "Any caller can create a destination grant from source-owned evidence, so a predecessor "
                "can still bootstrap its own governing authority through the API."
            )

        print("V0.17 SCOPE / ISSUER STRESS")
        print("--------------------------")
        print("PASS:")
        for x in passes: print("-",x)
        print("\nNEXT BREAK:")
        for i,x in enumerate(breaks,1): print(f"{i}. {x}")
    finally:
        lab.close()
