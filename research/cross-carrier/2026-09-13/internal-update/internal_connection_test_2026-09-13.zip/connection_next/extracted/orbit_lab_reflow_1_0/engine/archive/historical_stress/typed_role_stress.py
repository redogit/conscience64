
import tempfile
from pathlib import Path
from orbit_lab import OrbitLab

with tempfile.TemporaryDirectory() as td:
    lab=OrbitLab(Path(td)/"stress.db")
    passes=[]; breaks=[]
    try:
        frame=lab.add("ObservationFrame","aliased frame",data={
            "observer":"observer-A",
            "apparatus":"sampled sensor",
            "accessible_variables":["y"],
            "resolution":"1000 ms",
            "intervention":"none",
            "boundary":"delay sweep"
        },provenance_class="TEST",provenance="stress",identity_key="frame")
        passes.append("ObservationFrame now carries the fields that determine observability.")

        col=lab.add("Collection","Micro-Ouro research branch",
                    provenance_class="LIBRARY_ARTIFACT",provenance="library",
                    identity_key="collection")
        subject=lab.add("Subject","Does recurrent depth improve exact recall?",
                        provenance_class="CURRENT_CONVERSATION",provenance="conversation",
                        identity_key="subject")
        lab.add_to_collection(col,subject,note="one current question within the branch")
        lab.pin("subject",subject)
        passes.append("Persistent branch container is separated from current Subject.")

        # Deeper attack: Episode role contracts validate role names, not participant types.
        wrong_source=lab.add("Claim","I am not a representation",
                             provenance_class="TEST",provenance="stress",identity_key="wrong")
        wrong_target=lab.add("Remainder","I am not a representation either",
                             data={"unknown_type":"OTHER"},
                             provenance_class="TEST",provenance="stress",identity_key="wrong2")
        ob=lab.add("Obligation","preserve behavior",
                   provenance_class="TEST",provenance="stress",identity_key="ob")
        ev=lab.add("Evidence","comparison",
                   provenance_class="TEST",provenance="stress",identity_key="ev",epistemic="OBSERVED")
        lab.add_episode(
            "FAITHFUL_TRANSPORT","type-invalid but role-complete",
            participants=[
                {"role":"source","object_id":wrong_source},
                {"role":"target","object_id":wrong_target},
                {"role":"obligation","object_id":ob},
                {"role":"evidence","object_id":ev},
            ],
            provenance_class="TEST",provenance="stress"
        )
        breaks.append(
            "Episode contracts enforce role presence but not role type. "
            "FAITHFUL_TRANSPORT accepted Claim→Remainder as source/target."
        )

        # Same for counterfactual: controls can be arbitrary entities.
        cand=lab.add("Candidate","link",provenance_class="TEST",provenance="stress",identity_key="cand")
        reset=lab.add("Artifact","reset",provenance_class="TEST",provenance="stress",identity_key="reset")
        bogus_control=lab.add("Boundary","not an execution",provenance_class="TEST",provenance="stress",identity_key="bc")
        bogus_treat=lab.add("Decision","also not an execution",provenance_class="TEST",provenance="stress",identity_key="bt")
        result=lab.add("Observation","result",provenance_class="TEST",provenance="stress",identity_key="res",epistemic="OBSERVED")
        lab.add_episode(
            "MATCHED_COUNTERFACTUAL","role-complete but type-invalid",
            participants=[
                {"role":"candidate","object_id":cand},
                {"role":"reset","object_id":reset},
                {"role":"control","object_id":bogus_control},
                {"role":"treatment","object_id":bogus_treat},
                {"role":"result","object_id":result},
            ],
            provenance_class="TEST",provenance="stress"
        )
        breaks.append(
            "MATCHED_COUNTERFACTUAL accepts non-execution control/treatment participants. "
            "Role semantics are not machine-checkable yet."
        )

        print("V0.7 FRAME/COLLECTION STRESS")
        print("----------------------------")
        print("PASS:")
        for x in passes: print("-",x)
        print("\nNEXT BREAK:")
        for i,x in enumerate(breaks,1): print(f"{i}. {x}")
    finally:
        lab.close()
