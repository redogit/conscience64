# Orbit Lab Alpha 0.21 — Method Relevance / Authority Boundary

The remaining Operator Moonshot recovery-method material exposed a generic seam:

`method relevance != method authority`.

Orbit Lab already had `METHOD_COMPLIANCE` with `CURRENT`, `PREDECESSOR`, `WRONG_METHOD`, `OBSOLETE`, and `UNKNOWN`. The missing connection was claim admission.

Alpha 0.21 adds a claim-local `evidence_method_compliance_contract` that binds cited evidence to an exact Method, Context, Scope, and allowed compliance verdicts. The compliance verdict comes from METHOD_COMPLIANCE episodes, not from filenames, evidence tags, or self-declared source roles.

Bounded attack:
- historical recovery prompt retains predecessor relevance;
- it cannot satisfy a claim requiring CURRENT compliance;
- exact active procedure can;
- a later OBSOLETE assessment causes audit to invalidate the previously CURRENT-supported claim.

The active procedure identity is `beefec...22f8`; the active schema identity is `72a39b...14ae`.

No new kernel object or Episode type is added.
