# Conversation Recovery State — Distinction Physics

## 1. Origin of this branch

The branch began by reopening a possibility beneath the apparent GR-versus-quantum-theory crack: the disagreement might not merely be between the two theories. Both may share a primitive distinction that was made too early.

The user then identified an even smaller starting point:

```text
THIS | NOT-THIS
```

This was treated cautiously: not as a complete ontology and not as classical logical negation, but as the minimal presence of a distinction. The investigation therefore moved from naming things to attacking candidate boundaries.

The recurring destructive rule is:

```text
remove/merge a distinction
→ observe consequential failure
→ restore only what the failure forces
```

The inverse discipline also applies: if a preserved distinction can be removed without consequential loss in the registered scope, merge it there without claiming universal identity.

## 2. Original target map

Three targets were deliberately kept unresolved:

```text
<?>_SPACE
<?>_TIME
<?>_GRAVITY
```

and pairwise/joint relations were also left open:

```text
<?>_(SPACE↔TIME)
<?>_(SPACE↔GRAVITY)
<?>_(TIME↔GRAVITY)
<?>_(SPACE↔TIME↔GRAVITY)
```

The GR/quantum seam was then used as an adversarial comparison surface rather than as a presumed final partition.

## 3. Early cross-theory map

An early map tentatively treated:

- `time_GR | time_QM` as a structural split,
- `space_GR | space_QM` as needing reopening,
- `gravity_GR | gravity_QM` as needing reopening because no experimentally established quantum-gravity object exists to compare symmetrically,
- `dynamical geometry | supplied/background geometry` as a useful role distinction.

This was intentionally provisional.

## 4. Relation-record correction

The user supplied a note titled **“Classify the Tested Relation, Not the Thing.”** Its minimal record was:

```text
(B, δ, O, S) → ΔO
```

The active synthesis retained the structure but changed the measurement symbol to `M` to avoid collision with OLU's `O = Obligation`:

```text
(B, δ, M, S) → ΔM
```

Optional research envelope:

```text
Obligation |
[(B, δ, M, S) → ΔM] |
(Empirical witness, Structural witness, Confounds, Remainder)
→ bounded verdict
```

The record prevents a result such as `ΔM=0` from becoming “the things are identical,” and prevents a bounded required distinction from becoming “universally fundamental.”

## 5. Science pass 001 — relational time

### Quantum-side attack

Baseline: finite-dimensional quantum evolution described using an external Schrödinger time parameter.

Intervention: replace the external-time description with a stationary joint clock+system state and condition on internal clock readings.

Registered measures: conditional system-state fidelity and independent-basis probabilities.

Tested finite dimensions included `d = 2, 3, 4, 5, 8, 16`; an independent exact symbolic benchmark was performed at `d=4`.

Primary bounded result: the relational construction reproduced the registered external predictions to floating error (reported maximum infidelity on the order of `8.9e-16`) and exactly in the symbolic benchmark.

A product-state control removing clock-system correlation destroyed the predictive agreement. Therefore merely adding a clock is insufficient; the correlation structure matters.

A first attempted destructive control used a cyclic energy-label permutation. It unexpectedly preserved the registered discrete-time predictions because the permutation contributed only a global phase at the chosen roots-of-unity clock readings. This was preserved as a **failed control**, not counted as support. A non-affine swap was then used and did break the agreement.

Bounded verdict:

```text
external-time description | internal relational-clock description
→ MERGE
```

**Scope:** only the tested finite Page–Wootters-type constructions and registered predictions.

Non-claim: this does not show that time is emergent, nonexistent, or fundamentally relational.

### GR-side analogue

For two static clocks in Schwarzschild geometry:

```text
dτ_i = sqrt(1 - 2GM/(r_i c²)) dt
```

The shared coordinate-time intermediary was removed algebraically to obtain a direct proper-clock relation:

```text
(dτ_2/dτ_1)
= sqrt[(1 - 2GM/(r_2 c²))/(1 - 2GM/(r_1 c²))]
```

The two routes agreed to very high numerical precision in the audit. Thus coordinate-time mediation can be merged away for this registered static clock-rate comparison.

Bounded verdict:

```text
coordinate-time intermediary | direct proper-clock relation
→ MERGE
```

**Scope:** static Schwarzschild clock comparison only.

### Map correction caused by pass 001

The earlier global classification

```text
time_GR | time_QM → SPLIT
```

was too coarse and was changed to:

```text
time_GR | time_QM → REOPEN
```

because the quantum side is not exhausted by an external-time role and GR observables can also be expressed relationally.

## 6. Science pass 002 — interaction, clock resolution, and gravity bridge

### Interaction is not the boundary

A stationary interacting clock-system propagation Hamiltonian was constructed whose history state encoded a sequence of system states.

Across six finite deterministic cases, conditioning on the clock reproduced the registered external dynamics to numerical precision; an exact symbolic `d=2, T=3` case had the intended stationary history state/unique nullspace.

Corrupting one propagation unitary or replacing dynamics with identity controls broke agreement.

Bounded verdict:

```text
noninteracting relational clock | interacting relational clock
→ MERGE
```

within the tested constructed models.

Small perturbations produced approximately quadratic infidelity scaling (`~ g²`) across the finite panel, but no universal law was claimed from that observation.

### Clock-resolution attack

Clock readings were blurred into neighboring readings with probability `epsilon`.

The exact coherence transfer factor was:

```text
φ_q = (1-ε) + ε cos(2πq/d)
```

For `q=0`, populations are exactly preserved:

```text
φ_0 = 1
```

but nonzero coherences are generally attenuated.

Thus the **same intervention** received different verdicts depending on the measured consequence:

```text
blurred clock readout, M = energy populations
→ MERGE

blurred clock readout, M = phase/coherence/Fourier observables
→ SPLIT
```

This became a direct demonstration of the user's principle: classify the tested relation, not the clock as a whole.

### GR → quantum-clock semiclassical bridge

Using the static Schwarzschild clock relation and ordinary quantum phase/frequency accumulation, a 1 mm illustrative height difference near Earth gave a fractional clock-rate shift around:

```text
1.090206290109928e-19
```

For an illustrative 429 THz optical transition this corresponds to an illustrative frequency difference around `4.68e-5 Hz`, with phase accumulation proportional to duration.

Independent optical-clock experiments have measured gravitational redshift at millimetre scales. This supports the semiclassical chain:

```text
spatial/gravitational relation
→ proper-time difference
→ quantum clock phase/frequency difference
```

Non-claim: classical curved geometry affecting quantum matter is not evidence that gravity itself is quantized.

### Gravity-entanglement structural toy

For two path qubits with branch-dependent interaction phases, the exact pure-state concurrence was found to depend on the mixed phase:

```text
Δ×φ = φ00 + φ11 - φ01 - φ10
C = |sin(Δ×φ / 2)|
```

The phase table can be decomposed into independent local contributions `φ_ij = a_i + b_j` if and only if the mixed phase obstruction vanishes.

Therefore within this toy model:

```text
nonseparable joint phase | additive local phase
→ SPLIT
```

for the entanglement measure.

Collapsing the spatial path distinction also removes the entanglement witness.

Critical ceiling: the Hamiltonian already assumes a branch-dependent quantum gravitational interaction. It cannot establish that real gravity is quantum.

Current empirical verdict:

```text
classical gravity | quantum gravity
→ UNRESOLVED
```

for direct gravity-mediated nonclassicality.

## 7. Wolfram-directed structural advance

Wolfram was used as an independent symbolic/tensor tool rather than as an ontology source.

### Mixed second difference

For a general radial interaction `f(R)` with branch displacements `x` and `y`, the mixed difference is:

```text
Δ×f = f(R) + f(R+y-x) - f(R+y) - f(R-x)
```

Its small-displacement expansion begins:

```text
Δ×f = -xy f''(R)
      + (x²y/2) f‴(R)
      - (xy²/2) f‴(R)
      + (x²y²/4) f⁗(R)
      + ...
```

So the leading interaction-bearing term is a **difference of differences**. For affine `f`, `f''=0`, so this leading mixed obstruction disappears.

For a `1/R` interaction the leading scale is `~ 1/R³`.

This motivated, but did not ontologically establish, the candidate:

```text
Δ(Δ) ≠ 0
```

as an interaction-bearing structure.

### Schwarzschild tidal tensor vs Newtonian Hessian

Using one explicit Riemann sign convention, Wolfram returned the Schwarzschild static orthonormal tidal components:

```text
R_{0i0j} = diag(-r_s/r³, r_s/(2r³), r_s/(2r³))
```

with zero trace outside the source.

Using `r_s = 2GM/c²`:

```text
R_{0i0j}
= (1/c²) diag(-2GM/r³, GM/r³, GM/r³)
```

An independent Newtonian-potential Hessian calculation for `Φ=-GM/r` on a radial axis gave:

```text
Hess Φ = diag(-2GM/r³, GM/r³, GM/r³)
```

again with zero trace.

Thus in the registered weak-field/sign-convention boundary:

```text
R_{0i0j} ↔ (1/c²) ∂i∂j Φ
```

is a structural bridge.

### Rindler destructive control

For flat spacetime in uniformly accelerated Rindler coordinates, the complete Riemann tensor was computed as zero.

So acceleration-like behavior can remain while genuine tidal curvature vanishes.

Bounded distinction:

```text
uniform/local acceleration | tidal curvature
→ SPLIT
```

**Structural witness:** exact curvature calculation.

At that point an empirical witness had not yet been separately audited in the conversation.

## 8. External research direction — quantum observables sensitive to curvature

SciSpace was deliberately pointed at literature connecting Riemann/tidal curvature to quantum phases/coherence rather than at vague “quantum gravity.” Relevant results returned included:

- Chiao & Speliotopoulos (2003), *Quantum interference to measure spacetime curvature*, deriving an atom-interferometric phase sensitive to `R_{0i0j}`.
- Singh, Khanna & Kothawala (2023), *Decoherence due to Spacetime Curvature*, explicitly separating curvature/tidal effects from non-inertial kinematics in a quantum setting.
- Swan & Hogan (2025 preprint), *Atom Interferometer Phase Shear and Spacetime Sectional Curvature*, expressing a phase-shear observable through integrated sectional curvature.

A SciSpace attempt to add an enrichment/findings column failed to resolve its own returned identifiers. This was preserved as a retrieval-layer failure and not treated as evidence.

## 9. Empirical curvature witness found

The conversation then identified a stronger existing experiment: Asenbaum, Overstreet, Kim, Curti & Kasevich, *Phase Shift in an Atom Interferometer due to Spacetime Curvature across its Wave Function* (Physical Review Letters 118, 183602, 2017).

The reported setup isolates a tidal/curvature-dependent quantum phase across an extended atom-interferometer wavefunction. This changes the status of the question:

```text
Can a quantum observable distinguish tidal curvature from local acceleration?
```

from merely structural/proposed to **experimentally witnessed within the classical-gravity/quantum-matter regime**.

This is still not quantum gravity; the gravitational background is classical.

## 10. Minimal exact curvature filter

A local exact-symbolic calculation independently verified the centered second-difference operator:

```text
D²_h[Φ](x) = Φ(x+h) - 2Φ(x) + Φ(x-h)
```

For any affine potential:

```text
Φ(x)=a+bx
D²_h[Φ]=0
```

For a quadratic potential:

```text
Φ(x)=a+bx+(1/2)Γx²
D²_h[Φ]=Γh²
```

For Newtonian `Φ(x)=-μ/x`:

```text
D²_h[Φ]
= -2 μ h² / [x(x-h)(x+h)]
= -2 μ h²/x³ - 2 μ h⁴/x⁵ + O(h⁶)
```

This is an operational curvature/tidal filter: constant and linear terms are annihilated, while the quadratic/tidal term survives.

A Wolfram call for this particular substep failed due to a network error, so this result was taken only from the independent local exact-symbolic computation.

## 11. Current map — high-value entries

### `THIS | NOT-THIS`

- **Verdict:** PRESERVE
- **Witness:** structural only
- **Scope:** minimal nontrivial representation/inference
- **Non-claim:** not ontology.

### `external time | relational clock`

- **Verdict:** MERGE for some finite registered quantum predictions.
- **Global status of time itself:** REOPEN.

### `noninteracting relational clock | interacting relational clock`

- **Verdict:** MERGE in tested finite history-state constructions.

### `ideal clock | blurred clock`

- **Energy populations:** MERGE.
- **Phase/coherence:** SPLIT.

### `here | there`

- **As a primitive:** REOPEN.
- **For gravitational clock-rate consequence:** different metric/potential relation must be PRESERVED.

### `uniform acceleration | tidal curvature`

- **Verdict:** SPLIT.
- **Structural witness:** Schwarzschild curvature vs flat Rindler acceleration.
- **Empirical witness:** atom-interferometric tidal/curvature phase measurements in a classical gravitational background.

### `affine gravitational relation | tidal/non-affine relation`

- **Verdict:** SPLIT for curvature-sensitive phase/second-difference measures.
- **Witness:** exact second-difference annihilation of affine terms; surviving `~1/r³` Newtonian tidal term.

### `space | time`, `space | gravity`, `time | gravity`

- **Verdict:** REOPEN as presumed independent primitives.
- They remain useful independent experimental targets.
- GR coupling does not by itself establish one deeper ontological object.

### `space-time-gravity as one deeper common relation`

- **Verdict:** UNRESOLVED.

### `GR representation | quantum representation`

- **Status:** preserve their present representational distinction when required by the tested scope; do not treat the theory names themselves as fundamental categories.
- More useful seam: `dynamical spacetime structure | supplied/background structure` in conventional formulations.

### `classical gravity | quantum gravity`

- **Verdict:** UNRESOLVED for direct gravitational nonclassicality.

### `quantum probe of classical curvature | observable requiring nonclassical gravity`

- **Verdict:** UNRESOLVED.
- This is now one of the most consequential frontiers.

## 12. Smallest currently justified cross-target structure

A cautious current chain is:

```text
spatial difference
→ difference of gravitational differences
→ Hessian/tidal structure
→ weak-field Riemann curvature
→ relative trajectory / clock / quantum-phase consequence
```

This does not reduce space, time, and gravity to one thing.

A candidate recurring operation is:

```text
Δ(Δ)
```

but it remains a candidate structural motif, not a claimed fundamental primitive.

A stronger scoped statement is currently justified:

> A locally removable first-order acceleration-like effect can coexist with a non-removable differential/tidal relational effect, and quantum matter can be sensitive to that tidal relation.

## 13. Tool routing adopted

Use tools directionally rather than redundantly:

```text
Wolfram      → exact symbolic structure / tensor algebra
SciSpace     → published scientific bridges and counterexamples
Mathbox      → computation/claim audit discipline
local code   → controlled ablations and parameter sweeps
web/current  → present experimental status
OLU/Library  → provenance, scope, failure, recoverability, remainder
```

No tool is an authority on ontology. Each supplies bounded witnesses.

## 14. Important failures preserved

1. Cyclic energy-label destructive control accidentally preserved the quantum result because of a global-phase symmetry at the registered discrete times.
2. A first SymPy simplification of the concurrence identity did not close automatically; an explicit exact algebraic check replaced it.
3. A Wolfram tensor call failed because of malformed `Module` syntax; the same registered calculation was rerun with syntax corrected.
4. A later Wolfram second-difference call failed at the network/tool layer; local exact symbolic algebra was used instead.
5. SciSpace findings-column enrichment failed to resolve the paper IDs returned by its own search; the enrichment was discarded.

None of these failures was promoted into a physics result.

## 15. Current unresolved remainder

The most important unresolved pieces are:

1. reconstruct the measured tidal atom-interferometer phase from the mechanism rather than accepting the published equation as a black box;
2. explicitly ablate constant and linear gravitational terms and verify the tidal phase is invariant to them while vanishing with the curvature term;
3. rewrite the same mechanism in a local relativistic/Fermi-normal form using `R_{0i0j}`;
4. determine which part is merely a quantum probe of classical curvature and which candidate observable, if any, genuinely requires nonclassical gravitational degrees of freedom;
5. preserve space, time, and gravity as separate targets until a tested relation forces a merger or split.

The next action is specified separately in `05_NEXT_ACTION.md`.
