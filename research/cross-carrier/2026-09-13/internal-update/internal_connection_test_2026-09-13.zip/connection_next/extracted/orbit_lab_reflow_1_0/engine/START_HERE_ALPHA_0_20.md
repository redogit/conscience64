# Orbit Lab Alpha 0.20 — Current

Alpha 0.20 integrates one bounded relation at the GR/quantum-theory seam rather than treating theory resemblance as evidence of unification.

Registered relation:

```text
uniform/local acceleration | tidal curvature
        -> quantum interferometer phase
```

Structural result:
- `D2[a+bz]=0`;
- `D2[a+bz+(q/2)z^2]=q h^2`;
- half-recoil shift in the gravity-gradient phase gives exactly `phi_tidal=(hbar/(2m))*K^2*Tzz*T^3`;
- constant potential and uniform-linear terms do not change this tidal recoil-difference;
- `Tzz=0` removes it.

Local relativistic transport, under the explicitly registered sign convention:
`Tzz=-c^2 R_0z0z`, so `phi_tidal=-(hbar K^2 c^2/(2m)) R_0z0z T^3`.

Witness discipline:
- structural derivation alone cannot certify an empirical measurement claim;
- empirical measurement alone cannot certify the structural reconstruction;
- together they support the bounded bridge;
- the same evidence cannot certify that gravity itself is quantum.

External empirical source: Asenbaum et al., PRL 118, 183602 (2017), DOI 10.1103/PhysRevLett.118.183602.

Validation:
- 185/185 regressions PASS
- 26 selector components / 95 obligations
- gr-qm-tidal task profile PASS
- direct S5 whole integration PASS
- strict path successor of Alpha 0.19
- zero new kernel object/Episode types

Preserved provenance remainder: the recovered finite-difference source executes and reproduces the same mathematical expressions, but its stdout is not byte-identical to the archived output because one printed label differs. This is not treated as a physics contradiction.
