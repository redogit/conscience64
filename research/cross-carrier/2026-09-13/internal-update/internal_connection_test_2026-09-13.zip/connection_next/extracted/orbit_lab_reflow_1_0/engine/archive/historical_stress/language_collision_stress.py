
import tempfile
from pathlib import Path
from orbit_lab import OrbitLab
with tempfile.TemporaryDirectory() as td:
    lab=OrbitLab(Path(td)/"stress.db"); passes=[]; breaks=[]
    try:
        probe=lab.add("Probe","confirmation run",provenance_class="TEST",provenance="stress",identity_key="p")
        harness=lab.add("Artifact","confirmation harness",provenance_class="TEST",provenance="stress",identity_key="h")
        obs=lab.add("Observation","nonzero exit",data={"exit_code":1},
                    provenance_class="TEST",provenance="stress",identity_key="o",epistemic="OBSERVED")
        frame=lab.add("ObservationFrame","failure frame",data={"observer":"process","apparatus":"confirmation harness","accessible_variables":["exit_code"],"resolution":"1","intervention":"execute","boundary":"confirmation"},
                      provenance_class="TEST",provenance="stress",identity_key="frame")
        failure=lab.record_failure(subject_entity_id=probe,location_entity_id=harness,
            observation_id=obs,frame_id=frame,cause_status="UNKNOWN",provenance_class="TEST",provenance="stress")
        if lab.episode(failure)["data"]["cause_status"]=="UNKNOWN":
            passes.append("Observed failure location can be retained without inventing a cause.")

        c1=lab.add("Inference","temporary module registration defect",provenance_class="DERIVED",
                   provenance="analysis",identity_key="c1")
        c2=lab.add("Inference","language semantic defect",provenance_class="DERIVED",
                   provenance="analysis",identity_key="c2")
        contested=lab.record_failure(subject_entity_id=probe,location_entity_id=harness,
            observation_id=obs,frame_id=frame,cause_status="CONTESTED",cause_entity_ids=[c1,c2],
            provenance_class="DERIVED",provenance="stress")
        passes.append("Competing causal explanations can coexist without overwriting the observed failure.")

        # Meta-research pressure: sometimes the failure is not in the scientific candidate at all;
        # the vocabulary/schema maps two cases requiring different actions to one description.
        case_a=lab.add("Artifact","Case A: acquire more evidence",provenance_class="TEST",provenance="stress",identity_key="a")
        case_b=lab.add("Artifact","Case B: repair measurement",provenance_class="TEST",provenance="stress",identity_key="b")
        breaks.append(
            "The research corpus explicitly tracks LANGUAGE_COLLISION / ONTOLOGY_LEAKAGE: when one schema "
            "description covers cases requiring different actions, the failure belongs to the representation "
            "itself, not either scientific case. Orbit Lab has no first-class way to record that its own vocabulary "
            "is insufficient and require a schema repair before inference continues."
        )
        print("V0.28 FAILURE / LANGUAGE-COLLISION STRESS")
        print("----------------------------------------")
        print("PASS:"); [print("-",x) for x in passes]
        print("\nNEXT PRESSURE:"); [print(f"{i}. {x}") for i,x in enumerate(breaks,1)]
    finally: lab.close()
