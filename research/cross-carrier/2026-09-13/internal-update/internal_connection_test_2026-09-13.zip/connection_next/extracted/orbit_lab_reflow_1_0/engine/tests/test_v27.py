
import tempfile
from pathlib import Path
import unittest
from orbit_lab import OrbitLab
class V27Tests(unittest.TestCase):
    def setUp(self): self.tmp=tempfile.TemporaryDirectory(); self.lab=OrbitLab(Path(self.tmp.name)/"t.db")
    def tearDown(self): self.lab.close(); self.tmp.cleanup()
    def add(self,t,title,key,**kw): return self.lab.add(t,title,provenance_class="TEST",provenance="test",identity_key=key,**kw)
    def test_adaptation_does_not_promote(self):
        c=self.add("Context","C","c"); a=self.add("Actor","A","a"); s=self.add("Scope","S","s")
        x=self.add("Candidate","X","x",epistemic="PROPOSED"); e=self.add("Evidence","signal","e",epistemic="OBSERVED")
        ep=self.lab.record_adaptation(context_id=c,actor_id=a,entity_id=x,scope_id=s,
            action="temporarily reweight X",basis_entity_ids=[e],rollback_condition="signal clears",
            max_exposure="1 cycle",provenance_class="TEST",provenance="test")
        self.assertFalse(self.lab.episode(ep)["data"]["persistent_promotion"])
        self.assertEqual(self.lab.get(x).epistemic,"PROPOSED")
    def test_promotion_requires_real_witness(self):
        c=self.add("Context","C","c"); s=self.add("Scope","S","s")
        x=self.add("Candidate","X","x"); f=self.add("ValidityFrame","F","f",data={"conditions":{"domain":"D"}})
        assoc_target=self.add("Artifact","T","t"); assoc_src=self.add("Artifact","S","src")
        assoc=self.lab.record_association(source_entity_id=assoc_src,target_entity_id=assoc_target,scope_id=s,
            relation="MENTIONED",resolution_status="LIBRARY_ID_EXACT",provenance_class="TEST",provenance="test")
        with self.assertRaises(TypeError):
            self.lab.record_promotion(context_id=c,entity_id=x,scope_id=s,validity_frame_id=f,
                witness_entity_id=assoc,basis_entity_ids=[],change_claim="promote X",
                revalidation_rule="retest on frame change",provenance_class="TEST",provenance="test")
    def test_promotion_records_frame_and_revalidation(self):
        c=self.add("Context","C","c"); s=self.add("Scope","S","s"); x=self.add("Candidate","X","x")
        f=self.add("ValidityFrame","F","f",data={"conditions":{"domain":"D"}})
        e=self.add("Evidence","change witness","e",epistemic="OBSERVED")
        ep=self.lab.record_promotion(context_id=c,entity_id=x,scope_id=s,validity_frame_id=f,
            witness_entity_id=e,basis_entity_ids=[e],change_claim="persistent relation changed",
            revalidation_rule="revalidate if frame changes",provenance_class="TEST",provenance="test")
        self.assertTrue(self.lab.episode(ep)["data"]["persistent_promotion"])
if __name__=="__main__": unittest.main()
