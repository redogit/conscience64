# Orbit Lab — Consolidated Integration Lineage through Alpha 0.12

Alpha 0.12 consolidates Alpha 0.6, 0.6.1, 0.7, 0.8, 0.9, 0.10 and 0.11.

Integrated branches: CSOL + One_Level_Up; Language Structure Workbench; TBCL Hodge / Reduction; BGZF; Society / Recovery / Bridge; Fractal Unroll / Mirror; Compact Branching Geometry; and the 3D Tree/Orbit Hybrid shard.

The operational rule is unchanged: source research remains authoritative at its source; Orbit Lab keeps only the distinctions/tests it actually earned. Superseded candidate packages and duplicate intake copies may leave Incoming once continuity is verified.
