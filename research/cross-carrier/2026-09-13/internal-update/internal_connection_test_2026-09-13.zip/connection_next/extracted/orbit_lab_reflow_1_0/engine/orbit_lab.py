
#!/usr/bin/env python3
"""
Orbit Lab alpha 0.4-selector-core — internal research kernel.

Library -> subject-scoped Orbit -> Current -> evidence/correction -> Return.

v0.3 keeps the v0.2 controls and adds the first higher-order relation forced by stress:
- QUARANTINED lifecycle
- first-class Claim
- typed provenance classes
- identity-key deduplication
- relation payloads
- subject-scoped Orbit
- bounded Current with explicit expansion
- cycle protection for SUPERSEDES/CORRECTS
"""

from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
from typing import Optional
import argparse
import datetime as dt
import json
import hashlib
import sqlite3
import uuid

OBJECT_TYPES = {
    "Compass", "Subject", "Obligation", "Boundary", "Probe", "Observation",
    "Evidence", "Inference", "Claim", "Decision", "Remainder", "Candidate",
    "Helper", "Artifact", "Capacity", "Consequence", "ObservationFrame", "Collection", "Parameters", "RunIdentity", "Order", "Measurement", "Context", "Scope", "Authority", "Actor", "Method", "ValidityFrame", "ContentIdentity", "ArtifactInstance", "Occurrence"
}
LIFECYCLES = {
    "QUARANTINED", "DORMANT", "ORBITING", "ACTIVE", "RETURNED",
    "SUPERSEDED", "REJECTED", "UNRESOLVED"
}
EPISTEMIC = {"PROPOSED", "OBSERVED", "TESTED", "SUPPORTED", "DISPROVED", "UNKNOWN", "UNEXPLAINED"}
PROVENANCE_CLASSES = {
    "USER", "CURRENT_CONVERSATION", "LIBRARY_ARTIFACT", "PRIMARY_ARTIFACT",
    "RECOVERY_PACKET", "EXTERNAL_SOURCE", "DERIVED", "TEST", "DEMO"
}
CURRENT_SLOTS = {"subject", "obligation", "boundary", "probe", "observation", "remainder"}

OPERATIONS = {
    "PRESERVE", "INSPECT", "RETRIEVE", "CITE", "USE_AS_EVIDENCE",
    "USE_FOR_DISCOVERY", "MODIFY", "EXECUTE", "ACTIVATE", "TRANSFER",
    "DELEGATE", "VERIFY", "ADJUDICATE", "AUTHORIZE", "SCHEMA_CHANGE", "PROPOSE", "TUNE", "CLEAN_EVALUATE"
}

AUTHORIZATION_RESULTS = {"GRANTED", "DENIED"}
TRANSFER_RESULTS = {"PRESERVED", "FAILED", "UNRESOLVED"}
METHOD_COMPLIANCE_RESULTS = {"CURRENT", "PREDECESSOR", "WRONG_METHOD", "OBSOLETE", "UNKNOWN"}
REPLACEMENT_RESULTS = {"AUTHORITY_REPLACEMENT", "PARTIAL_REPLACEMENT", "DISTINCT_SOURCE_WINDOW", "HISTORICAL_LOCATOR_ONLY", "UNKNOWN_RELATION"}
APPLICABILITY_RESULTS = {"CURRENTLY_APPLICABLE", "CONDITIONALLY_APPLICABLE", "HISTORICALLY_SUPPORTED", "OBSOLETE", "UNKNOWN"}
CUSTODY_MODES = {"REGISTER", "OBSERVE", "COPY", "MOVE", "RECONSTRUCT"}
ASSOCIATION_RESOLUTION_STATUSES = {
    "SOURCE_ID_EXACT", "CONTENT_HASH_EXACT", "LIBRARY_ID_EXACT",
    "BRANCH_SCOPED_FILENAME_MATCH", "DECLARED_SOURCE_NAME_UNRESOLVED",
    "STALE_OR_UNRESOLVED_ID", "CONVERSATION_ONLY_SOURCE",
    "WORKSPACE_OR_ARCHIVE_INTERNAL", "METHOD_CONTEXT_LIBRARY_MATCH",
    "METHOD_CONTEXT_NAME_ONLY", "FILENAME_LIBRARY_MATCH", "LOGICAL_ARTIFACT_ID",
    "UNKNOWN"
}
NON_EVIDENTIARY_EPISODE_KINDS = {"ASSOCIATION"}
ADAPTATION_RESULTS = {"APPLIED", "ROLLED_BACK", "EXPIRED", "REJECTED"}
PROMOTION_RESULTS = {"PROMOTED", "REJECTED", "RETIRED"}
FAILURE_CAUSE_STATUSES = {"UNKNOWN", "HYPOTHESIZED", "SINGLE_SUPPORTED", "MULTICAUSAL", "CONTESTED"}

EXECUTION_STATUSES = {"COMPLETED", "CONFOUNDED", "TOOL_FAILED"}
REPLICATION_GRADES = {"REPLAY", "REPEATABILITY", "PARTIAL", "INDEPENDENT", "UNRESOLVED"}

UNKNOWN_TYPES = {
    "UNOBSERVED", "UNDERDETERMINED", "INACCESSIBLE",
    "MEASUREMENT_INVALID", "CONTRADICTORY", "INCOMPARABLE", "OTHER"
}

EPISODE_CONTRACTS = {
    "EXECUTION": {"run", "probe", "frame", "parameters", "reset", "observation"},
    "REPLICATION_ASSESSMENT": {"original", "candidate", "basis"},
    "MEASUREMENT": {"subject", "measurement", "basis"},
    "COMPARISON": {"order", "candidate", "measurement", "result"},
    "FAITHFUL_TRANSPORT": {"source", "target", "obligation", "evidence"},
    "MATCHED_COUNTERFACTUAL": {"candidate", "reset", "control", "treatment", "result"},
    "CLAIM_ASSESSMENT": {"claim", "frame", "evidence"},
    "ADMISSION": {"candidate", "decision"},
    "CONTEXT_ADMISSION": {"context", "candidate", "decision"},
    "AUTHORITY_ROOT": {"context", "scope", "authority", "holder"},
    "DELEGATION": {"context", "scope", "parent", "authority", "grantee"},
    "REVOCATION": {"authority", "decision"},
    "AUTHORIZATION": {"context", "principal", "entity", "scope", "issuer", "decision"},
    "ACCESS": {"context", "actor", "entity", "scope", "authorization"},
    "TRANSFER": {"source_context", "destination_context", "entity", "obligation", "result"},
    "METHOD_COMPLIANCE": {"context", "entity", "method", "scope", "result"},
    "REPLACEMENT": {"predecessor", "successor", "scope", "result"},
    "APPLICABILITY_ASSESSMENT": {"entity", "historical_frame", "current_frame", "scope", "result"},
    "CONTENT_OCCURRENCE": {"content", "occurrence"},
    "INSTANCE_CONTENT": {"instance", "content"},
    "INSTANCE_OCCURRENCE": {"instance", "occurrence", "context"},
    "CUSTODY_TRANSFER": {"source_context", "destination_context", "source_occurrence", "destination_occurrence", "obligation", "result"},
    "DERIVATION": {"input", "method", "output"},
    "ASSOCIATION": {"source", "target", "scope"},
    "ADAPTATION": {"context", "actor", "entity", "scope", "result"},
    "PROMOTION": {"context", "entity", "scope", "frame", "witness", "result"},
    "FAILURE": {"subject", "location", "observation", "frame"},
}

# Allowed participant descriptors. "EPISODE:*" means any Episode kind.
EPISODE_ROLE_TYPES = {
    "EXECUTION": {
        "run": {"OBJECT:RunIdentity"},
        "probe": {"OBJECT:Probe"},
        "frame": {"OBJECT:ObservationFrame"},
        "parameters": {"OBJECT:Parameters"},
        "reset": {"OBJECT:Artifact"},
        "observation": {"OBJECT:Observation", "OBJECT:Evidence"},
    },
    "COMPARISON": {
        "order": {"OBJECT:Order"},
        "candidate": {"OBJECT:Candidate"},
        "measurement": {"EPISODE:MEASUREMENT"},
        "result": {"OBJECT:Decision"},
    },
    "REPLICATION_ASSESSMENT": {
        "original": {"EPISODE:EXECUTION"},
        "candidate": {"EPISODE:EXECUTION"},
        "basis": {"OBJECT:Evidence", "OBJECT:Observation", "OBJECT:Artifact", "OBJECT:ObservationFrame"},
    },
    "FAITHFUL_TRANSPORT": {
        "source": {"OBJECT:Artifact", "OBJECT:Candidate"},
        "target": {"OBJECT:Artifact", "OBJECT:Candidate"},
        "obligation": {"OBJECT:Obligation"},
        "evidence": {"OBJECT:Evidence", "OBJECT:Observation", "OBJECT:Artifact", "EPISODE:*"},
    },
    "MATCHED_COUNTERFACTUAL": {
        "candidate": {"OBJECT:Candidate"},
        "reset": {"OBJECT:Artifact"},
        "control": {"EPISODE:EXECUTION"},
        "treatment": {"EPISODE:EXECUTION"},
        "result": {"OBJECT:Observation", "OBJECT:Evidence"},
    },
    "CLAIM_ASSESSMENT": {
        "claim": {"OBJECT:Claim"},
        "frame": {"OBJECT:ObservationFrame"},
        "evidence": {"OBJECT:Evidence", "OBJECT:Observation", "OBJECT:Artifact", "EPISODE:*"},
    },
    "ADMISSION": {
        "candidate": {"OBJECT:*"},
        "decision": {"OBJECT:Decision"},
        "evidence": {"OBJECT:Evidence", "OBJECT:Observation", "OBJECT:Artifact", "EPISODE:*"},
    },
    "CONTEXT_ADMISSION": {
        "context": {"OBJECT:Context"},
        "candidate": {"OBJECT:*"},
        "decision": {"OBJECT:Decision"},
        "evidence": {"OBJECT:Evidence", "OBJECT:Observation", "OBJECT:Artifact", "EPISODE:*"},
    },
    "AUTHORIZATION": {
        "context": {"OBJECT:Context"},
        "principal": {"OBJECT:Actor"},
        "entity": {"OBJECT:*", "EPISODE:*"},
        "scope": {"OBJECT:Scope"},
        "issuer": {"OBJECT:Authority"},
        "decision": {"OBJECT:Decision"},
        "basis": {"OBJECT:Evidence", "OBJECT:Observation", "OBJECT:Artifact", "EPISODE:*"},
    },
    "ACCESS": {
        "context": {"OBJECT:Context"},
        "actor": {"OBJECT:Actor"},
        "entity": {"OBJECT:*", "EPISODE:*"},
        "scope": {"OBJECT:Scope"},
        "authorization": {"EPISODE:AUTHORIZATION"},
    },
    "TRANSFER": {
        "source_context": {"OBJECT:Context"},
        "destination_context": {"OBJECT:Context"},
        "entity": {"OBJECT:*", "EPISODE:*"},
        "obligation": {"OBJECT:Obligation"},
        "result": {"OBJECT:Decision"},
        "evidence": {"OBJECT:Evidence", "OBJECT:Observation", "OBJECT:Artifact", "EPISODE:*"},
    },
    "METHOD_COMPLIANCE": {
        "context": {"OBJECT:Context"},
        "entity": {"OBJECT:*", "EPISODE:*"},
        "method": {"OBJECT:Method"},
        "scope": {"OBJECT:Scope"},
        "result": {"OBJECT:Decision"},
        "basis": {"OBJECT:Evidence", "OBJECT:Observation", "OBJECT:Artifact", "EPISODE:*"},
    },
    "REPLACEMENT": {
        "predecessor": {"OBJECT:*", "EPISODE:*"},
        "successor": {"OBJECT:*", "EPISODE:*"},
        "scope": {"OBJECT:Scope"},
        "result": {"OBJECT:Decision"},
        "basis": {"OBJECT:Evidence", "OBJECT:Observation", "OBJECT:Artifact", "EPISODE:*"},
    },
    "APPLICABILITY_ASSESSMENT": {
        "entity": {"OBJECT:*", "EPISODE:*"},
        "historical_frame": {"OBJECT:ValidityFrame"},
        "current_frame": {"OBJECT:ValidityFrame"},
        "scope": {"OBJECT:Scope"},
        "result": {"OBJECT:Decision"},
        "basis": {"OBJECT:Evidence", "OBJECT:Observation", "OBJECT:Artifact", "EPISODE:*"},
    },
    "CONTENT_OCCURRENCE": {
        "content": {"OBJECT:ContentIdentity"},
        "occurrence": {"OBJECT:Occurrence"},
    },
    "INSTANCE_CONTENT": {
        "instance": {"OBJECT:ArtifactInstance"},
        "content": {"OBJECT:ContentIdentity"},
    },
    "INSTANCE_OCCURRENCE": {
        "instance": {"OBJECT:ArtifactInstance"},
        "occurrence": {"OBJECT:Occurrence"},
        "context": {"OBJECT:Context"},
        "actor": {"OBJECT:Actor"},
        "prior_occurrence": {"OBJECT:Occurrence"},
    },
    "CUSTODY_TRANSFER": {
        "source_context": {"OBJECT:Context"},
        "destination_context": {"OBJECT:Context"},
        "source_occurrence": {"OBJECT:Occurrence"},
        "destination_occurrence": {"OBJECT:Occurrence"},
        "obligation": {"OBJECT:Obligation"},
        "result": {"OBJECT:Decision"},
        "evidence": {"OBJECT:Evidence", "OBJECT:Observation", "OBJECT:Artifact", "EPISODE:*"},
    },
    "DERIVATION": {
        "input": {"OBJECT:Occurrence"},
        "method": {"OBJECT:Method"},
        "execution": {"EPISODE:EXECUTION"},
        "output": {"OBJECT:Occurrence"},
        "basis": {"OBJECT:Evidence", "OBJECT:Observation", "OBJECT:Artifact", "EPISODE:EXECUTION"},
    },
    "ASSOCIATION": {
        "source": {"OBJECT:*", "EPISODE:*"},
        "target": {"OBJECT:*", "EPISODE:*"},
        "scope": {"OBJECT:Scope"},
    },
    "ADAPTATION": {
        "context": {"OBJECT:Context"},
        "actor": {"OBJECT:Actor"},
        "entity": {"OBJECT:*", "EPISODE:*"},
        "scope": {"OBJECT:Scope"},
        "result": {"OBJECT:Decision"},
        "basis": {"OBJECT:Evidence", "OBJECT:Observation", "OBJECT:Artifact", "EPISODE:EXECUTION"},
    },
    "PROMOTION": {
        "context": {"OBJECT:Context"},
        "entity": {"OBJECT:*", "EPISODE:*"},
        "scope": {"OBJECT:Scope"},
        "frame": {"OBJECT:ValidityFrame"},
        "witness": {"OBJECT:Evidence", "OBJECT:Observation", "EPISODE:EXECUTION", "EPISODE:REPLICATION_ASSESSMENT"},
        "result": {"OBJECT:Decision"},
        "basis": {"OBJECT:Evidence", "OBJECT:Observation", "OBJECT:Artifact", "EPISODE:EXECUTION", "EPISODE:REPLICATION_ASSESSMENT"},
    },
    "FAILURE": {
        "subject": {"OBJECT:*", "EPISODE:*"},
        "location": {"OBJECT:*", "EPISODE:*"},
        "observation": {"OBJECT:Observation", "OBJECT:Evidence"},
        "frame": {"OBJECT:ObservationFrame"},
        "cause": {"OBJECT:Inference", "OBJECT:Candidate", "OBJECT:Claim"},
        "basis": {"OBJECT:Evidence", "OBJECT:Observation", "OBJECT:Artifact", "EPISODE:EXECUTION"},
    },
}
SLOT_TYPES = {
    "subject": "Subject", "obligation": "Obligation", "boundary": "Boundary",
    "probe": "Probe", "observation": "Observation", "remainder": "Remainder"
}
DEFAULT_LIMITS = {
    "subject": 1,
    "obligation": 5,
    "boundary": 5,
    "probe": 3,
    "observation": 8,
    "remainder": 8,
}


STATE_TABLES = [
    "schema_terms", "schema_roles", "schema_gaps", "schema_changes",
    "entities", "objects", "episodes", "episode_participants", "relations",
    "scope_edges", "context_admission", "admission", "collection_members",
    "current_slots", "current_limits", "orbit_members", "history",
]

STATE_IMPORT_ORDER = [
    "schema_terms", "schema_roles", "schema_gaps",
    "entities", "objects", "episodes", "episode_participants", "relations",
    "schema_changes", "scope_edges", "context_admission", "admission",
    "collection_members", "current_slots", "current_limits", "orbit_members",
    "history",
]

SCHEMA = """
PRAGMA foreign_keys = ON;



CREATE TABLE IF NOT EXISTS schema_terms (
    name TEXT PRIMARY KEY,
    entity_kind TEXT NOT NULL CHECK(entity_kind IN ('OBJECT','EPISODE')),
    status TEXT NOT NULL CHECK(status IN ('ACTIVE','RETIRED')),
    definition TEXT NOT NULL DEFAULT '',
    origin TEXT NOT NULL,
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS schema_roles (
    episode_kind TEXT NOT NULL REFERENCES schema_terms(name),
    role TEXT NOT NULL,
    required INTEGER NOT NULL DEFAULT 0,
    allowed_json TEXT NOT NULL DEFAULT '[]',
    PRIMARY KEY(episode_kind, role)
);

CREATE TABLE IF NOT EXISTS schema_gaps (
    id TEXT PRIMARY KEY,
    gap_kind TEXT NOT NULL CHECK(gap_kind IN ('LANGUAGE_COLLISION','ONTOLOGY_LEAKAGE')),
    current_term TEXT NOT NULL,
    case_a_id TEXT,
    case_b_id TEXT,
    required_action_a TEXT,
    required_action_b TEXT,
    missing_distinction TEXT NOT NULL,
    status TEXT NOT NULL CHECK(status IN ('OPEN','REPAIRED','REJECTED')),
    provenance_class TEXT NOT NULL,
    provenance TEXT NOT NULL,
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS schema_changes (
    id TEXT PRIMARY KEY,
    gap_id TEXT NOT NULL REFERENCES schema_gaps(id),
    proposal_id TEXT,
    promotion_episode_id TEXT,
    authorization_episode_id TEXT,
    actor_id TEXT,
    context_id TEXT,
    scope_id TEXT,
    term_name TEXT NOT NULL,
    entity_kind TEXT NOT NULL CHECK(entity_kind IN ('OBJECT','EPISODE')),
    action TEXT NOT NULL CHECK(action IN ('ADD','REVISE','REJECT')),
    reason TEXT NOT NULL,
    provenance_class TEXT NOT NULL,
    provenance TEXT NOT NULL,
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS entities (
    id TEXT PRIMARY KEY,
    entity_kind TEXT NOT NULL CHECK(entity_kind IN ('OBJECT','EPISODE')),
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS objects (
    id TEXT PRIMARY KEY,
    type TEXT NOT NULL,
    lifecycle TEXT NOT NULL DEFAULT 'DORMANT',
    epistemic TEXT NOT NULL DEFAULT 'UNKNOWN',
    title TEXT NOT NULL,
    data_json TEXT NOT NULL DEFAULT '{}',
    provenance_class TEXT NOT NULL,
    provenance TEXT NOT NULL,
    identity_key TEXT UNIQUE,
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS relations (
    id TEXT PRIMARY KEY,
    from_id TEXT NOT NULL REFERENCES objects(id),
    kind TEXT NOT NULL,
    to_id TEXT NOT NULL REFERENCES objects(id),
    data_json TEXT NOT NULL DEFAULT '{}',
    provenance_class TEXT NOT NULL,
    provenance TEXT NOT NULL,
    created_at TEXT NOT NULL
);


CREATE TABLE IF NOT EXISTS episodes (
    id TEXT PRIMARY KEY,
    kind TEXT NOT NULL,
    title TEXT NOT NULL,
    data_json TEXT NOT NULL DEFAULT '{}',
    provenance_class TEXT NOT NULL,
    provenance TEXT NOT NULL,
    identity_key TEXT UNIQUE,
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS episode_participants (
    episode_id TEXT NOT NULL REFERENCES episodes(id) ON DELETE CASCADE,
    role TEXT NOT NULL,
    participant_id TEXT NOT NULL REFERENCES entities(id) ON DELETE RESTRICT,
    ordinal INTEGER NOT NULL DEFAULT 0,
    required INTEGER NOT NULL DEFAULT 1,
    PRIMARY KEY (episode_id, role, ordinal)
);

CREATE INDEX IF NOT EXISTS idx_episode_kind ON episodes(kind);
CREATE INDEX IF NOT EXISTS idx_episode_participant_entity ON episode_participants(participant_id);



CREATE TABLE IF NOT EXISTS scope_edges (
    parent_scope_id TEXT NOT NULL REFERENCES objects(id) ON DELETE RESTRICT,
    child_scope_id TEXT NOT NULL REFERENCES objects(id) ON DELETE RESTRICT,
    created_at TEXT NOT NULL,
    PRIMARY KEY(parent_scope_id, child_scope_id)
);

CREATE INDEX IF NOT EXISTS idx_scope_child ON scope_edges(child_scope_id);

CREATE TABLE IF NOT EXISTS context_admission (
    context_id TEXT NOT NULL REFERENCES objects(id) ON DELETE CASCADE,
    object_id TEXT NOT NULL REFERENCES objects(id) ON DELETE CASCADE,
    status TEXT NOT NULL,
    decision_episode_id TEXT REFERENCES episodes(id),
    updated_at TEXT NOT NULL,
    PRIMARY KEY(context_id, object_id)
);

CREATE TABLE IF NOT EXISTS admission (
    object_id TEXT PRIMARY KEY REFERENCES objects(id) ON DELETE CASCADE,
    status TEXT NOT NULL,
    decision_episode_id TEXT REFERENCES episodes(id),
    updated_at TEXT NOT NULL
);


CREATE TABLE IF NOT EXISTS collection_members (
    collection_id TEXT NOT NULL REFERENCES objects(id) ON DELETE CASCADE,
    entity_id TEXT NOT NULL REFERENCES entities(id) ON DELETE RESTRICT,
    note TEXT NOT NULL DEFAULT '',
    added_at TEXT NOT NULL,
    PRIMARY KEY(collection_id, entity_id)
);

CREATE INDEX IF NOT EXISTS idx_collection_member_entity ON collection_members(entity_id);

CREATE TABLE IF NOT EXISTS current_slots (
    slot TEXT NOT NULL,
    object_id TEXT NOT NULL REFERENCES objects(id),
    PRIMARY KEY (slot, object_id)
);

CREATE TABLE IF NOT EXISTS current_limits (
    slot TEXT PRIMARY KEY,
    max_items INTEGER NOT NULL,
    reason TEXT NOT NULL DEFAULT 'default'
);

CREATE TABLE IF NOT EXISTS orbit_members (
    subject_id TEXT NOT NULL REFERENCES objects(id),
    object_id TEXT NOT NULL REFERENCES objects(id),
    reason TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL,
    PRIMARY KEY(subject_id, object_id)
);

CREATE TABLE IF NOT EXISTS history (
    seq INTEGER PRIMARY KEY AUTOINCREMENT,
    event TEXT NOT NULL,
    object_id TEXT,
    details_json TEXT NOT NULL DEFAULT '{}',
    created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_objects_type ON objects(type);
CREATE INDEX IF NOT EXISTS idx_objects_lifecycle ON objects(lifecycle);
CREATE INDEX IF NOT EXISTS idx_rel_from ON relations(from_id);
CREATE INDEX IF NOT EXISTS idx_rel_to ON relations(to_id);
CREATE INDEX IF NOT EXISTS idx_orbit_subject ON orbit_members(subject_id);

CREATE TRIGGER IF NOT EXISTS trg_objects_semantic_immutable
BEFORE UPDATE OF type,title,data_json,provenance_class,provenance,identity_key,created_at
ON objects
BEGIN
    SELECT RAISE(ABORT, 'object semantic fields are immutable; create a new object version');
END;

CREATE TRIGGER IF NOT EXISTS trg_episodes_semantic_immutable
BEFORE UPDATE OF kind,title,data_json,provenance_class,provenance,identity_key,created_at
ON episodes
BEGIN
    SELECT RAISE(ABORT, 'episode semantic fields are immutable; create a new episode');
END;

CREATE TRIGGER IF NOT EXISTS trg_episode_participants_immutable_update
BEFORE UPDATE ON episode_participants
BEGIN
    SELECT RAISE(ABORT, 'episode participants are immutable; create a new episode');
END;

CREATE TRIGGER IF NOT EXISTS trg_episode_participants_immutable_delete
BEFORE DELETE ON episode_participants
BEGIN
    SELECT RAISE(ABORT, 'episode participants are immutable; preserve the episode');
END;

CREATE TRIGGER IF NOT EXISTS trg_history_immutable_update
BEFORE UPDATE ON history
BEGIN
    SELECT RAISE(ABORT, 'history is append-only');
END;

CREATE TRIGGER IF NOT EXISTS trg_history_immutable_delete
BEFORE DELETE ON history
BEGIN
    SELECT RAISE(ABORT, 'history is append-only');
END;

CREATE TRIGGER IF NOT EXISTS trg_object_delete_through_entity
BEFORE DELETE ON objects
BEGIN
    DELETE FROM entities WHERE id=OLD.id;
END;

CREATE TRIGGER IF NOT EXISTS trg_episode_delete_through_entity
BEFORE DELETE ON episodes
BEGIN
    DELETE FROM entities WHERE id=OLD.id;
END;

"""

def now_dt() -> dt.datetime:
    return dt.datetime.now(dt.timezone.utc)

def now() -> str:
    return now_dt().isoformat()

def oid(prefix: str = "obj") -> str:
    return f"{prefix}-{uuid.uuid4().hex[:10]}"

@dataclass(frozen=True)
class Obj:
    id: str
    type: str
    lifecycle: str
    epistemic: str
    title: str
    data: dict
    provenance_class: str
    provenance: str
    identity_key: Optional[str]
    created_at: str

class OrbitLab:
    def __init__(self, db_path: str | Path = "orbit_lab.db"):
        self.db_path = Path(db_path)
        self.conn = sqlite3.connect(self.db_path)
        self.conn.row_factory = sqlite3.Row
        self.conn.executescript(SCHEMA)
        self._seed_schema_registry()
        for slot, limit in DEFAULT_LIMITS.items():
            self.conn.execute(
                "INSERT OR IGNORE INTO current_limits(slot,max_items,reason) VALUES(?,?,?)",
                (slot, limit, "default minimal operating limit")
            )
        self.conn.commit()


    def _seed_schema_registry(self):
        """Bootstrap the previously hard-coded vocabulary into the runtime registry.

        The constants remain only as the bootstrap/compatibility source. Runtime
        validation below reads this registry, so evidence-earned extensions no
        longer require editing OBJECT_TYPES/EPISODE_CONTRACTS.
        """
        created=now()
        for name in sorted(OBJECT_TYPES):
            self.conn.execute(
                """INSERT OR IGNORE INTO schema_terms
                   (name,entity_kind,status,definition,origin,created_at)
                   VALUES(?,?,?,?,?,?)""",
                (name,"OBJECT","ACTIVE","legacy v0.28 bootstrap object","BOOTSTRAP",created)
            )
        episode_names=set(EPISODE_CONTRACTS)|set(EPISODE_ROLE_TYPES)
        for name in sorted(episode_names):
            self.conn.execute(
                """INSERT OR IGNORE INTO schema_terms
                   (name,entity_kind,status,definition,origin,created_at)
                   VALUES(?,?,?,?,?,?)""",
                (name,"EPISODE","ACTIVE","legacy v0.28 bootstrap episode","BOOTSTRAP",created)
            )
            required=EPISODE_CONTRACTS.get(name,set())
            roles=EPISODE_ROLE_TYPES.get(name,{})
            all_roles=set(required)|set(roles)
            for role in sorted(all_roles):
                self.conn.execute(
                    """INSERT OR IGNORE INTO schema_roles
                       (episode_kind,role,required,allowed_json)
                       VALUES(?,?,?,?)""",
                    (name,role,1 if role in required else 0,
                     json.dumps(sorted(roles.get(role,set()))))
                )
        self.conn.commit()

    def schema_term(self, name: str) -> dict:
        row=self.conn.execute("SELECT * FROM schema_terms WHERE name=?",(name,)).fetchone()
        if not row:
            raise KeyError(name)
        return dict(row)

    def _schema_known(self, name: str, entity_kind: str) -> bool:
        row=self.conn.execute(
            "SELECT 1 FROM schema_terms WHERE name=? AND entity_kind=? AND status='ACTIVE'",
            (name,entity_kind)
        ).fetchone()
        return row is not None

    def _episode_schema(self, kind: str) -> tuple[set[str], dict[str,set[str]]]:
        if not self._schema_known(kind,"EPISODE"):
            raise ValueError(f"unknown/unadmitted episode kind: {kind}")
        rows=self.conn.execute(
            "SELECT role,required,allowed_json FROM schema_roles WHERE episode_kind=?",
            (kind,)
        ).fetchall()
        required={r["role"] for r in rows if r["required"]}
        allowed={r["role"]:set(json.loads(r["allowed_json"])) for r in rows}
        return required,allowed

    def record_schema_gap(
        self,
        *,
        gap_kind: str,
        current_term: str,
        missing_distinction: str,
        case_a_id: Optional[str]=None,
        case_b_id: Optional[str]=None,
        required_action_a: Optional[str]=None,
        required_action_b: Optional[str]=None,
        provenance_class: str,
        provenance: str,
    ) -> str:
        gap_kind=gap_kind.upper()
        if gap_kind not in {"LANGUAGE_COLLISION","ONTOLOGY_LEAKAGE"}:
            raise ValueError("gap_kind must be LANGUAGE_COLLISION or ONTOLOGY_LEAKAGE")
        if not missing_distinction.strip():
            raise ValueError("missing_distinction required")
        for eid in (case_a_id,case_b_id):
            if eid is not None:
                self.entity_kind(eid)
        gid=oid("schema-gap")
        self.conn.execute(
            """INSERT INTO schema_gaps
               (id,gap_kind,current_term,case_a_id,case_b_id,required_action_a,
                required_action_b,missing_distinction,status,provenance_class,
                provenance,created_at)
               VALUES(?,?,?,?,?,?,?,?,?,?,?,?)""",
            (gid,gap_kind,current_term,case_a_id,case_b_id,required_action_a,
             required_action_b,missing_distinction,"OPEN",provenance_class,
             provenance,now())
        )
        self._event("SCHEMA_GAP_RECORDED",None,gap_id=gid,gap_kind=gap_kind,
                    current_term=current_term,missing_distinction=missing_distinction)
        self.conn.commit()
        return gid

    def _open_schema_gap(self, gap_id: str) -> dict:
        row=self.conn.execute("SELECT * FROM schema_gaps WHERE id=?",(gap_id,)).fetchone()
        if not row:
            raise KeyError(gap_id)
        d=dict(row)
        if d["status"]!="OPEN":
            raise ValueError(f"schema gap is not OPEN: {d['status']}")
        return d


    def _insert_schema_object_type(
        self,
        *,
        gap_id: str,
        type_name: str,
        definition: str,
        reason: str,
        proposal_id: Optional[str],
        promotion_episode_id: Optional[str],
        authorization_episode_id: Optional[str],
        actor_id: Optional[str],
        context_id: Optional[str],
        scope_id: Optional[str],
        provenance_class: str,
        provenance: str,
    ):
        self._open_schema_gap(gap_id)
        if self._schema_known(type_name,"OBJECT"):
            raise ValueError(f"object type already active: {type_name}")
        if not type_name.strip() or not definition.strip() or not reason.strip():
            raise ValueError("type_name, definition, reason required")
        self.conn.execute(
            """INSERT INTO schema_terms
               (name,entity_kind,status,definition,origin,created_at)
               VALUES(?,?,?,?,?,?)""",
            (type_name,"OBJECT","ACTIVE",definition,f"GAP:{gap_id}",now())
        )
        cid=oid("schema-change")
        self.conn.execute(
            """INSERT INTO schema_changes
               (id,gap_id,proposal_id,promotion_episode_id,authorization_episode_id,
                actor_id,context_id,scope_id,term_name,entity_kind,action,reason,
                provenance_class,provenance,created_at)
               VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (cid,gap_id,proposal_id,promotion_episode_id,authorization_episode_id,
             actor_id,context_id,scope_id,type_name,"OBJECT","ADD",reason,
             provenance_class,provenance,now())
        )
        self.conn.execute("UPDATE schema_gaps SET status='REPAIRED' WHERE id=?",(gap_id,))
        self._event("SCHEMA_EXTENDED",None,gap_id=gap_id,term_name=type_name,
                    entity_kind="OBJECT",schema_change_id=cid,
                    proposal_id=proposal_id,promotion_episode_id=promotion_episode_id,
                    authorization_episode_id=authorization_episode_id)
        self.conn.commit()

    def _insert_schema_episode_type(
        self,
        *,
        gap_id: str,
        kind: str,
        definition: str,
        roles: dict[str,dict],
        reason: str,
        proposal_id: Optional[str],
        promotion_episode_id: Optional[str],
        authorization_episode_id: Optional[str],
        actor_id: Optional[str],
        context_id: Optional[str],
        scope_id: Optional[str],
        provenance_class: str,
        provenance: str,
    ):
        self._open_schema_gap(gap_id)
        if self._schema_known(kind,"EPISODE"):
            raise ValueError(f"episode kind already active: {kind}")
        if not kind.strip() or not definition.strip() or not roles or not reason.strip():
            raise ValueError("kind, definition, roles, reason required")
        self.conn.execute(
            """INSERT INTO schema_terms
               (name,entity_kind,status,definition,origin,created_at)
               VALUES(?,?,?,?,?,?)""",
            (kind,"EPISODE","ACTIVE",definition,f"GAP:{gap_id}",now())
        )
        for role,spec in roles.items():
            allowed=set(spec.get("allowed",[]))
            required=bool(spec.get("required",False))
            if not role.strip():
                raise ValueError("role names must be nonempty")
            for descriptor in allowed:
                if ":" not in descriptor:
                    raise ValueError(f"invalid role descriptor: {descriptor}")
                entity_kind,name=descriptor.split(":",1)
                if entity_kind=="OBJECT" and name!="*" and not self._schema_known(name,"OBJECT"):
                    raise ValueError(f"role references unknown object type: {name}")
                if entity_kind=="EPISODE" and name!="*" and not self._schema_known(name,"EPISODE"):
                    raise ValueError(f"role references unknown episode kind: {name}")
            self.conn.execute(
                """INSERT INTO schema_roles
                   (episode_kind,role,required,allowed_json)
                   VALUES(?,?,?,?)""",
                (kind,role,1 if required else 0,json.dumps(sorted(allowed)))
            )
        cid=oid("schema-change")
        self.conn.execute(
            """INSERT INTO schema_changes
               (id,gap_id,proposal_id,promotion_episode_id,authorization_episode_id,
                actor_id,context_id,scope_id,term_name,entity_kind,action,reason,
                provenance_class,provenance,created_at)
               VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (cid,gap_id,proposal_id,promotion_episode_id,authorization_episode_id,
             actor_id,context_id,scope_id,kind,"EPISODE","ADD",reason,
             provenance_class,provenance,now())
        )
        self.conn.execute("UPDATE schema_gaps SET status='REPAIRED' WHERE id=?",(gap_id,))
        self._event("SCHEMA_EXTENDED",None,gap_id=gap_id,term_name=kind,
                    entity_kind="EPISODE",schema_change_id=cid,
                    proposal_id=proposal_id,promotion_episode_id=promotion_episode_id,
                    authorization_episode_id=authorization_episode_id)
        self.conn.commit()

    def admit_object_type_from_gap(self, **kwargs):
        raise PermissionError(
            "direct schema mutation retired in v0.30; use apply_schema_object_type() "
            "with an authorized, promoted schema proposal"
        )

    def admit_episode_type_from_gap(self, **kwargs):
        raise PermissionError(
            "direct schema mutation retired in v0.30; use apply_schema_episode_type() "
            "with an authorized, promoted schema proposal"
        )

    def propose_schema_object_type(
        self,
        *,
        gap_id: str,
        type_name: str,
        definition: str,
        provenance_class: str,
        provenance: str,
        identity_key: Optional[str]=None,
    ) -> str:
        gap=self._open_schema_gap(gap_id)
        if self._schema_known(type_name,"OBJECT"):
            raise ValueError(f"object type already active: {type_name}")
        return self.add(
            "Candidate",
            f"Schema object type: {type_name}",
            data={
                "schema_proposal_kind":"ADD_OBJECT_TYPE",
                "gap_id":gap_id,
                "term_name":type_name,
                "definition":definition,
                "missing_distinction":gap["missing_distinction"],
            },
            epistemic="PROPOSED",
            provenance_class=provenance_class,
            provenance=provenance,
            identity_key=identity_key,
        )

    def propose_schema_episode_type(
        self,
        *,
        gap_id: str,
        kind: str,
        definition: str,
        roles: dict[str,dict],
        provenance_class: str,
        provenance: str,
        identity_key: Optional[str]=None,
    ) -> str:
        gap=self._open_schema_gap(gap_id)
        if self._schema_known(kind,"EPISODE"):
            raise ValueError(f"episode kind already active: {kind}")
        return self.add(
            "Candidate",
            f"Schema episode type: {kind}",
            data={
                "schema_proposal_kind":"ADD_EPISODE_TYPE",
                "gap_id":gap_id,
                "term_name":kind,
                "definition":definition,
                "roles":roles,
                "missing_distinction":gap["missing_distinction"],
            },
            epistemic="PROPOSED",
            provenance_class=provenance_class,
            provenance=provenance,
            identity_key=identity_key,
        )

    def _validate_schema_promotion(
        self,
        *,
        proposal_id: str,
        promotion_episode_id: str,
        context_id: str,
        scope_id: str,
    ) -> dict:
        proposal=self.get(proposal_id)
        if proposal.type!="Candidate":
            raise TypeError("schema proposal must be Candidate")
        if self.entity_descriptor(promotion_episode_id)!="EPISODE:PROMOTION":
            raise TypeError("promotion_episode_id must be PROMOTION Episode")
        ep=self.episode(promotion_episode_id)
        if ep["data"].get("result")!="PROMOTED":
            raise PermissionError("schema proposal has not been PROMOTED")
        if self.episode_role_ids(promotion_episode_id,"entity") != [proposal_id]:
            raise PermissionError("promotion does not apply to this schema proposal")
        if self.episode_role_ids(promotion_episode_id,"context") != [context_id]:
            raise PermissionError("promotion belongs to a different Context")
        promotion_scopes=self.episode_role_ids(promotion_episode_id,"scope")
        if len(promotion_scopes)!=1 or not self.scope_contains(promotion_scopes[0],scope_id):
            raise PermissionError("promotion Scope does not cover schema-change Scope")
        return proposal.data

    def apply_schema_object_type(
        self,
        *,
        proposal_id: str,
        promotion_episode_id: str,
        context_id: str,
        actor_id: str,
        scope_id: str,
        reason: str,
        provenance_class: str,
        provenance: str,
    ):
        proposal_data=self._validate_schema_promotion(
            proposal_id=proposal_id,promotion_episode_id=promotion_episode_id,
            context_id=context_id,scope_id=scope_id)
        if proposal_data.get("schema_proposal_kind")!="ADD_OBJECT_TYPE":
            raise TypeError("proposal is not an object-type schema proposal")
        auth=self.check_authorized(
            context_id=context_id,actor_id=actor_id,entity_id=proposal_id,
            operation="SCHEMA_CHANGE",scope_id=scope_id)
        if not auth["authorized"]:
            raise PermissionError(f"schema change not authorized: {auth['reason']}")
        self._insert_schema_object_type(
            gap_id=proposal_data["gap_id"],
            type_name=proposal_data["term_name"],
            definition=proposal_data["definition"],
            reason=reason,
            proposal_id=proposal_id,
            promotion_episode_id=promotion_episode_id,
            authorization_episode_id=auth["authorization_id"],
            actor_id=actor_id,context_id=context_id,scope_id=scope_id,
            provenance_class=provenance_class,provenance=provenance)

    def apply_schema_episode_type(
        self,
        *,
        proposal_id: str,
        promotion_episode_id: str,
        context_id: str,
        actor_id: str,
        scope_id: str,
        reason: str,
        provenance_class: str,
        provenance: str,
    ):
        proposal_data=self._validate_schema_promotion(
            proposal_id=proposal_id,promotion_episode_id=promotion_episode_id,
            context_id=context_id,scope_id=scope_id)
        if proposal_data.get("schema_proposal_kind")!="ADD_EPISODE_TYPE":
            raise TypeError("proposal is not an episode-type schema proposal")
        auth=self.check_authorized(
            context_id=context_id,actor_id=actor_id,entity_id=proposal_id,
            operation="SCHEMA_CHANGE",scope_id=scope_id)
        if not auth["authorized"]:
            raise PermissionError(f"schema change not authorized: {auth['reason']}")
        self._insert_schema_episode_type(
            gap_id=proposal_data["gap_id"],
            kind=proposal_data["term_name"],
            definition=proposal_data["definition"],
            roles=proposal_data["roles"],
            reason=reason,
            proposal_id=proposal_id,
            promotion_episode_id=promotion_episode_id,
            authorization_episode_id=auth["authorization_id"],
            actor_id=actor_id,context_id=context_id,scope_id=scope_id,
            provenance_class=provenance_class,provenance=provenance)

    def close(self):
        self.conn.close()

    def _event(self, event: str, object_id: Optional[str] = None, **details):
        self.conn.execute(
            "INSERT INTO history(event,object_id,details_json,created_at) VALUES(?,?,?,?)",
            (event, object_id, json.dumps(details, sort_keys=True), now())
        )

    def add(
        self, type: str, title: str, *,
        data: Optional[dict] = None,
        provenance_class: str,
        provenance: str,
        identity_key: Optional[str] = None,
        lifecycle: str = "DORMANT",
        epistemic: str = "UNKNOWN",
        id: Optional[str] = None,
    ) -> str:
        if not self._schema_known(type,"OBJECT"): raise ValueError(f"unknown/unadmitted object type: {type}")
        if lifecycle not in LIFECYCLES: raise ValueError(f"unknown lifecycle: {lifecycle}")
        if epistemic not in EPISTEMIC: raise ValueError(f"unknown epistemic status: {epistemic}")
        if type == "Claim" and epistemic != "UNKNOWN":
            raise ValueError("Claim epistemic status is relational; use assess_claim()")
        if type == "Remainder":
            utype = (data or {}).get("unknown_type")
            if epistemic != "UNEXPLAINED" and utype not in UNKNOWN_TYPES:
                raise ValueError(f"Remainder requires unknown_type in {sorted(UNKNOWN_TYPES)} unless epistemic=UNEXPLAINED")
            if utype is not None and utype not in UNKNOWN_TYPES:
                raise ValueError(f"unknown Remainder unknown_type: {utype}")
        if type == "ObservationFrame":
            required_frame = {"observer","apparatus","accessible_variables","resolution","intervention","boundary"}
            missing = required_frame - set((data or {}).keys())
            if missing:
                raise ValueError(f"ObservationFrame missing fields: {sorted(missing)}")
        if type == "Collection" and lifecycle == "ACTIVE":
            raise ValueError("Collection is organizational; it does not become the active Subject")
        if type == "Context" and lifecycle == "ACTIVE":
            raise ValueError("Context scopes authority; it is not the active Subject")
        if type == "Scope" and lifecycle == "ACTIVE":
            raise ValueError("Scope bounds authority; it is not active work")
        if type == "Authority" and lifecycle == "ACTIVE":
            raise ValueError("Authority grants permission; it is not active work")
        if type == "Actor" and lifecycle == "ACTIVE":
            raise ValueError("Actor identity is not the current work item")
        if type == "Method" and lifecycle == "ACTIVE":
            raise ValueError("Method describes how work is done; it is not the active Subject")
        if type == "ValidityFrame":
            conditions = (data or {}).get("conditions")
            if not isinstance(conditions, dict) or not conditions:
                raise ValueError("ValidityFrame requires nonempty conditions")
            if lifecycle == "ACTIVE":
                raise ValueError("ValidityFrame bounds applicability; it is not the active Subject")
        if type == "ContentIdentity":
            spec=data or {}
            if not spec.get("algorithm") or not spec.get("digest"):
                raise ValueError("ContentIdentity requires algorithm and digest")
            if lifecycle == "ACTIVE":
                raise ValueError("ContentIdentity is identity metadata, not active work")
        if type == "ArtifactInstance":
            if lifecycle == "ACTIVE":
                raise ValueError("ArtifactInstance is durable identity, not active work")
        if type == "Occurrence":
            spec=data or {}
            if not spec.get("locator"):
                raise ValueError("Occurrence requires locator")
            if lifecycle == "ACTIVE":
                raise ValueError("Occurrence is a historical appearance, not active work")
        if type == "RunIdentity" and not identity_key:
            raise ValueError("RunIdentity requires a stable identity_key")
        if type == "Measurement":
            spec = data or {}
            if not isinstance(spec.get("metric"), str) or not spec["metric"].strip():
                raise ValueError("Measurement requires metric")
            try:
                float(spec["value"])
            except Exception as e:
                raise ValueError("Measurement requires numeric value") from e
            if "unit" not in spec:
                raise ValueError("Measurement requires unit (may be empty string)")
        if type == "Order":
            spec = data or {}
            metrics = spec.get("metrics")
            if not isinstance(metrics, list) or not metrics:
                raise ValueError("Order requires a nonempty metrics list")
            for m in metrics:
                if not isinstance(m, dict) or not m.get("name"):
                    raise ValueError("each Order metric requires name")
                if m.get("direction") not in {"MIN","MAX"}:
                    raise ValueError("Order metric direction must be MIN or MAX")
            if spec.get("rule","PARETO") not in {"PARETO","LEXICOGRAPHIC"}:
                raise ValueError("Order rule must be PARETO or LEXICOGRAPHIC")
        if provenance_class not in PROVENANCE_CLASSES:
            raise ValueError(f"unknown provenance class: {provenance_class}")
        if not provenance.strip(): raise ValueError("provenance locator is required")
        object_id = id or oid(type.lower())
        try:
            self.conn.execute("BEGIN")
            created = now()
            self.conn.execute(
                "INSERT INTO entities(id,entity_kind,created_at) VALUES(?,?,?)",
                (object_id, "OBJECT", created)
            )
            self.conn.execute(
                """INSERT INTO objects
                (id,type,lifecycle,epistemic,title,data_json,provenance_class,provenance,identity_key,created_at)
                VALUES(?,?,?,?,?,?,?,?,?,?)""",
                (object_id, type, lifecycle, epistemic, title,
                 json.dumps(data or {}, sort_keys=True), provenance_class,
                 provenance, identity_key, created)
            )
        except sqlite3.IntegrityError as e:
            self.conn.rollback()
            if identity_key and "identity_key" in str(e):
                existing = self.conn.execute(
                    "SELECT id FROM objects WHERE identity_key=?", (identity_key,)
                ).fetchone()
                raise ValueError(f"identity already exists: {existing['id']} ({identity_key})") from e
            raise
        self._event("ADDED", object_id, type=type, title=title, identity_key=identity_key)
        admission_status = "QUARANTINED" if lifecycle == "QUARANTINED" else "NATIVE"
        self.conn.execute(
            "INSERT OR REPLACE INTO admission(object_id,status,decision_episode_id,updated_at) VALUES(?,?,NULL,?)",
            (object_id, admission_status, now())
        )
        self.conn.commit()
        return object_id

    def get(self, object_id: str) -> Obj:
        r = self.conn.execute("SELECT * FROM objects WHERE id=?", (object_id,)).fetchone()
        if not r: raise KeyError(object_id)
        return Obj(
            r["id"], r["type"], r["lifecycle"], r["epistemic"], r["title"],
            json.loads(r["data_json"]), r["provenance_class"], r["provenance"],
            r["identity_key"], r["created_at"]
        )

    def relate(
        self, from_id: str, kind: str, to_id: str, *,
        data: Optional[dict] = None,
        provenance_class: str,
        provenance: str
    ) -> str:
        self.get(from_id); self.get(to_id)
        if provenance_class not in PROVENANCE_CLASSES:
            raise ValueError(f"unknown provenance class: {provenance_class}")
        if not provenance.strip(): raise ValueError("relation provenance locator is required")
        kind = kind.upper()
        if kind == "REQUIRES":
            src=self.get(from_id); dst=self.get(to_id)
            if src.type != "Claim" or dst.type != "Claim":
                raise TypeError("REQUIRES is reserved for Claim -> Claim justification dependencies")
            if from_id == to_id or self._path_exists(to_id, from_id, kind):
                raise ValueError("REQUIRES would create a justification cycle")
        if kind in {"SUPERSEDES", "CORRECTS"} and self._path_exists(to_id, from_id, kind):
            raise ValueError(f"{kind} would create a cycle")
        rid = oid("rel")
        self.conn.execute(
            """INSERT INTO relations
               (id,from_id,kind,to_id,data_json,provenance_class,provenance,created_at)
               VALUES(?,?,?,?,?,?,?,?)""",
            (rid, from_id, kind, to_id, json.dumps(data or {}, sort_keys=True),
             provenance_class, provenance, now())
        )
        self._event("RELATED", from_id, relation=kind, to=to_id, data=data or {})
        self.conn.commit()
        return rid

    def _path_exists(self, start: str, target: str, kind: str) -> bool:
        todo, seen = [start], set()
        while todo:
            x = todo.pop()
            if x == target: return True
            if x in seen: continue
            seen.add(x)
            rows = self.conn.execute(
                "SELECT to_id FROM relations WHERE from_id=? AND kind=?", (x, kind)
            ).fetchall()
            todo.extend(r["to_id"] for r in rows)
        return False



    def entity_kind(self, entity_id: str) -> str:
        row = self.conn.execute(
            "SELECT entity_kind FROM entities WHERE id=?", (entity_id,)
        ).fetchone()
        if not row:
            raise KeyError(entity_id)
        return row["entity_kind"]


    def entity_descriptor(self, entity_id: str) -> str:
        kind = self.entity_kind(entity_id)
        if kind == "OBJECT":
            return f"OBJECT:{self.get(entity_id).type}"
        row = self.conn.execute("SELECT kind FROM episodes WHERE id=?", (entity_id,)).fetchone()
        return f"EPISODE:{row['kind']}"

    @staticmethod
    def _descriptor_allowed(descriptor: str, allowed: set[str]) -> bool:
        if descriptor in allowed:
            return True
        if descriptor.startswith("EPISODE:"):
            kind=descriptor.split(":",1)[1]
            if kind in NON_EVIDENTIARY_EPISODE_KINDS:
                return False
        prefix = descriptor.split(":",1)[0] + ":*"
        return prefix in allowed

    def entity(self, entity_id: str) -> dict:
        kind = self.entity_kind(entity_id)
        if kind == "OBJECT":
            o = self.get(entity_id)
            return {
                "id":o.id,"entity_kind":"OBJECT","type":o.type,"title":o.title,
                "lifecycle":o.lifecycle,"epistemic":o.epistemic,"data":o.data
            }
        ep = self.episode(entity_id)
        return {
            "id":ep["id"],"entity_kind":"EPISODE","type":ep["kind"],
            "title":ep["title"],"data":ep["data"]
        }


    def episode_role_ids(self, episode_id: str, role: str) -> list[str]:
        row = self.conn.execute("SELECT 1 FROM episodes WHERE id=?", (episode_id,)).fetchone()
        if not row:
            raise KeyError(episode_id)
        rows = self.conn.execute(
            """SELECT participant_id FROM episode_participants
               WHERE episode_id=? AND role=? ORDER BY ordinal""",
            (episode_id, role.lower())
        ).fetchall()
        return [r["participant_id"] for r in rows]

    def add_episode(
        self,
        kind: str,
        title: str,
        *,
        participants: list[dict],
        data: Optional[dict] = None,
        provenance_class: str,
        provenance: str,
        identity_key: Optional[str] = None,
        id: Optional[str] = None,
    ) -> str:
        """Create a higher-order tested relation with typed role-bearing participants."""
        if provenance_class not in PROVENANCE_CLASSES:
            raise ValueError(f"unknown provenance class: {provenance_class}")
        if not provenance.strip():
            raise ValueError("episode provenance locator is required")
        if not kind.strip():
            raise ValueError("episode kind is required")
        if not participants:
            raise ValueError("episode must have at least one participant")

        episode_id = id or oid("episode")
        seen_slots = set()
        normalized = []
        for raw in participants:
            role = str(raw["role"]).strip().lower()
            participant_id = raw.get("entity_id", raw.get("object_id", raw.get("episode_id")))
            if participant_id is None:
                raise ValueError("participant requires entity_id/object_id/episode_id")
            participant_id = str(participant_id)
            ordinal = int(raw.get("ordinal", 0))
            required = bool(raw.get("required", True))
            if not role:
                raise ValueError("participant role is required")
            self.entity_kind(participant_id)
            slot = (role, ordinal)
            if slot in seen_slots:
                raise ValueError(f"duplicate participant slot: {slot}")
            seen_slots.add(slot)
            normalized.append((role, participant_id, ordinal, 1 if required else 0))

        kind=kind.upper()
        contract,typed_contract=self._episode_schema(kind)
        roles = {role for role, _, _, _ in normalized}
        missing = contract - roles
        if missing:
            raise ValueError(
                f"{kind} missing required participant roles: {sorted(missing)}"
            )

        declared_roles=set(typed_contract)
        undeclared=roles-declared_roles
        if undeclared:
            raise ValueError(f"{kind} contains undeclared roles: {sorted(undeclared)}")

        for role, participant_id, ordinal, required in normalized:
            allowed = typed_contract.get(role,set())
            if not allowed:
                continue
            descriptor = self.entity_descriptor(participant_id)
            if not self._descriptor_allowed(descriptor, allowed):
                raise TypeError(
                    f"{kind} role '{role}' does not accept {descriptor}; "
                    f"allowed={sorted(allowed)}"
                )

        if kind.upper() == "MATCHED_COUNTERFACTUAL":
            role_map = {}
            for role, participant_id, ordinal, required in normalized:
                role_map.setdefault(role, []).append(participant_id)
            control = role_map["control"][0]
            treatment = role_map["treatment"][0]
            declared_reset = role_map["reset"][0]

            def one(ep, r):
                vals = self.episode_role_ids(ep, r)
                if len(vals) != 1:
                    raise ValueError(f"EXECUTION {ep} must have exactly one {r}")
                return vals[0]

            c_frame, t_frame = one(control,"frame"), one(treatment,"frame")
            c_params, t_params = one(control,"parameters"), one(treatment,"parameters")
            c_reset, t_reset = one(control,"reset"), one(treatment,"reset")

            if c_frame != t_frame:
                raise ValueError("matched counterfactual requires identical ObservationFrame")
            if c_params != t_params:
                raise ValueError("matched counterfactual requires identical nuisance Parameters")
            if c_reset != t_reset or c_reset != declared_reset:
                raise ValueError("matched counterfactual requires identical reset state")
            c_status=self.episode(control)["data"].get("status")
            t_status=self.episode(treatment)["data"].get("status")
            if c_status!="COMPLETED" or t_status!="COMPLETED":
                raise ValueError(
                    f"matched counterfactual requires COMPLETED executions; control={c_status}, treatment={t_status}"
                )

        try:
            self.conn.execute("BEGIN")
            created = now()
            self.conn.execute(
                "INSERT INTO entities(id,entity_kind,created_at) VALUES(?,?,?)",
                (episode_id, "EPISODE", created)
            )
            self.conn.execute(
                """INSERT INTO episodes
                   (id,kind,title,data_json,provenance_class,provenance,identity_key,created_at)
                   VALUES(?,?,?,?,?,?,?,?)""",
                (episode_id, kind.upper(), title, json.dumps(data or {}, sort_keys=True),
                 provenance_class, provenance, identity_key, created)
            )
            for role, participant_id, ordinal, required in normalized:
                self.conn.execute(
                    """INSERT INTO episode_participants
                       (episode_id,role,participant_id,ordinal,required)
                       VALUES(?,?,?,?,?)""",
                    (episode_id, role, participant_id, ordinal, required)
                )
            self._event("EPISODE_ADDED", None, episode_id=episode_id, kind=kind.upper(), title=title)
            self.conn.commit()
        except sqlite3.IntegrityError as e:
            self.conn.rollback()
            if identity_key and "identity_key" in str(e):
                existing = self.conn.execute(
                    "SELECT id FROM episodes WHERE identity_key=?", (identity_key,)
                ).fetchone()
                raise ValueError(f"episode identity already exists: {existing['id']} ({identity_key})") from e
            raise
        return episode_id

    def episode(self, episode_id: str) -> dict:
        row = self.conn.execute("SELECT * FROM episodes WHERE id=?", (episode_id,)).fetchone()
        if not row:
            raise KeyError(episode_id)
        d = dict(row)
        d["data"] = json.loads(d.pop("data_json"))
        parts = self.conn.execute(
            """SELECT p.role,p.ordinal,p.required,p.participant_id,
                      en.entity_kind,
                      COALESCE(o.type,e.kind) AS type,
                      COALESCE(o.title,e.title) AS participant_title,
                      o.lifecycle,o.epistemic
               FROM episode_participants p
               JOIN entities en ON en.id=p.participant_id
               LEFT JOIN objects o ON o.id=p.participant_id AND en.entity_kind='OBJECT'
               LEFT JOIN episodes e ON e.id=p.participant_id AND en.entity_kind='EPISODE'
               WHERE p.episode_id=?
               ORDER BY p.role,p.ordinal""",
            (episode_id,)
        ).fetchall()
        d["participants"] = [dict(r) for r in parts]
        return d

    def episodes_for(self, object_id: str) -> list[dict]:
        self.entity_kind(object_id)
        rows = self.conn.execute(
            """SELECT e.*,p.role,p.ordinal,p.required
               FROM episode_participants p
               JOIN episodes e ON e.id=p.episode_id
               WHERE p.participant_id=?
               ORDER BY e.created_at DESC""",
            (object_id,)
        ).fetchall()
        out = []
        for r in rows:
            d = dict(r)
            d["data"] = json.loads(d.pop("data_json"))
            out.append(d)
        return out


    def revise_object(
        self,
        object_id: str,
        *,
        title: Optional[str] = None,
        data: Optional[dict] = None,
        provenance_class: str,
        provenance: str,
        identity_key: Optional[str] = None,
        reason: str = "",
    ) -> str:
        """Create a new semantic snapshot and link it to the prior snapshot."""
        old = self.get(object_id)
        new_id = self.add(
            old.type,
            title if title is not None else old.title,
            data=old.data if data is None else data,
            provenance_class=provenance_class,
            provenance=provenance,
            identity_key=identity_key,
            lifecycle="DORMANT",
            epistemic="UNKNOWN" if old.type == "Claim" else old.epistemic,
        )
        self.relate(
            new_id, "SUPERSEDES", old.id,
            data={"reason": reason},
            provenance_class=provenance_class,
            provenance=provenance,
        )
        self._event("OBJECT_REVISED", new_id, prior=old.id, reason=reason)
        self.conn.commit()
        return new_id


    def record_execution(
        self,
        *,
        run_id: str,
        probe_id: str,
        frame_id: str,
        parameters_id: str,
        reset_id: str,
        observation_ids: list[str],
        status: str,
        provenance_class: str,
        provenance: str,
        identity_key: Optional[str] = None,
        title: Optional[str] = None,
    ) -> str:
        run = self.get(run_id)
        if run.type != "RunIdentity":
            raise TypeError("execution run_id must be RunIdentity")
        used = self.conn.execute(
            """SELECT p.episode_id FROM episode_participants p
               JOIN episodes e ON e.id=p.episode_id
               WHERE e.kind='EXECUTION' AND p.role='run' AND p.participant_id=? LIMIT 1""",
            (run_id,)
        ).fetchone()
        if used:
            raise ValueError(f"RunIdentity already consumed by execution {used['episode_id']}")

        probe = self.get(probe_id)
        if probe.type != "Probe":
            raise TypeError("execution probe must be Probe")
        frame = self.get(frame_id)
        if frame.type != "ObservationFrame":
            raise TypeError("execution frame must be ObservationFrame")
        params = self.get(parameters_id)
        if params.type != "Parameters":
            raise TypeError("execution parameters must be Parameters")
        reset = self.get(reset_id)
        if reset.type != "Artifact":
            raise TypeError("execution reset must be Artifact")
        status = status.upper()
        if status not in EXECUTION_STATUSES:
            raise ValueError(f"unknown execution status: {status}")
        if not observation_ids:
            raise ValueError("execution requires at least one Observation/Evidence")
        participants=[
            {"role":"run","object_id":run_id},
            {"role":"probe","object_id":probe_id},
            {"role":"frame","object_id":frame_id},
            {"role":"parameters","object_id":parameters_id},
            {"role":"reset","object_id":reset_id},
        ]
        for i,oid in enumerate(observation_ids):
            ob=self.get(oid)
            if ob.type not in {"Observation","Evidence"}:
                raise TypeError("execution observations must be Observation or Evidence")
            participants.append({"role":"observation","object_id":oid,"ordinal":i})
        return self.add_episode(
            "EXECUTION",
            title or f"Execution: {probe.title}",
            participants=participants,
            data={"status":status},
            provenance_class=provenance_class,
            provenance=provenance,
            identity_key=identity_key,
        )


    def assess_replication(
        self,
        *,
        original_execution_id: str,
        candidate_execution_id: str,
        grade: str,
        basis_ids: list[str],
        reason: str,
        provenance_class: str,
        provenance: str,
        identity_key: Optional[str] = None,
    ) -> str:
        if self.entity_descriptor(original_execution_id) != "EPISODE:EXECUTION":
            raise TypeError("original must be EXECUTION Episode")
        if self.entity_descriptor(candidate_execution_id) != "EPISODE:EXECUTION":
            raise TypeError("candidate must be EXECUTION Episode")
        if original_execution_id == candidate_execution_id:
            raise ValueError("replication assessment requires two distinct executions")
        grade = grade.upper()
        if grade not in REPLICATION_GRADES:
            raise ValueError(f"unknown replication grade: {grade}")
        if not basis_ids:
            raise ValueError("replication assessment requires a basis")
        participants=[
            {"role":"original","episode_id":original_execution_id},
            {"role":"candidate","episode_id":candidate_execution_id},
        ]
        for i,bid in enumerate(basis_ids):
            b=self.get(bid)
            if b.type not in {"Evidence","Observation","Artifact","ObservationFrame"}:
                raise TypeError("replication basis must be evidence/frame/artifact")
            participants.append({"role":"basis","object_id":bid,"ordinal":i})
        return self.add_episode(
            "REPLICATION_ASSESSMENT",
            f"{grade}: replication assessment",
            participants=participants,
            data={"grade":grade,"reason":reason},
            provenance_class=provenance_class,
            provenance=provenance,
            identity_key=identity_key,
        )


    def record_measurement(
        self,
        *,
        candidate_id: str,
        metric: str,
        value: float,
        unit: str,
        basis_entity_id: str,
        provenance_class: str,
        provenance: str,
        identity_key: Optional[str] = None,
    ) -> str:
        candidate=self.get(candidate_id)
        if candidate.type!="Candidate":
            raise TypeError("measurement subject must be Candidate")
        self.entity_kind(basis_entity_id)
        m=self.add(
            "Measurement", f"{candidate.title}: {metric}={value} {unit}".strip(),
            data={"metric":metric,"value":float(value),"unit":unit},
            provenance_class=provenance_class, provenance=provenance,
        )
        return self.add_episode(
            "MEASUREMENT", f"Measure {metric} for {candidate.title}",
            participants=[
                {"role":"subject","object_id":candidate_id},
                {"role":"measurement","object_id":m},
                {"role":"basis","entity_id":basis_entity_id},
            ],
            provenance_class=provenance_class, provenance=provenance,
            identity_key=identity_key,
        )

    def compare_candidates(
        self,
        *,
        order_id: str,
        candidate_ids: list[str],
        measurement_episode_ids: list[str],
        provenance_class: str,
        provenance: str,
        identity_key: Optional[str] = None,
        title: str = "Candidate comparison",
    ) -> str:
        order=self.get(order_id)
        if order.type!="Order": raise TypeError("order_id must be Order")
        if len(candidate_ids)<2: raise ValueError("comparison requires at least two candidates")
        candidates=[self.get(cid) for cid in candidate_ids]
        if any(c.type!="Candidate" for c in candidates): raise TypeError("comparison candidates must be Candidate objects")
        observed={}
        for eid in measurement_episode_ids:
            if self.entity_descriptor(eid)!="EPISODE:MEASUREMENT":
                raise TypeError("comparison measurement inputs must be MEASUREMENT Episodes")
            subject_ids=self.episode_role_ids(eid,"subject")
            measurement_ids=self.episode_role_ids(eid,"measurement")
            if len(subject_ids)!=1 or len(measurement_ids)!=1:
                raise ValueError("MEASUREMENT must bind one subject and one Measurement")
            cid=subject_ids[0]; m=self.get(measurement_ids[0]); key=(cid,m.data["metric"])
            if key in observed:
                raise ValueError(f"multiple measurements supplied for {cid}/{m.data['metric']}; aggregation not declared")
            observed[key]=m.data
        metrics=order.data["metrics"]; feasible=[]; metric_vectors={}
        for c in candidates:
            vec={}; ok=True
            for m in metrics:
                name=m["name"]; key=(c.id,name)
                if key not in observed: raise ValueError(f"candidate {c.id} lacks evidence-bound measurement for {name}")
                val=float(observed[key]["value"]); vec[name]=val
                if "max_allowed" in m and val>float(m["max_allowed"]): ok=False
                if "min_allowed" in m and val<float(m["min_allowed"]): ok=False
            metric_vectors[c.id]=vec
            if ok: feasible.append(c.id)
        def dominates(a,b):
            at_least=True; strict=False
            for m in metrics:
                n=m["name"]; av=metric_vectors[a][n]; bv=metric_vectors[b][n]
                if m["direction"]=="MIN":
                    if av>bv: at_least=False
                    if av<bv: strict=True
                else:
                    if av<bv: at_least=False
                    if av>bv: strict=True
            return at_least and strict
        if order.data.get("rule","PARETO")=="PARETO":
            front=[a for a in feasible if not any(dominates(b,a) for b in feasible if b!=a)]
            chosen=front[0] if len(front)==1 else None
            verdict="UNIQUE" if chosen else ("PARETO_SET" if front else "NO_FEASIBLE")
        else:
            ranked=list(feasible)
            for m in reversed(metrics):
                n=m["name"]; rev=m["direction"]=="MAX"; ranked.sort(key=lambda cid:metric_vectors[cid][n],reverse=rev)
            chosen=ranked[0] if ranked else None; front=[chosen] if chosen else []; verdict="UNIQUE" if chosen else "NO_FEASIBLE"
        decision=self.add("Decision",f"{title}: {verdict}",
            data={"verdict":verdict,"chosen":chosen,"pareto":front,"vectors":metric_vectors},
            provenance_class=provenance_class,provenance=provenance)
        participants=[{"role":"order","object_id":order_id},{"role":"result","object_id":decision}]
        for i,cid in enumerate(candidate_ids): participants.append({"role":"candidate","object_id":cid,"ordinal":i})
        for i,eid in enumerate(measurement_episode_ids): participants.append({"role":"measurement","episode_id":eid,"ordinal":i})
        return self.add_episode("COMPARISON",title,participants=participants,data={"verdict":verdict},
            provenance_class=provenance_class,provenance=provenance,identity_key=identity_key)


    def assess_method_compliance(
        self,
        *,
        context_id: str,
        entity_id: str,
        method_id: str,
        scope_id: str,
        verdict: str,
        basis_entity_ids: list[str],
        reason: str,
        provenance_class: str,
        provenance: str,
        identity_key: Optional[str] = None,
    ) -> str:
        context = self.get(context_id)
        method = self.get(method_id)
        scope = self.get(scope_id)
        if context.type != "Context":
            raise TypeError("context_id must be Context")
        if method.type != "Method":
            raise TypeError("method_id must be Method")
        if scope.type != "Scope":
            raise TypeError("scope_id must be Scope")
        self.entity_kind(entity_id)
        verdict = verdict.upper()
        if verdict not in METHOD_COMPLIANCE_RESULTS:
            raise ValueError(f"unknown method-compliance verdict: {verdict}")
        if not reason.strip():
            raise ValueError("method-compliance reason required")
        for bid in basis_entity_ids:
            self.entity_kind(bid)

        decision = self.add(
            "Decision",
            f"Method compliance: {verdict}",
            data={"verdict": verdict, "reason": reason},
            provenance_class=provenance_class,
            provenance=provenance,
        )
        participants = [
            {"role": "context", "object_id": context_id},
            {"role": "entity", "entity_id": entity_id},
            {"role": "method", "object_id": method_id},
            {"role": "scope", "object_id": scope_id},
            {"role": "result", "object_id": decision},
        ]
        for i, bid in enumerate(basis_entity_ids):
            participants.append({"role": "basis", "entity_id": bid, "ordinal": i})
        return self.add_episode(
            "METHOD_COMPLIANCE",
            f"{verdict}: {self.entity(entity_id)['title']}",
            participants=participants,
            data={"verdict": verdict, "reason": reason},
            provenance_class=provenance_class,
            provenance=provenance,
            identity_key=identity_key,
        )

    def record_replacement(
        self,
        *,
        predecessor_entity_id: str,
        successor_entity_id: str,
        scope_id: str,
        relation: str,
        basis_entity_ids: list[str],
        reason: str,
        provenance_class: str,
        provenance: str,
        identity_key: Optional[str] = None,
    ) -> str:
        self.entity_kind(predecessor_entity_id)
        self.entity_kind(successor_entity_id)
        scope = self.get(scope_id)
        if scope.type != "Scope":
            raise TypeError("scope_id must be Scope")
        relation = relation.upper()
        if relation not in REPLACEMENT_RESULTS:
            raise ValueError(f"unknown replacement relation: {relation}")
        if not reason.strip():
            raise ValueError("replacement reason required")
        for bid in basis_entity_ids:
            self.entity_kind(bid)

        decision = self.add(
            "Decision",
            f"Replacement relation: {relation}",
            data={"relation": relation, "reason": reason},
            provenance_class=provenance_class,
            provenance=provenance,
        )
        participants = [
            {"role": "predecessor", "entity_id": predecessor_entity_id},
            {"role": "successor", "entity_id": successor_entity_id},
            {"role": "scope", "object_id": scope_id},
            {"role": "result", "object_id": decision},
        ]
        for i, bid in enumerate(basis_entity_ids):
            participants.append({"role": "basis", "entity_id": bid, "ordinal": i})
        return self.add_episode(
            "REPLACEMENT",
            relation,
            participants=participants,
            data={"relation": relation, "reason": reason},
            provenance_class=provenance_class,
            provenance=provenance,
            identity_key=identity_key,
        )


    def validity_frame_diff(self, historical_frame_id: str, current_frame_id: str) -> dict:
        old=self.get(historical_frame_id); new=self.get(current_frame_id)
        if old.type!="ValidityFrame" or new.type!="ValidityFrame":
            raise TypeError("validity_frame_diff requires ValidityFrame objects")
        a=old.data["conditions"]; b=new.data["conditions"]
        keys=sorted(set(a)|set(b))
        return {
            k: {"historical":a.get(k),"current":b.get(k)}
            for k in keys if a.get(k)!=b.get(k)
        }

    def assess_applicability(
        self,
        *,
        entity_id: str,
        historical_frame_id: str,
        current_frame_id: str,
        scope_id: str,
        verdict: str,
        basis_entity_ids: list[str],
        reason: str,
        provenance_class: str,
        provenance: str,
        identity_key: Optional[str]=None,
    ) -> str:
        self.entity_kind(entity_id)
        historical=self.get(historical_frame_id); current=self.get(current_frame_id); scope=self.get(scope_id)
        if historical.type!="ValidityFrame" or current.type!="ValidityFrame":
            raise TypeError("applicability frames must be ValidityFrame")
        if scope.type!="Scope": raise TypeError("scope_id must be Scope")
        verdict=verdict.upper()
        if verdict not in APPLICABILITY_RESULTS:
            raise ValueError(f"unknown applicability verdict: {verdict}")
        if not reason.strip(): raise ValueError("applicability reason required")
        for bid in basis_entity_ids: self.entity_kind(bid)
        decision=self.add(
            "Decision",f"Applicability: {verdict}",
            data={"verdict":verdict,"reason":reason,"frame_diff":self.validity_frame_diff(historical_frame_id,current_frame_id)},
            provenance_class=provenance_class,provenance=provenance)
        participants=[
            {"role":"entity","entity_id":entity_id},
            {"role":"historical_frame","object_id":historical_frame_id},
            {"role":"current_frame","object_id":current_frame_id},
            {"role":"scope","object_id":scope_id},
            {"role":"result","object_id":decision},
        ]
        for i,bid in enumerate(basis_entity_ids):
            participants.append({"role":"basis","entity_id":bid,"ordinal":i})
        return self.add_episode(
            "APPLICABILITY_ASSESSMENT",f"{verdict}: {self.entity(entity_id)['title']}",
            participants=participants,
            data={"verdict":verdict,"reason":reason},
            provenance_class=provenance_class,provenance=provenance,identity_key=identity_key)


    def register_content(
        self,
        *,
        algorithm: str,
        digest: str,
        title: Optional[str]=None,
        provenance_class: str,
        provenance: str,
    ) -> str:
        algorithm=algorithm.strip().lower(); digest=digest.strip().lower()
        if not algorithm or not digest:
            raise ValueError("content algorithm/digest required")
        identity_key=f"content:{algorithm}:{digest}"
        row=self.conn.execute("SELECT id FROM objects WHERE identity_key=?",(identity_key,)).fetchone()
        if row:
            return row["id"]
        return self.add(
            "ContentIdentity",title or f"{algorithm}:{digest[:16]}",
            data={"algorithm":algorithm,"digest":digest},
            provenance_class=provenance_class,provenance=provenance,
            identity_key=identity_key)


    def create_artifact_instance(
        self,
        *,
        content_id: str,
        title: Optional[str]=None,
        provenance_class: str,
        provenance: str,
        identity_key: Optional[str]=None,
    ) -> str:
        content=self.get(content_id)
        if content.type!="ContentIdentity":
            raise TypeError("content_id must be ContentIdentity")
        instance=self.add(
            "ArtifactInstance",
            title or f"Instance of {content.title}",
            data={},
            provenance_class=provenance_class,
            provenance=provenance,
            identity_key=identity_key,
        )
        self.add_episode(
            "INSTANCE_CONTENT",
            f"Content of {self.get(instance).title}",
            participants=[
                {"role":"instance","object_id":instance},
                {"role":"content","object_id":content_id},
            ],
            provenance_class=provenance_class,
            provenance=provenance,
        )
        return instance

    def content_of_instance(self, instance_id: str) -> str:
        inst=self.get(instance_id)
        if inst.type!="ArtifactInstance":
            raise TypeError("instance_id must be ArtifactInstance")
        rows=self.conn.execute(
            """SELECT pc.participant_id AS content_id
               FROM episode_participants pi
               JOIN episodes e ON e.id=pi.episode_id
               JOIN episode_participants pc ON pc.episode_id=e.id
               WHERE e.kind='INSTANCE_CONTENT'
                 AND pi.role='instance' AND pi.participant_id=?
                 AND pc.role='content'""",
            (instance_id,)
        ).fetchall()
        if len(rows)!=1:
            raise ValueError("ArtifactInstance must bind exactly one ContentIdentity")
        return rows[0]["content_id"]

    def record_instance_occurrence(
        self,
        *,
        instance_id: str,
        context_id: str,
        locator: str,
        actor_id: Optional[str]=None,
        mode: str="OBSERVE",
        prior_occurrence_id: Optional[str]=None,
        occurred_at: Optional[str]=None,
        provenance_class: str,
        provenance: str,
        identity_key: Optional[str]=None,
        title: Optional[str]=None,
    ) -> str:
        inst=self.get(instance_id)
        ctx=self.get(context_id)
        if inst.type!="ArtifactInstance":
            raise TypeError("instance_id must be ArtifactInstance")
        if ctx.type!="Context":
            raise TypeError("context_id must be Context")
        if actor_id is not None and self.get(actor_id).type!="Actor":
            raise TypeError("actor_id must be Actor")
        mode=mode.upper()
        if mode not in CUSTODY_MODES:
            raise ValueError(f"unknown custody mode: {mode}")
        if prior_occurrence_id is not None:
            prior=self.get(prior_occurrence_id)
            if prior.type!="Occurrence":
                raise TypeError("prior_occurrence_id must be Occurrence")
            if self.instance_of_occurrence(prior_occurrence_id)!=instance_id:
                raise ValueError("prior occurrence belongs to a different ArtifactInstance")

        occ=self.add(
            "Occurrence",
            title or locator,
            data={
                "locator":locator,
                "occurred_at":occurred_at,
                "mode":mode,
            },
            provenance_class=provenance_class,
            provenance=provenance,
            identity_key=identity_key,
        )
        participants=[
            {"role":"instance","object_id":instance_id},
            {"role":"occurrence","object_id":occ},
            {"role":"context","object_id":context_id},
        ]
        if actor_id is not None:
            participants.append({"role":"actor","object_id":actor_id})
        if prior_occurrence_id is not None:
            participants.append({"role":"prior_occurrence","object_id":prior_occurrence_id})
        self.add_episode(
            "INSTANCE_OCCURRENCE",
            f"{mode}: {locator}",
            participants=participants,
            data={"mode":mode,"locator":locator,"occurred_at":occurred_at},
            provenance_class=provenance_class,
            provenance=provenance,
        )
        return occ

    def instance_of_occurrence(self, occurrence_id: str) -> str:
        occ=self.get(occurrence_id)
        if occ.type!="Occurrence":
            raise TypeError("occurrence_id must be Occurrence")
        rows=self.conn.execute(
            """SELECT pi.participant_id AS instance_id
               FROM episode_participants po
               JOIN episodes e ON e.id=po.episode_id
               JOIN episode_participants pi ON pi.episode_id=e.id
               WHERE e.kind='INSTANCE_OCCURRENCE'
                 AND po.role='occurrence' AND po.participant_id=?
                 AND pi.role='instance'""",
            (occurrence_id,)
        ).fetchall()
        if len(rows)!=1:
            raise ValueError("Occurrence must bind exactly one ArtifactInstance on the instance-aware path")
        return rows[0]["instance_id"]

    def content_of_instance_occurrence(self, occurrence_id: str) -> str:
        return self.content_of_instance(self.instance_of_occurrence(occurrence_id))

    def same_instance(self, occurrence_a: str, occurrence_b: str) -> bool:
        return self.instance_of_occurrence(occurrence_a)==self.instance_of_occurrence(occurrence_b)

    def custody_transfer(
        self,
        *,
        source_context_id: str,
        destination_context_id: str,
        source_occurrence_id: str,
        destination_locator: str,
        mode: str,
        obligation_ids: list[str],
        evidence_entity_ids: list[str],
        actor_id: Optional[str]=None,
        reconstructed_content_id: Optional[str]=None,
        result: str="PRESERVED",
        reason: str,
        provenance_class: str,
        provenance: str,
        identity_key: Optional[str]=None,
    ) -> dict:
        source_ctx=self.get(source_context_id)
        dest_ctx=self.get(destination_context_id)
        if source_ctx.type!="Context" or dest_ctx.type!="Context":
            raise TypeError("custody transfer endpoints must be Context")
        source_occ=self.get(source_occurrence_id)
        if source_occ.type!="Occurrence":
            raise TypeError("source_occurrence_id must be Occurrence")
        source_instance=self.instance_of_occurrence(source_occurrence_id)
        source_content=self.content_of_instance(source_instance)
        mode=mode.upper()
        if mode not in {"COPY","MOVE","RECONSTRUCT"}:
            raise ValueError("custody_transfer mode must be COPY, MOVE, or RECONSTRUCT")
        if not obligation_ids:
            raise ValueError("custody transfer requires at least one obligation")
        for oid in obligation_ids:
            if self.get(oid).type!="Obligation":
                raise TypeError("obligation_ids must be Obligation")
        for eid in evidence_entity_ids:
            self.entity_kind(eid)

        if mode=="MOVE":
            destination_instance=source_instance
        elif mode=="COPY":
            destination_instance=self.create_artifact_instance(
                content_id=source_content,
                title=f"Copy of {self.get(source_instance).title}",
                provenance_class=provenance_class,
                provenance=provenance,
            )
        else:
            content_id=reconstructed_content_id or source_content
            content=self.get(content_id)
            if content.type!="ContentIdentity":
                raise TypeError("reconstructed_content_id must be ContentIdentity")
            destination_instance=self.create_artifact_instance(
                content_id=content_id,
                title=f"Reconstruction from {self.get(source_instance).title}",
                provenance_class=provenance_class,
                provenance=provenance,
            )

        destination_occurrence=self.record_instance_occurrence(
            instance_id=destination_instance,
            context_id=destination_context_id,
            locator=destination_locator,
            actor_id=actor_id,
            mode=mode,
            prior_occurrence_id=source_occurrence_id if mode=="MOVE" else None,
            provenance_class=provenance_class,
            provenance=provenance,
        )
        result=result.upper()
        if result not in TRANSFER_RESULTS:
            raise ValueError(f"unknown transfer result: {result}")
        if result=="PRESERVED":
            self._require_preserved_transfer_obligations(obligation_ids,evidence_entity_ids)
        decision=self.add(
            "Decision",
            f"Custody transfer {mode}: {result}",
            data={
                "mode":mode,
                "result":result,
                "reason":reason,
                "source_instance_id":source_instance,
                "destination_instance_id":destination_instance,
                "content_preserved": self.content_of_instance(destination_instance)==source_content,
            },
            provenance_class=provenance_class,
            provenance=provenance,
        )
        participants=[
            {"role":"source_context","object_id":source_context_id},
            {"role":"destination_context","object_id":destination_context_id},
            {"role":"source_occurrence","object_id":source_occurrence_id},
            {"role":"destination_occurrence","object_id":destination_occurrence},
            {"role":"result","object_id":decision},
        ]
        for i,oid in enumerate(obligation_ids):
            participants.append({"role":"obligation","object_id":oid,"ordinal":i})
        for i,eid in enumerate(evidence_entity_ids):
            participants.append({"role":"evidence","entity_id":eid,"ordinal":i})
        episode=self.add_episode(
            "CUSTODY_TRANSFER",
            f"{mode}: {source_ctx.title} -> {dest_ctx.title}",
            participants=participants,
            data={
                "mode":mode,
                "result":result,
                "reason":reason,
                "source_instance_id":source_instance,
                "destination_instance_id":destination_instance,
                "content_preserved": self.content_of_instance(destination_instance)==source_content,
            },
            provenance_class=provenance_class,
            provenance=provenance,
            identity_key=identity_key,
        )
        return {
            "episode_id":episode,
            "mode":mode,
            "source_instance_id":source_instance,
            "destination_instance_id":destination_instance,
            "source_occurrence_id":source_occurrence_id,
            "destination_occurrence_id":destination_occurrence,
            "content_preserved":self.content_of_instance(destination_instance)==source_content,
        }

    def record_occurrence(
        self,
        *,
        content_id: str,
        locator: str,
        context_id: Optional[str]=None,
        actor_id: Optional[str]=None,
        occurred_at: Optional[str]=None,
        provenance_class: str,
        provenance: str,
        identity_key: Optional[str]=None,
        title: Optional[str]=None,
    ) -> str:
        content=self.get(content_id)
        if content.type!="ContentIdentity": raise TypeError("content_id must be ContentIdentity")
        if context_id is not None and self.get(context_id).type!="Context":
            raise TypeError("context_id must be Context")
        if actor_id is not None and self.get(actor_id).type!="Actor":
            raise TypeError("actor_id must be Actor")
        occ=self.add(
            "Occurrence",title or locator,
            data={"locator":locator,"context_id":context_id,"actor_id":actor_id,"occurred_at":occurred_at},
            provenance_class=provenance_class,provenance=provenance,
            identity_key=identity_key)
        self.add_episode(
            "CONTENT_OCCURRENCE",f"Occurrence of {content.title}",
            participants=[
                {"role":"content","object_id":content_id},
                {"role":"occurrence","object_id":occ},
            ],
            data={"locator":locator},
            provenance_class=provenance_class,provenance=provenance)
        return occ

    def content_of_occurrence(self, occurrence_id: str) -> str:
        occ=self.get(occurrence_id)
        if occ.type!="Occurrence": raise TypeError("occurrence_id must be Occurrence")
        rows=self.conn.execute(
            """SELECT p2.participant_id AS content_id
               FROM episode_participants p1
               JOIN episodes e ON e.id=p1.episode_id
               JOIN episode_participants p2 ON p2.episode_id=e.id
               WHERE e.kind='CONTENT_OCCURRENCE'
                 AND p1.role='occurrence' AND p1.participant_id=?
                 AND p2.role='content'""",(occurrence_id,)).fetchall()
        if len(rows)!=1: raise ValueError("Occurrence must bind exactly one ContentIdentity")
        return rows[0]["content_id"]

    def same_content(self, occurrence_a: str, occurrence_b: str) -> bool:
        return self.content_of_occurrence(occurrence_a)==self.content_of_occurrence(occurrence_b)


    def _derivation_outputs_from(self, occurrence_id: str) -> list[str]:
        rows=self.conn.execute(
            """SELECT DISTINCT po.participant_id AS output_id
               FROM episode_participants pi
               JOIN episodes e ON e.id=pi.episode_id
               JOIN episode_participants po ON po.episode_id=e.id
               WHERE e.kind='DERIVATION'
                 AND pi.role='input' AND pi.participant_id=?
                 AND po.role='output'""",
            (occurrence_id,)
        ).fetchall()
        return [r["output_id"] for r in rows]

    def _derivation_reaches(self, start_occurrence_id: str, target_occurrence_id: str) -> bool:
        todo=[start_occurrence_id]; seen=set()
        while todo:
            cur=todo.pop()
            if cur==target_occurrence_id:
                return True
            if cur in seen:
                continue
            seen.add(cur)
            todo.extend(self._derivation_outputs_from(cur))
        return False

    def record_derivation(
        self,
        *,
        input_occurrence_ids: list[str],
        method_id: str,
        output_occurrence_id: str,
        execution_id: Optional[str]=None,
        basis_entity_ids: Optional[list[str]]=None,
        transformation: str,
        reconstructibility: str,
        provenance_class: str,
        provenance: str,
        identity_key: Optional[str]=None,
    ) -> str:
        if not input_occurrence_ids:
            raise ValueError("derivation requires at least one input occurrence")
        method=self.get(method_id)
        output=self.get(output_occurrence_id)
        if method.type!="Method":
            raise TypeError("method_id must be Method")
        if output.type!="Occurrence":
            raise TypeError("output_occurrence_id must be Occurrence")
        for iid in input_occurrence_ids:
            if self.get(iid).type!="Occurrence":
                raise TypeError("all derivation inputs must be Occurrence")
            if iid==output_occurrence_id or self._derivation_reaches(output_occurrence_id,iid):
                raise ValueError("derivation would create a provenance cycle")
        if execution_id is not None and self.entity_descriptor(execution_id)!="EPISODE:EXECUTION":
            raise TypeError("execution_id must be EXECUTION Episode")
        basis_entity_ids=basis_entity_ids or []
        for bid in basis_entity_ids:
            self.entity_kind(bid)
        if not transformation.strip():
            raise ValueError("transformation description required")
        if reconstructibility not in {"DIRECT","PARTIAL","RECONSTRUCTED","UNKNOWN"}:
            raise ValueError("invalid reconstructibility")

        participants=[
            {"role":"method","object_id":method_id},
            {"role":"output","object_id":output_occurrence_id},
        ]
        for i,iid in enumerate(input_occurrence_ids):
            participants.append({"role":"input","object_id":iid,"ordinal":i})
        if execution_id is not None:
            participants.append({"role":"execution","episode_id":execution_id})
        for i,bid in enumerate(basis_entity_ids):
            participants.append({"role":"basis","entity_id":bid,"ordinal":i})
        return self.add_episode(
            "DERIVATION",
            transformation,
            participants=participants,
            data={
                "transformation":transformation,
                "reconstructibility":reconstructibility,
            },
            provenance_class=provenance_class,
            provenance=provenance,
            identity_key=identity_key,
        )


    def record_association(
        self,
        *,
        source_entity_id: str,
        target_entity_id: str,
        scope_id: str,
        relation: str,
        resolution_status: str,
        provenance_class: str,
        provenance: str,
        identity_key: Optional[str]=None,
        note: str="",
    ) -> str:
        self.entity_kind(source_entity_id)
        self.entity_kind(target_entity_id)
        scope=self.get(scope_id)
        if scope.type!="Scope":
            raise TypeError("scope_id must be Scope")
        if not relation.strip():
            raise ValueError("association relation type required")
        resolution_status=resolution_status.upper()
        if resolution_status not in ASSOCIATION_RESOLUTION_STATUSES:
            raise ValueError(f"unknown association resolution status: {resolution_status}")
        return self.add_episode(
            "ASSOCIATION",
            relation,
            participants=[
                {"role":"source","entity_id":source_entity_id},
                {"role":"target","entity_id":target_entity_id},
                {"role":"scope","object_id":scope_id},
            ],
            data={
                "relation":relation,
                "resolution_status":resolution_status,
                "note":note,
                "evidence_effect":"NONE",
                "authority_effect":"NONE",
                "applicability_effect":"NONE",
                "movement_effect":"NONE",
            },
            provenance_class=provenance_class,
            provenance=provenance,
            identity_key=identity_key,
        )


    def record_adaptation(
        self,
        *,
        context_id: str,
        actor_id: str,
        entity_id: str,
        scope_id: str,
        action: str,
        basis_entity_ids: list[str],
        rollback_condition: str,
        max_exposure: str,
        result: str="APPLIED",
        provenance_class: str,
        provenance: str,
        identity_key: Optional[str]=None,
    ) -> str:
        if self.get(context_id).type!="Context": raise TypeError("context_id must be Context")
        if self.get(actor_id).type!="Actor": raise TypeError("actor_id must be Actor")
        if self.get(scope_id).type!="Scope": raise TypeError("scope_id must be Scope")
        self.entity_kind(entity_id)
        if not action.strip() or not rollback_condition.strip() or not max_exposure.strip():
            raise ValueError("adaptation requires action, rollback_condition, and max_exposure")
        result=result.upper()
        if result not in ADAPTATION_RESULTS: raise ValueError(f"unknown adaptation result: {result}")
        for bid in basis_entity_ids: self.entity_kind(bid)
        decision=self.add(
            "Decision",f"Adaptation {result}",
            data={
                "result":result,"action":action,"rollback_condition":rollback_condition,
                "max_exposure":max_exposure,"persistent_promotion":False,
            },
            provenance_class=provenance_class,provenance=provenance)
        participants=[
            {"role":"context","object_id":context_id},
            {"role":"actor","object_id":actor_id},
            {"role":"entity","entity_id":entity_id},
            {"role":"scope","object_id":scope_id},
            {"role":"result","object_id":decision},
        ]
        for i,bid in enumerate(basis_entity_ids):
            participants.append({"role":"basis","entity_id":bid,"ordinal":i})
        return self.add_episode(
            "ADAPTATION",action,participants=participants,
            data={
                "result":result,"action":action,"rollback_condition":rollback_condition,
                "max_exposure":max_exposure,"reversible":True,"persistent_promotion":False,
            },
            provenance_class=provenance_class,provenance=provenance,identity_key=identity_key)


    def _require_promotion_witness(self, witness_entity_id: str):
        descriptor=self.entity_descriptor(witness_entity_id)
        if descriptor in {"OBJECT:Evidence","OBJECT:Observation"}:
            obj=self.get(witness_entity_id)
            if obj.epistemic not in {"OBSERVED","TESTED","SUPPORTED"}:
                raise ValueError(
                    f"promotion witness {descriptor} has inadequate epistemic status: {obj.epistemic}"
                )
            return
        if descriptor=="EPISODE:EXECUTION":
            ep=self.episode(witness_entity_id)
            if ep["data"].get("status")!="COMPLETED":
                raise ValueError(
                    f"promotion witness execution is not COMPLETED: {ep['data'].get('status')}"
                )
            return
        if descriptor=="EPISODE:REPLICATION_ASSESSMENT":
            ep=self.episode(witness_entity_id)
            if ep["data"].get("grade")=="UNRESOLVED":
                raise ValueError("UNRESOLVED replication assessment cannot certify promotion")
            return
        raise TypeError("promotion witness must be adequate Evidence/Observation/Execution/ReplicationAssessment")

    def record_promotion(
        self,
        *,
        context_id: str,
        entity_id: str,
        scope_id: str,
        validity_frame_id: str,
        witness_entity_id: str,
        basis_entity_ids: list[str],
        change_claim: str,
        revalidation_rule: str,
        result: str="PROMOTED",
        provenance_class: str,
        provenance: str,
        identity_key: Optional[str]=None,
    ) -> str:
        if self.get(context_id).type!="Context": raise TypeError("context_id must be Context")
        if self.get(scope_id).type!="Scope": raise TypeError("scope_id must be Scope")
        if self.get(validity_frame_id).type!="ValidityFrame":
            raise TypeError("validity_frame_id must be ValidityFrame")
        self.entity_kind(entity_id)
        self._require_promotion_witness(witness_entity_id)
        if not change_claim.strip() or not revalidation_rule.strip():
            raise ValueError("promotion requires change_claim and revalidation_rule")
        result=result.upper()
        if result not in PROMOTION_RESULTS: raise ValueError(f"unknown promotion result: {result}")
        for bid in basis_entity_ids: self.entity_kind(bid)
        decision=self.add(
            "Decision",f"Promotion {result}",
            data={
                "result":result,"change_claim":change_claim,
                "revalidation_rule":revalidation_rule,"persistent_promotion":True,
            },
            provenance_class=provenance_class,provenance=provenance)
        participants=[
            {"role":"context","object_id":context_id},
            {"role":"entity","entity_id":entity_id},
            {"role":"scope","object_id":scope_id},
            {"role":"frame","object_id":validity_frame_id},
            {"role":"witness","entity_id":witness_entity_id},
            {"role":"result","object_id":decision},
        ]
        for i,bid in enumerate(basis_entity_ids):
            participants.append({"role":"basis","entity_id":bid,"ordinal":i})
        return self.add_episode(
            "PROMOTION",change_claim,participants=participants,
            data={
                "result":result,"change_claim":change_claim,
                "revalidation_rule":revalidation_rule,"persistent_promotion":True,
            },
            provenance_class=provenance_class,provenance=provenance,identity_key=identity_key)


    def record_failure(
        self,
        *,
        subject_entity_id: str,
        location_entity_id: str,
        observation_id: str,
        frame_id: str,
        cause_status: str="UNKNOWN",
        cause_entity_ids: Optional[list[str]]=None,
        basis_entity_ids: Optional[list[str]]=None,
        failure_class: str="FAILURE",
        provenance_class: str,
        provenance: str,
        identity_key: Optional[str]=None,
    ) -> str:
        self.entity_kind(subject_entity_id)
        self.entity_kind(location_entity_id)
        obs=self.get(observation_id)
        if obs.type not in {"Observation","Evidence"}:
            raise TypeError("failure observation must be Observation or Evidence")
        frame=self.get(frame_id)
        if frame.type!="ObservationFrame":
            raise TypeError("failure frame_id must be ObservationFrame")
        cause_status=cause_status.upper()
        if cause_status not in FAILURE_CAUSE_STATUSES:
            raise ValueError(f"unknown cause status: {cause_status}")
        cause_entity_ids=cause_entity_ids or []
        basis_entity_ids=basis_entity_ids or []
        if cause_status=="UNKNOWN" and cause_entity_ids:
            raise ValueError("UNKNOWN cause status cannot carry cause entities")
        if cause_status=="SINGLE_SUPPORTED" and len(cause_entity_ids)!=1:
            raise ValueError("SINGLE_SUPPORTED requires exactly one cause")
        if cause_status in {"MULTICAUSAL","CONTESTED"} and len(cause_entity_ids)<2:
            raise ValueError(f"{cause_status} requires at least two causes")
        if cause_status=="HYPOTHESIZED" and not cause_entity_ids:
            raise ValueError("HYPOTHESIZED requires at least one cause candidate")
        for cid in cause_entity_ids:
            c=self.get(cid)
            if c.type not in {"Inference","Candidate","Claim"}:
                raise TypeError("failure cause must be Inference, Candidate, or Claim")
        for bid in basis_entity_ids:
            self.entity_kind(bid)

        participants=[
            {"role":"subject","entity_id":subject_entity_id},
            {"role":"location","entity_id":location_entity_id},
            {"role":"observation","object_id":observation_id},
            {"role":"frame","object_id":frame_id},
        ]
        for i,cid in enumerate(cause_entity_ids):
            participants.append({"role":"cause","object_id":cid,"ordinal":i})
        for i,bid in enumerate(basis_entity_ids):
            participants.append({"role":"basis","entity_id":bid,"ordinal":i})
        return self.add_episode(
            "FAILURE",failure_class,
            participants=participants,
            data={"failure_class":failure_class,"cause_status":cause_status},
            provenance_class=provenance_class,provenance=provenance,
            identity_key=identity_key)

    def _claim_has_supported_assessment(self, claim_id: str) -> bool:
        for ep in self.claim_assessments(claim_id):
            if ep["data"].get("verdict") == "SUPPORTED":
                return True
        return False

    def claim_dependency_status(self, claim_id: str) -> dict:
        """Check declared Claim->Claim REQUIRES dependencies recursively.

        A Claim with no REQUIRES edges is dependency-ready. A required Claim must
        itself have at least one SUPPORTED assessment and have its own declared
        requirements satisfied. This does not establish theorem truth; it only
        prevents a declared justification graph from being bypassed.
        """
        if self.get(claim_id).type != "Claim":
            raise TypeError("claim_dependency_status requires a Claim")
        visiting=set(); checked=set(); missing=[]; cycles=[]

        def walk(cid: str, path: list[str]):
            if cid in visiting:
                cycles.append(path + [cid]); return
            if cid in checked: return
            visiting.add(cid)
            rows=self.conn.execute(
                "SELECT to_id,data_json FROM relations WHERE from_id=? AND kind='REQUIRES' ORDER BY created_at",
                (cid,)
            ).fetchall()
            for r in rows:
                rid=r["to_id"]
                try:
                    robj=self.get(rid)
                except KeyError:
                    missing.append({"claim":cid,"required":rid,"reason":"missing entity"}); continue
                if robj.type != "Claim":
                    missing.append({"claim":cid,"required":rid,"reason":"required entity is not Claim"}); continue
                if not self._claim_has_supported_assessment(rid):
                    missing.append({"claim":cid,"required":rid,"reason":"required claim has no SUPPORTED assessment"})
                walk(rid,path+[cid])
            visiting.remove(cid); checked.add(cid)

        walk(claim_id,[])
        return {"satisfied":not missing and not cycles,"missing":missing,"cycles":cycles}

    def claim_evidence_qualification_status(self, claim_id: str, evidence_ids: list[str]) -> dict:
        """Check claim-local evidence qualifications without inventing a new evidence ontology.

        A Claim may declare ``required_evidence_tags`` in its data. Evidence,
        Observation, or Artifact objects may declare ``evidence_tags``. A SUPPORT
        assessment is qualification-ready only when every required tag is supplied
        by at least one cited evidence object. Tags express declared applicability;
        they do not authenticate or prove the underlying evidence by themselves.
        """
        claim=self.get(claim_id)
        if claim.type!="Claim":
            raise TypeError("claim_evidence_qualification_status requires a Claim")
        raw_required=claim.data.get("required_evidence_tags",[])
        if raw_required is None: raw_required=[]
        if not isinstance(raw_required,list) or any(not isinstance(x,str) or not x.strip() for x in raw_required):
            raise ValueError("Claim required_evidence_tags must be a list of nonempty strings")
        required=set(raw_required)
        provided=set(); sources={}
        invalid=[]
        for eid in evidence_ids:
            ev=self.get(eid)
            if ev.type not in {"Evidence","Observation","Artifact"}:
                invalid.append({"evidence_id":eid,"type":ev.type})
                continue
            raw_tags=ev.data.get("evidence_tags",[])
            if raw_tags is None: raw_tags=[]
            if not isinstance(raw_tags,list) or any(not isinstance(x,str) or not x.strip() for x in raw_tags):
                raise ValueError(f"evidence_tags for {eid} must be a list of nonempty strings")
            for tag in raw_tags:
                provided.add(tag); sources.setdefault(tag,[]).append(eid)
        missing=sorted(required-provided)
        return {
            "satisfied":not missing and not invalid,
            "required":sorted(required),
            "provided":sorted(provided),
            "missing":missing,
            "sources":sources,
            "invalid":invalid,
        }




    def claim_evidence_method_compliance_status(self, claim_id: str, evidence_ids: list[str]) -> dict:
        """Validate claim-local method-compliance requirements for cited evidence.

        A Claim may declare ``evidence_method_compliance_contract`` with:
        - method_id: exact Method object that governs the relation;
        - context_id: exact Context of the compliance assessment;
        - scope_id: exact Scope of the compliance assessment;
        - allowed_verdicts: e.g. ["CURRENT"];
        - require_assessment: defaults true.

        Compliance is derived from METHOD_COMPLIANCE episodes, not from a source's
        self-declared role, filename, or evidence tag. The latest assessment for
        each cited evidence entity under the exact method/context/scope is used.
        """
        claim=self.get(claim_id)
        if claim.type!="Claim":
            raise TypeError("claim_evidence_method_compliance_status requires a Claim")
        contract=claim.data.get("evidence_method_compliance_contract")
        if contract is None:
            return {"satisfied":True,"contract":None,"evidence":[]}
        if not isinstance(contract,dict):
            raise ValueError("Claim evidence_method_compliance_contract must be an object")
        method_id=contract.get("method_id")
        context_id=contract.get("context_id")
        scope_id=contract.get("scope_id")
        method=self.get(method_id)
        context=self.get(context_id)
        scope=self.get(scope_id)
        if method.type!="Method": raise TypeError("method compliance contract method_id must be Method")
        if context.type!="Context": raise TypeError("method compliance contract context_id must be Context")
        if scope.type!="Scope": raise TypeError("method compliance contract scope_id must be Scope")
        allowed=contract.get("allowed_verdicts",["CURRENT"])
        if not isinstance(allowed,list) or not allowed:
            raise ValueError("allowed_verdicts must be a nonempty list")
        allowed={str(x).upper() for x in allowed}
        if not allowed.issubset(METHOD_COMPLIANCE_RESULTS):
            raise ValueError("method compliance contract contains unknown verdict")
        require=bool(contract.get("require_assessment",True))
        failures=[]; rows=[]
        for eid in evidence_ids:
            self.entity_kind(eid)
            eps=self.conn.execute(
                """SELECT DISTINCT e.id,e.created_at
                   FROM episodes e
                   JOIN episode_participants pe ON pe.episode_id=e.id
                   JOIN episode_participants pm ON pm.episode_id=e.id
                   JOIN episode_participants pc ON pc.episode_id=e.id
                   JOIN episode_participants ps ON ps.episode_id=e.id
                   WHERE e.kind='METHOD_COMPLIANCE'
                     AND pe.role='entity' AND pe.participant_id=?
                     AND pm.role='method' AND pm.participant_id=?
                     AND pc.role='context' AND pc.participant_id=?
                     AND ps.role='scope' AND ps.participant_id=?
                   ORDER BY e.created_at DESC,e.id DESC""",
                (eid,method_id,context_id,scope_id)
            ).fetchall()
            if not eps:
                rows.append({"evidence_id":eid,"assessment_id":None,"verdict":None})
                if require:
                    failures.append({"evidence_id":eid,"kind":"METHOD_COMPLIANCE_MISSING"})
                continue
            ep=self.episode(eps[0]["id"])
            verdict=str(ep["data"].get("verdict","")).upper()
            rows.append({"evidence_id":eid,"assessment_id":ep["id"],"verdict":verdict})
            if verdict not in allowed:
                failures.append({
                    "evidence_id":eid,"kind":"METHOD_COMPLIANCE_NOT_ALLOWED",
                    "verdict":verdict,"allowed":sorted(allowed),"assessment_id":ep["id"]
                })
        return {
            "satisfied":not failures,
            "method_id":method_id,"context_id":context_id,"scope_id":scope_id,
            "allowed_verdicts":sorted(allowed),"require_assessment":require,
            "evidence":rows,"failures":failures,
        }

    def claim_evidence_source_role_status(self, claim_id: str, evidence_ids: list[str]) -> dict:
        """Validate claim-local source-role constraints for cited evidence.

        A Claim may declare ``evidence_source_role_contract`` in its data:

        {
          "allowed": ["EMPIRICAL_RESULT", ...],        # optional
          "forbidden": ["PHILOSOPHY", ...],           # optional
          "require_declared_role": true|false          # optional, default false
        }

        Evidence/Observation/Artifact objects may declare a task-local ``source_role``.
        This does not make the role globally intrinsic to the underlying thing. It only
        constrains what role that cited evidence is allowed to play for this Claim.
        """
        claim=self.get(claim_id)
        if claim.type!="Claim":
            raise TypeError("claim_evidence_source_role_status requires a Claim")
        contract=claim.data.get("evidence_source_role_contract")
        if contract is None:
            return {"satisfied":True,"contract":None,"evidence":[]}
        if not isinstance(contract,dict):
            raise ValueError("Claim evidence_source_role_contract must be an object")

        def _norm_list(name):
            raw=contract.get(name,[])
            if raw is None:
                raw=[]
            if not isinstance(raw,list) or any(not isinstance(x,str) or not x.strip() for x in raw):
                raise ValueError(f"evidence_source_role_contract {name} must be a list of nonempty strings")
            return set(x.strip() for x in raw)

        allowed=_norm_list("allowed")
        forbidden=_norm_list("forbidden")
        require_declared=bool(contract.get("require_declared_role",False))
        failures=[]; rows=[]
        for eid in evidence_ids:
            ev=self.get(eid)
            if ev.type not in {"Evidence","Observation","Artifact"}:
                failures.append({"evidence_id":eid,"kind":"INVALID_EVIDENCE_TYPE","type":ev.type})
                continue
            role=ev.data.get("source_role")
            if role is not None and (not isinstance(role,str) or not role.strip()):
                raise ValueError(f"source_role for {eid} must be a nonempty string when present")
            role=None if role is None else role.strip()
            rows.append({"evidence_id":eid,"source_role":role})
            if require_declared and role is None:
                failures.append({"evidence_id":eid,"kind":"SOURCE_ROLE_MISSING"})
                continue
            if role is None:
                continue
            if role in forbidden:
                failures.append({"evidence_id":eid,"kind":"FORBIDDEN_SOURCE_ROLE","source_role":role})
            if allowed and role not in allowed:
                failures.append({
                    "evidence_id":eid,"kind":"SOURCE_ROLE_NOT_ALLOWED",
                    "source_role":role,"allowed":sorted(allowed)
                })
        return {
            "satisfied":not failures,
            "allowed":sorted(allowed),
            "forbidden":sorted(forbidden),
            "require_declared_role":require_declared,
            "evidence":rows,
            "failures":failures,
        }

    def claim_evidence_set_status(self, claim_id: str) -> dict:
        """Validate an exact evidence-set contract declared by a Claim.

        A Claim may carry ``evidence_set_contract`` with:
        - collection_id: Collection containing the linked raw evidence;
        - expected_count: optional exact member count;
        - identity_field: optional member-data field used for exact identity checks;
        - expected_identities: optional exact identity set;
        - expected_identity_sha256: optional SHA-256 of the canonical identity set;
        - required_member_evidence_tags: optional tags every member must carry.

        This checks custody/composition of the evidence set. It does not make the
        observations true and does not convert UNKNOWN observations into misses.
        """
        claim=self.get(claim_id)
        if claim.type!="Claim":
            raise TypeError("claim_evidence_set_status requires a Claim")
        contract=claim.data.get("evidence_set_contract")
        if contract is None:
            return {"satisfied":True,"contract":None}
        if not isinstance(contract,dict):
            raise ValueError("Claim evidence_set_contract must be an object")
        collection_id=contract.get("collection_id")
        if not isinstance(collection_id,str) or not collection_id:
            raise ValueError("evidence_set_contract requires collection_id")
        collection=self.get(collection_id)
        if collection.type!="Collection":
            raise TypeError("evidence_set_contract collection_id must identify a Collection")

        members=self.collection_members(collection_id)
        failures=[]
        expected_count=contract.get("expected_count")
        if expected_count is not None:
            if not isinstance(expected_count,int) or expected_count < 0:
                raise ValueError("evidence_set_contract expected_count must be a nonnegative integer")
            if len(members)!=expected_count:
                failures.append({
                    "kind":"COUNT_MISMATCH",
                    "expected_count":expected_count,
                    "actual_count":len(members),
                })

        allowed_types=set(contract.get("allowed_member_types",["Evidence","Observation","Artifact"]))
        invalid_types=[]
        member_objects=[]
        for m in members:
            if m["type"] not in allowed_types:
                invalid_types.append({"entity_id":m["entity_id"],"type":m["type"]})
                continue
            member_objects.append(self.get(m["entity_id"]))
        if invalid_types:
            failures.append({"kind":"INVALID_MEMBER_TYPES","members":invalid_types[:20]})

        required_tags=contract.get("required_member_evidence_tags",[])
        if required_tags is None:
            required_tags=[]
        if not isinstance(required_tags,list) or any(not isinstance(x,str) or not x for x in required_tags):
            raise ValueError("required_member_evidence_tags must be a list of nonempty strings")
        tag_failures=[]
        for obj in member_objects:
            tags=obj.data.get("evidence_tags",[]) or []
            if not isinstance(tags,list):
                tag_failures.append({"entity_id":obj.id,"reason":"evidence_tags is not a list"})
                continue
            missing=sorted(set(required_tags)-set(tags))
            if missing:
                tag_failures.append({"entity_id":obj.id,"missing":missing})
        if tag_failures:
            failures.append({"kind":"MEMBER_TAG_MISMATCH","members":tag_failures[:20]})

        identity_field=contract.get("identity_field")
        identities=[]
        if identity_field is not None:
            if not isinstance(identity_field,str) or not identity_field:
                raise ValueError("identity_field must be a nonempty string")
            missing_identity=[]
            for obj in member_objects:
                if identity_field not in obj.data:
                    missing_identity.append(obj.id)
                else:
                    identities.append(obj.data[identity_field])
            if missing_identity:
                failures.append({
                    "kind":"MISSING_MEMBER_IDENTITY",
                    "identity_field":identity_field,
                    "entity_ids":missing_identity[:20],
                })

            canonical=[json.dumps(v,sort_keys=True,separators=(",",":"),ensure_ascii=False) for v in identities]
            if len(canonical)!=len(set(canonical)):
                failures.append({"kind":"DUPLICATE_MEMBER_IDENTITIES","identity_field":identity_field})

            expected_identities=contract.get("expected_identities")
            if expected_identities is not None:
                if not isinstance(expected_identities,list):
                    raise ValueError("expected_identities must be a list")
                expected_canonical=sorted(
                    json.dumps(v,sort_keys=True,separators=(",",":"),ensure_ascii=False)
                    for v in expected_identities
                )
                actual_canonical=sorted(canonical)
                if actual_canonical!=expected_canonical:
                    failures.append({
                        "kind":"IDENTITY_SET_MISMATCH",
                        "identity_field":identity_field,
                        "expected_count":len(expected_canonical),
                        "actual_count":len(actual_canonical),
                    })

            expected_digest=contract.get("expected_identity_sha256")
            if expected_digest is not None:
                if not isinstance(expected_digest,str) or len(expected_digest)!=64:
                    raise ValueError("expected_identity_sha256 must be a 64-character hex string")
                digest=hashlib.sha256(
                    ("\n".join(sorted(canonical))+"\n").encode("utf-8")
                ).hexdigest()
                if digest.lower()!=expected_digest.lower():
                    failures.append({
                        "kind":"IDENTITY_DIGEST_MISMATCH",
                        "expected":expected_digest.lower(),
                        "actual":digest,
                    })

        return {
            "satisfied":not failures,
            "collection_id":collection_id,
            "member_count":len(members),
            "failures":failures,
            "identity_field":identity_field,
            "identities_observed":len(identities),
        }

    def obligation_evidence_qualification_status(self, obligation_id: str, evidence_entity_ids: list[str]) -> dict:
        """Check evidence qualifications declared by an Obligation.

        An Obligation may carry ``required_evidence_tags``. Evidence-like Objects
        or Episodes may carry ``evidence_tags``. Tags do not prove truth; they
        prevent a PRESERVED transfer from bypassing its own declared evidence kind.
        """
        obligation=self.get(obligation_id)
        if obligation.type!="Obligation":
            raise TypeError("obligation_evidence_qualification_status requires an Obligation")
        raw_required=obligation.data.get("required_evidence_tags",[])
        if raw_required is None:
            raw_required=[]
        if not isinstance(raw_required,list) or any(
            not isinstance(x,str) or not x.strip() for x in raw_required
        ):
            raise ValueError("Obligation required_evidence_tags must be a list of nonempty strings")
        required=set(raw_required)
        provided=set(); sources={}
        for eid in evidence_entity_ids:
            kind=self.entity_kind(eid)
            data=self.get(eid).data if kind=="OBJECT" else self.episode(eid)["data"]
            raw_tags=data.get("evidence_tags",[])
            if raw_tags is None:
                raw_tags=[]
            if not isinstance(raw_tags,list) or any(
                not isinstance(x,str) or not x.strip() for x in raw_tags
            ):
                raise ValueError(f"evidence_tags for {eid} must be a list of nonempty strings")
            for tag in raw_tags:
                provided.add(tag)
                sources.setdefault(tag,[]).append(eid)
        missing=sorted(required-provided)
        return {
            "satisfied":not missing,
            "required":sorted(required),
            "provided":sorted(provided),
            "missing":missing,
            "sources":sources,
        }

    def _require_preserved_transfer_obligations(
        self,
        obligation_ids: list[str],
        evidence_entity_ids: list[str],
    ) -> list[dict]:
        statuses=[]
        for oid in obligation_ids:
            status=self.obligation_evidence_qualification_status(oid,evidence_entity_ids)
            statuses.append({"obligation_id":oid,**status})
            if not status["satisfied"]:
                raise ValueError(
                    "cannot record PRESERVED transfer without satisfying declared obligation evidence qualifications: "
                    + json.dumps(status, sort_keys=True)
                )
        return statuses

    def assess_claim(
        self,
        claim_id: str,
        *,
        frame_id: str,
        evidence_ids: list[str],
        verdict: str,
        scope: str,
        provenance_class: str,
        provenance: str,
        identity_key: Optional[str] = None,
        title: Optional[str] = None,
    ) -> str:
        """Attach a frame-scoped verdict to a Claim without mutating the Claim itself."""
        claim = self.get(claim_id)
        if claim.type != "Claim":
            raise TypeError("assess_claim requires a Claim")
        frame = self.get(frame_id)
        if frame.type != "ObservationFrame":
            raise TypeError("claim assessment frame must be ObservationFrame")
        if not evidence_ids:
            raise ValueError("claim assessment requires evidence")
        verdict = verdict.upper()
        allowed = {"SUPPORTED", "CONTRADICTED", "UNRESOLVED", "INCOMPARABLE"}
        if verdict not in allowed:
            raise ValueError(f"unknown claim-assessment verdict: {verdict}")
        if verdict == "SUPPORTED":
            dep=self.claim_dependency_status(claim_id)
            if not dep["satisfied"]:
                raise ValueError(
                    "cannot SUPPORT a claim while declared REQUIRES dependencies are unresolved: "
                    + json.dumps(dep, sort_keys=True)
                )
            qual=self.claim_evidence_qualification_status(claim_id,evidence_ids)
            if not qual["satisfied"]:
                raise ValueError(
                    "cannot SUPPORT a claim without its declared evidence qualifications: "
                    + json.dumps(qual, sort_keys=True)
                )
            role_status=self.claim_evidence_source_role_status(claim_id,evidence_ids)
            if not role_status["satisfied"]:
                raise ValueError(
                    "cannot SUPPORT a claim with disallowed evidence source roles: "
                    + json.dumps(role_status, sort_keys=True)
                )
            method_status=self.claim_evidence_method_compliance_status(claim_id,evidence_ids)
            if not method_status["satisfied"]:
                raise ValueError(
                    "cannot SUPPORT a claim without its declared method compliance: "
                    + json.dumps(method_status, sort_keys=True)
                )
            evidence_set=self.claim_evidence_set_status(claim_id)
            if not evidence_set["satisfied"]:
                raise ValueError(
                    "cannot SUPPORT a claim with an unsatisfied evidence-set contract: "
                    + json.dumps(evidence_set, sort_keys=True)
                )
        participants = [
            {"role":"claim","object_id":claim_id},
            {"role":"frame","object_id":frame_id},
        ]
        for i,eid in enumerate(evidence_ids):
            ev = self.get(eid)
            if ev.type not in {"Evidence","Observation","Artifact"}:
                raise TypeError("claim assessment evidence must be Evidence, Observation, or Artifact")
            participants.append({"role":"evidence","object_id":eid,"ordinal":i})
        return self.add_episode(
            "CLAIM_ASSESSMENT",
            title or f"{verdict}: {claim.title}",
            participants=participants,
            data={"verdict":verdict,"scope":scope},
            provenance_class=provenance_class,
            provenance=provenance,
            identity_key=identity_key,
        )

    def claim_assessments(self, claim_id: str) -> list[dict]:
        claim = self.get(claim_id)
        if claim.type != "Claim":
            raise TypeError("claim_assessments requires a Claim")
        rows = self.conn.execute(
            """SELECT DISTINCT e.id
               FROM episodes e
               JOIN episode_participants p ON p.episode_id=e.id
               WHERE e.kind='CLAIM_ASSESSMENT' AND p.role='claim' AND p.participant_id=?
               ORDER BY e.created_at""",
            (claim_id,)
        ).fetchall()
        return [self.episode(r["id"]) for r in rows]

    def set_epistemic(self, object_id: str, status: str, *, reason: str = ""):
        if status not in EPISTEMIC: raise ValueError(status)
        old = self.get(object_id)
        if old.type == "Claim":
            raise ValueError("Claim epistemic status is relational; use assess_claim()")
        self.conn.execute("UPDATE objects SET epistemic=? WHERE id=?", (status, object_id))
        self._event("EPISTEMIC_CHANGED", object_id, old=old.epistemic, new=status, reason=reason)
        self.conn.commit()

    def orbit(self, object_id: str, subject_id: str, *, reason: str = ""):
        obj = self.get(object_id)
        subject = self.get(subject_id)
        if subject.type != "Subject": raise TypeError("orbit subject must be Subject")
        self.conn.execute(
            "INSERT OR REPLACE INTO orbit_members(subject_id,object_id,reason,created_at) VALUES(?,?,?,?)",
            (subject_id, object_id, reason, now())
        )
        if obj.lifecycle not in {"ACTIVE", "QUARANTINED"}:
            self.conn.execute("UPDATE objects SET lifecycle='ORBITING' WHERE id=?", (object_id,))
        self._event("ORBITED", object_id, subject=subject_id, reason=reason)
        self.conn.commit()

    def deorbit(self, object_id: str, subject_id: str, *, reason: str = ""):
        self.conn.execute(
            "DELETE FROM orbit_members WHERE subject_id=? AND object_id=?", (subject_id, object_id)
        )
        remaining = self.conn.execute(
            "SELECT COUNT(*) n FROM orbit_members WHERE object_id=?", (object_id,)
        ).fetchone()["n"]
        obj = self.get(object_id)
        if remaining == 0 and obj.lifecycle == "ORBITING":
            self.conn.execute("UPDATE objects SET lifecycle='DORMANT' WHERE id=?", (object_id,))
        self._event("DEORBITED", object_id, subject=subject_id, reason=reason)
        self.conn.commit()



    def add_to_collection(self, collection_id: str, entity_id: str, *, note: str = ""):
        collection = self.get(collection_id)
        if collection.type != "Collection":
            raise TypeError("collection_id must be a Collection")
        self.entity_kind(entity_id)
        self.conn.execute(
            """INSERT OR IGNORE INTO collection_members(collection_id,entity_id,note,added_at)
               VALUES(?,?,?,?)""",
            (collection_id, entity_id, note, now())
        )
        self._event("COLLECTION_ADD", collection_id, entity_id=entity_id, note=note)
        self.conn.commit()

    def remove_from_collection(self, collection_id: str, entity_id: str, *, reason: str = ""):
        collection = self.get(collection_id)
        if collection.type != "Collection":
            raise TypeError("collection_id must be a Collection")
        self.conn.execute(
            "DELETE FROM collection_members WHERE collection_id=? AND entity_id=?",
            (collection_id, entity_id)
        )
        self._event("COLLECTION_REMOVE", collection_id, entity_id=entity_id, reason=reason)
        self.conn.commit()

    def collection_members(self, collection_id: str) -> list[dict]:
        collection = self.get(collection_id)
        if collection.type != "Collection":
            raise TypeError("collection_id must be a Collection")
        rows=self.conn.execute(
            """SELECT cm.entity_id,cm.note,cm.added_at,en.entity_kind,
                      COALESCE(o.type,e.kind) AS type,
                      COALESCE(o.title,e.title) AS title
               FROM collection_members cm
               JOIN entities en ON en.id=cm.entity_id
               LEFT JOIN objects o ON o.id=cm.entity_id AND en.entity_kind='OBJECT'
               LEFT JOIN episodes e ON e.id=cm.entity_id AND en.entity_kind='EPISODE'
               WHERE cm.collection_id=? ORDER BY cm.added_at""",
            (collection_id,)
        ).fetchall()
        return [dict(r) for r in rows]



    # ------------------------------------------------------------------
    # Scope layer
    # ------------------------------------------------------------------

    def link_scope(self, parent_scope_id: str, child_scope_id: str):
        parent = self.get(parent_scope_id)
        child = self.get(child_scope_id)
        if parent.type != "Scope" or child.type != "Scope":
            raise TypeError("scope containment requires Scope objects")
        if parent_scope_id == child_scope_id:
            raise ValueError("scope cannot contain itself")
        # Would parent -> child create a cycle? Check whether parent is already below child.
        if self.scope_contains(child_scope_id, parent_scope_id):
            raise ValueError("scope containment would create a cycle")
        self.conn.execute(
            "INSERT OR IGNORE INTO scope_edges(parent_scope_id,child_scope_id,created_at) VALUES(?,?,?)",
            (parent_scope_id, child_scope_id, now())
        )
        self._event("SCOPE_LINKED", child_scope_id, parent_scope_id=parent_scope_id)
        self.conn.commit()

    def scope_contains(self, parent_scope_id: str, requested_scope_id: str) -> bool:
        parent = self.get(parent_scope_id)
        requested = self.get(requested_scope_id)
        if parent.type != "Scope" or requested.type != "Scope":
            raise TypeError("scope containment requires Scope objects")
        if parent_scope_id == requested_scope_id:
            return True
        todo = [parent_scope_id]
        seen = set()
        while todo:
            current = todo.pop()
            if current in seen:
                continue
            seen.add(current)
            rows = self.conn.execute(
                "SELECT child_scope_id FROM scope_edges WHERE parent_scope_id=?",
                (current,)
            ).fetchall()
            for r in rows:
                child = r["child_scope_id"]
                if child == requested_scope_id:
                    return True
                todo.append(child)
        return False

    # ------------------------------------------------------------------
    # Authority layer
    # ------------------------------------------------------------------


    def establish_authority_root(
        self,
        *,
        context_id: str,
        scope_id: str,
        operations: list[str],
        holder_actor_id: str,
        max_delegation_depth: int = 0,
        expires_at: Optional[str] = None,
        provenance_class: str,
        provenance: str,
        identity_key: Optional[str] = None,
        title: str = "Destination authority",
    ) -> str:
        """Create a destination-owned root authority.

        Imported or derived predecessor material cannot create a root authority
        for a destination in this prototype.
        """
        context = self.get(context_id)
        scope = self.get(scope_id)
        holder = self.get(holder_actor_id)
        if holder.type != "Actor":
            raise TypeError("holder_actor_id must be Actor")
        if context.type != "Context":
            raise TypeError("context_id must be Context")
        if scope.type != "Scope":
            raise TypeError("scope_id must be Scope")
        if provenance_class != "USER":
            raise PermissionError("authority root requires explicit USER provenance")
        ops = [x.upper() for x in operations]
        if not ops or any(x not in OPERATIONS for x in ops):
            raise ValueError("authority root contains unknown/empty operations")
        if max_delegation_depth < 0:
            raise ValueError("max_delegation_depth must be >= 0")

        authority = self.add(
            "Authority",
            title,
            data={
                "operations": sorted(set(ops)),
                "remaining_delegation_depth": int(max_delegation_depth),
                "expires_at": expires_at,
            },
            provenance_class=provenance_class,
            provenance=provenance,
            identity_key=identity_key,
        )
        self.add_episode(
            "AUTHORITY_ROOT",
            title,
            participants=[
                {"role": "context", "object_id": context_id},
                {"role": "scope", "object_id": scope_id},
                {"role": "authority", "object_id": authority},
                {"role": "holder", "object_id": holder_actor_id},
            ],
            data={
                "operations": sorted(set(ops)),
                "remaining_delegation_depth": int(max_delegation_depth),
                "expires_at": expires_at,
            },
            provenance_class=provenance_class,
            provenance=provenance,
        )
        return authority

    def _authority_revoked(self, authority_id: str) -> bool:
        row = self.conn.execute(
            """SELECT 1 FROM episodes e
               JOIN episode_participants p ON p.episode_id=e.id
               WHERE e.kind='REVOCATION' AND p.role='authority'
                 AND p.participant_id=? LIMIT 1""",
            (authority_id,)
        ).fetchone()
        return row is not None

    @staticmethod
    def _expired(expires_at: Optional[str]) -> bool:
        if not expires_at:
            return False
        try:
            when = dt.datetime.fromisoformat(expires_at)
            if when.tzinfo is None:
                when = when.replace(tzinfo=dt.timezone.utc)
            return now_dt() >= when.astimezone(dt.timezone.utc)
        except Exception as e:
            raise ValueError(f"invalid expires_at: {expires_at}") from e

    def authority_info(self, authority_id: str) -> dict:
        authority = self.get(authority_id)
        if authority.type != "Authority":
            raise TypeError("authority_id must be Authority")
        if self._authority_revoked(authority_id):
            raise PermissionError("authority has been revoked")

        root_rows = self.conn.execute(
            """SELECT DISTINCT e.id FROM episodes e
               JOIN episode_participants p ON p.episode_id=e.id
               WHERE e.kind='AUTHORITY_ROOT'
                 AND p.role='authority' AND p.participant_id=?""",
            (authority_id,)
        ).fetchall()
        del_rows = self.conn.execute(
            """SELECT DISTINCT e.id FROM episodes e
               JOIN episode_participants p ON p.episode_id=e.id
               WHERE e.kind='DELEGATION'
                 AND p.role='authority' AND p.participant_id=?""",
            (authority_id,)
        ).fetchall()
        if len(root_rows) + len(del_rows) != 1:
            raise ValueError("Authority must have exactly one root or delegation origin")

        ep = self.episode((root_rows or del_rows)[0]["id"])
        data = ep["data"]
        expires_at = data.get("expires_at")
        if self._expired(expires_at):
            raise PermissionError("authority has expired")

        info = {
            "authority_id": authority_id,
            "context_id": self.episode_role_ids(ep["id"], "context")[0],
            "scope_id": self.episode_role_ids(ep["id"], "scope")[0],
            "operations": set(data.get("operations", [])),
            "remaining_delegation_depth": int(data.get("remaining_delegation_depth", 0)),
            "expires_at": expires_at,
            "episode_id": ep["id"],
            "kind": ep["kind"],
            "holder_id": None,
            "parent_authority_id": None,
        }
        if ep["kind"] == "DELEGATION":
            info["holder_id"] = self.episode_role_ids(ep["id"], "grantee")[0]
            info["parent_authority_id"] = self.episode_role_ids(ep["id"], "parent")[0]
            # A delegated capability remains live only while its complete ancestry is live.
            parent = self.authority_info(info["parent_authority_id"])
            if parent["context_id"] != info["context_id"]:
                raise PermissionError("delegated authority context differs from live parent")
            if not self.scope_contains(parent["scope_id"], info["scope_id"]):
                raise PermissionError("delegated authority scope exceeds live parent")
            if not info["operations"].issubset(parent["operations"]):
                raise PermissionError("delegated authority operations exceed live parent")
            if parent["expires_at"] and not info["expires_at"]:
                raise PermissionError("finite parent cannot have unbounded live descendant")
        else:
            info["holder_id"] = self.episode_role_ids(ep["id"], "holder")[0]
        return info

    def delegate_authority(
        self,
        *,
        parent_authority_id: str,
        grantee_id: str,
        scope_id: str,
        operations: list[str],
        max_delegation_depth: int = 0,
        expires_at: Optional[str] = None,
        reason: str,
        provenance_class: str,
        provenance: str,
        identity_key: Optional[str] = None,
    ) -> str:
        parent = self.authority_info(parent_authority_id)
        grantee = self.get(grantee_id)
        scope = self.get(scope_id)
        if grantee.type != "Actor":
            raise TypeError("delegation grantee must be Actor")
        if scope.type != "Scope":
            raise TypeError("delegation scope_id must be Scope")
        if parent["remaining_delegation_depth"] <= 0:
            raise PermissionError("parent authority cannot delegate further")
        if max_delegation_depth < 0 or max_delegation_depth >= parent["remaining_delegation_depth"]:
            raise ValueError("delegated depth must be >=0 and less than parent's remaining depth")
        ops = [x.upper() for x in operations]
        if not ops or any(x not in OPERATIONS for x in ops):
            raise ValueError("delegation contains unknown/empty operations")
        if not set(ops).issubset(parent["operations"]):
            raise PermissionError("delegated operations exceed parent authority")
        if not self.scope_contains(parent["scope_id"], scope_id):
            raise PermissionError("delegated Scope exceeds parent authority")
        if parent["expires_at"] and expires_at is None:
            # Attenuation: omission cannot turn a finite parent into an unbounded child.
            expires_at = parent["expires_at"]
        if parent["expires_at"] and expires_at:
            parent_when = dt.datetime.fromisoformat(parent["expires_at"])
            child_when = dt.datetime.fromisoformat(expires_at)
            if parent_when.tzinfo is None:
                parent_when = parent_when.replace(tzinfo=dt.timezone.utc)
            if child_when.tzinfo is None:
                child_when = child_when.replace(tzinfo=dt.timezone.utc)
            if child_when > parent_when:
                raise PermissionError("delegated expiry exceeds parent expiry")
        if not reason.strip():
            raise ValueError("delegation reason required")

        authority = self.add(
            "Authority",
            f"Delegated authority for {grantee.title}",
            data={
                "operations": sorted(set(ops)),
                "remaining_delegation_depth": int(max_delegation_depth),
                "expires_at": expires_at,
            },
            provenance_class=provenance_class,
            provenance=provenance,
            identity_key=identity_key,
        )
        self.add_episode(
            "DELEGATION",
            f"Delegate to {grantee.title}",
            participants=[
                {"role": "context", "object_id": parent["context_id"]},
                {"role": "scope", "object_id": scope_id},
                {"role": "parent", "object_id": parent_authority_id},
                {"role": "authority", "object_id": authority},
                {"role": "grantee", "object_id": grantee_id},
            ],
            data={
                "operations": sorted(set(ops)),
                "remaining_delegation_depth": int(max_delegation_depth),
                "expires_at": expires_at,
                "reason": reason,
            },
            provenance_class=provenance_class,
            provenance=provenance,
        )
        return authority

    def revoke_authority(
        self,
        authority_id: str,
        *,
        reason: str,
        provenance_class: str,
        provenance: str,
    ) -> str:
        self.authority_info(authority_id)  # validates and ensures not already revoked
        if not reason.strip():
            raise ValueError("revocation reason required")
        decision = self.add(
            "Decision",
            "Revoke authority",
            data={"decision": "REVOKE", "reason": reason},
            provenance_class=provenance_class,
            provenance=provenance,
        )
        return self.add_episode(
            "REVOCATION",
            "Authority revocation",
            participants=[
                {"role": "authority", "object_id": authority_id},
                {"role": "decision", "object_id": decision},
            ],
            data={"reason": reason},
            provenance_class=provenance_class,
            provenance=provenance,
        )


    def grant_authorization(
        self,
        *,
        context_id: str,
        entity_id: str,
        operation: str,
        scope_id: str,
        issuer_authority_id: str,
        issuer_actor_id: str,
        principal_id: str,
        basis_entity_ids: list[str],
        result: str = "GRANTED",
        prerequisites: Optional[dict] = None,
        reason: str,
        provenance_class: str,
        provenance: str,
        identity_key: Optional[str] = None,
    ) -> str:
        context = self.get(context_id)
        if context.type != "Context":
            raise TypeError("context_id must be Context")
        self.entity_kind(entity_id)
        operation = operation.upper()
        result = result.upper()
        if operation not in OPERATIONS:
            raise ValueError(f"unknown operation: {operation}")
        if result not in AUTHORIZATION_RESULTS:
            raise ValueError(f"unknown authorization result: {result}")
        scope_obj = self.get(scope_id)
        if scope_obj.type != "Scope":
            raise TypeError("authorization scope_id must be Scope")
        issuer = self.authority_info(issuer_authority_id)
        issuer_actor = self.get(issuer_actor_id)
        principal = self.get(principal_id)
        if issuer_actor.type != "Actor" or principal.type != "Actor":
            raise TypeError("issuer_actor_id and principal_id must be Actor")
        if issuer["holder_id"] != issuer_actor_id:
            raise PermissionError("issuer Actor does not hold issuer Authority")
        if issuer["context_id"] != context_id:
            raise PermissionError("issuer authority belongs to a different Context")
        if operation not in issuer["operations"]:
            raise PermissionError(f"issuer cannot grant operation {operation}")
        if not self.scope_contains(issuer["scope_id"], scope_id):
            raise PermissionError("issuer authority does not cover requested Scope")
        if not reason.strip():
            raise ValueError("authorization reason is required")
        for bid in basis_entity_ids:
            self.entity_kind(bid)

        decision = self.add(
            "Decision",
            f"{result} {operation}",
            data={
                "decision": result,
                "operation": operation,
                "scope_id": scope_id,
                "issuer_authority_id": issuer_authority_id,
                "issuer_actor_id": issuer_actor_id,
                "principal_id": principal_id,
                "reason": reason,
                "prerequisites": prerequisites or {},
            },
            provenance_class=provenance_class,
            provenance=provenance,
        )
        participants = [
            {"role": "context", "object_id": context_id},
            {"role": "principal", "object_id": principal_id},
            {"role": "entity", "entity_id": entity_id},
            {"role": "scope", "object_id": scope_id},
            {"role": "issuer", "object_id": issuer_authority_id},
            {"role": "decision", "object_id": decision},
        ]
        for i, bid in enumerate(basis_entity_ids):
            participants.append({"role": "basis", "entity_id": bid, "ordinal": i})

        return self.add_episode(
            "AUTHORIZATION",
            f"{result} {operation} in {context.title}",
            participants=participants,
            data={
                "operation": operation,
                "scope_id": scope_id,
                "issuer_authority_id": issuer_authority_id,
                "issuer_actor_id": issuer_actor_id,
                "principal_id": principal_id,
                "result": result,
                "prerequisites": prerequisites or {},
                "reason": reason,
            },
            provenance_class=provenance_class,
            provenance=provenance,
            identity_key=identity_key,
        )

    def _authorization_episodes(self, context_id: str, principal_id: str, entity_id: str, operation: str) -> list[dict]:
        operation = operation.upper()
        rows = self.conn.execute(
            """SELECT DISTINCT e.id,e.created_at
               FROM episodes e
               JOIN episode_participants pc ON pc.episode_id=e.id
               JOIN episode_participants pp ON pp.episode_id=e.id
               JOIN episode_participants pe ON pe.episode_id=e.id
               WHERE e.kind='AUTHORIZATION'
                 AND pc.role='context' AND pc.participant_id=?
                 AND pp.role='principal' AND pp.participant_id=?
                 AND pe.role='entity' AND pe.participant_id=?
               ORDER BY e.created_at DESC""",
            (context_id, principal_id, entity_id),
        ).fetchall()
        out = []
        for r in rows:
            ep = self.episode(r["id"])
            if ep["data"].get("operation") == operation:
                out.append(ep)
        return out

    def access_events(self, context_id: str) -> list[dict]:
        context = self.get(context_id)
        if context.type != "Context":
            raise TypeError("context_id must be Context")
        rows = self.conn.execute(
            """SELECT DISTINCT e.id,e.created_at
               FROM episodes e
               JOIN episode_participants p ON p.episode_id=e.id
               WHERE e.kind='ACCESS' AND p.role='context' AND p.participant_id=?
               ORDER BY e.created_at""",
            (context_id,),
        ).fetchall()
        return [self.episode(r["id"]) for r in rows]

    def exposure_tags(self, context_id: str, scope_id: Optional[str]=None) -> set[str]:
        tags=set()
        if scope_id is not None and self.get(scope_id).type!="Scope":
            raise TypeError("scope_id must be Scope")
        for ep in self.access_events(context_id):
            if scope_id is not None:
                access_scopes=self.episode_role_ids(ep["id"],"scope")
                if len(access_scopes)!=1:
                    continue
                access_scope=access_scopes[0]
                # Exposure is relevant when the access and requested work occupy
                # overlapping declared scope: same scope, ancestor, or descendant.
                if not (
                    self.scope_contains(access_scope,scope_id)
                    or self.scope_contains(scope_id,access_scope)
                ):
                    continue
            tags.update(str(x) for x in ep["data"].get("exposure_tags", []))
        return tags

    def check_authorized(
        self,
        *,
        context_id: str,
        actor_id: str,
        entity_id: str,
        operation: str,
        scope_id: str,
    ) -> dict:
        context = self.get(context_id)
        if context.type != "Context":
            raise TypeError("context_id must be Context")
        actor = self.get(actor_id)
        if actor.type != "Actor":
            raise TypeError("actor_id must be Actor")
        self.entity_kind(entity_id)
        operation = operation.upper()
        if operation not in OPERATIONS:
            raise ValueError(f"unknown operation: {operation}")
        requested_scope = self.get(scope_id)
        if requested_scope.type != "Scope":
            raise TypeError("scope_id must be Scope")

        candidates = self._authorization_episodes(context_id, actor_id, entity_id, operation)
        exposures = self.exposure_tags(context_id, scope_id)
        for ep in candidates:
            data = ep["data"]
            grant_scope_ids = self.episode_role_ids(ep["id"], "scope")
            if len(grant_scope_ids) != 1:
                continue
            if not self.scope_contains(grant_scope_ids[0], scope_id):
                continue
            issuer_id = data.get("issuer_authority_id")
            if not issuer_id:
                continue
            try:
                issuer = self.authority_info(issuer_id)
            except (PermissionError, ValueError, KeyError):
                # Historical authorization/denial remains in history but is no longer exercisable.
                continue
            if issuer["context_id"] != context_id:
                continue
            if not self.scope_contains(issuer["scope_id"], scope_id):
                continue
            if operation not in issuer["operations"]:
                continue
            if data.get("result") != "GRANTED":
                return {"authorized": False, "reason": "explicit denial", "authorization_id": ep["id"]}
            prereq = data.get("prerequisites") or {}
            forbidden = set(prereq.get("forbid_exposure_tags", []))
            if forbidden & exposures:
                return {
                    "authorized": False,
                    "reason": f"history-sensitive prerequisite failed: {sorted(forbidden & exposures)}",
                    "authorization_id": ep["id"],
                }
            return {"authorized": True, "reason": "granted", "authorization_id": ep["id"]}
        return {"authorized": False, "reason": "no matching authorization", "authorization_id": None}

    def record_access(
        self,
        *,
        context_id: str,
        actor_id: str,
        entity_id: str,
        operation: str,
        scope_id: str,
        exposure_tags: list[str],
        provenance_class: str,
        provenance: str,
        identity_key: Optional[str] = None,
    ) -> str:
        auth = self.check_authorized(
            context_id=context_id, actor_id=actor_id, entity_id=entity_id, operation=operation, scope_id=scope_id
        )
        if not auth["authorized"]:
            raise PermissionError(auth["reason"])
        return self.add_episode(
            "ACCESS",
            f"{operation.upper()} access",
            participants=[
                {"role": "context", "object_id": context_id},
                {"role": "actor", "object_id": actor_id},
                {"role": "entity", "entity_id": entity_id},
                {"role": "scope", "object_id": scope_id},
                {"role": "authorization", "episode_id": auth["authorization_id"]},
            ],
            data={
                "operation": operation.upper(),
                "scope_id": scope_id,
                "exposure_tags": list(dict.fromkeys(exposure_tags)),
            },
            provenance_class=provenance_class,
            provenance=provenance,
            identity_key=identity_key,
        )

    def transfer(
        self,
        *,
        source_context_id: str,
        destination_context_id: str,
        entity_id: str,
        obligation_ids: list[str],
        evidence_entity_ids: list[str],
        requested_operations: list[str],
        result: str,
        reason: str,
        provenance_class: str,
        provenance: str,
        identity_key: Optional[str] = None,
    ) -> str:
        source = self.get(source_context_id)
        destination = self.get(destination_context_id)
        if source.type != "Context" or destination.type != "Context":
            raise TypeError("transfer endpoints must be Context")
        self.entity_kind(entity_id)
        if not obligation_ids:
            raise ValueError("transfer requires at least one obligation")
        for oid in obligation_ids:
            if self.get(oid).type != "Obligation":
                raise TypeError("transfer obligation_ids must be Obligation")
        for eid in evidence_entity_ids:
            self.entity_kind(eid)
        requested = [x.upper() for x in requested_operations]
        if any(x not in OPERATIONS for x in requested):
            raise ValueError("transfer contains unknown requested operation")
        result = result.upper()
        if result not in TRANSFER_RESULTS:
            raise ValueError(f"unknown transfer result: {result}")
        if result=="PRESERVED":
            self._require_preserved_transfer_obligations(obligation_ids,evidence_entity_ids)

        decision = self.add(
            "Decision",
            f"Transfer {result}",
            data={
                "result": result,
                "requested_operations": requested,
                "reason": reason,
            },
            provenance_class=provenance_class,
            provenance=provenance,
        )
        participants = [
            {"role": "source_context", "object_id": source_context_id},
            {"role": "destination_context", "object_id": destination_context_id},
            {"role": "entity", "entity_id": entity_id},
            {"role": "result", "object_id": decision},
        ]
        for i, oid in enumerate(obligation_ids):
            participants.append({"role": "obligation", "object_id": oid, "ordinal": i})
        for i, eid in enumerate(evidence_entity_ids):
            participants.append({"role": "evidence", "entity_id": eid, "ordinal": i})
        return self.add_episode(
            "TRANSFER",
            f"{source.title} -> {destination.title}",
            participants=participants,
            data={
                "result": result,
                "requested_operations": requested,
                "reason": reason,
            },
            provenance_class=provenance_class,
            provenance=provenance,
            identity_key=identity_key,
        )

    def launch_authorized(
        self,
        *,
        context_id: str,
        actor_id: str,
        object_id: str,
        scope_id: str,
        slot: Optional[str] = None,
        reason: str = "",
    ):
        auth = self.check_authorized(
            context_id=context_id, actor_id=actor_id, entity_id=object_id, operation="ACTIVATE", scope_id=scope_id
        )
        if not auth["authorized"]:
            raise PermissionError(auth["reason"])
        obj = self.get(object_id)
        blocker = self.conn.execute(
            """SELECT r.from_id,o.title FROM relations r JOIN objects o ON o.id=r.from_id
               WHERE r.kind='BLOCKS' AND r.to_id=?
               AND o.lifecycle IN ('ACTIVE','ORBITING') LIMIT 1""",
            (object_id,),
        ).fetchone()
        if blocker:
            raise PermissionError(f"activation blocked by {blocker['from_id']}: {blocker['title']}")
        self.conn.execute("UPDATE objects SET lifecycle='ACTIVE' WHERE id=?", (object_id,))
        self._event(
            "AUTHORIZED_LAUNCH",
            object_id,
            context_id=context_id,
            actor_id=actor_id,
            scope_id=scope_id,
            authorization_id=auth["authorization_id"],
            reason=reason,
        )
        if slot:
            self.pin(slot, object_id)
        self.conn.commit()

    def context_admission_status(self, context_id: str, object_id: str) -> dict:
        context=self.get(context_id)
        if context.type!="Context": raise TypeError("context_id must be Context")
        self.get(object_id)
        row=self.conn.execute(
            "SELECT * FROM context_admission WHERE context_id=? AND object_id=?",
            (context_id,object_id)
        ).fetchone()
        if not row:
            return {"context_id":context_id,"object_id":object_id,"status":"UNREVIEWED","decision_episode_id":None}
        return dict(row)

    def admit_in_context(
        self,
        context_id: str,
        object_id: str,
        *,
        support_entity_ids: list[str],
        reason: str,
        provenance_class: str,
        provenance: str,
    ) -> str:
        context=self.get(context_id)
        if context.type!="Context": raise TypeError("context_id must be Context")
        obj=self.get(object_id)
        if not reason.strip(): raise ValueError("context admission reason required")
        for sid in support_entity_ids: self.entity_kind(sid)
        decision=self.add("Decision",f"Admit in {context.title}: {obj.title}",
            data={"decision":"ADMIT","context_id":context_id,"reason":reason},
            provenance_class=provenance_class,provenance=provenance)
        participants=[
            {"role":"context","object_id":context_id},
            {"role":"candidate","object_id":object_id},
            {"role":"decision","object_id":decision},
        ]
        for i,sid in enumerate(support_entity_ids): participants.append({"role":"evidence","entity_id":sid,"ordinal":i})
        ep=self.add_episode("CONTEXT_ADMISSION",f"Admission of {obj.title} to {context.title}",
            participants=participants,data={"reason":reason},provenance_class=provenance_class,provenance=provenance)
        self.conn.execute(
            "INSERT OR REPLACE INTO context_admission(context_id,object_id,status,decision_episode_id,updated_at) VALUES(?,?,?,?,?)",
            (context_id,object_id,"ADMITTED",ep,now())
        )
        self._event("CONTEXT_ADMITTED",object_id,context_id=context_id,decision_episode=ep,reason=reason)
        self.conn.commit(); return ep

    def launch_in_context(self, context_id: str, object_id: str, *, slot: Optional[str]=None, reason: str=""):
        raise PermissionError(
            "legacy context-admission activation retired; use launch_authorized("
            "context_id=..., actor_id=..., scope_id=...)"
        )


    def admission_status(self, object_id: str) -> dict:
        self.get(object_id)
        row = self.conn.execute(
            "SELECT * FROM admission WHERE object_id=?", (object_id,)
        ).fetchone()
        return dict(row)

    def admit(
        self,
        object_id: str,
        *,
        support_object_ids: list[str],
        reason: str,
        provenance_class: str,
        provenance: str,
    ) -> str:
        """Admit a quarantined object. v0.5 support must still be object IDs."""
        obj = self.get(object_id)
        status = self.admission_status(object_id)["status"]
        if status != "QUARANTINED":
            raise ValueError(f"object is not quarantined: {status}")
        if not reason.strip():
            raise ValueError("admission reason required")
        for sid in support_object_ids:
            self.entity_kind(sid)

        decision = self.add(
            "Decision",
            f"Admit: {obj.title}",
            data={"decision":"ADMIT","reason":reason},
            provenance_class=provenance_class,
            provenance=provenance,
        )
        participants=[
            {"role":"candidate","object_id":object_id},
            {"role":"decision","object_id":decision},
        ]
        for i,sid in enumerate(support_object_ids):
            participants.append({"role":"evidence","object_id":sid,"ordinal":i})
        ep = self.add_episode(
            "ADMISSION",
            f"Admission of {obj.title}",
            participants=participants,
            data={"reason":reason},
            provenance_class=provenance_class,
            provenance=provenance,
        )
        self.conn.execute(
            "UPDATE admission SET status='ADMITTED',decision_episode_id=?,updated_at=? WHERE object_id=?",
            (ep, now(), object_id)
        )
        if obj.lifecycle == "QUARANTINED":
            self.conn.execute("UPDATE objects SET lifecycle='DORMANT' WHERE id=?", (object_id,))
        self._event("ADMITTED", object_id, decision_episode=ep, reason=reason)
        self.conn.commit()
        return ep

    def launch(self, object_id: str, *, slot: Optional[str] = None, reason: str = ""):
        raise PermissionError(
            "direct launch() retired in alpha 0.2; activation requires "
            "launch_authorized(context_id, actor_id, object_id, scope_id)"
        )


    def return_(self, object_id: str, *, reason: str = ""):
        self.conn.execute("DELETE FROM current_slots WHERE object_id=?", (object_id,))
        self.conn.execute("DELETE FROM orbit_members WHERE object_id=?", (object_id,))
        old = self.get(object_id)
        self.conn.execute("UPDATE objects SET lifecycle='RETURNED' WHERE id=?", (object_id,))
        self._event("RETURNED", object_id, old=old.lifecycle, reason=reason)
        self.conn.commit()

    def unresolved(self, object_id: str, *, reason: str = ""):
        old = self.get(object_id)
        self.conn.execute("UPDATE objects SET lifecycle='UNRESOLVED' WHERE id=?", (object_id,))
        self._event("MARKED_UNRESOLVED", object_id, old=old.lifecycle, reason=reason)
        self.conn.commit()

    def pin(self, slot: str, object_id: str):
        if slot not in CURRENT_SLOTS: raise ValueError(f"unknown slot: {slot}")
        obj = self.get(object_id)
        expected = SLOT_TYPES[slot]
        if obj.type != expected: raise TypeError(f"{slot} expects {expected}, got {obj.type}")
        if slot == "subject":
            self.conn.execute("DELETE FROM current_slots WHERE slot='subject'")
        else:
            limit = self.conn.execute(
                "SELECT max_items FROM current_limits WHERE slot=?", (slot,)
            ).fetchone()["max_items"]
            count = self.conn.execute(
                "SELECT COUNT(*) n FROM current_slots WHERE slot=?", (slot,)
            ).fetchone()["n"]
            already = self.conn.execute(
                "SELECT 1 FROM current_slots WHERE slot=? AND object_id=?", (slot, object_id)
            ).fetchone()
            if count >= limit and not already:
                raise RuntimeError(
                    f"current slot '{slot}' is full ({count}/{limit}); "
                    f"expand explicitly before adding more"
                )
        self.conn.execute(
            "INSERT OR IGNORE INTO current_slots(slot,object_id) VALUES(?,?)", (slot, object_id)
        )
        self._event("PINNED", object_id, slot=slot)
        self.conn.commit()

    def expand_current(self, slot: str, new_limit: int, *, reason: str):
        if slot not in CURRENT_SLOTS or slot == "subject":
            raise ValueError("only non-subject current slots can be expanded")
        old = self.conn.execute(
            "SELECT max_items FROM current_limits WHERE slot=?", (slot,)
        ).fetchone()["max_items"]
        if new_limit <= old: raise ValueError("new limit must be larger")
        if not reason.strip(): raise ValueError("expansion reason required")
        self.conn.execute(
            "UPDATE current_limits SET max_items=?, reason=? WHERE slot=?",
            (new_limit, reason, slot)
        )
        self._event("CURRENT_EXPANDED", None, slot=slot, old=old, new=new_limit, reason=reason)
        self.conn.commit()

    def scan(self) -> dict:
        out = {"limits": {}}
        for row in self.conn.execute("SELECT * FROM current_limits"):
            out["limits"][row["slot"]] = row["max_items"]
        for slot in sorted(CURRENT_SLOTS):
            rows = self.conn.execute(
                """SELECT o.* FROM current_slots c JOIN objects o ON o.id=c.object_id
                   WHERE c.slot=? ORDER BY o.created_at""", (slot,)
            ).fetchall()
            out[slot] = [self._row_dict(r) for r in rows]
        return out

    def orbit_list(self, subject_id: str) -> list[dict]:
        self.get(subject_id)
        rows = self.conn.execute(
            """SELECT o.*,m.reason AS orbit_reason
               FROM orbit_members m JOIN objects o ON o.id=m.object_id
               WHERE m.subject_id=? ORDER BY m.created_at DESC""", (subject_id,)
        ).fetchall()
        return [self._row_dict(r) for r in rows]

    def library(self, *, type: Optional[str] = None, lifecycle: Optional[str] = None, q: Optional[str] = None):
        sql, args = "SELECT * FROM objects WHERE 1=1", []
        if type: sql += " AND type=?"; args.append(type)
        if lifecycle: sql += " AND lifecycle=?"; args.append(lifecycle)
        if q:
            sql += " AND (title LIKE ? OR data_json LIKE ? OR provenance LIKE ?)"
            args.extend([f"%{q}%", f"%{q}%", f"%{q}%"])
        sql += " ORDER BY created_at DESC"
        return [self._row_dict(r) for r in self.conn.execute(sql,args).fetchall()]

    def trail(self, object_id: Optional[str] = None, limit: int = 50):
        if object_id:
            rows = self.conn.execute(
                "SELECT * FROM history WHERE object_id=? ORDER BY seq DESC LIMIT ?",
                (object_id, limit)
            ).fetchall()
        else:
            rows = self.conn.execute(
                "SELECT * FROM history ORDER BY seq DESC LIMIT ?", (limit,)
            ).fetchall()
        out=[]
        for r in rows:
            d=dict(r); d["details"]=json.loads(d.pop("details_json")); out.append(d)
        return out

    def graph(self, object_id: str):
        objrow = self.conn.execute("SELECT * FROM objects WHERE id=?", (object_id,)).fetchone()
        if not objrow: raise KeyError(object_id)
        outs=self.conn.execute(
            """SELECT r.*,o.title to_title,o.type to_type FROM relations r
               JOIN objects o ON o.id=r.to_id WHERE r.from_id=?""",(object_id,)
        ).fetchall()
        ins=self.conn.execute(
            """SELECT r.*,o.title from_title,o.type from_type FROM relations r
               JOIN objects o ON o.id=r.from_id WHERE r.to_id=?""",(object_id,)
        ).fetchall()
        def rel_dict(r):
            d=dict(r); d["data"]=json.loads(d.pop("data_json")); return d
        return {"object":self._row_dict(objrow),
                "outgoing":[rel_dict(r) for r in outs],
                "incoming":[rel_dict(r) for r in ins]}

    def stats(self):
        counts = {
            "objects": self.conn.execute("SELECT COUNT(*) n FROM objects").fetchone()["n"],
            "relations": self.conn.execute("SELECT COUNT(*) n FROM relations").fetchone()["n"],
            "history": self.conn.execute("SELECT COUNT(*) n FROM history").fetchone()["n"],
            "orbit_members": self.conn.execute("SELECT COUNT(*) n FROM orbit_members").fetchone()["n"],
            "episodes": self.conn.execute("SELECT COUNT(*) n FROM episodes").fetchone()["n"],
            "episode_participants": self.conn.execute("SELECT COUNT(*) n FROM episode_participants").fetchone()["n"],
            "admitted": self.conn.execute("SELECT COUNT(*) n FROM admission WHERE status='ADMITTED'").fetchone()["n"],
            "quarantined": self.conn.execute("SELECT COUNT(*) n FROM admission WHERE status='QUARANTINED'").fetchone()["n"],
            "entities": self.conn.execute("SELECT COUNT(*) n FROM entities").fetchone()["n"],
            "collections": self.conn.execute("SELECT COUNT(*) n FROM objects WHERE type='Collection'").fetchone()["n"],
            "collection_members": self.conn.execute("SELECT COUNT(*) n FROM collection_members").fetchone()["n"],
            "contexts": self.conn.execute("SELECT COUNT(*) n FROM objects WHERE type='Context'").fetchone()["n"],
            "context_admissions": self.conn.execute("SELECT COUNT(*) n FROM context_admission WHERE status='ADMITTED'").fetchone()["n"],
            "authorizations": self.conn.execute("SELECT COUNT(*) n FROM episodes WHERE kind='AUTHORIZATION'").fetchone()["n"],
            "access_events": self.conn.execute("SELECT COUNT(*) n FROM episodes WHERE kind='ACCESS'").fetchone()["n"],
            "transfers": self.conn.execute("SELECT COUNT(*) n FROM episodes WHERE kind='TRANSFER'").fetchone()["n"],
            "scopes": self.conn.execute("SELECT COUNT(*) n FROM objects WHERE type='Scope'").fetchone()["n"],
            "scope_edges": self.conn.execute("SELECT COUNT(*) n FROM scope_edges").fetchone()["n"],
            "authority_roots": self.conn.execute("SELECT COUNT(*) n FROM episodes WHERE kind='AUTHORITY_ROOT'").fetchone()["n"],
            "delegations": self.conn.execute("SELECT COUNT(*) n FROM episodes WHERE kind='DELEGATION'").fetchone()["n"],
            "revocations": self.conn.execute("SELECT COUNT(*) n FROM episodes WHERE kind='REVOCATION'").fetchone()["n"],
            "method_assessments": self.conn.execute("SELECT COUNT(*) n FROM episodes WHERE kind='METHOD_COMPLIANCE'").fetchone()["n"],
            "replacements": self.conn.execute("SELECT COUNT(*) n FROM episodes WHERE kind='REPLACEMENT'").fetchone()["n"],
            "applicability_assessments": self.conn.execute("SELECT COUNT(*) n FROM episodes WHERE kind='APPLICABILITY_ASSESSMENT'").fetchone()["n"],
            "content_identities": self.conn.execute("SELECT COUNT(*) n FROM objects WHERE type='ContentIdentity'").fetchone()["n"],
            "occurrences": self.conn.execute("SELECT COUNT(*) n FROM objects WHERE type='Occurrence'").fetchone()["n"],
            "artifact_instances": self.conn.execute("SELECT COUNT(*) n FROM objects WHERE type='ArtifactInstance'").fetchone()["n"],
            "custody_transfers": self.conn.execute("SELECT COUNT(*) n FROM episodes WHERE kind='CUSTODY_TRANSFER'").fetchone()["n"],
            "derivations": self.conn.execute("SELECT COUNT(*) n FROM episodes WHERE kind='DERIVATION'").fetchone()["n"],
            "associations": self.conn.execute("SELECT COUNT(*) n FROM episodes WHERE kind='ASSOCIATION'").fetchone()["n"],
            "adaptations": self.conn.execute("SELECT COUNT(*) n FROM episodes WHERE kind='ADAPTATION'").fetchone()["n"],
            "promotions": self.conn.execute("SELECT COUNT(*) n FROM episodes WHERE kind='PROMOTION'").fetchone()["n"],
            "failures": self.conn.execute("SELECT COUNT(*) n FROM episodes WHERE kind='FAILURE'").fetchone()["n"],
            "schema_terms": self.conn.execute("SELECT COUNT(*) n FROM schema_terms WHERE status='ACTIVE'").fetchone()["n"],
            "open_schema_gaps": self.conn.execute("SELECT COUNT(*) n FROM schema_gaps WHERE status='OPEN'").fetchone()["n"],
            "schema_changes": self.conn.execute("SELECT COUNT(*) n FROM schema_changes").fetchone()["n"],
        }
        counts["by_type"] = {r["type"]:r["n"] for r in self.conn.execute(
            "SELECT type,COUNT(*) n FROM objects GROUP BY type")}
        counts["by_lifecycle"] = {r["lifecycle"]:r["n"] for r in self.conn.execute(
            "SELECT lifecycle,COUNT(*) n FROM objects GROUP BY lifecycle")}
        return counts


    def _table_rows(self, table: str) -> list[dict]:
        if table not in STATE_TABLES:
            raise ValueError(f"unsupported state table: {table}")
        rows=self.conn.execute(f"SELECT * FROM {table}").fetchall()
        data=[dict(r) for r in rows]
        # Canonical row ordering independent of SQLite query plan.
        return sorted(data,key=lambda x:json.dumps(x,sort_keys=True,separators=(",",":")))

    @staticmethod
    def _snapshot_digest_payload(snapshot: dict) -> dict:
        return {
            "format":snapshot["format"],
            "tables":snapshot["tables"],
        }

    @classmethod
    def snapshot_digest(cls, snapshot: dict) -> str:
        payload=json.dumps(
            cls._snapshot_digest_payload(snapshot),
            sort_keys=True,separators=(",",":"),ensure_ascii=False
        ).encode("utf-8")
        return hashlib.sha256(payload).hexdigest()

    def state_snapshot(self) -> dict:
        tables={table:self._table_rows(table) for table in STATE_TABLES}
        snapshot={
            "format":"orbit-lab-state-v1",
            "kernel":"Orbit Lab alpha 0.4-selector-core",
            "tables":tables,
        }
        snapshot["sha256"]=self.snapshot_digest(snapshot)
        return snapshot

    def export_state(self, path: str | Path) -> dict:
        path=Path(path)
        snapshot=self.state_snapshot()
        path.write_text(
            json.dumps(snapshot,indent=2,sort_keys=True,ensure_ascii=False)+"\n",
            encoding="utf-8"
        )
        return {"path":str(path),"sha256":snapshot["sha256"]}

    def _assert_import_target_empty(self):
        # Bootstrap schema terms/roles and current_limits are expected; research state is not.
        checks={
            "objects":"SELECT COUNT(*) n FROM objects",
            "episodes":"SELECT COUNT(*) n FROM episodes",
            "relations":"SELECT COUNT(*) n FROM relations",
            "history":"SELECT COUNT(*) n FROM history",
            "schema_changes":"SELECT COUNT(*) n FROM schema_changes",
            "schema_gaps":"SELECT COUNT(*) n FROM schema_gaps",
        }
        nonempty={k:self.conn.execute(q).fetchone()["n"] for k,q in checks.items()}
        bad={k:v for k,v in nonempty.items() if v}
        if bad:
            raise ValueError(f"import target contains research state: {bad}")

    def import_state(self, path: str | Path) -> dict:
        path=Path(path)
        snapshot=json.loads(path.read_text(encoding="utf-8"))
        if snapshot.get("format")!="orbit-lab-state-v1":
            raise ValueError("unsupported state snapshot format")
        expected=snapshot.get("sha256")
        actual=self.snapshot_digest(snapshot)
        if not expected or expected!=actual:
            raise ValueError("state snapshot digest mismatch")
        tables=snapshot.get("tables")
        if not isinstance(tables,dict) or set(tables)!=set(STATE_TABLES):
            raise ValueError("state snapshot table set mismatch")

        self._assert_import_target_empty()
        self.conn.execute("PRAGMA defer_foreign_keys = ON")
        try:
            # Remove bootstrap-only rows so imported schema/current limits are exact.
            self.conn.execute("DELETE FROM schema_roles")
            self.conn.execute("DELETE FROM schema_terms")
            self.conn.execute("DELETE FROM current_limits")

            for table in STATE_IMPORT_ORDER:
                rows=tables[table]
                if not rows:
                    continue
                columns=list(rows[0].keys())
                if any(list(r.keys())!=columns for r in rows):
                    # JSON sort_keys can alter key order, so compare sets and normalize.
                    colset=set(columns)
                    if any(set(r)!=colset for r in rows):
                        raise ValueError(f"inconsistent columns in table {table}")
                columns=sorted(columns)
                placeholders=",".join("?" for _ in columns)
                sql=f"INSERT INTO {table} ({','.join(columns)}) VALUES ({placeholders})"
                for row in rows:
                    self.conn.execute(sql,tuple(row.get(c) for c in columns))
            fk=list(self.conn.execute("PRAGMA foreign_key_check"))
            if fk:
                raise ValueError(f"foreign-key violations after import: {[tuple(x) for x in fk[:10]]}")
            self.conn.commit()
        except Exception:
            self.conn.rollback()
            raise

        restored=self.state_snapshot()
        if restored["sha256"]!=expected:
            raise ValueError(
                f"round-trip state digest mismatch: expected={expected} restored={restored['sha256']}"
            )
        return {"sha256":expected,"tables":len(STATE_TABLES)}

    def alpha_audit(self) -> dict:
        failures=[]
        warnings=[]

        fk=[tuple(x) for x in self.conn.execute("PRAGMA foreign_key_check")]
        if fk:
            failures.append({"check":"foreign_keys","details":fk[:20]})

        # Entity registry must correspond exactly to one object or episode.
        entity_rows=self.conn.execute(
            """SELECT e.id,e.entity_kind,
                      CASE WHEN o.id IS NULL THEN 0 ELSE 1 END AS has_object,
                      CASE WHEN p.id IS NULL THEN 0 ELSE 1 END AS has_episode
               FROM entities e
               LEFT JOIN objects o ON o.id=e.id
               LEFT JOIN episodes p ON p.id=e.id"""
        ).fetchall()
        bad_entities=[]
        for r in entity_rows:
            expected_obj=1 if r["entity_kind"]=="OBJECT" else 0
            expected_ep=1 if r["entity_kind"]=="EPISODE" else 0
            if r["has_object"]!=expected_obj or r["has_episode"]!=expected_ep:
                bad_entities.append(dict(r))
        if bad_entities:
            failures.append({"check":"entity_registry","details":bad_entities[:20]})

        # Every object / episode must be admitted by the runtime schema.
        unknown_objects=[
            dict(r) for r in self.conn.execute(
                """SELECT o.id,o.type FROM objects o
                   LEFT JOIN schema_terms s
                     ON s.name=o.type AND s.entity_kind='OBJECT' AND s.status='ACTIVE'
                   WHERE s.name IS NULL"""
            ).fetchall()
        ]
        unknown_episodes=[
            dict(r) for r in self.conn.execute(
                """SELECT e.id,e.kind FROM episodes e
                   LEFT JOIN schema_terms s
                     ON s.name=e.kind AND s.entity_kind='EPISODE' AND s.status='ACTIVE'
                   WHERE s.name IS NULL"""
            ).fetchall()
        ]
        if unknown_objects:
            failures.append({"check":"object_schema","details":unknown_objects[:20]})
        if unknown_episodes:
            failures.append({"check":"episode_schema","details":unknown_episodes[:20]})

        # Re-validate every episode against the current runtime schema without mutating.
        invalid_eps=[]
        for r in self.conn.execute("SELECT id,kind FROM episodes ORDER BY created_at"):
            eid=r["id"]; kind=r["kind"]
            try:
                required,typed=self._episode_schema(kind)
                participants=self.conn.execute(
                    """SELECT role,participant_id,ordinal
                       FROM episode_participants WHERE episode_id=?""",(eid,)
                ).fetchall()
                roles={x["role"] for x in participants}
                missing=required-roles
                undeclared=roles-set(typed)
                if missing or undeclared:
                    raise ValueError(f"missing={sorted(missing)} undeclared={sorted(undeclared)}")
                for part in participants:
                    allowed=typed.get(part["role"],set())
                    if allowed:
                        desc=self.entity_descriptor(part["participant_id"])
                        if not self._descriptor_allowed(desc,allowed):
                            raise TypeError(f"{part['role']} got {desc}, allowed={sorted(allowed)}")
            except Exception as e:
                invalid_eps.append({"id":eid,"kind":kind,"error":str(e)})
        if invalid_eps:
            failures.append({"check":"episode_contracts","details":invalid_eps[:20]})

        # Every non-bootstrap schema addition must carry the governance chain.
        bad_changes=[]
        for r in self.conn.execute("SELECT * FROM schema_changes WHERE action='ADD'"):
            d=dict(r)
            required_fields=[
                "proposal_id","promotion_episode_id","authorization_episode_id",
                "actor_id","context_id","scope_id"
            ]
            missing=[x for x in required_fields if not d.get(x)]
            if missing:
                bad_changes.append({"id":d["id"],"missing":missing})
                continue
            try:
                if self.entity_descriptor(d["promotion_episode_id"])!="EPISODE:PROMOTION":
                    raise ValueError("promotion link is not PROMOTION")
                if self.entity_descriptor(d["authorization_episode_id"])!="EPISODE:AUTHORIZATION":
                    raise ValueError("authorization link is not AUTHORIZATION")
                proposal=self.get(d["proposal_id"])
                if proposal.type!="Candidate":
                    raise ValueError("proposal is not Candidate")
                proposal_gap=proposal.data.get("gap_id")
                proposal_term=proposal.data.get("term_name")
                proposal_kind=proposal.data.get("schema_proposal_kind")
                if proposal_gap != d["gap_id"]:
                    raise ValueError("schema-change gap differs from proposal gap")
                if proposal_term != d["term_name"]:
                    raise ValueError("schema-change term differs from proposal term")
                expected_kind = "OBJECT" if proposal_kind=="ADD_OBJECT_TYPE" else (
                    "EPISODE" if proposal_kind=="ADD_EPISODE_TYPE" else None
                )
                if expected_kind != d["entity_kind"]:
                    raise ValueError("schema-change entity kind differs from proposal kind")
                gap=self.conn.execute("SELECT * FROM schema_gaps WHERE id=?",(d["gap_id"],)).fetchone()
                if not gap or gap["status"]!="REPAIRED":
                    raise ValueError("schema-change gap is missing or not REPAIRED")
                term=self.conn.execute(
                    "SELECT * FROM schema_terms WHERE name=? AND entity_kind=?",
                    (d["term_name"],d["entity_kind"])
                ).fetchone()
                if not term or term["origin"] != f"GAP:{d['gap_id']}":
                    raise ValueError("schema term origin does not match earning gap")
                if term["definition"] != proposal.data.get("definition"):
                    raise ValueError("active schema definition differs from promoted proposal")
                if d["entity_kind"]=="EPISODE":
                    expected_roles=proposal.data.get("roles") or {}
                    actual_rows=self.conn.execute(
                        "SELECT role,required,allowed_json FROM schema_roles WHERE episode_kind=?",
                        (d["term_name"],)
                    ).fetchall()
                    actual_roles={
                        r["role"]:{
                            "required":bool(r["required"]),
                            "allowed":sorted(json.loads(r["allowed_json"]))
                        }
                        for r in actual_rows
                    }
                    normalized_expected={
                        role:{
                            "required":bool(spec.get("required",False)),
                            "allowed":sorted(set(spec.get("allowed",[])))
                        }
                        for role,spec in expected_roles.items()
                    }
                    if actual_roles != normalized_expected:
                        raise ValueError("active episode-role schema differs from promoted proposal")
                promotion=self.episode(d["promotion_episode_id"])
                if promotion["data"].get("result")!="PROMOTED":
                    raise ValueError("promotion result is not PROMOTED")
                if self.episode_role_ids(d["promotion_episode_id"],"entity") != [d["proposal_id"]]:
                    raise ValueError("promotion does not target schema proposal")
                if self.episode_role_ids(d["promotion_episode_id"],"context") != [d["context_id"]]:
                    raise ValueError("promotion context differs from schema change")
                promotion_scopes=self.episode_role_ids(d["promotion_episode_id"],"scope")
                if len(promotion_scopes)!=1 or not self.scope_contains(promotion_scopes[0],d["scope_id"]):
                    raise ValueError("promotion scope does not cover schema change")
                auth=self.episode(d["authorization_episode_id"])
                if auth["data"].get("operation")!="SCHEMA_CHANGE" or auth["data"].get("result")!="GRANTED":
                    raise ValueError("authorization is not granted SCHEMA_CHANGE")
                if auth["data"].get("principal_id")!=d["actor_id"]:
                    raise ValueError("schema-change actor differs from authorized principal")
                if self.episode_role_ids(d["authorization_episode_id"],"context") != [d["context_id"]]:
                    raise ValueError("authorization context differs from schema change")
                auth_scopes=self.episode_role_ids(d["authorization_episode_id"],"scope")
                if len(auth_scopes)!=1 or not self.scope_contains(auth_scopes[0],d["scope_id"]):
                    raise ValueError("authorization scope does not cover schema change")
            except Exception as e:
                bad_changes.append({"id":d["id"],"error":str(e)})
        if bad_changes:
            failures.append({"check":"schema_governance","details":bad_changes[:20]})

        # Current working-set integrity.
        bad_slots=[]
        counts={}
        for r in self.conn.execute("SELECT slot,object_id FROM current_slots"):
            slot=r["slot"]; oid_=r["object_id"]
            counts[slot]=counts.get(slot,0)+1
            expected=SLOT_TYPES.get(slot)
            try:
                actual=self.get(oid_).type
            except Exception:
                actual=None
            if expected is None or actual != expected:
                bad_slots.append({"slot":slot,"object_id":oid_,"expected":expected,"actual":actual})
        if bad_slots:
            failures.append({"check":"current_slot_types","details":bad_slots[:20]})
        over=[]
        for slot,count in counts.items():
            row=self.conn.execute("SELECT max_items FROM current_limits WHERE slot=?",(slot,)).fetchone()
            if not row or count>row["max_items"]:
                over.append({"slot":slot,"count":count,"limit":None if not row else row["max_items"]})
        if over:
            failures.append({"check":"current_slot_limits","details":over})

        # Declared claim-justification dependencies cannot be bypassed.
        bad_supported_claims=[]
        supported_claim_ids=set()
        for row in self.conn.execute(
            "SELECT DISTINCT p.participant_id AS claim_id FROM episode_participants p JOIN episodes e ON e.id=p.episode_id WHERE e.kind='CLAIM_ASSESSMENT' AND p.role='claim'"
        ):
            cid=row["claim_id"]
            if self._claim_has_supported_assessment(cid):
                supported_claim_ids.add(cid)
        for cid in sorted(supported_claim_ids):
            dep=self.claim_dependency_status(cid)
            if not dep["satisfied"]:
                bad_supported_claims.append({"claim_id":cid,"dependency_status":dep})
        if bad_supported_claims:
            failures.append({"check":"claim_dependencies","details":bad_supported_claims[:20]})

        # Supported claims must still satisfy their declared evidence qualifications.
        bad_evidence_qualifications=[]
        for cid in sorted(supported_claim_ids):
            for ep in self.claim_assessments(cid):
                if ep["data"].get("verdict")!="SUPPORTED":
                    continue
                evidence_ids=self.episode_role_ids(ep["id"],"evidence")
                try:
                    qual=self.claim_evidence_qualification_status(cid,evidence_ids)
                except Exception as exc:
                    bad_evidence_qualifications.append({"claim_id":cid,"assessment_id":ep["id"],"error":str(exc)})
                    continue
                if not qual["satisfied"]:
                    bad_evidence_qualifications.append({"claim_id":cid,"assessment_id":ep["id"],"qualification_status":qual})
        if bad_evidence_qualifications:
            failures.append({"check":"claim_evidence_qualifications","details":bad_evidence_qualifications[:20]})

        # Supported claims must still satisfy claim-local method-compliance contracts.
        bad_method_compliance=[]
        for cid in sorted(supported_claim_ids):
            for ep in self.claim_assessments(cid):
                if ep["data"].get("verdict")!="SUPPORTED":
                    continue
                evidence_ids=self.episode_role_ids(ep["id"],"evidence")
                try:
                    status=self.claim_evidence_method_compliance_status(cid,evidence_ids)
                except Exception as exc:
                    bad_method_compliance.append({"claim_id":cid,"assessment_id":ep["id"],"error":str(exc)})
                    continue
                if not status["satisfied"]:
                    bad_method_compliance.append({
                        "claim_id":cid,"assessment_id":ep["id"],"method_compliance_status":status
                    })
        if bad_method_compliance:
            failures.append({"check":"claim_evidence_method_compliance","details":bad_method_compliance[:20]})

        # Supported claims must still satisfy claim-local evidence source-role contracts.
        bad_source_roles=[]
        for cid in sorted(supported_claim_ids):
            for ep in self.claim_assessments(cid):
                if ep["data"].get("verdict")!="SUPPORTED":
                    continue
                evidence_ids=self.episode_role_ids(ep["id"],"evidence")
                try:
                    status=self.claim_evidence_source_role_status(cid,evidence_ids)
                except Exception as exc:
                    bad_source_roles.append({"claim_id":cid,"assessment_id":ep["id"],"error":str(exc)})
                    continue
                if not status["satisfied"]:
                    bad_source_roles.append({
                        "claim_id":cid,"assessment_id":ep["id"],"source_role_status":status
                    })
        if bad_source_roles:
            failures.append({"check":"claim_evidence_source_roles","details":bad_source_roles[:20]})

        # Supported claims must still satisfy exact evidence-set contracts.
        bad_evidence_sets=[]
        for cid in sorted(supported_claim_ids):
            try:
                status=self.claim_evidence_set_status(cid)
            except Exception as exc:
                bad_evidence_sets.append({"claim_id":cid,"error":str(exc)})
                continue
            if not status["satisfied"]:
                bad_evidence_sets.append({"claim_id":cid,"evidence_set_status":status})
        if bad_evidence_sets:
            failures.append({"check":"claim_evidence_sets","details":bad_evidence_sets[:20]})

        # PRESERVED transfers must still satisfy evidence qualifications declared by their Obligations.
        bad_transfer_obligations=[]
        for row in self.conn.execute(
            "SELECT id,kind,data_json FROM episodes WHERE kind IN ('TRANSFER','CUSTODY_TRANSFER')"
        ):
            data=json.loads(row["data_json"])
            if data.get("result")!="PRESERVED":
                continue
            obligations=self.episode_role_ids(row["id"],"obligation")
            evidence=self.episode_role_ids(row["id"],"evidence")
            for oid in obligations:
                try:
                    status=self.obligation_evidence_qualification_status(oid,evidence)
                except Exception as exc:
                    bad_transfer_obligations.append({
                        "episode_id":row["id"],"obligation_id":oid,"error":str(exc)
                    })
                    continue
                if not status["satisfied"]:
                    bad_transfer_obligations.append({
                        "episode_id":row["id"],"obligation_id":oid,
                        "qualification_status":status
                    })
        if bad_transfer_obligations:
            failures.append({
                "check":"transfer_obligation_evidence",
                "details":bad_transfer_obligations[:20]
            })

        # Scope graph integrity: endpoints must be Scope objects and containment must be acyclic.
        bad_scope_edges=[]
        for r in self.conn.execute("SELECT parent_scope_id,child_scope_id FROM scope_edges"):
            try:
                if self.get(r["parent_scope_id"]).type!="Scope" or self.get(r["child_scope_id"]).type!="Scope":
                    bad_scope_edges.append(dict(r))
            except Exception:
                bad_scope_edges.append(dict(r))
        if bad_scope_edges:
            failures.append({"check":"scope_edge_types","details":bad_scope_edges[:20]})

        graph={}
        for r in self.conn.execute("SELECT parent_scope_id,child_scope_id FROM scope_edges"):
            graph.setdefault(r["parent_scope_id"],[]).append(r["child_scope_id"])
        visiting=set(); visited=set(); cycle=[]
        def visit(node,path):
            nonlocal cycle
            if cycle:
                return
            if node in visiting:
                i=path.index(node) if node in path else 0
                cycle=path[i:]+[node]
                return
            if node in visited:
                return
            visiting.add(node)
            for child in graph.get(node,[]):
                visit(child,path+[node])
            visiting.remove(node)
            visited.add(node)
        for node in list(graph):
            visit(node,[])
            if cycle:
                break
        if cycle:
            failures.append({"check":"scope_acyclic","details":cycle})

        # Check for semantic immutability triggers.
        trigger_names={r["name"] for r in self.conn.execute(
            "SELECT name FROM sqlite_master WHERE type='trigger'"
        )}
        required_triggers={
            "trg_objects_semantic_immutable",
            "trg_episodes_semantic_immutable",
            "trg_episode_participants_immutable_update",
            "trg_episode_participants_immutable_delete",
            "trg_history_immutable_update",
            "trg_history_immutable_delete",
        }
        missing_triggers=sorted(required_triggers-trigger_names)
        if missing_triggers:
            failures.append({"check":"immutability_triggers","details":missing_triggers})

        # Internal alpha explicitly does not claim authenticated multi-user identity.
        warnings.append({
            "boundary":"runtime_authentication",
            "status":"EXTERNAL_TRUST_BOUNDARY",
            "detail":"Actor identity is supplied by the embedding runtime; this kernel does not authenticate principals."
        })

        snapshot=self.state_snapshot()
        return {
            "stage":"ALPHA_CANDIDATE" if not failures else "PRE_ALPHA",
            "passed":not failures,
            "failures":failures,
            "warnings":warnings,
            "state_sha256":snapshot["sha256"],
            "stats":self.stats(),
        }

    def export_jsonl(self, path: str | Path):
        """Human/debug line export.

        `export_state()` is the state-complete portable format.
        """
        path=Path(path)
        snapshot=self.state_snapshot()
        with path.open("w",encoding="utf-8") as f:
            f.write(json.dumps({"kind":"manifest","format":snapshot["format"],
                                "sha256":snapshot["sha256"]},sort_keys=True)+"\n")
            for table in STATE_TABLES:
                for row in snapshot["tables"][table]:
                    f.write(json.dumps({"kind":"table_row","table":table,"row":row},
                                       sort_keys=True)+"\n")

    def _row_dict(self, row):
        d=dict(row)
        if "data_json" in d:
            d["data"]=json.loads(d.pop("data_json"))
        return d

def main():
    p=argparse.ArgumentParser(prog="orbit")
    p.add_argument("--db",default="orbit_lab.db")
    sub=p.add_subparsers(dest="cmd",required=True)

    a=sub.add_parser("add")
    a.add_argument("type"); a.add_argument("title")
    a.add_argument("--provenance-class",required=True,choices=sorted(PROVENANCE_CLASSES))
    a.add_argument("--provenance",required=True); a.add_argument("--identity-key")
    a.add_argument("--lifecycle",default="DORMANT",choices=sorted(LIFECYCLES))
    a.add_argument("--epistemic",default="UNKNOWN",choices=sorted(EPISTEMIC))
    a.add_argument("--data",default="{}")

    r=sub.add_parser("relate")
    r.add_argument("from_id"); r.add_argument("kind"); r.add_argument("to_id")
    r.add_argument("--provenance-class",required=True,choices=sorted(PROVENANCE_CLASSES))
    r.add_argument("--provenance",required=True); r.add_argument("--data",default="{}")

    o=sub.add_parser("orbit"); o.add_argument("id"); o.add_argument("subject_id"); o.add_argument("--reason",default="")
    d=sub.add_parser("deorbit"); d.add_argument("id"); d.add_argument("subject_id"); d.add_argument("--reason",default="")
    l=sub.add_parser("launch"); l.add_argument("id"); l.add_argument("--context",required=True); l.add_argument("--actor",required=True); l.add_argument("--scope",required=True); l.add_argument("--slot",choices=sorted(CURRENT_SLOTS)); l.add_argument("--reason",default="")
    rr=sub.add_parser("return"); rr.add_argument("id"); rr.add_argument("--reason",default="")
    u=sub.add_parser("unresolved"); u.add_argument("id"); u.add_argument("--reason",default="")
    pin=sub.add_parser("pin"); pin.add_argument("slot",choices=sorted(CURRENT_SLOTS)); pin.add_argument("id")
    ex=sub.add_parser("expand"); ex.add_argument("slot",choices=sorted(CURRENT_SLOTS)); ex.add_argument("new_limit",type=int); ex.add_argument("--reason",required=True)

    sub.add_parser("scan")
    ol=sub.add_parser("orbit-list"); ol.add_argument("subject_id")
    lib=sub.add_parser("library"); lib.add_argument("--type"); lib.add_argument("--lifecycle",choices=sorted(LIFECYCLES)); lib.add_argument("--q")
    sh=sub.add_parser("show"); sh.add_argument("id")
    tr=sub.add_parser("trail"); tr.add_argument("id",nargs="?"); tr.add_argument("--limit",type=int,default=30)
    sub.add_parser("stats")
    ep=sub.add_parser("epistemic"); ep.add_argument("id"); ep.add_argument("status",choices=sorted(EPISTEMIC)); ep.add_argument("--reason",default="")
    exp=sub.add_parser("export"); exp.add_argument("path")
    es=sub.add_parser("export-state"); es.add_argument("path")
    im=sub.add_parser("import-state"); im.add_argument("path")
    sub.add_parser("alpha-audit")

    args=p.parse_args(); lab=OrbitLab(args.db)
    try:
        if args.cmd=="add":
            print(lab.add(args.type,args.title,data=json.loads(args.data),
                          provenance_class=args.provenance_class,provenance=args.provenance,
                          identity_key=args.identity_key,lifecycle=args.lifecycle,epistemic=args.epistemic))
        elif args.cmd=="relate":
            print(lab.relate(args.from_id,args.kind,args.to_id,data=json.loads(args.data),
                             provenance_class=args.provenance_class,provenance=args.provenance))
        elif args.cmd=="orbit": lab.orbit(args.id,args.subject_id,reason=args.reason)
        elif args.cmd=="deorbit": lab.deorbit(args.id,args.subject_id,reason=args.reason)
        elif args.cmd=="launch": lab.launch_authorized(context_id=args.context,actor_id=args.actor,object_id=args.id,scope_id=args.scope,slot=args.slot,reason=args.reason)
        elif args.cmd=="return": lab.return_(args.id,reason=args.reason)
        elif args.cmd=="unresolved": lab.unresolved(args.id,reason=args.reason)
        elif args.cmd=="pin": lab.pin(args.slot,args.id)
        elif args.cmd=="expand": lab.expand_current(args.slot,args.new_limit,reason=args.reason)
        elif args.cmd=="scan": print(json.dumps(lab.scan(),indent=2))
        elif args.cmd=="orbit-list":
            print(json.dumps(lab.orbit_list(args.subject_id),indent=2))
        elif args.cmd=="library":
            print(json.dumps(lab.library(type=args.type,lifecycle=args.lifecycle,q=args.q),indent=2))
        elif args.cmd=="show": print(json.dumps(lab.graph(args.id),indent=2))
        elif args.cmd=="trail": print(json.dumps(lab.trail(args.id,args.limit),indent=2))
        elif args.cmd=="stats": print(json.dumps(lab.stats(),indent=2))
        elif args.cmd=="epistemic": lab.set_epistemic(args.id,args.status,reason=args.reason)
        elif args.cmd=="export": lab.export_jsonl(args.path); print(args.path)
        elif args.cmd=="export-state": print(json.dumps(lab.export_state(args.path),indent=2))
        elif args.cmd=="import-state": print(json.dumps(lab.import_state(args.path),indent=2))
        elif args.cmd=="alpha-audit": print(json.dumps(lab.alpha_audit(),indent=2,sort_keys=True))
    finally:
        lab.close()

if __name__=="__main__":
    main()
