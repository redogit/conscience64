
import unittest
from supporters.adversary import OrbitalGAN

class OrbitalGANTests(unittest.TestCase):
    def test_controls_remain_controls(self):
        gan=OrbitalGAN(seed=1)
        self.assertIsNone(gan.association_control_trial({"mutation":1}))
        self.assertIsNone(gan.lineage_control_trial({"mutation":1}))

    def test_adversarial_run_is_deterministic_by_seed(self):
        a=OrbitalGAN(seed=42).run(rounds=24)
        b=OrbitalGAN(seed=42).run(rounds=24)
        self.assertEqual(
            [x["signature"] for x in a["findings"]],
            [x["signature"] for x in b["findings"]]
        )

if __name__=="__main__":
    unittest.main()
