from __future__ import annotations
from pathlib import Path
import hashlib,json,tempfile,sys
ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path: sys.path.insert(0,str(ROOT))
from orbit_lab import OrbitLab
DATA=ROOT/"data"/"method_authority"
MANIFEST=json.loads((DATA/"SOURCE_MANIFEST.json").read_text())

def run():
    active_bytes=(DATA/MANIFEST["active_procedure"]["file"]).read_bytes()
    hist_bytes=(DATA/MANIFEST["historical_prompt_variant"]["file"]).read_bytes()
    source_identities=(
        hashlib.sha256(active_bytes).hexdigest()==MANIFEST["active_procedure"]["sha256"]
        and hashlib.sha256(hist_bytes).hexdigest()==MANIFEST["historical_prompt_variant"]["sha256"]
    )
    with tempfile.TemporaryDirectory() as td:
        lab=OrbitLab(Path(td)/"method.db")
        try:
            context=lab.add("Context","Current recovery contract",data={},provenance_class="TEST",provenance="method-authority",identity_key="ctx")
            scope=lab.add("Scope","One-conversation recovery",data={"parent_scope_id":None},provenance_class="TEST",provenance="method-authority",identity_key="scope")
            method=lab.add("Method","Active Operator Moonshot recovery method",data={
                "procedure_sha256":MANIFEST["active_procedure"]["sha256"],
                "schema_sha256":MANIFEST["active_schema"]["sha256"]
            },provenance_class="TEST",provenance="method-authority",identity_key="method")
            active=lab.add("Evidence","Active recovery procedure",data={
                "source_role":"METHOD_CONTEXT","evidence_tags":["RECOVERY_METHOD_CONTEXT"],
                "sha256":MANIFEST["active_procedure"]["sha256"]
            },epistemic="OBSERVED",provenance_class="LIBRARY_ARTIFACT",provenance="active-contract",identity_key="active")
            predecessor=lab.add("Evidence","Historical recovery prompt variant",data={
                "source_role":"METHOD_CONTEXT","evidence_tags":["RECOVERY_METHOD_CONTEXT"],
                "sha256":MANIFEST["historical_prompt_variant"]["sha256"]
            },epistemic="OBSERVED",provenance_class="LIBRARY_ARTIFACT",provenance="historical-method",identity_key="pred")
            basis=lab.add("Artifact","Library authority/custody basis",data={
                "active_path":MANIFEST["active_procedure"]["library_path"],
                "archived_path":MANIFEST["archived_predecessor_library"]["library_path"],
                "schema_path":MANIFEST["active_schema"]["library_path"]
            },provenance_class="TEST",provenance="method-authority",identity_key="basis")
            lab.assess_method_compliance(
                context_id=context,entity_id=active,method_id=method,scope_id=scope,
                verdict="CURRENT",basis_entity_ids=[basis],
                reason="exact active procedure identity is under ACTIVE_RECOVERY_CONTRACT with active schema",
                provenance_class="TEST",provenance="method-authority",identity_key="mc-active")
            lab.assess_method_compliance(
                context_id=context,entity_id=predecessor,method_id=method,scope_id=scope,
                verdict="PREDECESSOR",basis_entity_ids=[basis],
                reason="historical prompt remains method context but is not the current one-conversation procedure",
                provenance_class="TEST",provenance="method-authority",identity_key="mc-pred")

            claim=lab.add("Claim","Cited recovery method satisfies the current one-conversation contract",data={
                "required_evidence_tags":["RECOVERY_METHOD_CONTEXT"],
                "evidence_source_role_contract":{"allowed":["METHOD_CONTEXT"],"require_declared_role":True},
                "evidence_method_compliance_contract":{
                    "method_id":method,"context_id":context,"scope_id":scope,
                    "allowed_verdicts":["CURRENT"],"require_assessment":True
                }
            },provenance_class="TEST",provenance="method-authority",identity_key="claim")
            frame=lab.add("ObservationFrame","Method authority frame",data={
                "observer":"method-authority-probe","apparatus":"Library identity + METHOD_COMPLIANCE",
                "accessible_variables":["content identity","method verdict","source role"],
                "resolution":"exact method/context/scope relation",
                "intervention":"substitute predecessor for current procedure",
                "boundary":"method governance only; method artifacts contribute no branch scientific evidence"
            },provenance_class="TEST",provenance="method-authority",identity_key="frame")

            predecessor_blocked=False
            try:
                lab.assess_claim(claim,frame_id=frame,evidence_ids=[predecessor],verdict="SUPPORTED",
                    scope="current recovery method",provenance_class="TEST",provenance="method-authority")
            except ValueError:
                predecessor_blocked=True
            current_ep=lab.assess_claim(claim,frame_id=frame,evidence_ids=[active],verdict="SUPPORTED",
                scope="current recovery method",provenance_class="TEST",provenance="method-authority")
            current_supported=lab.episode(current_ep)["data"]["verdict"]=="SUPPORTED"

            # Relevance remains intact: predecessor can support a historical-description claim
            # that explicitly accepts PREDECESSOR compliance.
            hist_claim=lab.add("Claim","Historical prompt is relevant predecessor method context",data={
                "required_evidence_tags":["RECOVERY_METHOD_CONTEXT"],
                "evidence_method_compliance_contract":{
                    "method_id":method,"context_id":context,"scope_id":scope,
                    "allowed_verdicts":["PREDECESSOR"],"require_assessment":True
                }
            },provenance_class="TEST",provenance="method-authority",identity_key="hist-claim")
            hist_ep=lab.assess_claim(hist_claim,frame_id=frame,evidence_ids=[predecessor],verdict="SUPPORTED",
                scope="historical method context",provenance_class="TEST",provenance="method-authority")
            predecessor_relevance_preserved=lab.episode(hist_ep)["data"]["verdict"]=="SUPPORTED"

            # Newer method assessment changes the live relation; audit of prior CURRENT support must fail.
            lab.assess_method_compliance(
                context_id=context,entity_id=active,method_id=method,scope_id=scope,
                verdict="OBSOLETE",basis_entity_ids=[basis],reason="synthetic successor-method drift attack",
                provenance_class="TEST",provenance="method-authority")
            drift_audit=lab.alpha_audit()
            drift_detected=(not drift_audit["passed"] and any(
                f["check"]=="claim_evidence_method_compliance" for f in drift_audit["failures"]
            ))
        finally:
            lab.close()

    cleanup=MANIFEST["incoming_cleanup"]
    return {
        "passed":all([
            source_identities,predecessor_blocked,current_supported,predecessor_relevance_preserved,
            drift_detected,cleanup["next_update_guide"]["independent_copy_byte_equal"],
            cleanup["recovery_mapping"]["independent_copy_byte_equal"]
        ]),
        "source_identities_verified":source_identities,
        "current_method_identity":MANIFEST["active_procedure"]["sha256"],
        "active_schema_identity":MANIFEST["active_schema"]["sha256"],
        "historical_prompt_variant_identity":MANIFEST["historical_prompt_variant"]["sha256"],
        "predecessor_relevant_but_blocked_from_current_method_claim":predecessor_blocked and predecessor_relevance_preserved,
        "current_method_can_satisfy_current_method_claim":current_supported,
        "post_support_method_drift_detected":drift_detected,
        "guide_duplicate_verified":cleanup["next_update_guide"]["independent_copy_byte_equal"],
        "mapping_duplicate_verified":cleanup["recovery_mapping"]["independent_copy_byte_equal"],
        "kernel_schema_additions":0,
        "claim_ceiling":[
            "method compliance is relative to the exact registered Method, Context, and Scope",
            "predecessor status does not make historical material irrelevant",
            "the test does not establish that the active recovery method is scientifically optimal",
            "the method artifacts remain non-evidentiary for domain scientific claims"
        ]
    }

if __name__=="__main__": print(json.dumps(run(),indent=2,sort_keys=True))
