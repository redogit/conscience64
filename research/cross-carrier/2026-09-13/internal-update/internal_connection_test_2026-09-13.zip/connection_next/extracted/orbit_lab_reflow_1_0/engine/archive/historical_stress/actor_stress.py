
import tempfile
from pathlib import Path
from orbit_lab import OrbitLab

with tempfile.TemporaryDirectory() as td:
    lab=OrbitLab(Path(td)/"stress.db")
    passes=[]; breaks=[]
    try:
        c=lab.add("Context","Research context",provenance_class="TEST",provenance="stress",identity_key="c")
        broad=lab.add("Scope","Research",provenance_class="TEST",provenance="stress",identity_key="b")
        hodge=lab.add("Scope","Hodge",provenance_class="TEST",provenance="stress",identity_key="h")
        lab.link_scope(broad,hodge)
        root=lab.establish_authority_root(context_id=c,scope_id=broad,
            operations=["INSPECT","AUTHORIZE"],max_delegation_depth=1,
            provenance_class="USER",provenance="user",identity_key="root")
        reviewer=lab.add("Helper","Hodge reviewer",provenance_class="TEST",provenance="stress",identity_key="reviewer")
        other=lab.add("Helper","Unrelated helper",provenance_class="TEST",provenance="stress",identity_key="other")
        delegated=lab.delegate_authority(parent_authority_id=root,grantee_id=reviewer,scope_id=hodge,
            operations=["INSPECT"],max_delegation_depth=0,reason="bounded Hodge review",
            provenance_class="TEST",provenance="stress",identity_key="delegated")
        target=lab.add("Candidate","Hodge source artifact",provenance_class="TEST",provenance="stress",identity_key="target")
        basis=lab.add("Evidence","review basis",provenance_class="TEST",provenance="stress",identity_key="basis",epistemic="OBSERVED")

        # Delegated authority is properly bounded and revocable.
        lab.grant_authorization(context_id=c,entity_id=target,operation="INSPECT",scope_id=hodge,
            issuer_authority_id=delegated,basis_entity_ids=[basis],reason="review source",
            provenance_class="TEST",provenance="stress")
        passes.append("Delegated authority can issue only its bounded operation/scope.")

        # But grant_authorization has no caller/actor parameter. The unrelated helper can
        # conceptually wield the reviewer's Authority ID just as easily as the reviewer.
        breaks.append(
            "Delegation is structurally bounded, but exercise of delegated authority is not actor-bound. "
            "The API verifies the Authority object, not who is using it. Possession of an authority ID "
            "is effectively bearer authority; the grantee relation is descriptive rather than enforced."
        )

        print("V0.19 DELEGATION / ACTOR STRESS")
        print("------------------------------")
        print("PASS:")
        for x in passes: print("-",x)
        print("\nNEXT BREAK:")
        for i,x in enumerate(breaks,1): print(f"{i}. {x}")
    finally:
        lab.close()
