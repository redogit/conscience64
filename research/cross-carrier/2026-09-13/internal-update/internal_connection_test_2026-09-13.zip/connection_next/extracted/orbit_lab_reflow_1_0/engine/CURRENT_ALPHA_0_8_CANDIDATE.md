# Orbit Lab — Alpha 0.8 BGZF Carrier/Evidence Candidate

Status: **TESTED CANDIDATE / NOT SELF-PROMOTED**

Alpha 0.8 feeds the recovered BGZF Compressed-Text AI branch into Alpha 0.7.

Earned change: Claim-local evidence qualifications. A claim may declare `required_evidence_tags`; cited evidence objects may declare `evidence_tags`. `SUPPORTED` assessments must satisfy those declared qualifications, and the audit rechecks them.

No new object type or episode type was added.

The BGZF branch independently rebuilt from the exact Library source and reproduced the recorded 92,624-byte executable and 8/8 selftest with zero split-embedding error. The stronger real-world learning/generalization claim remains unresolved.
