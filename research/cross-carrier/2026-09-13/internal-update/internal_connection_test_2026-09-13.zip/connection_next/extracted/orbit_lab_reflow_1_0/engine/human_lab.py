from __future__ import annotations

import argparse
import json
import shlex
import subprocess
import sys
from pathlib import Path
from typing import Optional

from orbit_lab import OrbitLab
from supporters.catalog import PROFILES, route_profile
from supporters.surface_guard import inspect_surface
from connections import ConnectionMap
from work_helpers.gdsn import render as render_gdsn
from library_support import render as render_library_support

BASE = Path(__file__).resolve().parent

# Human-facing names deliberately stay task-local. The kernel types remain stable underneath.
CARD = {
    "question": ("subject", "Subject", "Question"),
    "need": ("obligation", "Obligation", "Need"),
    "limit": ("boundary", "Boundary", "Limit"),
    "try": ("probe", "Probe", "Try"),
    "saw": ("observation", "Observation", "Saw"),
    "left": ("remainder", "Remainder", "Left"),
}

PROFILE_LABELS = {
    "transport": "faithful_transport",
    "adaptive": "adaptive_architecture",
    "schema": "schema_change",
    "holdout": "holdout_experiment",
    "language": "language_or_representation",
    "pipeline": "pipeline_or_wrapper",
    "theorem": "theorem_dependent_inference",
}

PROFILE_HELP = {
    "transport": "moving/copying/reconstructing something while preserving what matters",
    "adaptive": "a mechanism that changes or learns over time",
    "schema": "changing the language, record shape, or distinctions used by the lab",
    "holdout": "a protected evaluation, truth set, or clean comparison",
    "language": "a representation, vocabulary, serializer, or meaning distinction",
    "pipeline": "a multi-part system where wrapper success may hide component behavior",
    "theorem": "a conclusion that depends on theorem validity plus a checked application of its hypotheses",
}


def _short(identifier: str) -> str:
    return identifier.split("-")[-1][:8] if identifier else ""


def _line(text: str = "", char: str = "-") -> str:
    return char * max(8, min(76, len(text) if text else 56))


class HumanLab:
    def __init__(self, db: str | Path):
        self.db = Path(db)
        self.lab = OrbitLab(self.db)

    def close(self):
        self.lab.close()

    def _add_current(self, command: str, text: str) -> str:
        slot, object_type, _ = CARD[command]
        kwargs = {
            "provenance_class": "CURRENT_CONVERSATION",
            "provenance": "human-interface",
        }
        if object_type == "Observation":
            kwargs["epistemic"] = "OBSERVED"
            guard=inspect_surface(text,intended_role="Observation")
            if guard["signals"]:
                kwargs["data"]={"human_surface":"Saw","surface_guard":guard}
        elif object_type == "Remainder":
            kwargs["epistemic"] = "UNEXPLAINED"
        oid = self.lab.add(object_type, text, **kwargs)
        self.lab.pin(slot, oid)
        return oid

    def clear_card(self, reason: str = "new human-facing research card"):
        current = self.lab.scan()
        seen = set()
        for key in ("subject", "obligation", "boundary", "probe", "observation", "remainder"):
            for obj in current.get(key, []):
                oid = obj["id"]
                if oid not in seen:
                    self.lab.return_(oid, reason=reason)
                    seen.add(oid)

    def start(self, question: str) -> str:
        self.clear_card()
        return self._add_current("question", question)

    def add(self, command: str, text: str) -> str:
        return self._add_current(command, text)

    def compare(self, text: str) -> str:
        scan=self.lab.scan()
        observations=scan.get("observation",[])
        if len(observations)<2:
            raise ValueError("compare needs at least two current observations; record them with saw first")
        source_ids=[x["id"] for x in observations]
        oid=self.lab.add(
            "Inference", text,
            data={"human_surface":"Comparison","derived_from_observation_count":len(source_ids)},
            provenance_class="CURRENT_CONVERSATION",
            provenance="human-interface",
            epistemic="PROPOSED",
        )
        for sid in source_ids:
            self.lab.relate(
                oid,"DERIVED_FROM",sid,
                data={"human_surface":"Comparison","source_role":"Observation"},
                provenance_class="DERIVED",provenance="human-interface",
            )
        subject=self.current_subject_id()
        if subject:
            self.lab.relate(oid,"ABOUT",subject,data={"human_surface":"Comparison","evidence_effect":"NONE"},
                            provenance_class="DERIVED",provenance="human-interface")
        return oid

    def think(self, text: str) -> str:
        oid = self.lab.add(
            "Inference", text,
            data={"human_surface":"Thought"},
            provenance_class="CURRENT_CONVERSATION",
            provenance="human-interface",
            epistemic="PROPOSED",
        )
        subject = self.current_subject_id()
        if subject:
            self.lab.relate(
                oid, "ABOUT", subject,
                data={"human_surface": "Thought", "evidence_effect": "NONE"},
                provenance_class="DERIVED",
                provenance="human-interface",
            )
        return oid

    def decide(self, text: str) -> str:
        oid = self.lab.add(
            "Decision", text,
            provenance_class="CURRENT_CONVERSATION",
            provenance="human-interface",
        )
        subject = self.current_subject_id()
        if subject:
            self.lab.relate(
                oid, "ABOUT", subject,
                data={"human_surface": "Decision"},
                provenance_class="DERIVED",
                provenance="human-interface",
            )
        return oid

    def current_subject_id(self) -> Optional[str]:
        scan = self.lab.scan()
        items = scan.get("subject", [])
        return items[-1]["id"] if items else None

    def card(self) -> str:
        scan = self.lab.scan()
        rows = []
        for _, (slot, _, label) in CARD.items():
            items = scan.get(slot, [])
            if not items:
                rows.append((label, "—"))
                continue
            # Current limits allow several non-subject entries; preserve order but keep the view compact.
            if len(items) == 1:
                value = items[0]["title"]
            else:
                value = " | ".join(x["title"] for x in items)
            rows.append((label, value))

        lines = ["RESEARCH CARD", "============="]
        width = max(len(label) for label, _ in rows)
        for label, value in rows:
            lines.append(f"{label:<{width}}  {value}")
        lines += ["", "Rule: Saw = observation. Thought = interpretation. They are not the same thing."]
        return "\n".join(lines)

    def recent_thoughts(self, limit: int = 5) -> str:
        subject = self.current_subject_id()
        if not subject:
            return "No current question."
        rows = []
        for typ, default_label in (("Inference", "Thought"), ("Decision", "Decision")):
            for obj in self.lab.library(type=typ)[:limit]:
                rel = self.lab.conn.execute(
                    "SELECT 1 FROM relations WHERE from_id=? AND kind='ABOUT' AND to_id=?",
                    (obj["id"], subject),
                ).fetchone()
                if rel:
                    label=obj.get("data",{}).get("human_surface",default_label)
                    rows.append((obj["created_at"], label, obj["title"]))
        rows.sort(reverse=True)
        if not rows:
            return "No recorded thoughts or decisions for the current question."
        return "\n".join(f"{label}: {title}" for _, label, title in rows[:limit])

    def support(self, friendly_profile: str) -> str:
        key = PROFILE_LABELS.get(friendly_profile, friendly_profile)
        if key not in PROFILES:
            choices = ", ".join(PROFILE_LABELS)
            raise ValueError(f"unknown support shape; choose one of: {choices}")
        routed = route_profile(key)
        selected = routed["selected"]
        lines = [
            f"SUPPORT FOR: {friendly_profile}",
            "=" * (13 + len(friendly_profile)),
            routed["reason"],
            "",
            f"Smallest current helper set (cost {routed['total_cost']}):",
        ]
        for helper in selected:
            lines.append(f"  • {helper['name']} — {helper['note']}")
        lines += [
            "",
            "These helpers use different mechanisms, but they share this runtime; this is not independent replication.",
        ]
        return "\n".join(lines)

    def incoming(self) -> str:
        return ConnectionMap().summary()

    def why_connected(self, area: str) -> str:
        return ConnectionMap().why(area)

    def health(self) -> str:
        path = BASE / "artifacts" / "latest_selector_run.json"
        if not path.exists():
            return (
                "LAB CHECK\n=========\nNo verified selector run is available yet.\n"
                "Run the lab selector once, then this view will explain the result."
            )
        try:
            result = json.loads(path.read_text(encoding="utf-8"))
        except Exception as e:
            return f"LAB CHECK\n=========\nThe latest selector result could not be read: {e}"
        tests = None
        orbital = None
        supporters = None
        historical = None
        for level in result.get("trace", []):
            for probe in level.get("probes", []):
                if probe["probe"] == "compile+regression":
                    tests = probe["detail"].get("tests")
                elif probe["probe"] == "bounded-random-orbital":
                    orbital = probe["detail"].get("trials")
                elif probe["probe"] == "supporter-ecology":
                    supporters = probe["detail"].get("signals")
                elif probe["probe"] == "historical-lineage-audit":
                    historical = probe["detail"].get("historical_total")
        lines = [
            "LAB CHECK",
            "=========",
            f"Status: {'PASS' if result.get('passed') else 'FAIL'}",
            f"Stage: {result.get('stage','unknown')}",
            f"Active components: {result.get('passed_components',0)}/{result.get('total_components',0)} passed",
            f"Declared obligations: {len(result.get('resolved_obligations',[]))}/{len(result.get('required_obligations',[]))} resolved",
        ]
        if tests is not None: lines.append(f"Regression tests: {tests} passed")
        if orbital is not None: lines.append(f"Adversarial trials: {orbital} with no surviving finding")
        if supporters is not None: lines.append(f"Supporter signals: {supporters}")
        if historical is not None: lines.append(f"Historical probes classified: {historical}")
        unresolved=result.get("unresolved_obligations",[])
        lines.append("Unresolved lab obligations: " + (", ".join(unresolved) if unresolved else "none"))
        lines += [
            "",
            "This view reports the latest selector-run artifact; it does not silently rerun the lab.",
            "The result is bounded software/research evidence, not a completeness claim.",
        ]
        return "\n".join(lines)

    def history(self, limit: int = 12) -> str:
        events = self.lab.trail(limit=limit)
        if not events:
            return "No history yet."
        friendly = {
            "ADDED": "recorded",
            "PINNED": "put on current card",
            "RETURNED": "returned to history",
            "RELATION_ADDED": "related",
            "MARKED_UNRESOLVED": "left unresolved",
        }
        lines = ["RECENT HISTORY", "=============="]
        for e in events:
            event = friendly.get(e["event"], e["event"].lower().replace("_", " "))
            oid = e.get("object_id")
            title = ""
            if oid:
                try:
                    title = self.lab.get(oid).title
                except Exception:
                    title = _short(oid)
            lines.append(f"• {event}: {title}".rstrip())
        return "\n".join(lines)

    def next_hint(self) -> str:
        scan = self.lab.scan()
        if not scan.get("subject"):
            return "Start with a Question."
        if not scan.get("obligation"):
            return "Add a Need: what must this work preserve or accomplish?"
        if not scan.get("boundary"):
            return "Add a Limit if something must not be assumed, changed, exposed, or exceeded."
        if not scan.get("probe"):
            return "Add a Try: one concrete action or test that could change what you believe."
        if not scan.get("observation"):
            return "Run the Try, then record only what you saw before interpreting it."
        if not scan.get("remainder"):
            return "Record what is Left unresolved—or record a Thought separately if you have an interpretation."
        return "The card is populated. Compare what you Saw with the Need, then decide whether to test again, think, decide, or return the work."

    def advanced(self) -> str:
        stats = self.lab.stats()
        audit = self.lab.alpha_audit()
        return json.dumps({"audit": audit, "stats": stats}, indent=2, sort_keys=True)


def help_text() -> str:
    return """HUMAN LAB COMMANDS
==================
start <question>    Start a new Research Card; the previous Current is returned to history.
need <text>         What must this work preserve or accomplish?
limit <text>        What boundary or constraint matters?
try <text>          What concrete probe/action will you attempt?
saw <text>          What was actually observed? (recorded as OBSERVED)
compare <text>      Derive a comparison from the current observations; kept separate
                    from both Saw and Thought.
left <text>         What remains unexplained? (recorded as UNEXPLAINED)
think <text>        Record an interpretation separately from observation.
decide <text>       Record a decision separately from evidence.
card                Show the current Research Card.
next                Suggest the next missing step on the card.
support <shape>     Choose a small supporter set for: transport, adaptive, schema,
                    holdout, language, or pipeline.
incoming            Show the connected quarantined research branches.
why <area>          Explain why sources connect to a lab area, e.g. selector,
                    human-interface, persistence, whole, supporter-ecology.
health              Show the latest verified selector-run result.
gdsn <problem>      Triage a GDSN work problem without adding it to the lab history.
find-support <item>   Find declared/nearby Library support routes. Related items remain candidates
                      until their source and tested relation are inspected.
history [n]         Show recent history in human terms.
advanced            Show kernel audit/stats.
help                Show this help.
quit                 Exit.
"""


def dispatch(h: HumanLab, argv: list[str]) -> str:
    if not argv:
        return help_text()
    command = argv[0].lower()
    rest = " ".join(argv[1:]).strip()
    if command == "start":
        if not rest: raise ValueError("start needs a question")
        oid = h.start(rest)
        return f"Started: {rest}\n{h.next_hint()}"
    if command in {"need", "limit", "try", "saw", "left"}:
        if not rest: raise ValueError(f"{command} needs text")
        oid=h.add(command, rest)
        warning_text=""
        if command=="saw":
            guard=h.lab.get(oid).data.get("surface_guard",{})
            warnings=guard.get("warnings",[])
            if warnings:
                warning_text="\nSurface check:\n  - " + "\n  - ".join(warnings)
        return f"Recorded {CARD[command][2]}: {rest}{warning_text}\n{h.next_hint()}"
    if command == "compare":
        if not rest: raise ValueError("compare needs text")
        h.compare(rest); return f"Recorded Comparison: {rest}\n(Derived from observations; kept separate from interpretation.)"
    if command == "think":
        if not rest: raise ValueError("think needs text")
        h.think(rest); return f"Recorded Thought: {rest}\n(Interpretation kept separate from observation.)"
    if command == "decide":
        if not rest: raise ValueError("decide needs text")
        h.decide(rest); return f"Recorded Decision: {rest}"
    if command == "card": return h.card()
    if command == "next": return h.next_hint()
    if command == "support":
        if not rest:
            return "Choose a shape:\n" + "\n".join(f"  {k:<10} {v}" for k, v in PROFILE_HELP.items())
        return h.support(rest.split()[0].lower())
    if command == "incoming": return h.incoming()
    if command == "why":
        if not rest: raise ValueError("why needs a connected lab area")
        return h.why_connected(rest.split()[0])
    if command == "health": return h.health()
    if command == "gdsn":
        if not rest: raise ValueError("gdsn needs a short problem description")
        return render_gdsn(rest)
    if command in {"find-support","library-support"}:
        if not rest: raise ValueError("find-support needs an item, claim, or concept")
        return render_library_support(rest)
    if command == "history":
        n = int(argv[1]) if len(argv) > 1 else 12
        return h.history(n)
    if command == "advanced": return h.advanced()
    if command == "help": return help_text()
    if command in {"quit", "exit"}: return "__QUIT__"
    raise ValueError(f"unknown command: {command}; use 'help'")


def interactive(db: Path):
    h = HumanLab(db)
    print("Orbit Lab — Human Interface")
    print("Type 'help' for commands. Type 'card' to see the current work.\n")
    try:
        while True:
            try:
                raw = input("lab> ").strip()
            except EOFError:
                break
            if not raw:
                continue
            try:
                out = dispatch(h, shlex.split(raw))
                if out == "__QUIT__": break
                print(out)
            except Exception as e:
                print(f"Could not do that: {e}")
    finally:
        h.close()


def demo():
    import tempfile
    with tempfile.TemporaryDirectory() as td:
        h = HumanLab(Path(td) / "demo.db")
        try:
            print(dispatch(h, ["start", "Does the human-facing interface reduce reconstruction work without hiding consequential distinctions?"]))
            print(dispatch(h, ["need", "Keep observation separate from interpretation and keep history recoverable."]))
            print(dispatch(h, ["limit", "Do not expose kernel complexity unless it changes the user's action."]))
            print(dispatch(h, ["try", "Use the six-field Research Card for one bounded research cycle."]))
            print(dispatch(h, ["saw", "The card can be filled without using object IDs, schema terms, or authority plumbing."]))
            print(dispatch(h, ["left", "Whether real users make fewer consequential mistakes remains untested."]))
            print(dispatch(h, ["think", "The interface appears simpler structurally, but usability benefit needs human testing."]))
            print("\n" + h.card())
            print("\n" + h.recent_thoughts())
            print("\n" + h.support("language"))
            print("\n" + h.incoming())
            print("\n" + h.why_connected("human-interface"))
            print("\nNEXT\n====\n" + h.next_hint())
        finally:
            h.close()



def demo_unresolved():
    import tempfile
    with tempfile.TemporaryDirectory() as td:
        h = HumanLab(Path(td) / "unresolved-demo.db")
        try:
            steps=[
                ("start","Where are the actual code/results for the carrier-library mutation/staleness attack?"),
                ("need","Primary code, logs, outputs, or hashes rather than remembered numerical claims."),
                ("limit","Do not treat failure to locate an artifact in a bounded search as proof it never existed."),
                ("try","Search exact experiment identities first, then widen by behavior and source role."),
                ("saw","Only recovery/index records were located; no primary execution artifact was recovered in the searched Library routes."),
                ("left","Whether the mutation attack was executed, and what its result was, remains unresolved."),
                ("think","The search is useful as a provenance result, but it does not settle the historical execution question."),
            ]
            for cmd,text in steps:
                print(dispatch(h,[cmd,text]))
            print("\n"+h.card())
            print("\n"+h.recent_thoughts())
        finally:
            h.close()

def main():
    p = argparse.ArgumentParser(description="Human-facing console for Orbit Lab")
    p.add_argument("--db", default="human_lab.db")
    p.add_argument("--demo", action="store_true")
    p.add_argument("--demo-unresolved", action="store_true")
    p.add_argument("command", nargs=argparse.REMAINDER)
    args = p.parse_args()
    if args.demo:
        demo(); return
    if args.demo_unresolved:
        demo_unresolved(); return
    if args.command:
        h = HumanLab(args.db)
        try:
            out = dispatch(h, args.command)
            if out != "__QUIT__": print(out)
        finally:
            h.close()
        return
    interactive(Path(args.db))


if __name__ == "__main__":
    main()
