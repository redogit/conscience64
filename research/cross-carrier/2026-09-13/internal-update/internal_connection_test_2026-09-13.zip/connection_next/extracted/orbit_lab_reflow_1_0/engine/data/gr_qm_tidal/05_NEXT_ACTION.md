# Next Action — Reconstruct and Ablate the Measured Tidal Phase

## Research decision

Do **not** broaden to another theory or another high-level ontology yet.

The next consequential experiment is to reconstruct the already measured curvature/tidal atom-interferometer phase from the mechanism itself and then remove candidate lower-order gravitational structure one piece at a time.

## Target relation

```text
uniform/local acceleration | tidal curvature
```

with measured consequence:

```text
quantum interferometer phase
```

## Registered record

### B — Before

A minimal light-pulse atom interferometer model in a weak gravitational field expanded locally as:

```text
Phi(z) = Phi_0 + g z + (1/2) Gamma z^2 + higher terms
```

where:

- `Phi_0` = constant potential offset,
- `g` = local uniform acceleration term,
- `Gamma` = local gravity-gradient / tidal term.

### δ — Intervention sequence

Run one-degree ablations in this order:

1. `Phi_0 -> 0` while preserving `g, Gamma`.
2. `g -> 0` while preserving `Gamma`.
3. `Gamma -> 0` while preserving all registered interferometer operations.
4. Add arbitrary affine contamination `A + B z` back and verify the curvature-sensitive observable remains invariant.

Do not alter more than one independent term in each primary ablation.

### M — Measures

At minimum record separately:

- total interferometer phase,
- acceleration-sensitive phase component,
- tidal/curvature-sensitive phase component,
- arm separation / path geometry,
- any laser/separation/action phase decomposition used.

### S — Scope

Start with the experimentally relevant weak-field/quadratic regime used to derive the Asenbaum et al. tidal phase. Explicitly register pulse sequence, recoil momentum, interrogation time, path separation assumptions, and approximation order.

## Pass/fail logic

### Expected structural behavior

If the observable is genuinely curvature/tidal sensitive in the intended way:

```text
add constant potential      -> no curvature-phase change
add/remove linear potential -> no isolated curvature-phase change after the registered cancellation geometry
remove Gamma                -> tidal phase vanishes
```

A failure of the first two invariances means the implemented observable is still contaminated by lower-order structure or the interferometer geometry/cancellation has been modeled incorrectly.

A nonzero tidal phase at `Gamma=0` is a decisive implementation/derivation failure unless another explicitly registered curvature source remains.

## Independent relativistic transport

Only after the weak-field reconstruction passes, rewrite the local field in Fermi-normal or equivalent local inertial coordinates around a reference freely falling worldline, using the quadratic curvature term schematically:

```text
g_00 = -1 - R_0i0j x^i x^j + ...
```

(sign/factor conventions must be declared explicitly).

Then test whether the same registered interferometer consequence is carried by `R_0i0j` without relying on coordinate acceleration.

## Tool routing

- **Wolfram:** tensor expansion, Fermi-normal/curvature algebra, exact simplification.
- **Local Python/SymPy:** independent derivation, ablations, numerical parameter sanity checks, exact finite algebra where possible.
- **SciSpace:** retrieve the experimental/theoretical derivation details and known cancellation geometries; separate peer-reviewed measurement from proposed mechanisms.
- **Mathbox audit:** audit sign conventions, omitted phase terms, approximation order, independent checks, and claim ceiling.
- **Web/current literature:** only after the structural observable is precise, check whether an empirical measurement isolates exactly the registered quantity.
- **OLU/Library:** preserve baseline, intervention, witnesses, failures, and remainder; do not reinterpret results as ontology.

## Stop conditions

Stop and classify rather than continue if any of these occurs:

1. the derivation depends on an unstated gauge/coordinate choice that changes the registered observable;
2. independent implementations disagree;
3. the published experimental geometry cannot be reconstructed from accessible source detail;
4. the tidal phase is inseparable from lower-order acceleration terms in the chosen model;
5. approximation error is comparable to the target phase;
6. a new distinction is required to explain the failure.

## Claim ceiling

Even a successful reconstruction supports only:

> A specified quantum interferometer observable responds to a specified classical tidal/curvature relation while rejecting specified lower-order acceleration-like terms in the tested regime.

It does **not** establish:

- that gravity is quantum,
- that spacetime is fundamental or emergent,
- that space, time, and gravity are one object,
- that `Delta(Delta)` is a fundamental law,
- or a unification of GR and quantum theory.

## Next frontier after a successful pass

Only then attack:

```text
quantum probe of classical curvature
|
observable requiring nonclassical gravitational degrees of freedom
```

That is the appropriate boundary for the subsequent quantum-gravity-facing work.
