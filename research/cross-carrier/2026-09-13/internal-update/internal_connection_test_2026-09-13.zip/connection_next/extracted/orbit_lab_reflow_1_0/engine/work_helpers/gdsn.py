from __future__ import annotations
from pathlib import Path
import json, re

BASE=Path(__file__).resolve().parents[1]
SPEC=json.loads((BASE/'data'/'gdsn_work_helper'/'GDSN_WORK_HELPER.json').read_text(encoding='utf-8'))

ROUTES=(
    ('confirmation', ('cic','review','rejected','received','synchronised','synchronized','confirmation')),
    ('publication-subscription', ('publication','publish','subscription','subscribe','rfcin','cin','notification','sync list','synchronisation','synchronization')),
    ('hierarchy', ('hierarchy','case','each','pallet','pack','parent','child','gtin level')),
    ('data-quality', ('attribute','validation','missing','invalid','error','required','gpc','classification')),
    ('identity-targeting', ('gtin','gln','target market','recipient','source gln')),
    ('message-lineage', ('message id','instanceidentifier','correlation','xml','payload','ack','transport')),
)

def classify(problem:str)->str:
    text=problem.lower()
    scores=[]
    for route,terms in ROUTES:
        score=sum(1 for t in terms if t in text)
        if score: scores.append((score,route))
    return max(scores)[1] if scores else 'general'

def _route_questions(route:str)->list[str]:
    common=[
        'What did you expect to happen, and what actually happened?',
        'Are you acting as the data source, data recipient, or investigating between them?',
        'What is the smallest safe identity needed to distinguish the item/context (for example redacted GTIN, GLN and target market)?',
        'What is the last independently observed good state, message, or timestamp?',
    ]
    extra={
        'confirmation':[
            'What CIC state is actually present: RECEIVED, SYNCHRONISED, REVIEW, or REJECTED?',
            'If REVIEW/REJECTED, are confirmation-status or corrective-action details present?',
            'Do not infer item activation or purchasability merely from SYNCHRONISED.'
        ],
        'publication-subscription':[
            'Was the item published, subscribed, republished, or requested by RFCIN?',
            'Is the expected recipient/item relationship present in the synchronisation path?',
            'Treat RFCIN as a one-time resend/request, not a persistent subscription.'
        ],
        'hierarchy':[
            'Which hierarchy level is affected, and which GTIN level is expected?',
            'Is a parent/child level missing, duplicated, or inconsistent?',
            'Check the hierarchy relation separately from individual attribute validity.'
        ],
        'data-quality':[
            'Which attribute or validation rule failed, and who declares that requirement?',
            'Is the requirement a GS1/GDSN standard rule, a target-market rule, or a trading-partner/data-pool rule?',
            'Separate missing data from data that is present but rejected by a local rule.'
        ],
        'identity-targeting':[
            'Confirm the relevant GTIN, GLN/party role and target market without exposing unnecessary production identifiers.',
            'Check whether the problem follows the item identity or only one recipient/target-market relationship.'
        ],
        'message-lineage':[
            'Capture message type, direction, timestamp, and safe/redacted message identifier.',
            'Check request/response correlation before interpreting business state.',
            'Separate transport receipt from business acceptance.'
        ],
        'general':[
            'Which layer is failing: item data, identity/targeting, publication/subscription, data pool/registry path, recipient processing, or local business rule?',
            'What single observation would distinguish the two most plausible layers?'
        ]
    }
    return common+extra[route]

def triage(problem:str)->dict:
    route=classify(problem)
    return {
        'problem':problem,
        'route':route,
        'questions':_route_questions(route),
        'boundaries':[
            'Use sanitized examples where possible; do not include passwords, credentials, confidential customer data, or full production payloads.',
            'GS1/GDSN standards are reference authority for the standard; local data-pool, retailer, employer, and contractual rules must be checked separately.',
            'Do not turn a status label into a stronger business conclusion than the status supports.'
        ],
        'known_distinctions':SPEC['guardrails'][:4],
        'claim_ceiling':'This helper can organize and explain a GDSN problem; it cannot certify a company-specific production cause without the relevant local evidence.'
    }

def render(problem:str)->str:
    r=triage(problem)
    lines=['GDSN WORK HELPER','================',f"Problem: {r['problem']}",f"Route: {r['route']}",'','Check:']
    lines += [f"  {i+1}. {q}" for i,q in enumerate(r['questions'])]
    lines += ['','Boundaries:']+[f"  - {x}" for x in r['boundaries']]
    lines += ['','Useful distinction:']+[f"  - {x}" for x in r['known_distinctions']]
    lines += ['',r['claim_ceiling']]
    return '\n'.join(lines)
