# Orbit Lab Reflow 1.0

A clean active-context rebuild of Orbit Lab using the distinctions earned through Alpha 0.26 and the full current conversation.

Read in this order:

1. `CURRENT.md`
2. `context/00_ORIENTATION.md`
3. `context/01_WORK.md`
4. `context/02_VERIFY.md`
5. `context/03_LIBRARY.md`
6. `context/04_CAPABILITIES.md`
7. `context/05_APPLIED_TRIALS.md`
8. `context/06_OPEN_WORK.md`
9. `history/ALPHA_LINEAGE.md` only when history is needed
10. `history/CONVERSATION_REFLOW.md` for the reorganized conversation narrative

`engine/` contains the exact verified Alpha 0.26 implementation lineage. It is intentionally not the conceptual entry point.

## Minimal mental model

```text
WORK      ask / need / limit / try / saw / left
VERIFY    what can this actually support?
LIBRARY   what should remain recoverable and what can help next?
```
