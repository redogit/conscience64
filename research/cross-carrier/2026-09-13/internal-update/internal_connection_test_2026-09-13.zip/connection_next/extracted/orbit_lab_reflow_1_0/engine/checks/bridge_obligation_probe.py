
from __future__ import annotations
from pathlib import Path
import tempfile, json, sys
ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0,str(ROOT))
from orbit_lab import OrbitLab

def run():
    with tempfile.TemporaryDirectory() as td:
        lab=OrbitLab(Path(td)/"bridge.db")
        try:
            def add(t,title,key,**kw):
                return lab.add(t,title,provenance_class="TEST",provenance="bridge-probe",identity_key=key,**kw)
            src=add("Context","Source arrangement","src")
            dst=add("Context","Target arrangement","dst")
            thing=add("Artifact","Converted representation","thing")
            ob=add("Obligation","Preserve exact content identity","ob",
                data={"required_evidence_tags":["SAME_CONTENT_IDENTITY"]})
            weak=add("Evidence","Semantic resemblance","weak",epistemic="OBSERVED",
                data={"evidence_tags":["SEMANTIC_SIMILARITY"]})
            exact=add("Evidence","Digest identity","exact",epistemic="OBSERVED",
                data={"evidence_tags":["SAME_CONTENT_IDENTITY"]})

            weak_blocked=False
            try:
                lab.transfer(
                    source_context_id=src,destination_context_id=dst,entity_id=thing,
                    obligation_ids=[ob],evidence_entity_ids=[weak],
                    requested_operations=["PRESERVE"],result="PRESERVED",
                    reason="weak test",provenance_class="TEST",provenance="bridge-probe")
            except ValueError:
                weak_blocked=True

            unresolved=lab.transfer(
                source_context_id=src,destination_context_id=dst,entity_id=thing,
                obligation_ids=[ob],evidence_entity_ids=[weak],
                requested_operations=["PRESERVE"],result="UNRESOLVED",
                reason="insufficient evidence",
                provenance_class="TEST",provenance="bridge-probe")

            preserved=lab.transfer(
                source_context_id=src,destination_context_id=dst,entity_id=thing,
                obligation_ids=[ob],evidence_entity_ids=[exact],
                requested_operations=["PRESERVE"],result="PRESERVED",
                reason="qualified identity evidence",
                provenance_class="TEST",provenance="bridge-probe")

            actor=add("Actor","Unprivileged actor","actor")
            scope=add("Scope","Destination use","scope")
            auth=lab.check_authorized(
                context_id=dst,actor_id=actor,entity_id=thing,
                operation="ACTIVATE",scope_id=scope)

            audit=lab.alpha_audit()
            return {
                "passed": (
                    weak_blocked
                    and lab.episode(unresolved)["data"]["result"]=="UNRESOLVED"
                    and lab.episode(preserved)["data"]["result"]=="PRESERVED"
                    and not auth["authorized"]
                    and audit["passed"]
                ),
                "weak_similarity_cannot_certify_identity_preservation":weak_blocked,
                "insufficient_evidence_can_remain_unresolved":lab.episode(unresolved)["data"]["result"]=="UNRESOLVED",
                "qualified_evidence_can_certify_declared_obligation":lab.episode(preserved)["data"]["result"]=="PRESERVED",
                "transfer_does_not_grant_destination_authority":not auth["authorized"],
                "audit_passed":audit["passed"],
                "kernel_schema_additions":0,
                "bridge_representation":"existing TRANSFER + Obligation + qualified evidence",
            }
        finally:
            lab.close()

if __name__=="__main__":
    print(json.dumps(run(),indent=2,sort_keys=True))
