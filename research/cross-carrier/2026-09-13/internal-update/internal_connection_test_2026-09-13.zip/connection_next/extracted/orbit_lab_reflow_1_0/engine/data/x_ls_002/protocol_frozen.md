# X-LS-001 — Applicability-Language Collision Preflight

Status: `DEVELOPMENT_PROTOCOL_DRAFT`  
Date: 2026-08-31  
Mode: design followed by an executable exhaustive-finite development check  
Canonical authority: unavailable; no `SOCIETY_HEAD.json`, `STATE.json`, or `PATHWAYS.json` was found in the supplied workspace.  
Claim ceiling: exact constructed panel and exact serializers/router only. This is not confirmation, generalization, ontology validation, or evidence that real cases can be classified correctly.

## 1. Question and decision

`Q-LS-001`: On a frozen finite panel of paired synthetic records, does a constructed status-only baseline `(probe_type, routing_status)` collapse records assigned different stipulated route labels, and does a nine-field candidate representation remove those collisions without runtime access to the labels?

Decision:

- If the baseline has at least one within-pair label collision, the candidate representation has none, all stipulated route labels are reproduced by the frozen router, and leave-one-field-out ablation restores the collision assigned to every field, retain the representation as a locally irredundant development preflight candidate.
- Otherwise reject or narrow the repair and isolate the smallest surviving collision.

The test does not decide whether the labels are correct, whether any field value can be inferred in an open-world research case, or whether nine separate semantic fields are preferable to a weaker recoding. Those require separate experiments.

## 2. Constructs and operationalizations

- **Routing distinguishability (`C1`)**: within the declared panel, no two records with the same declared serializer output have different stipulated route labels.
- **Label collision (`C2`)**: two records share a declared serializer output while their separately stored stipulated route labels differ.
- **Synthetic applicability record (`C3`)**: a constructed JSON feature record representing one independent probe; it is neither an observed research-system state nor evidence that the named condition exists in nature.
- **Per-case target isolation (`C4`)**: the routing phase cannot read the case-to-label file or any case-specific target alias. The preregistered global routing table necessarily contains its possible output labels and is explicitly outside this construct. This is narrower than semantic leakage and MoonShot's `ONTOLOGY_LEAKAGE`, neither of which is resolved here.
- **Local syntactic field necessity (`C5`)**: under the fixed serializer and panel, deleting one named field causes at least one collision in the pair constructed to differ only on that field. It does not establish empirical, architectural, semantic, or global necessity.

Operationalization:

- Baseline serializer `L0(feature)` returns `(probe_type, routing_status)`.
- Candidate serializer `L1(feature)` returns `L0` plus nine synthetic probe-state token fields: `carrier_witness`, `bridge_witness`, `composition_witness`, `boundary_ablation_effect`, `retrieval_state`, `net_value_state`, `correction_route_state`, `measurement_state`, and `evidence_resolution`.
- Each token is a frozen categorical design value, not a measured result. The token names preserve the semantics proposed for later measurement work, but this study tests only their encoding behavior.
- Collision count is computed over groups of identical canonical serialized values that contain more than one stipulated route label.
- Router conformance is exact match between a preregistered deterministic decision table and the separately stored `stipulated_route_label`.
- Per-case target isolation is checked by separate feature and label files, a routing process that receives only the feature-file path, schema-enforced runtime projection, post-routing forbidden-key/value scanning, and logged hashes of the exact router inputs and route output.

## 3. Design and units

This is a constructed finite schema experiment, not a sampled empirical study and not a causal claim.

- Experimental/analysis unit: one of nine constructed semantic pairs.
- Observation unit: one serialized feature record.
- The three surface-reference mutations are dependent attack views of each semantic pair, not additional evidential units.
- Panel: 9 pairs × 3 surface-reference mutations = 54 cases.
- Assignment/randomization: none. Surface references are deterministic mutations and carry no routing information.
- Comparator: `L0`, a constructed status-only baseline. It is not asserted to be the complete current MoonShot record or unrestricted MoonShot language.
- Intervention: add the nine synthetic probe-state token fields and apply `L1`.
- Ablation: remove each field from `L1` one at a time.

Within each pair and surface-reference mutation, the two feature records have identical `probe_type`, `routing_status`, identifiers stripped from the declared serializer signature, and all candidate values except the field named for that pair. Their stipulated route labels differ by construction. The labels are author-assigned reference outputs for routing conformance; they are not independent evidence that any action is necessary or correct.

## 4. Frozen pair definitions

| Pair | Independent probe | Varied field | Token A → stipulated label | Token B → stipulated label |
| --- | --- | --- | --- | --- |
| P01 | carrier | `carrier_witness` | `PRESENT` → `CHECK_BRIDGE` | `ABSENT` → `SEARCH_CARRIER` |
| P02 | bridge | `bridge_witness` | `VERIFIED` → `CHECK_COMPOSITION` | `ABSENT` → `CONSTRUCT_BRIDGE` |
| P03 | composition | `composition_witness` | `SUFFICIENT` → `CHECK_BOUNDARY` | `UNTESTED` → `TEST_COMPOSITION` |
| P04 | boundary | `boundary_ablation_effect` | `RESTORES` → `REMOVE_FALSE_OBSTRUCTION` | `DOES_NOT_RESTORE` → `CHECK_ROUTING` |
| P05 | retrieval | `retrieval_state` | `REACHABLE` → `CHECK_COST` | `UNRECOGNIZED` → `REPAIR_ROUTING` |
| P06 | economics | `net_value_state` | `POSITIVE` → `CHECK_CORRECTABILITY` | `NONPOSITIVE` → `ARCHIVE_OR_REJECT` |
| P07 | correction | `correction_route_state` | `OPEN` → `ADMIT_BOUNDED_REUSE` | `CLOSED` → `RESTORE_CORRECTION_ROUTE` |
| P08 | measurement | `measurement_state` | `VALID` → `ALLOW_MEASUREMENT_DEPENDENT_INFERENCE` | `INVALID` → `REPAIR_MEASUREMENT` |
| P09 | evidence | `evidence_resolution` | `DECISIVE` → `APPLY_DECLARED_ROUTE` | `UNDERDETERMINED` → `DESIGN_DISCRIMINATING_TEST` |

`probe_type` is only the frozen field-selection key used by the router; probes are independent and no sequential gate is claimed. All non-varied candidate fields use `OUT_OF_PROBE_SCOPE`, meaning only that the independent probe does not inspect them.

## 5. Frozen analysis contract

Primary computations:

1. `baseline_collision_groups`: number of all-panel canonical `L0` signature groups containing different stipulated labels.
2. `candidate_collision_groups`: number of all-panel canonical `L1` signature groups containing different stipulated labels.
3. `router_exact_matches / 54` against the stipulated labels.
4. For each of nine fields, `ablation_restored_assigned_collision`: whether omitting that field causes a collision in all three mutations of its assigned pair.
5. Per-case target-isolation violations.

Success requires all of:

- frozen panel validator reports `valid = true` and the run aborts before routing otherwise;
- `baseline_collision_groups = 9/9` and each of 27 dependent surface-pair views witnesses the same paired collision;
- `candidate_collision_groups = 0`;
- router exact accuracy `= 54/54`;
- each of 9 field ablations restores its assigned collision in `3/3` mutations;
- `per_case_target_isolation_violations = 0`;
- identifier stripping, case reordering, and surface-reference permutation leave the three declared invariance measurements—baseline collision-group count, candidate collision-group count, and router exact-match count—unchanged.

Failure/downgrade occurs if any success conjunct fails. No partial result may be reported as a protocol pass.

No statistical uncertainty interval is appropriate because the exact enumerated panel is exhaustively evaluated. Uncertainty about transfer beyond the panel remains unrestricted and is explicitly `UNKNOWN`.

## 6. Router and precedence

The routing phase uses `probe_type` to inspect only that probe's designated field and returns the stipulated label in the frozen global table above. It runs as a separate process that receives only `features_frozen.json` and writes serializer/prediction output that is hashed before the scoring process starts. It may not read the case-to-label file, prose, or a per-case stipulated label. The later scoring phase alone loads `labels_frozen.json`. This is a routing-conformance check, not discovery or validation of the decision table.

## 7. Attacks and controls

- **Field ablation:** tests local syntactic field necessity under the fixed serializer and constructed pairs.
- **Identifier stripping:** prevents record identity from solving the task.
- **Surface-reference permutation:** changes neutral source/target references without changing results.
- **Case reordering:** detects order dependence.
- **Prose exclusion:** the router receives no vignette or explanatory notes.
- **Per-case target-isolation check:** rejects forbidden label keys and nested aliases in features, verifies that routing completed and its output was hashed before scoring loaded labels, then scans frozen features for exact stored target values. The global preregistered route table is exempt; semantic leakage through co-design remains outside this check and is disclosed.

## 8. Evidence and reproducibility

Inputs to freeze before execution:

- this protocol;
- `generate_panel.mjs`; its joined review view `panel_frozen.json`; its runtime-separated `features_frozen.json` and `labels_frozen.json`;
- `route_x_ls_001.mjs` and `score_x_ls_001.mjs`;
- SHA-256 digests for the Supreme Governing Principle, Society prompt, current framework, current ledger, protocol, scripts, and panel;
- runtime identity and exact command.

Outputs:

- raw per-case serializations and router predictions;
- collision groups for baseline, repair, and each ablation;
- attack results;
- machine-readable result summary;
- deviation log, including empty log.

The generation command is `$CODEX_PRIMARY_RUNTIME_NODE generate_panel.mjs`. Before freezing, validation must establish 54 unique feature IDs, 54 matching label IDs, 27 pair/surface views with exactly two records each, nine declared fields, valid enum membership, and exactly one varied candidate field inside each pair/surface view.

Execution is two-phase after fail-closed validation: `$CODEX_PRIMARY_RUNTIME_NODE validate_panel.mjs features_frozen.json labels_frozen.json validation_report.json`. First routing phase: `$CODEX_PRIMARY_RUNTIME_NODE route_x_ls_001.mjs features_frozen.json route_output`. This process receives no label-file path and freezes serializer signatures and predictions. Second, and only after the first process exits and its output is hashed: `$CODEX_PRIMARY_RUNTIME_NODE score_x_ls_001.mjs route_output labels_frozen.json features_frozen.json validation_report.json run_output`. The scripts use lexicographically key-sorted canonical JSON, represent omitted ablation fields by deletion rather than `null`, and preserve complete collision membership. A failed validator aborts before routing and is preserved as an invalid development run.

The fixed attacks are: reverse record order; SHA-256 input-hash order; all six permutations of the three surface-reference assignments; identifier exclusion from both signatures; and prose exclusion by schema. No random seed or discretionary transform selection is used.

`source_manifest.json` will bind every logical input title to absolute source path, byte size, SHA-256 digest, provenance role, and frozen copy where applicable. `run_manifest.json` will bind UTC start/end, working directory, runtime versions, both exact commands, phase order, route-output pre-score digest, exit states, stdout/stderr paths, input/output hashes, and deviations. `package_audit.json` will enumerate all required package members and must report complete before `K4` may be marked achieved.

Documentation establishes reproducibility readiness only. An independent rerun would be required to claim replication.

## 9. Relation ledger

| Relation | Current statement | Status | Consequence if changed |
| --- | --- | --- | --- |
| `Q → C1/C2` | Question concerns label distinguishability under two exact serializers, not action correctness or expressive power of unrestricted prose. | Fixed | Broadening would overclaim current-language insufficiency. |
| `C1/C2 → L0/L1` | Sufficiency is operationalized by collision counts under exact serializers. | Proposed | A different serializer changes the tested language. |
| `I + B → K1/K2` | `L1` is compared with `L0` on the same frozen cases. | Fixed | Different cases destroy the paired contrast. |
| `M → E` | Deterministic script emits raw signatures, collisions, predictions, attacks, and hashes. | Proposed | Missing raw output prevents audit. |
| `E → K1` | Baseline collisions support only label insufficiency of the constructed `L0` on this panel. | Fixed | Cannot imply the complete MoonShot record or natural language is insufficient. |
| `E → K2` | Zero candidate collisions plus router conformance supports only exact-panel collision freedom and table conformance. | Fixed | Cannot establish action correctness or open-world classification. |
| `E → K3` | Leave-one-field-out collisions support local syntactic necessity within constructed pairs. | Fixed | Cannot establish semantic necessity, architectural necessity, or global minimality. |
| `K → D` | Pass retains the representation as a locally irredundant development preflight candidate and forces a weaker-recoding comparison. | Fixed | No canonical activation, action validation, or ontology ratification follows. |

## 10. Claims licensed by a pass

- `K1`: the constructed `L0` is label-insufficient on the exact 54-record panel (`EXHAUSTIVE_FINITE`).
- `K2`: `L1` is collision-free and the frozen router is table-conformant on that exact panel (`EXHAUSTIVE_FINITE`).
- `K3`: each candidate field is locally syntactically necessary for its assigned constructed pair under this serializer (`EXHAUSTIVE_FINITE`).
- `K4`: package completeness and reproducibility readiness may be reported only if the post-run completeness audit passes (`PROCEDURAL`).

Not licensed: insufficiency of the complete current MoonShot record or unrestricted language; correctness or necessity of the stipulated labels; semantic or architectural necessity of nine named fields; broader `ONTOLOGY_LEAKAGE` safety; real-world inference accuracy; causal performance improvement; D1–D4 completeness; formal topology; economic value; canonical adoption; or independent replication.

## 11. Known threats

- The cases, tokens, labels, and router are co-designed, so the result is a serializer/routing conformance demonstration, not unbiased confirmation or action validation.
- The nine fields may be redundant with unrestricted free text or derivable raw observations.
- Nine named fields may be recodable as one generic `probe_state` field; this design does not test that weaker alternative.
- Independent probes are a candidate test organization, not an earned universal architecture.
- `OUT_OF_PROBE_SCOPE` is an inert construction token and must not be read as absence.
- Surface-reference mutation tests reference-name invariance only, not domain transfer.

## 12. Stopping and deviations

Execute once after protocol review and byte freeze. Any protocol, panel, serializer, threshold, or router change after execution begins creates a new experiment identity. Preserve failed, invalid, and adverse outputs. Do not consume or claim confirmation material. If this run passes, the next experiment must compare the nine-field representation with weaker recodings before any minimality or retention claim.

Recorded execution incident: `X-LS-001-DEV-R1` is `EXECUTION_INVALID`. Its run wrapper changed working directory while passing relative frozen paths, so the validator process exited before producing a validation report; routing and scoring did not execute. The frozen package and invalid run are preserved under `frozen_v1/` and `run_v1/`. No scientific inference and no confirmation consumption are permitted from R1. Successor `X-LS-001-DEV-R2` changes only runner path normalization to absolute paths and receives a new frozen package identity.
