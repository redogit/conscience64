from pathlib import Path
import json, hashlib, sys
ROOT=Path(__file__).resolve().parent
m=json.loads((ROOT/"state/MANIFEST.json").read_text())
errs=[]
for r in m["records"]:
 p=ROOT/r["path"]
 if not p.exists(): errs.append(f"missing {r['path']}"); continue
 h=hashlib.sha256(p.read_bytes()).hexdigest()
 if h!=r["sha256"]: errs.append(f"hash mismatch {r['path']}")
required=["CURRENT.md","context/00_ORIENTATION.md","context/01_WORK.md","context/02_VERIFY.md","context/03_LIBRARY.md","history/CONVERSATION_REFLOW.md","engine/human_lab.py","engine/library_support.py"]
for x in required:
 if not (ROOT/x).exists(): errs.append(f"required missing {x}")
text=(ROOT/"context/03_LIBRARY.md").read_text()
for boundary in ["RELATED != SUPPORTS","retrieval != proof","PRESERVED != AVAILABLE != ACTIVE"]:
 if boundary.lower() not in text.lower(): errs.append(f"boundary missing: {boundary}")
print(json.dumps({"passed":not errs,"errors":errs,"manifest_files":len(m['records'])},indent=2))
sys.exit(1 if errs else 0)
