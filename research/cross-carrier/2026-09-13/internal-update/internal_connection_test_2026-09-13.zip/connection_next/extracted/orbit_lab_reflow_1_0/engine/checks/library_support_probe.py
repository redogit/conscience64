from __future__ import annotations
from library_support import static_summary, exact_reference_candidates, lexical_route_candidates, support_search_plan, DEFAULT_PRIVATE_NAMESPACES


def run():
    s=static_summary()
    # Exact known primary source route from the seeded association map.
    fourd=exact_reference_candidates("4d_codec_inversion_observer_conversation_archive.zip",include_unresolved=False)
    exact_ok=any(c.file_id=="file_00000000f62881f5adae58285be931d2" and c.status=="verified-reference" for c in fourd)
    nonupgrade=all(not c.can_self_certify_support for c in fourd)
    # A broad phrase may find routes, but these must remain related-only.
    near=lexical_route_candidates("composable knowledge carrier shared well",limit=8)
    ambiguity_ok=bool(near) and all(c.relation_kind=="RELATED_ONLY" and not c.can_self_certify_support for c in near)
    # An unresolved declared pointer must not become a resolved identity.
    unresolved=exact_reference_candidates("MOONSHOT_SHARED_WELL_ORIENTATION_v1.md",include_unresolved=True)
    unresolved_ok=any(c.status=="unresolved" and not c.file_id for c in unresolved)
    plan=support_search_plan("Parameter Differential Reflow recurrent context")
    privacy_ok=plan["private_namespaces_excluded"]==list(DEFAULT_PRIVATE_NAMESPACES) and not plan["automatic_private_access"]
    stage_order=[x["name"] for x in plan["stages"]]
    staged_ok=stage_order==["identity-and-declared-lineage","bounded-neighborhood-discovery","qualification","claim-bounded-return"]
    seed_ok=s["rows"]==633 and s["resolved_exact"]==124 and s["resolved_file_ids"]==77
    passed=all([seed_ok,exact_ok,nonupgrade,ambiguity_ok,unresolved_ok,privacy_ok,staged_ok,s["relation_index_source_present"]])
    return {
      "passed":passed,
      "observations":{
        "association_seed_counts_match":seed_ok,
        "exact_identity_route_preserved":exact_ok,
        "association_does_not_self_certify_support":nonupgrade,
        "semantic_or_lexical_neighborhood_remains_related_only":ambiguity_ok,
        "unresolved_pointer_not_substituted":unresolved_ok,
        "private_namespaces_excluded_by_default":privacy_ok,
        "progressive_search_sequence_preserved":staged_ok,
        "relation_index_source_present":s["relation_index_source_present"],
      },
      "kernel_schema_additions":0,
      "claim_ceiling":[
        "The support finder retrieves and routes candidate supporting items; it does not itself establish support.",
        "Association maps preserve lineage and source role but do not upgrade evidence sufficiency.",
        "Lexical/semantic neighborhood search is candidate discovery only.",
      ]
    }

if __name__=="__main__":
    import json; print(json.dumps(run(),indent=2,sort_keys=True))
