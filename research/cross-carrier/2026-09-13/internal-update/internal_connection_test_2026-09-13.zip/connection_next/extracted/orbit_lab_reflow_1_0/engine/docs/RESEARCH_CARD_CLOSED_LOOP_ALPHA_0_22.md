# Orbit Lab Alpha 0.22 — Research Card Closed Loop

Alpha 0.22 tests the simple six-field Research Card on a real unresolved MoonShot provenance question.

Question:
Where are the primary code/results for the Python-library mutation/staleness attack?

The bounded Library search recovered only recovery/index references. The source
association map classifies the relevant filesystem benchmark records as
`CONVERSATION_ONLY_SOURCE` and gives no primary Library file id/path.

The correct end state is therefore:

- Saw: no primary artifact was located in the searched Library routes.
- Left: whether the attack was executed and what happened remains unresolved.

A bounded claim about the search result is supportable.
A stronger claim that the experiment never happened is blocked.

This earns the relation:

`not found in bounded search != universal nonexistence`.

The Human Lab now includes `--demo-unresolved` to demonstrate this workflow without
showing kernel plumbing.

No new kernel object or Episode type was added.
