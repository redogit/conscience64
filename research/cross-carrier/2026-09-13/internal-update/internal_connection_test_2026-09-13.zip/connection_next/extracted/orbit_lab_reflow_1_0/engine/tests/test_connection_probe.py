import unittest
from checks.connection_probe import run
class ConnectionProbeTests(unittest.TestCase):
    def test_joint_probe(self):
        r=run(); self.assertTrue(r['passed'],r); self.assertEqual(r['kernel_schema_changes'],0)
        self.assertTrue(all(not x['merge_performed'] for x in r['joints'].values()))
if __name__=='__main__': unittest.main()
