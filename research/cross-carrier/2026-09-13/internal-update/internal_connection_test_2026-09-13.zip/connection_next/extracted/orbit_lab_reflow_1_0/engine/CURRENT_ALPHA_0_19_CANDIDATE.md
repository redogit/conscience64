# Orbit Lab Alpha 0.19 candidate

Executes X-LS-002 and reduces the bounded language representation from nine named state fields to one generic probe_state relation.
