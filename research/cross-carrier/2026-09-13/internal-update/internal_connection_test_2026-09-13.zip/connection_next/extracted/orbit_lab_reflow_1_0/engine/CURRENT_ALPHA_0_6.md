# Orbit Lab — Current

**Current executable checkpoint:** Alpha 0.6 — Connected Research Candidate

Start with `Current/START_HERE_ALPHA_0_6.md`.

Current shape:

```text
Human surface
  -> Research Card + compare + incoming/why
Selector
  -> weakest adequate verification/support path
Kernel
  -> evidence/history/context/authority/persistence
Connected research
  -> quarantined branch map; non-evidentiary associations only
Recoverable history
  -> prior alpha checkpoints and historical stress
```

Current verified gate:
- 11/11 components pass;
- 41/41 declared obligations resolve;
- 113 regression/invariant tests pass;
- 14 recovered branches remain quarantined;
- 32 candidate source/component associations are non-evidentiary;
- no kernel schema type was added to connect the new research.

Alpha 0.5 is preserved under `History/Alpha 0.5` as the pre-connection human-interface checkpoint.

Incoming Library material remains quarantined until a branch-specific test earns admission/applicability.
