from pathlib import Path
import json, tempfile, sys

BASE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(BASE))
from orbit_lab import OrbitLab
from human_lab import HumanLab


def raw_path(db):
    lab=OrbitLab(db)
    try:
        subject=lab.add("Subject","Does the interface preserve semantics?",
                        provenance_class="CURRENT_CONVERSATION",provenance="probe")
        lab.pin("subject",subject)
        observation=lab.add("Observation","Observed A",
                            epistemic="OBSERVED",
                            provenance_class="CURRENT_CONVERSATION",provenance="probe")
        lab.pin("observation",observation)
        inference=lab.add("Inference","A may imply B",
                          epistemic="PROPOSED",
                          provenance_class="CURRENT_CONVERSATION",provenance="probe")
        lab.relate(inference,"ABOUT",subject,
                   provenance_class="DERIVED",provenance="probe")
        return {
            "subject":lab.get(subject).type,
            "observation":lab.get(observation).epistemic,
            "inference":lab.get(inference).type,
        }
    finally: lab.close()


def human_path(db):
    h=HumanLab(db)
    try:
        h.start("Does the interface preserve semantics?")
        h.add("saw","Observed A")
        h.think("A may imply B")
        scan=h.lab.scan()
        inf=h.lab.library(type="Inference")[0]
        return {
            "subject":scan["subject"][0]["type"],
            "observation":scan["observation"][0]["epistemic"],
            "inference":inf["type"],
            "card":h.card(),
            "subject_id":scan["subject"][0]["id"],
        }
    finally: h.close()


def main():
    with tempfile.TemporaryDirectory() as td:
        td=Path(td)
        raw=raw_path(td/"raw.db")
        human=human_path(td/"human.db")
        semantics={k:human[k] for k in ("subject","observation","inference")}
        same=raw==semantics
        # Fixed three-action comparison: start question, record observation, record interpretation.
        proxy={
            "raw_kernel":{
                "user_visible_operations":6,
                "raw_ids_carried_between_operations":4,
                "kernel_terms_required":["Subject","subject slot","Observation","OBSERVED","observation slot","Inference","PROPOSED","ABOUT","provenance class"],
            },
            "human_surface":{
                "user_visible_operations":3,
                "raw_ids_carried_between_operations":0,
                "kernel_terms_required":[],
                "task_words":["start","saw","think"],
            }
        }
        out={
            "probe":"human-interface structural exposure",
            "passed":same and human["subject_id"] not in human["card"],
            "semantic_equivalence_on_tested_actions":same,
            "raw_id_hidden_from_default_card":human["subject_id"] not in human["card"],
            "surface_burden_proxy":proxy,
            "claim_ceiling":"This shows lower structural exposure for three tested actions while preserving their stored kernel semantics. It does not establish lower cognitive load, fewer human errors, better learnability, or general usability.",
        }
        print(json.dumps(out,indent=2,sort_keys=True))
        if not out["passed"]: raise SystemExit(1)

if __name__=="__main__": main()
