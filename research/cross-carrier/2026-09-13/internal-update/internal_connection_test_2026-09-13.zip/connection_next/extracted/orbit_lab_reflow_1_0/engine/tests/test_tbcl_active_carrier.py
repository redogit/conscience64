
import unittest
from checks.tbcl_active_carrier_probe import run

class TBCLActiveCarrierTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.r=run()

    def test_compact_carrier_preserves_actions_and_reconstruction(self):
        self.assertTrue(self.r["full_vs_compact_exact"])
        self.assertTrue(self.r["preserved_source_retained"])

    def test_active_footprint_reduces(self):
        f=self.r["active_footprint"]
        self.assertLess(f["compact_active_bytes"],f["verbose_active_bytes"])
        self.assertGreater(f["active_reduction_ratio"],2.0)

    def test_harmless_recoding_is_invariant(self):
        self.assertTrue(self.r["harmless_reorder_invariant"])
        self.assertTrue(self.r["raw_vs_zlib_encoding_invariant"])

    def test_consequential_ablations_fail(self):
        self.assertTrue(all(self.r["attacks"].values()))

    def test_no_global_minimality_or_schema_growth(self):
        self.assertFalse(self.r["global_minimality_claimed"])
        self.assertEqual(self.r["kernel_schema_additions"],0)

if __name__=="__main__":
    unittest.main()
