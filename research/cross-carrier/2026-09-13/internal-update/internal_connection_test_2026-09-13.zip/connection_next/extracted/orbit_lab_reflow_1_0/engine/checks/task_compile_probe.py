from __future__ import annotations
from pathlib import Path
import json, py_compile, tempfile

ROOT=Path(__file__).resolve().parents[1]
FILES=[
    ROOT/'orbit_lab.py', ROOT/'selector.py', ROOT/'human_lab.py',
    ROOT/'verification_carrier.py', ROOT/'verify_task.py',
]

def run():
    failures=[]
    with tempfile.TemporaryDirectory() as td:
        for p in FILES:
            try:
                py_compile.compile(str(p), cfile=str(Path(td)/(p.name+'.pyc')), doraise=True)
            except Exception as exc:
                failures.append({'file':p.name,'error':str(exc)})
    return {
        'passed':not failures,
        'compiled_files':[p.name for p in FILES],
        'failures':failures,
    }

if __name__=='__main__': print(json.dumps(run(),indent=2,sort_keys=True))
