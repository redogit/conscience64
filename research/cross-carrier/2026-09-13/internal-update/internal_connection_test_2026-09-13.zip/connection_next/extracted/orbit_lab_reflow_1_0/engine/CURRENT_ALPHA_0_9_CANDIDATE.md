# Orbit Lab Alpha 0.9 candidate

Adds obligation-qualified transfer preservation and audit support. No new kernel object or Episode type.
