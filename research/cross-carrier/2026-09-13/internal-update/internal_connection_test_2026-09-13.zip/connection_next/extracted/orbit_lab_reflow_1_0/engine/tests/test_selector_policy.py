import itertools, unittest
from selector import SELECTOR_PREORDER, COMPONENTS, POTENTIAL
from supporters.catalog import HELPERS, PROFILES, route_profile

class SelectorPolicyTests(unittest.TestCase):
    def test_selector_preorder(self):
        self.assertEqual(SELECTOR_PREORDER,("S0","S1","S2","S3","S4","S5"))
    def test_every_component_obligation_has_selector(self):
        potential=set().union(*POTENTIAL.values())
        for c in COMPONENTS:
            self.assertFalse(set(c.obligations)-potential,c.name)
    def test_router_is_exact_minimum_cost_on_all_profiles(self):
        for name,p in PROFILES.items():
            routed=route_profile(name); req=set(p['required']); best=None
            for r in range(len(HELPERS)+1):
                for combo in itertools.combinations(HELPERS,r):
                    cov=set().union(*(h.capabilities for h in combo)) if combo else set()
                    if req <= cov:
                        cost=sum(h.cost for h in combo)
                        best=cost if best is None else min(best,cost)
                if best is not None and best<=r: break
            self.assertEqual(routed['total_cost'],best,name)
            self.assertEqual(routed['selection_method'],'exact_minimum_cost_cover')

if __name__=='__main__': unittest.main()
