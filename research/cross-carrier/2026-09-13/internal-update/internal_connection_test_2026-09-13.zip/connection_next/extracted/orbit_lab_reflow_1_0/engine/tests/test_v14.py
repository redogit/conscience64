
import tempfile
from pathlib import Path
import unittest
from orbit_lab import OrbitLab
class V14Tests(unittest.TestCase):
    def setUp(self): self.tmp=tempfile.TemporaryDirectory(); self.lab=OrbitLab(Path(self.tmp.name)/"t.db")
    def tearDown(self): self.lab.close(); self.tmp.cleanup()
    def add(self,t,title,key,**kw): return self.lab.add(t,title,provenance_class="TEST",provenance="test",identity_key=key,**kw)
    def test_candidate_data_does_not_drive_comparison(self):
        order=self.add("Order","x","ord",data={"metrics":[{"name":"x","direction":"MIN"}]})
        a=self.add("Candidate","a","a",data={"x":0}); b=self.add("Candidate","b","b",data={"x":100})
        e=self.add("Evidence","basis","e",epistemic="OBSERVED")
        ma=self.lab.record_measurement(candidate_id=a,metric="x",value=2,unit="",basis_entity_id=e,provenance_class="TEST",provenance="test")
        mb=self.lab.record_measurement(candidate_id=b,metric="x",value=1,unit="",basis_entity_id=e,provenance_class="TEST",provenance="test")
        ep=self.lab.compare_candidates(order_id=order,candidate_ids=[a,b],measurement_episode_ids=[ma,mb],provenance_class="TEST",provenance="test")
        rid=[p["participant_id"] for p in self.lab.episode(ep)["participants"] if p["role"]=="result"][0]
        self.assertEqual(self.lab.get(rid).data["chosen"],b)
if __name__=="__main__": unittest.main()
