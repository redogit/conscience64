from __future__ import annotations
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Callable
import json, subprocess, sys, time, tempfile

from orbit_lab import OrbitLab
from supporters.adversary import OrbitalGAN
from supporters.ecology import SupporterEcology
from supporters.catalog import PROFILES, route_profile
from connections import ConnectionMap
from checks.connection_probe import run as run_connection_probe
from checks.human_pair_record_probe import run as run_human_pair_probe
from checks.hodge_justification_probe import run as run_hodge_justification_probe
from checks.language_surface_transfer_probe import run as run_language_surface_transfer_probe
from checks.bgzf_carrier_probe import run as run_bgzf_carrier_probe
from checks.bridge_obligation_probe import run as run_bridge_obligation_probe
from checks.fractal_representation_probe import run as run_fractal_representation_probe
from checks.source_execution_lineage_probe import run as run_source_execution_lineage_probe
from checks.generator_identity_boundary_probe import run as run_generator_identity_boundary_probe
from checks.shadow_evidence_integrity_probe import run as run_shadow_evidence_integrity_probe
from checks.tbcl_active_carrier_probe import run as run_tbcl_active_carrier_probe
from checks.retrieval_neighborhood_probe import run as run_retrieval_neighborhood_probe
from checks.operator_primary_route_probe import run as run_operator_primary_route_probe
from checks.philosophy_source_role_probe import run as run_philosophy_source_role_probe
from checks.x_ls_002_weaker_recode_probe import run as run_x_ls_002_weaker_recode_probe
from checks.gr_qm_tidal_phase_probe import run as run_gr_qm_tidal_phase_probe
from checks.method_authority_probe import run as run_method_authority_probe
from checks.research_card_negative_retrieval_probe import run as run_research_card_negative_retrieval_probe
from checks.penny_monthly_attention_probe import run as run_penny_monthly_attention_probe
from checks.gdsn_work_helper_probe import run as run_gdsn_work_helper_probe
from checks.library_fold_stage1_probe import run as run_library_fold_stage1_probe
from checks.library_fold_remaining_probe import run as run_library_fold_remaining_probe
from checks.library_support_probe import run as run_library_support_probe
from checks.tbcl_active_carrier_counterprobe import run as run_tbcl_active_carrier_counterprobe
from checks.task_compile_probe import run as run_task_compile_probe
from checks.human_interface_core_probe import run as run_human_interface_core_probe
from checks.self_verification_probe import run as run_self_verification_probe

BASE=Path(__file__).resolve().parent
SELECTOR_PREORDER=("S0","S1","S2","S3","S4","S5")

@dataclass(frozen=True)
class Component:
    name: str
    obligations: frozenset[str]

# This is the whole active contract. Historical scripts are passive evidence, not components.
COMPONENTS=[
    Component("kernel",frozenset({"compile","regression","authority","schema","history","scope","state","epistemic","lineage"})),
    Component("research-loader",frozenset({"research-load","historical-status"})),
    Component("historical-lineage",frozenset({"historical-classification","no-unexplained-historical-failure"})),
    Component("adversarial-supporter",frozenset({"random-composition","no-novel-counterexample","no-harness-error"})),
    Component("supporter-ecology",frozenset({"mechanism-diversity","no-supporter-finding","retain-pressure"})),
    Component("supporter-selection",frozenset({"applicability-routing","minimum-cost-cover","no-false-independence","profile-coverage"})),
    Component("bounded-reference",frozenset({"bounded-exact","metamorphic"})),
    Component("persistence",frozenset({"roundtrip","tamper-reject","audit"})),
    Component("human-interface",frozenset({"human-card","observation-inference-separation","comparison-interpretation-separation","no-raw-id-default","progressive-disclosure","recoverable-current","connected-human-view"})),
    Component("human-surface-guard",frozenset({"epistemic-surface-warning","workbench-transfer-bounded"})),
    Component("theorem-justification",frozenset({"claim-dependency-containment","theorem-application-separation"})),
    Component("carrier-evidence-qualification",frozenset({"exact-vs-learned-separation","weak-label-not-ground-truth","resource-accounting-scope"})),
    Component("obligation-preserving-transfer",frozenset({"bridge-obligation-qualification","insufficient-transfer-evidence-unresolved","transfer-authority-separation"})),
    Component("representation-frame-discipline",frozenset({"designed-inverse-vs-generic-inference","simulation-not-physical","implementation-not-measurement","bookkeeping-not-capacity"})),
    Component("source-execution-lineage",frozenset({"static-source-not-runtime-evidence","failure-repair-lineage","variant-identity-preserved"})),
    Component("generator-identity-boundary",frozenset({"address-not-generator-identity","generator-extra-state-visible","runtime-boundary-preserved"})),
    Component("campaign-evidence-integrity",frozenset({"declared-denominator-linked","unknown-observation-preserved","same-label-identity-separated","post-support-evidence-drift-detected"})),
    Component("tbcl-active-carrier",frozenset({"compact-action-equivalence","harmless-recoding-invariance","consequential-ablation-detected","provenance-recoverable-after-compression"})),
    Component("retrieval-neighborhood",frozenset({"narrow-equals-broad","project-source-role-preserved","widen-on-missing-source","provenance-recoverable-on-retrieval"})),
    Component("primary-evidence-route",frozenset({"map-to-primary-route","locator-not-primary-evidence","primary-source-identity-recoverable","bounded-consensus-grounding-counterexample"})),
    Component("philosophy-source-role",frozenset({"philosophy-not-empirical-evidence","philosophy-may-motivate-question","claim-local-source-role","source-role-audit"})),
    Component("language-weaker-recoding",frozenset({"weaker-recode-partition-equivalence","weaker-recode-route-equivalence","cross-probe-composition-no-alias","language-schema-cost-reduced"})),
    Component("gr-qm-tidal-bridge",frozenset({"affine-gravity-ablation","recoil-tidal-formula","curvature-transport-convention","structural-empirical-witness-separation","quantum-gravity-nonupgrade","source-output-lineage-preserved"})),
    Component("method-authority-boundary",frozenset({"method-relevance-not-authority","current-method-compliance-required","method-drift-audited","method-custody-recoverable"})),
    Component("research-card-negative-retrieval",frozenset({"card-to-bounded-search","negative-search-not-nonexistence","unresolved-remainder-preserved","negative-retrieval-custody"})),
    Component("low-attention-penny-pilot",frozenset({"monthly-only-replay","preexisting-risk-brake-enforced","withdrawal-not-principal-protection","exposure-reduction-bounded","posthoc-boundary-not-promoted","stress-panel-source-boundary"})),
    Component("gdsn-work-helper",frozenset({"gdsn-task-local-vocabulary","gdsn-status-boundary","gdsn-rfcin-subscription-boundary","gdsn-local-implementation-boundary","gdsn-work-privacy-boundary"})),
    Component("library-fold-stage1",frozenset({"incoming-stage-classified","historical-method-not-current","candidate-import-boundary","source-custody-to-history","remaining-library-staged"})),
    Component("library-fold-remaining",frozenset({"project-delta-only","bounded-negative-imported","pdr-candidate-boundary","shadow-campaign-boundary","source-roots-preserved","privacy-stage-reserved","loose-root-progressive-retrieval"})),
    Component("library-support-retrieval",frozenset({"support-exact-identity-first","support-association-not-evidence","support-ambiguity-preserved","support-unresolved-not-substituted","support-provenance-scope-preserved","support-private-default-exclusion","support-progressive-widening"})),
    Component("task-verification-carrier",frozenset({"task-carrier-integrity","task-release-separation","task-plan-exact-cover","task-uncovered-refuses-pass"})),
    Component("research-connections",frozenset({"connection-map","quarantine-preserved","non-evidentiary-bridges","source-boundaries","cross-branch-no-merge"})),
    Component("whole",frozenset({"whole-integration"})),
]

@dataclass
class ProbeResult:
    name: str
    selector: str
    passed: bool
    resolves: set[str]
    seconds: float
    detail: dict

class ProbeCache:
    def __init__(self): self.results: dict[str,ProbeResult]={}
    def run(self,name: str,fn: Callable[[],ProbeResult]) -> ProbeResult:
        if name not in self.results:
            self.results[name]=fn()
        return self.results[name]

CACHE=ProbeCache()

def cmd(args,timeout=180,cwd=None):
    t=time.time()
    p=subprocess.run(args,cwd=cwd or BASE,text=True,capture_output=True,timeout=timeout)
    return p,round(time.time()-t,3)

def probe_s0_compile_tests():
    t=time.time()
    compile_p=subprocess.run([sys.executable,"-m","compileall","-q","orbit_lab.py","selector.py","connections.py","supporters","checks","seed_research.py"],cwd=BASE,text=True,capture_output=True,timeout=60)
    tests_p=subprocess.run([sys.executable,"-m","unittest","discover","-s","tests","-q"],cwd=BASE,text=True,capture_output=True,timeout=150)
    passed=compile_p.returncode==0 and tests_p.returncode==0
    import re
    m=re.search(r"Ran (\d+) tests",tests_p.stderr+tests_p.stdout)
    count=int(m.group(1)) if m else None
    resolves={"compile","regression","authority","schema","history","scope","state","epistemic","lineage","human-card","observation-inference-separation","no-raw-id-default","progressive-disclosure","recoverable-current","connected-human-view","epistemic-surface-warning","workbench-transfer-bounded"} if passed else set()
    return ProbeResult("compile+regression","S0",passed,resolves,round(time.time()-t,3),{
        "tests":count,"compile_rc":compile_p.returncode,"test_rc":tests_p.returncode,
        "tail":(tests_p.stderr+tests_p.stdout)[-1200:]})

def probe_s1_loader():
    t=time.time()
    with tempfile.TemporaryDirectory() as td:
        p=subprocess.run([sys.executable,str(BASE/'seed_research.py')],cwd=td,text=True,capture_output=True,timeout=60,
                         env={**__import__('os').environ,'PYTHONPATH':str(BASE)})
    return ProbeResult("research-loader","S1",p.returncode==0,
        {"research-load","historical-status"} if p.returncode==0 else set(),round(time.time()-t,3),
        {"rc":p.returncode,"tail":(p.stdout+p.stderr)[-1600:]})

def probe_s1_historical():
    p,secs=cmd([sys.executable,"archive/historical_stress/audit.py"],180)
    detail={"rc":p.returncode,"tail":(p.stdout+p.stderr)[-2000:]}
    try:
        obj=json.loads(p.stdout)
        detail.update({k:obj.get(k) for k in ["historical_total","historical_pass","historical_expected_stale","historical_unexpected_failures","active_loaders"]})
    except Exception: pass
    return ProbeResult("historical-lineage-audit","S1",p.returncode==0,
        {"historical-classification","no-unexplained-historical-failure"} if p.returncode==0 else set(),secs,detail)

def _state_gate():
    with tempfile.TemporaryDirectory() as td:
        td=Path(td); lab=OrbitLab(td/'a.db')
        subject=lab.add("Subject","Can the kernel safely learn one new distinction?",provenance_class="TEST",provenance="selector",identity_key="subject")
        obligation=lab.add("Obligation","Preserve evidence/authority/history separation",provenance_class="TEST",provenance="selector",identity_key="obligation")
        lab.pin("subject",subject); lab.pin("obligation",obligation)
        ctx=lab.add("Context","Schema context",provenance_class="TEST",provenance="selector",identity_key="ctx")
        actor=lab.add("Actor","Operator",provenance_class="TEST",provenance="selector",identity_key="actor")
        scope=lab.add("Scope","Schema",provenance_class="TEST",provenance="selector",identity_key="scope")
        frame=lab.add("ValidityFrame","Frame",data={"conditions":{"selector":"S1"}},provenance_class="TEST",provenance="selector",identity_key="frame")
        witness=lab.add("Evidence","Controlled collision witness",epistemic="OBSERVED",provenance_class="TEST",provenance="selector",identity_key="w")
        gap=lab.record_schema_gap(gap_kind="LANGUAGE_COLLISION",current_term="Obligation",missing_distinction="pre-obligation pressure",provenance_class="TEST",provenance="selector")
        proposal=lab.propose_schema_object_type(gap_id=gap,type_name="SelectorPressure",definition="Observed pressure before an obligation is earned.",provenance_class="TEST",provenance="selector",identity_key="proposal")
        promotion=lab.record_promotion(context_id=ctx,entity_id=proposal,scope_id=scope,validity_frame_id=frame,witness_entity_id=witness,basis_entity_ids=[witness],change_claim="distinction earned",revalidation_rule="rerun collision",provenance_class="TEST",provenance="selector")
        root=lab.establish_authority_root(context_id=ctx,scope_id=scope,operations=["SCHEMA_CHANGE"],holder_actor_id=actor,provenance_class="USER",provenance="selector-user",identity_key="root")
        lab.grant_authorization(context_id=ctx,entity_id=proposal,operation="SCHEMA_CHANGE",scope_id=scope,issuer_authority_id=root,issuer_actor_id=actor,principal_id=actor,basis_entity_ids=[witness,promotion],reason="earned repair",provenance_class="TEST",provenance="selector")
        lab.apply_schema_object_type(proposal_id=proposal,promotion_episode_id=promotion,context_id=ctx,actor_id=actor,scope_id=scope,reason="apply",provenance_class="TEST",provenance="selector")
        instance=lab.add("SelectorPressure","pressure instance",provenance_class="TEST",provenance="selector",identity_key="pressure")
        before=lab.alpha_audit(); exp=lab.export_state(td/'state.json'); lab.close()
        # Tamper copy must fail.
        tampered=td/'tampered.json'; text=(td/'state.json').read_text(); tampered.write_text(text.replace('pressure instance','tampered instance',1))
        bad=OrbitLab(td/'bad.db'); tamper_rejected=False
        try: bad.import_state(tampered)
        except ValueError: tamper_rejected=True
        finally: bad.close()
        restored=OrbitLab(td/'b.db'); restored.import_state(td/'state.json'); after=restored.alpha_audit()
        same=restored.state_snapshot()['sha256']==exp['sha256']==before['state_sha256']==after['state_sha256']
        learned=restored.get(instance).type=='SelectorPressure'; restored.close()
        return {"passed":before['passed'] and after['passed'] and same and learned and tamper_rejected,
                "roundtrip":same,"learned_schema":learned,"tamper_rejected":tamper_rejected,"digest":exp['sha256']}

def probe_s1_state():
    t=time.time(); r=_state_gate()
    return ProbeResult("state-recovery-gate","S1",r['passed'],{"roundtrip","tamper-reject","audit"} if r['passed'] else set(),round(time.time()-t,3),r)

def probe_s1_connections():
    t=time.time(); r=ConnectionMap().check(); passed=r['passed']
    resolves={"connection-map","quarantine-preserved","non-evidentiary-bridges","source-boundaries"} if passed else set()
    return ProbeResult("research-connection-ingress","S1",passed,resolves,round(time.time()-t,3),r)

def probe_s2_orbital():
    t=time.time(); r=OrbitalGAN(seed=1701).run(rounds=128)
    passed=r['novel_findings']==0 and len(r['harness_errors'])==0
    return ProbeResult("bounded-random-orbital","S2",passed,
        {"random-composition","no-novel-counterexample","no-harness-error"} if passed else set(),round(time.time()-t,3),
        {"trials":r['trials'],"novel_findings":r['novel_findings'],"harness_errors":len(r['harness_errors']),"signatures":[x['signature'] for x in r['findings']]})

def probe_s3_ecology():
    t=time.time(); r=SupporterEcology().run(); passed=r['findings']==0
    return ProbeResult("supporter-ecology","S3",passed,{"mechanism-diversity","no-supporter-finding","retain-pressure"} if passed else set(),round(time.time()-t,3),
        {"signals":len(r['signals']),"passes":r['passes'],"pressures":r['pressures'],"findings":r['findings'],"finding_signatures":[x['signature'] for x in r['signals'] if x['status']=='FINDING']})

def probe_s3_router():
    t=time.time(); routes={n:route_profile(n) for n in PROFILES}
    passed=all(not r['uncovered'] for r in routes.values()) and all(r['independent'] is False for r in routes.values()) and all(r.get('selection_method')=='exact_minimum_cost_cover' for r in routes.values())
    return ProbeResult("exact-supporter-selector","S3",passed,{"applicability-routing","minimum-cost-cover","no-false-independence","profile-coverage"} if passed else set(),round(time.time()-t,3),
        {"profiles":{n:{"uncovered":r['uncovered'],"cost":r['total_cost'],"mechanisms":r['mechanisms'],"method":r.get('selection_method'),"independent":r['independent']} for n,r in routes.items()}})

def probe_s4_bounded():
    t=time.time(); e=SupporterEcology(); a=e.bounded_scope_explorer(); b=e.metamorphic_navigation_supporter(); passed=a.status!='FINDING' and b.status!='FINDING'
    return ProbeResult("bounded-distinguishing-search","S4",passed,{"bounded-exact","metamorphic"} if passed else set(),round(time.time()-t,3),{"signals":[asdict(a),asdict(b)]})

def probe_s4_connections():
    t=time.time(); r=run_connection_probe(); passed=r['passed']
    return ProbeResult("cross-branch-connection-audit","S4",passed,{"cross-branch-no-merge"} if passed else set(),round(time.time()-t,3),r)

def probe_s4_human_pair():
    t=time.time(); r=run_human_pair_probe(); passed=r['passed']
    return ProbeResult("human-paired-observation-comparison","S4",passed,{"comparison-interpretation-separation"} if passed else set(),round(time.time()-t,3),r)

def probe_s4_hodge_justification():
    t=time.time(); r=run_hodge_justification_probe(); passed=r['passed']
    return ProbeResult("hodge-theorem-justification","S4",passed,{"claim-dependency-containment","theorem-application-separation"} if passed else set(),round(time.time()-t,3),r)

def probe_s4_language_transfer():
    t=time.time(); r=run_language_surface_transfer_probe(); passed=r['passed']
    return ProbeResult("language-workbench-surface-transfer","S4",passed,{"epistemic-surface-warning","workbench-transfer-bounded"} if passed else set(),round(time.time()-t,3),r)

def probe_s4_bgzf_carrier():
    t=time.time(); r=run_bgzf_carrier_probe(); passed=r['passed']
    resolves={"exact-vs-learned-separation","weak-label-not-ground-truth","resource-accounting-scope"} if passed else set()
    return ProbeResult("bgzf-carrier-evidence-qualification","S4",passed,resolves,round(time.time()-t,3),r)


def probe_s4_bridge_obligation():
    t=time.time(); r=run_bridge_obligation_probe(); passed=r["passed"]
    resolves={
        "bridge-obligation-qualification",
        "insufficient-transfer-evidence-unresolved",
        "transfer-authority-separation",
    } if passed else set()
    return ProbeResult(
        "obligation-preserving-transfer",
        "S4",passed,resolves,round(time.time()-t,3),r
    )


def probe_s4_fractal_representation():
    t=time.time(); r=run_fractal_representation_probe(); passed=r["passed"]
    resolves={
        "designed-inverse-vs-generic-inference",
        "simulation-not-physical",
        "implementation-not-measurement",
        "bookkeeping-not-capacity",
    } if passed else set()
    return ProbeResult("representation-frame-discipline","S4",passed,resolves,round(time.time()-t,3),r)


def probe_s4_source_execution_lineage():
    t=time.time(); r=run_source_execution_lineage_probe(); passed=r["passed"]
    resolves={
        "static-source-not-runtime-evidence",
        "failure-repair-lineage",
        "variant-identity-preserved",
    } if passed else set()
    return ProbeResult("source-execution-lineage","S4",passed,resolves,round(time.time()-t,3),r)


def probe_s4_generator_identity_boundary():
    t=time.time(); r=run_generator_identity_boundary_probe(); passed=r["passed"]
    resolves={
        "address-not-generator-identity",
        "generator-extra-state-visible",
        "runtime-boundary-preserved",
    } if passed else set()
    return ProbeResult("generator-identity-boundary","S4",passed,resolves,round(time.time()-t,3),r)


def probe_s4_shadow_evidence_integrity():
    t=time.time(); r=run_shadow_evidence_integrity_probe(); passed=r["passed"]
    resolves={
        "declared-denominator-linked",
        "unknown-observation-preserved",
        "same-label-identity-separated",
        "post-support-evidence-drift-detected",
    } if passed else set()
    return ProbeResult("campaign-evidence-integrity","S4",passed,resolves,round(time.time()-t,3),r)


def probe_s4_tbcl_active_carrier():
    t=time.time()
    r=run_tbcl_active_carrier_probe()
    counter=run_tbcl_active_carrier_counterprobe()
    r["orthogonal_counterprobe"]=counter
    passed=r["passed"] and counter["passed"]
    resolves={
        "compact-action-equivalence",
        "harmless-recoding-invariance",
        "consequential-ablation-detected",
        "provenance-recoverable-after-compression",
    } if passed else set()
    return ProbeResult("tbcl-active-carrier","S4",passed,resolves,round(time.time()-t,3),r)

def probe_task_compile():
    t=time.time(); r=run_task_compile_probe(); passed=r["passed"]
    return ProbeResult("task-compile-sentinel","S0",passed,{"compile"} if passed else set(),round(time.time()-t,3),r)

def probe_human_interface_core():
    t=time.time(); r=run_human_interface_core_probe(); passed=r["passed"]
    resolves={"human-card","observation-inference-separation","no-raw-id-default","progressive-disclosure","recoverable-current","connected-human-view"} if passed else set()
    return ProbeResult("human-interface-core","S0",passed,resolves,round(time.time()-t,3),r)

def probe_s4_self_verification_carrier():
    t=time.time(); r=run_self_verification_probe(); passed=r["passed"]
    resolves={"task-carrier-integrity","task-release-separation","task-plan-exact-cover","task-uncovered-refuses-pass"} if passed else set()
    return ProbeResult("task-verification-carrier","S4",passed,resolves,round(time.time()-t,3),r)


def probe_s4_retrieval_neighborhood():
    t=time.time(); r=run_retrieval_neighborhood_probe(); passed=r["passed"]
    resolves={
        "narrow-equals-broad",
        "project-source-role-preserved",
        "widen-on-missing-source",
        "provenance-recoverable-on-retrieval",
    } if passed else set()
    return ProbeResult("retrieval-neighborhood","S4",passed,resolves,round(time.time()-t,3),r)


def probe_s4_operator_primary_route():
    t=time.time(); r=run_operator_primary_route_probe(); passed=r["passed"]
    resolves={
        "map-to-primary-route",
        "locator-not-primary-evidence",
        "primary-source-identity-recoverable",
        "bounded-consensus-grounding-counterexample",
    } if passed else set()
    return ProbeResult("operator-primary-route","S4",passed,resolves,round(time.time()-t,3),r)


def probe_s4_philosophy_source_role():
    t=time.time(); r=run_philosophy_source_role_probe(); passed=r["passed"]
    resolves={
        "philosophy-not-empirical-evidence",
        "philosophy-may-motivate-question",
        "claim-local-source-role",
        "source-role-audit",
    } if passed else set()
    return ProbeResult("philosophy-source-role","S4",passed,resolves,round(time.time()-t,3),r)


def probe_s4_x_ls_002_weaker_recode():
    t=time.time(); r=run_x_ls_002_weaker_recode_probe(); passed=r["passed"]
    resolves={
        "weaker-recode-partition-equivalence",
        "weaker-recode-route-equivalence",
        "cross-probe-composition-no-alias",
        "language-schema-cost-reduced",
    } if passed else set()
    return ProbeResult("language-weaker-recoding","S4",passed,resolves,round(time.time()-t,3),r)


def probe_s4_gr_qm_tidal_phase():
    t=time.time(); r=run_gr_qm_tidal_phase_probe(); passed=r["passed"]
    resolves={
        "affine-gravity-ablation",
        "recoil-tidal-formula",
        "curvature-transport-convention",
        "structural-empirical-witness-separation",
        "quantum-gravity-nonupgrade",
        "source-output-lineage-preserved",
    } if passed else set()
    return ProbeResult("gr-qm-tidal-bridge","S4",passed,resolves,round(time.time()-t,3),r)

def probe_s4_method_authority():
    t=time.time(); r=run_method_authority_probe(); passed=r["passed"]
    resolves={
        "method-relevance-not-authority",
        "current-method-compliance-required",
        "method-drift-audited",
        "method-custody-recoverable",
    } if passed else set()
    return ProbeResult("method-authority-boundary","S4",passed,resolves,round(time.time()-t,3),r)


def probe_s4_research_card_negative_retrieval():
    t=time.time(); r=run_research_card_negative_retrieval_probe(); passed=r["passed"]
    resolves={
        "card-to-bounded-search",
        "negative-search-not-nonexistence",
        "unresolved-remainder-preserved",
        "negative-retrieval-custody",
    } if passed else set()
    return ProbeResult("research-card-negative-retrieval","S4",passed,resolves,round(time.time()-t,3),r)


def probe_s4_penny_monthly_attention():
    t=time.time(); r=run_penny_monthly_attention_probe(); passed=r["passed"]
    resolves={
        "monthly-only-replay",
        "preexisting-risk-brake-enforced",
        "withdrawal-not-principal-protection",
        "exposure-reduction-bounded",
        "posthoc-boundary-not-promoted",
        "stress-panel-source-boundary",
    } if passed else set()
    return ProbeResult("low-attention-penny-pilot","S4",passed,resolves,round(time.time()-t,3),r)

def probe_s4_gdsn_work_helper():
    t=time.time(); r=run_gdsn_work_helper_probe(); passed=r["passed"]
    resolves={
        "gdsn-task-local-vocabulary",
        "gdsn-status-boundary",
        "gdsn-rfcin-subscription-boundary",
        "gdsn-local-implementation-boundary",
        "gdsn-work-privacy-boundary",
    } if passed else set()
    return ProbeResult("gdsn-work-helper","S4",passed,resolves,round(time.time()-t,3),r)

def probe_s4_library_fold_stage1():
    t=time.time(); r=run_library_fold_stage1_probe(); passed=r["passed"]
    resolves={
        "incoming-stage-classified",
        "historical-method-not-current",
        "candidate-import-boundary",
        "source-custody-to-history",
        "remaining-library-staged",
    } if passed else set()
    return ProbeResult("library-fold-stage1","S4",passed,resolves,round(time.time()-t,3),r)

def probe_s4_library_fold_remaining():
    t=time.time(); r=run_library_fold_remaining_probe(); passed=r["passed"]
    resolves={
        "project-delta-only","bounded-negative-imported","pdr-candidate-boundary",
        "shadow-campaign-boundary","source-roots-preserved","privacy-stage-reserved",
        "loose-root-progressive-retrieval",
    } if passed else set()
    return ProbeResult("library-fold-remaining","S4",passed,resolves,round(time.time()-t,3),r)

def probe_s4_library_support():
    t=time.time(); r=run_library_support_probe(); passed=r["passed"]
    resolves={
        "support-exact-identity-first","support-association-not-evidence",
        "support-ambiguity-preserved","support-unresolved-not-substituted",
        "support-provenance-scope-preserved","support-private-default-exclusion",
        "support-progressive-widening",
    } if passed else set()
    return ProbeResult("library-support-retrieval","S4",passed,resolves,round(time.time()-t,3),r)

def probe_s5_whole():
    t=time.time()
    with tempfile.TemporaryDirectory() as td:
        td=Path(td); lab=OrbitLab(td/'whole.db')
        def add(t_,title,key,**kw): return lab.add(t_,title,provenance_class="TEST",provenance="selector-whole",identity_key=key,**kw)
        source=add("Context","Source","src"); dest=add("Context","Destination","dst"); actor=add("Actor","Operator","actor")
        schema_scope=add("Scope","Schema","schema"); cycle1=add("Scope","Cycle 1","c1"); cycle2=add("Scope","Cycle 2","c2")
        evidence=add("Evidence","Observed witness","ev",epistemic="OBSERVED"); frame=add("ValidityFrame","Whole frame","vf",data={"conditions":{"mode":"whole"}})
        gap=lab.record_schema_gap(gap_kind="LANGUAGE_COLLISION",current_term="Obligation",missing_distinction="pre-obligation pressure",provenance_class="TEST",provenance="selector-whole")
        proposal=lab.propose_schema_object_type(gap_id=gap,type_name="WholePressure",definition="Pressure earned in whole integration.",provenance_class="TEST",provenance="selector-whole")
        promotion=lab.record_promotion(context_id=dest,entity_id=proposal,scope_id=schema_scope,validity_frame_id=frame,witness_entity_id=evidence,basis_entity_ids=[evidence],change_claim="distinction required",revalidation_rule="rerun whole",provenance_class="TEST",provenance="selector-whole")
        root=lab.establish_authority_root(context_id=dest,scope_id=schema_scope,operations=["SCHEMA_CHANGE"],holder_actor_id=actor,provenance_class="USER",provenance="selector-user")
        lab.grant_authorization(context_id=dest,entity_id=proposal,operation="SCHEMA_CHANGE",scope_id=schema_scope,issuer_authority_id=root,issuer_actor_id=actor,principal_id=actor,basis_entity_ids=[evidence,promotion],reason="whole earned repair",provenance_class="TEST",provenance="selector-whole")
        lab.apply_schema_object_type(proposal_id=proposal,promotion_episode_id=promotion,context_id=dest,actor_id=actor,scope_id=schema_scope,reason="apply",provenance_class="TEST",provenance="selector-whole")
        pressure=add("WholePressure","Observed pressure","pressure")
        content=lab.register_content(algorithm="sha256",digest="0123456789abcdef",provenance_class="TEST",provenance="selector-whole")
        inst=lab.create_artifact_instance(content_id=content,title="Source artifact",provenance_class="TEST",provenance="selector-whole",identity_key="inst")
        occ=lab.record_instance_occurrence(instance_id=inst,context_id=source,locator="/source/a",mode="REGISTER",provenance_class="TEST",provenance="selector-whole",identity_key="occ")
        ob=add("Obligation","Preserve content","ob")
        copy=lab.custody_transfer(source_context_id=source,destination_context_id=dest,source_occurrence_id=occ,destination_locator="/dest/a",mode="COPY",obligation_ids=[ob],evidence_entity_ids=[evidence],actor_id=actor,reason="whole copy",provenance_class="TEST",provenance="selector-whole")
        assert copy['content_preserved'] and copy['source_instance_id']!=copy['destination_instance_id']
        lab.record_association(source_entity_id=pressure,target_entity_id=copy['destination_occurrence_id'],scope_id=schema_scope,relation="MENTIONS",resolution_status="LOGICAL_ARTIFACT_ID",provenance_class="TEST",provenance="selector-whole")
        truth=add("Artifact","Holdout truth","truth"); model=add("Candidate","Model","model")
        root1=lab.establish_authority_root(context_id=dest,scope_id=cycle1,operations=["INSPECT"],holder_actor_id=actor,provenance_class="USER",provenance="selector-user")
        root2=lab.establish_authority_root(context_id=dest,scope_id=cycle2,operations=["CLEAN_EVALUATE"],holder_actor_id=actor,provenance_class="USER",provenance="selector-user")
        lab.grant_authorization(context_id=dest,entity_id=truth,operation="INSPECT",scope_id=cycle1,issuer_authority_id=root1,issuer_actor_id=actor,principal_id=actor,basis_entity_ids=[evidence],reason="truth access",provenance_class="TEST",provenance="selector-whole")
        lab.grant_authorization(context_id=dest,entity_id=model,operation="CLEAN_EVALUATE",scope_id=cycle2,issuer_authority_id=root2,issuer_actor_id=actor,principal_id=actor,basis_entity_ids=[evidence],prerequisites={"forbid_exposure_tags":["CONFIRMATION_TRUTH"]},reason="later clean eval",provenance_class="TEST",provenance="selector-whole")
        lab.record_access(context_id=dest,actor_id=actor,entity_id=truth,operation="INSPECT",scope_id=cycle1,exposure_tags=["CONFIRMATION_TRUTH"],provenance_class="TEST",provenance="selector-whole")
        assert lab.check_authorized(context_id=dest,actor_id=actor,entity_id=model,operation="CLEAN_EVALUATE",scope_id=cycle2)['authorized']
        remainder=add("Remainder","Unexplained residual","rem",epistemic="UNEXPLAINED")
        before=lab.alpha_audit(); assert before['passed']; exp=lab.export_state(td/'state.json'); digest=exp['sha256']; lab.close()
        restored=OrbitLab(td/'restored.db'); restored.import_state(td/'state.json'); after=restored.alpha_audit()
        assert after['passed'] and restored.state_snapshot()['sha256']==digest
        assert restored.get(pressure).type=='WholePressure' and restored.get(remainder).epistemic=='UNEXPLAINED'; restored.close()
    return ProbeResult("integrated-whole","S5",True,{"whole-integration"},round(time.time()-t,3),{"checks":["schema","authority","custody","association","exposure","residual","audit","roundtrip"]})

PROBES={
    "S0":[probe_s0_compile_tests],
    "S1":[probe_s1_loader,probe_s1_historical,probe_s1_state,probe_s1_connections],
    "S2":[probe_s2_orbital],
    "S3":[probe_s3_ecology,probe_s3_router],
    "S4":[probe_s4_bounded,probe_s4_connections,probe_s4_human_pair,probe_s4_hodge_justification,probe_s4_language_transfer,probe_s4_bgzf_carrier,probe_s4_bridge_obligation,probe_s4_fractal_representation,probe_s4_source_execution_lineage,probe_s4_generator_identity_boundary,probe_s4_shadow_evidence_integrity,probe_s4_tbcl_active_carrier,probe_s4_self_verification_carrier,probe_s4_retrieval_neighborhood,probe_s4_operator_primary_route,probe_s4_philosophy_source_role,probe_s4_x_ls_002_weaker_recode,probe_s4_gr_qm_tidal_phase,probe_s4_method_authority,probe_s4_research_card_negative_retrieval,probe_s4_penny_monthly_attention,probe_s4_gdsn_work_helper,probe_s4_library_fold_stage1,probe_s4_library_fold_remaining,probe_s4_library_support],
    "S5":[probe_s5_whole],
}
POTENTIAL={
    "S0":{"compile","regression","authority","schema","history","scope","state","epistemic","lineage","human-card","observation-inference-separation","no-raw-id-default","progressive-disclosure","recoverable-current","connected-human-view","epistemic-surface-warning","workbench-transfer-bounded"},
    "S1":{"research-load","historical-status","historical-classification","no-unexplained-historical-failure","roundtrip","tamper-reject","audit","connection-map","quarantine-preserved","non-evidentiary-bridges","source-boundaries"},
    "S2":{"random-composition","no-novel-counterexample","no-harness-error"},
    "S3":{"mechanism-diversity","no-supporter-finding","retain-pressure","applicability-routing","minimum-cost-cover","no-false-independence","profile-coverage"},
    "S4":{"bounded-exact","metamorphic","cross-branch-no-merge","comparison-interpretation-separation","claim-dependency-containment","theorem-application-separation","epistemic-surface-warning","workbench-transfer-bounded","exact-vs-learned-separation","weak-label-not-ground-truth","resource-accounting-scope","bridge-obligation-qualification","insufficient-transfer-evidence-unresolved","transfer-authority-separation","designed-inverse-vs-generic-inference","simulation-not-physical","implementation-not-measurement","bookkeeping-not-capacity","static-source-not-runtime-evidence","failure-repair-lineage","variant-identity-preserved","address-not-generator-identity","generator-extra-state-visible","runtime-boundary-preserved","declared-denominator-linked","unknown-observation-preserved","same-label-identity-separated","post-support-evidence-drift-detected","compact-action-equivalence","harmless-recoding-invariance","consequential-ablation-detected","provenance-recoverable-after-compression","task-carrier-integrity","task-release-separation","task-plan-exact-cover","task-uncovered-refuses-pass","narrow-equals-broad","project-source-role-preserved","widen-on-missing-source","provenance-recoverable-on-retrieval","map-to-primary-route","locator-not-primary-evidence","primary-source-identity-recoverable","bounded-consensus-grounding-counterexample","philosophy-not-empirical-evidence","philosophy-may-motivate-question","claim-local-source-role","source-role-audit","weaker-recode-partition-equivalence","weaker-recode-route-equivalence","cross-probe-composition-no-alias","language-schema-cost-reduced","affine-gravity-ablation","recoil-tidal-formula","curvature-transport-convention","structural-empirical-witness-separation","quantum-gravity-nonupgrade","source-output-lineage-preserved","method-relevance-not-authority","current-method-compliance-required","method-drift-audited","method-custody-recoverable","card-to-bounded-search","negative-search-not-nonexistence","unresolved-remainder-preserved","negative-retrieval-custody","monthly-only-replay","preexisting-risk-brake-enforced","withdrawal-not-principal-protection","exposure-reduction-bounded","posthoc-boundary-not-promoted","stress-panel-source-boundary","gdsn-task-local-vocabulary","gdsn-status-boundary","gdsn-rfcin-subscription-boundary","gdsn-local-implementation-boundary","gdsn-work-privacy-boundary","incoming-stage-classified","historical-method-not-current","candidate-import-boundary","source-custody-to-history","remaining-library-staged","project-delta-only","bounded-negative-imported","pdr-candidate-boundary","shadow-campaign-boundary","source-roots-preserved","privacy-stage-reserved","loose-root-progressive-retrieval","support-exact-identity-first","support-association-not-evidence","support-ambiguity-preserved","support-unresolved-not-substituted","support-provenance-scope-preserved","support-private-default-exclusion","support-progressive-widening"},
    "S5":{"whole-integration"},
}

def run_selector():
    required=set().union(*(set(c.obligations) for c in COMPONENTS)); resolved=set(); trace=[]; escalations=[]; stopped=False
    for level in SELECTOR_PREORDER:
        unresolved=required-resolved; applicable=unresolved & POTENTIAL[level]
        if not applicable:
            trace.append({"selector":level,"status":"SKIP","because":"no applicable unresolved obligation"}); continue
        if level!='S0': escalations.append({"to":level,"because":sorted(applicable)})
        results=[]
        for fn in PROBES[level]:
            r=CACHE.run(fn.__name__,fn); results.append({"probe":r.name,"passed":r.passed,"seconds":r.seconds,"resolved":sorted(r.resolves),"detail":r.detail})
            if r.passed: resolved |= r.resolves
            else: stopped=True
        trace.append({"selector":level,"status":"PASS" if all(x['passed'] for x in results) else "FAIL","applicable_obligations":sorted(applicable),"probes":results})
        if stopped: break
    components=[]
    for c in COMPONENTS:
        missing=set(c.obligations)-resolved; components.append({"component":c.name,"passed":not missing,"obligations":sorted(c.obligations),"unresolved":sorted(missing)})
    return {
        "stage":"alpha-0.26-library-fold-and-support-retrieval-candidate",
        "selector_preorder":SELECTOR_PREORDER,
        "policy":"Use the weakest applicable selector; escalate only while a declared obligation remains unresolved. Cache and share probe results.",
        "required_obligations":sorted(required),"resolved_obligations":sorted(resolved),"unresolved_obligations":sorted(required-resolved),
        "components":components,"passed_components":sum(x['passed'] for x in components),"total_components":len(components),
        "escalations":escalations,"trace":trace,
        "passed":not (required-resolved) and all(x['passed'] for x in components) and not stopped,
    }

def main():
    out=run_selector(); (BASE/'artifacts'/'latest_selector_run.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
    print(json.dumps(out,indent=2,sort_keys=True))
    if not out['passed']: raise SystemExit(1)

if __name__=='__main__': main()
