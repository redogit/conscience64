# Central research ledger v1.16 addendum

## Governing claim disposition

The full claim is now **falsified for the frozen bounded system**. This is stronger than the prior “not yet established” state but narrower than a universal impossibility claim.

## New completed experiment

- Version: `operator-moonshot-full-claim-gate-v1`
- Development freeze: `b5b13fcdbd6926c8947f96de85e240646a7fcc0d8c22ca9298f0573e74aad557`
- Confirmation seed: `2026081962`
- Confirmation target hash: `ac147ccd6a25b742128bf44faee5d720a3a0ef53432115149d6b2f3d092c324b`
- Generation 1: NAND (`f4=7`), exact proof retained/replayed.
- Generation 2: NAND-derived NOR (`f4=1`), exact proof and ancestry passed.
- Panel: 200 fresh five-variable structural truth functions; exact paired coverage 200/200/200.
- L0: 32,668,019.6.
- L1: 31,431,648.8; first-generation saving +1,236,370.8.
- L2: 43,573,363.3; second-generation loss −12,141,714.5 relative to L1.
- Zero-acquisition L0−L2 upper bound: −10,905,343.7.
- Cumulative delta with charged acquisition lower bound: −353,523,494.3.
- Generation-2 retrieval: 101 activations; 3 helpful; 98 harmful.
- Verdict: `VERIFIED_NO_FOR_FROZEN_BOUNDED_SYSTEM`.

## Claim ladder update

- Latent equivalence discovery: supported in exact finite Boolean semantics.
- Verified executable crystallization: supported.
- One prospective amortized operator event: supported historically and first-generation transfer passes here.
- Learned generation-2 ancestry: supported structurally and exactly.
- Repeated cumulative self-expansion with progressively cheaper novel computation: **rejected for this frozen machine/protocol**.
- Universal machine-level possibility/impossibility: unresolved by finite experiment and not claimed.

## Protected evidence

R2.1 and MNCL2.1 remain unopened. The full-claim confirmation used seed `2026081962` and does not license retrospective changes to any threshold, feature, model, operator selection, cost weight, or gate.
