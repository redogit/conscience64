# Orbit Lab Alpha 0.9 candidate

# Orbit Lab — Alpha 0.6.1 Battery-Hardened Connected Research Candidate

Alpha 0.6.1 keeps the Alpha 0.5 kernel/selector/human surface and adds a quarantined connection layer over the new Library ingress. It does not merge source projects or inherit their authority.

New human commands: `incoming`, `why <area>`, and `compare <text>`.

Read `docs/CONNECTED_RESEARCH.md` for the connection boundary and earned interface change.

---

# Orbit Lab — Alpha 0.5 Human Interface Candidate

## What this is

This is a small, correctable research kernel grown by feeding it real prior research until its current representation failed and a smaller earned repair became necessary.

It is **not** a universal ontology, complete research operating system, theorem, security boundary, or claim that the accumulated research has been unified.

The current purpose is simpler:

> Keep the active research surface small, keep consequential evidence/history recoverable, select only the helpers/tests needed by the current obligation, and let repeated real failures earn changes to the language or structure.

## Active surface

1. `human_lab.py` — human-facing console: Research Card, task words, progressive disclosure.
2. `orbit_lab.py` — kernel: things, episodes/history, context/scope, authority, evidence, schema correction, transfer/lineage, persistence.
3. `selector.py` — chooses the weakest applicable verification/support path and escalates only while a declared obligation remains unresolved.
4. `supporters/` — interchangeable helper mechanisms. They may attack, replay, compare, observe differently, account for cost, preserve residuals, or shrink counterexamples.
5. `seed_research.py` — representative research loader. Imported research begins historically bounded/quarantined rather than automatically authoritative.
6. `tests/` — current regression/invariant suite.
7. `archive/` — historical stress probes and superseded gates. Passive evidence; not the active API.
8. `docs/` — accumulated reports and lineage.

## One command

```bash
python selector.py
```

That command runs only the selector levels required by the declared whole-project obligations, caches shared probe results, writes `artifacts/latest_selector_run.json`, and exits non-zero on unresolved obligations or a failed applicable probe.

## Selector preorder

`S0 -> S1 -> S2 -> S3 -> S4 -> S5`

- `S0` — compile + current regressions. No active methodological choice.
- `S1` — deterministic fixed checks: research loading, historical-lineage classification, recovery/export/import/audit.
- `S2` — bounded seeded adversarial composition (Orbital GAN-like pressure).
- `S3` — supporter selection. Uses the exact minimum-cost cover of requested supporter capabilities for the current bounded catalog.
- `S4` — bounded distinguishing search: exact finite reference models + metamorphic checks.
- `S5` — whole integrated scenario, only when the whole-system obligation remains.

The selector levels are an **escalation policy**, not six architectural layers.

## Current stage boundary

Alpha 0.5 is an internal research alpha candidate. Actor identity is still supplied by the embedding runtime; this kernel does not authenticate real users/processes. Built-in supporters share runtime lineage and are role-separated mechanisms, **not independent replication**.

No finite test run establishes completeness.

## Human-facing console

The default kernel CLI remains available for debugging, but ordinary work can use:

```bash
python human_lab.py
```

The human surface is a six-field Research Card:

`Question -> Need -> Limit -> Try -> Saw -> Left`

This is a view over the existing kernel, not a replacement ontology. `Saw` maps to an
observed `Observation`; `Thought` is stored separately as an `Inference`. Raw IDs and
kernel plumbing are hidden by default and remain available through `advanced`.

A deterministic demo is available with:

```bash
python human_lab.py --demo
```


## Alpha 0.8 BGZF carrier/evidence candidate

The BGZF branch forced one generic claim-containment refinement: evidence qualification is now explicit when a claim requires a specific evidence class. This prevents learned/adaptive state from satisfying an exact deterministic carrier claim and prevents file-level weak labels from being silently promoted into block-level ground truth. See `docs/BGZF_INTEGRATION_ALPHA_0_8.md`.
