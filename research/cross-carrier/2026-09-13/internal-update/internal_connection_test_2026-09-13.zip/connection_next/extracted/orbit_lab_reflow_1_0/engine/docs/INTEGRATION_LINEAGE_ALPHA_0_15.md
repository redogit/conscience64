# Orbit Lab Alpha 0.15 — Integration Lineage

Alpha 0.15 turns the TBCL active-carrier result back onto Orbit Lab itself.

The full test/supporter/history surface remains preserved. A current research obligation activates only its falsifiers plus a fast whole-kernel sentinel. `regression` remains release-only.

This preserves the earlier pattern:

`PRESERVED verification history != ACTIVE verification plan`.

No kernel schema type was added. The reduction is in verification activation and orchestration.
