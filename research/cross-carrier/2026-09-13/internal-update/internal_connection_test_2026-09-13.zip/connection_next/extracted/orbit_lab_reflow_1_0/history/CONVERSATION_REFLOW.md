# Conversation Reflow — From Beginning to Current

This document reorganizes the substantive content of the conversation by function rather than chronology.
It is not a verbatim transcript and does not replace original artifacts or evidence.

## A. What the user wanted from Orbit

Across the conversation the same practical goal appeared in several forms:

- Can it do math?
- Are ethics primary?
- Can it make something small and fun that is free for everyone?
- Can it help create a low-attention way to investigate a $20 penny-stock idea without thinking about money constantly?
- Can it help with GDSN problems at work without dragging private production data into a permanent research record?
- Can the rest of the Library be folded in without turning Current into a dump?
- Can the Library find supporting items for what it already contains?

These are different domains, but the common requirement is:

> Help with the current thing, retrieve only what matters, show what actually supports the answer, protect people/data/evidence,
> preserve unresolved remainder, and avoid making the person carry the system's internal complexity.

## B. What Orbit became

Orbit started as a research kernel with explicit entities, episodes, selectors, supporters, audits, authority, scope, and history.
Repeated experiments showed that most of this should remain machine-side. The human-facing structure converged on the Research Card.

The Library work then showed that preserving everything and loading everything are different problems. Selective retrieval and
support qualification became the bridge between a small Current and a large recoverable Library.

## C. What did not survive as active doctrine

- completeness as a goal or gate;
- broad bulk ingestion merely because material is available;
- one global ontology for all projects;
- summaries/recovery maps as substitutes for primary evidence;
- semantic similarity as identity;
- consensus as grounding;
- positive ending wealth as a substitute for a risk criterion;
- a post-hoc boundary as a live financial rule;
- `SYNCHRONISED` as equivalent to retailer-active/usable;
- philosophy as empirical authority;
- source/specification as runtime behavior;
- historical method as current authority;
- current compression as permission to destroy open-ended evidence.

## D. What is active now

```text
Compass / ethics
        ↓
Research Card
        ↓
optional find-support
        ↓
Probe / action / calculation / work helper
        ↓
Saw (observation)
        ↓
Verify source + relation + scope + authority
        ↓
Bounded claim / decision
        ↓
Left (unresolved)
        ↓
Library preserves what must remain recoverable
```

The implementation underneath may remain complex because it preserves the tests that earned these distinctions.
The person should not need to reconstruct that complexity to use the lab.
