
import unittest
from checks.operator_primary_route_probe import run

class OperatorPrimaryRouteTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.r=run()

    def test_two_hop_route_reaches_primary_branch(self):
        self.assertTrue(self.r["map_points_to_primary_branch"])
        self.assertTrue(self.r["primary_branch_status_recovered"])
        self.assertTrue(self.r["primary_archive_identity_recoverable"])

    def test_bounded_wrong_input_witness_recovered(self):
        self.assertTrue(self.r["wrong_input_consensus_4096_witness"])

    def test_summary_locator_cannot_certify_primary_claim(self):
        self.assertTrue(self.r["recovery_map_alone_cannot_certify_primary_claim"])

    def test_cleanup_custody_is_redundant(self):
        self.assertTrue(self.r["independent_library_copies_byte_identical"])

    def test_no_schema_growth(self):
        self.assertEqual(self.r["kernel_schema_additions"],0)
        self.assertTrue(self.r["audit_passed"])

if __name__=="__main__":
    unittest.main()
