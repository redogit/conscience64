# Orbit Lab Alpha 0.13 — SHADOW Evidence Integrity Candidate

SHADOW contributed one new generic failure: a complete-looking campaign claim is
not admissible when the linked raw evidence cannot reconstruct the declared
denominator and identity set.

Alpha 0.12 reproduced the defect: a claim declaring an eight-record evidence-set
contract could be marked SUPPORTED with only seven collection members, and audit
still passed.

Alpha 0.13 adds a claim-local evidence-set contract over the existing Collection:
- exact count;
- optional identity field;
- exact identity set or canonical SHA-256;
- optional required tag(s) on every member.

SUPPORTED claims enforce the contract, and alpha_audit rechecks it so post-support
link loss or identity substitution invalidates the claim.

No Campaign, Denominator, Timeout, or Shard object type was added.

Existing distinctions were sufficient for:
- timeout raw observation remains UNKNOWN;
- same display label can have distinct RunIdentity identities;
- final classifier decision can be separate from raw timeout observation.

This is evidence-custody/admissibility enforcement, not a SHADOW behavioral claim.
