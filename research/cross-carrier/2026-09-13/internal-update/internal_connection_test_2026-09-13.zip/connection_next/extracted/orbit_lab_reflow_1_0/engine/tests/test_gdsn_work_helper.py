import tempfile, unittest
from pathlib import Path
from work_helpers.gdsn import classify, triage, render
from human_lab import HumanLab, dispatch

class TestGDSNWorkHelper(unittest.TestCase):
    def test_routes_and_boundaries(self):
        self.assertEqual(classify('CIC rejected item'),'confirmation')
        self.assertEqual(classify('RFCIN resend'),'publication-subscription')
        r=triage('SYNCHRONISED but item unavailable')
        self.assertTrue(any('SYNCHRONISED does not' in x for x in r['known_distinctions']))
        self.assertTrue(any('credentials' in x for x in r['boundaries']))

    def test_human_command_is_non_persistent(self):
        with tempfile.TemporaryDirectory() as td:
            h=HumanLab(Path(td)/'gdsn.db')
            try:
                before=h.lab.stats()
                out=dispatch(h,['gdsn','CIC','REVIEW','on','a','test','item'])
                after=h.lab.stats()
                self.assertIn('GDSN WORK HELPER',out)
                self.assertEqual(before,after)
            finally:
                h.close()

if __name__=='__main__': unittest.main()
