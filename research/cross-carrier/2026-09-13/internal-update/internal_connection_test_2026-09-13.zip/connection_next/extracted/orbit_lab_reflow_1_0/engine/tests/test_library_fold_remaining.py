import unittest
from checks.library_fold_remaining_probe import run
from library_fold import all_stage_status, lookup_stage2

class RemainingFoldTests(unittest.TestCase):
    def test_remaining_stages(self): self.assertTrue(run()["passed"])
    def test_all_stages_present(self): self.assertEqual(set(all_stage_status()),{"1","2","3","4","5"})
    def test_pdr_retrievable_as_candidate(self):
        hits=lookup_stage2("Parameter_Differential_Reflow")
        self.assertEqual(len(hits),1); self.assertEqual(hits[0]["classification"],"NEW_CANDIDATE_IMPORT")

if __name__=="__main__": unittest.main()
