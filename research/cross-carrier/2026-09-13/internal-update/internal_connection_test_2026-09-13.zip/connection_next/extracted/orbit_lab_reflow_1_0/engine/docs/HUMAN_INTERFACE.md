# Human-facing Orbit Lab interface — Alpha 0.5 candidate

## Purpose

The interface reduces reconstruction work at the **surface** without changing the kernel's
scientific distinctions. It is deliberately a view, not a second ontology.

## Default Research Card

```text
Question  What are we examining?
Need      What must the work preserve or accomplish?
Limit     What boundary or constraint matters?
Try       What concrete probe/action will we attempt?
Saw       What was actually observed?
Left      What remains unresolved?
```

Two consequential distinctions stay outside the six fields but remain one command away:

- `think` records an **Inference**, never an Observation.
- `decide` records a **Decision**, never evidence.

Kernel IDs, provenance plumbing, schema terms, authority machinery, and detailed audits are
hidden in the normal view. `advanced` exposes kernel audit/stats when they become relevant.

## Commands

```text
start <question>
need <text>
limit <text>
try <text>
saw <text>
left <text>
think <text>
decide <text>
card
next
support <transport|adaptive|schema|holdout|language|pipeline>
health
history [n]
advanced
```

`health` explains the latest selector-run artifact; it does not recursively rerun the lab.
The selector remains the single orchestration path.

## Bounded interface probe

For three tested actions—start a question, record an observation, record an interpretation—the
raw kernel path required six user-visible API operations and carrying raw IDs between operations.
The human surface used three task-word commands and exposed no raw ID in the default card, while
the stored Subject / OBSERVED Observation / Inference semantics matched.

This is a **structural exposure proxy**, not a human-usability result. No claim is made yet about
cognitive load, error rate, learnability, accessibility, or preference in real users.

## Next discriminating test

The useful next test is a small human task comparison, not more interface architecture:

1. Give the same bounded research-recording task through the raw/current technical surface and the Research Card.
2. Measure completion errors, consequential distinction loss, time/steps, clarification requests, and subjective reconstruction burden.
3. Preserve failures and comments.
4. Keep or change only interface distinctions that alter those outcomes.
