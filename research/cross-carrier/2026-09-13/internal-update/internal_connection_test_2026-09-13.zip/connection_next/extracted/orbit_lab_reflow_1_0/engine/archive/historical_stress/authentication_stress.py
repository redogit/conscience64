
import tempfile
from pathlib import Path
from orbit_lab import OrbitLab

with tempfile.TemporaryDirectory() as td:
    lab=OrbitLab(Path(td)/"stress.db")
    passes=[]; breaks=[]
    try:
        c=lab.add("Context","C",provenance_class="TEST",provenance="stress",identity_key="c")
        owner=lab.add("Actor","root owner",provenance_class="TEST",provenance="stress",identity_key="owner")
        reviewer=lab.add("Actor","reviewer",provenance_class="TEST",provenance="stress",identity_key="reviewer")
        impostor=lab.add("Actor","impostor",provenance_class="TEST",provenance="stress",identity_key="impostor")
        s=lab.add("Scope","Hodge",provenance_class="TEST",provenance="stress",identity_key="s")
        target=lab.add("Candidate","source artifact",provenance_class="TEST",provenance="stress",identity_key="target")
        basis=lab.add("Evidence","basis",provenance_class="TEST",provenance="stress",identity_key="basis",epistemic="OBSERVED")
        root=lab.establish_authority_root(context_id=c,scope_id=s,operations=["INSPECT"],holder_actor_id=owner,provenance_class="USER",provenance="user")
        lab.grant_authorization(context_id=c,entity_id=target,operation="INSPECT",scope_id=s,
            issuer_authority_id=root,issuer_actor_id=owner,principal_id=reviewer,basis_entity_ids=[basis],
            reason="reviewer only",provenance_class="TEST",provenance="stress")
        if not lab.check_authorized(context_id=c,actor_id=impostor,entity_id=target,operation="INSPECT",scope_id=s)["authorized"]:
            passes.append("Authorization is now bound to an Actor, not merely to Context/Entity.")

        # But actor_id is caller-supplied. The kernel cannot authenticate that the runtime caller
        # really is `reviewer`; an impostor can simply pass reviewer's ID.
        spoof=lab.check_authorized(context_id=c,actor_id=reviewer,entity_id=target,operation="INSPECT",scope_id=s)
        if spoof["authorized"]:
            breaks.append(
                "Actor binding is representational, not authenticated. The kernel trusts the caller-supplied "
                "actor_id, so an external caller can impersonate an authorized Actor unless the runtime supplies "
                "an authenticated principal/capability that the data model cannot forge."
            )

        print("V0.20 ACTOR / AUTHENTICATION STRESS")
        print("----------------------------------")
        print("PASS:")
        for x in passes: print("-",x)
        print("\nSYSTEM BOUNDARY:")
        for i,x in enumerate(breaks,1): print(f"{i}. {x}")
    finally:
        lab.close()
