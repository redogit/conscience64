# Orbit Lab Alpha 0.15 — Self-Verification Carrier

Orbit Lab now distinguishes **task verification** from **release verification**.

## Problem reproduced

Before Alpha 0.15, the weakest S0 check bundled the complete regression archive into one probe. A narrow research obligation therefore paid the cost of unrelated historical and component checks.

## Active carrier

A compiled obligation-to-probe relation now covers 68 task-verifiable obligations with 22 probes.

- active incidence body: **680 bytes**
- complete carrier including reconstructive dictionaries: **2930 bytes**
- release-only obligation: `regression`

Unknown or uncovered obligations cannot be certified. Deleting the only provider edge for `declared-denominator-linked` causes planning to fail instead of silently passing.

## Measured task behavior

Full packaged regression: **160 tests**, **9.21s** observed wall time.

Typical narrow profiles activate 2–4 probes and were observed at approximately **0.77–1.45s** wall time. The recovery/history profile remains expensive at approximately **22.9s**, because historical classification is genuinely part of that obligation.

This is the desired behavior: reduce unrelated work, not necessary work.

## Preservation

No tests were deleted. Historical version tests remain cold/recoverable and are still executed by the release gate. The task carrier is an activation index, not an evidence compressor that destroys the underlying regressions.

## Claim ceiling

The measurements are bounded to this Orbit Lab package and host. The carrier is not claimed globally minimal, and the task probes are not independent external replication.
