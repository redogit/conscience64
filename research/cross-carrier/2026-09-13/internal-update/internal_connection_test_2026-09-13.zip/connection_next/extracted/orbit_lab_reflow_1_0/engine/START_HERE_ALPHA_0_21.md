# Orbit Lab Alpha 0.21 — Current

Alpha 0.21 integrates the remaining Operator Moonshot recovery-method authority boundary.

Core distinction:

```text
method relevance / historical usefulness
        !=
current governing method authority
```

Orbit Lab already had `METHOD_COMPLIANCE` with `CURRENT`, `PREDECESSOR`, `WRONG_METHOD`, `OBSOLETE`, and `UNKNOWN`. Alpha 0.21 connects that existing layer to claim admission and audit.

A Claim may require an exact Method + Context + Scope and allowed compliance verdicts. Compliance is read from METHOD_COMPLIANCE episodes, not from filename similarity, evidence tags, or self-declared source role.

Bounded result:
- active recovery procedure identity: `beefec7981a52134c637640aa09e1f49dd3303343a968ae3d119c4a3e65922f8`;
- active schema identity: `72a39b469aa7e137b7c487374e53b9f3d2f8991671d12e8cf2ede7719a4114ae`;
- historical prompt variant remains retrievable/relevant as PREDECESSOR;
- predecessor cannot satisfy a CURRENT-method claim;
- current procedure can;
- post-support method drift to OBSOLETE is detected by audit.

Validation:
- 190/190 regressions PASS
- 27 selector components / 99 obligations
- method-authority task profile = core-sentinel + method-authority-boundary
- direct S5 whole integration PASS
- strict path successor of Alpha 0.20
- zero new kernel object/Episode types

Known infrastructure remainder: the public full selector process can still linger under the host/wrapper path; this is not reclassified as a scientific failure.
