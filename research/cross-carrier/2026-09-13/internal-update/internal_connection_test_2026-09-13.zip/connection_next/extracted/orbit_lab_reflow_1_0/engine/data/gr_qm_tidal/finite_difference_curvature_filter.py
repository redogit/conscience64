import sympy as sp

x, h = sp.symbols("x h", positive=True)
a, b, Gamma, mu = sp.symbols("a b Gamma mu")

def d2(expr):
    return sp.simplify(expr.subs(x, x+h) - 2*expr + expr.subs(x, x-h))

print("D2[affine] =", d2(a + b*x))
print("D2[quadratic] =", d2(a + b*x + sp.Rational(1,2)*Gamma*x**2))
print("D2[-mu/x] exact =", sp.factor(d2(-mu/x)))
print("D2[-mu/x] through h^4 =", sp.series(d2(-mu/x), h, 0, 6))
