from __future__ import annotations
from pathlib import Path
import json,tempfile,sys
ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path: sys.path.insert(0,str(ROOT))
from human_lab import HumanLab


def run():
    with tempfile.TemporaryDirectory() as td:
        h=HumanLab(Path(td)/'human.db')
        try:
            first=h.start('First question')
            h.add('need','Preserve the relevant distinction')
            h.add('saw','Observed value = 10')
            h.think('This may mean something')
            card=h.card()
            no_raw_id=(first not in card and 'Subject' not in card and 'Observation' not in card)
            thought_separate='Thought: This may mean something' in h.recent_thoughts()
            current_before=h.current_subject_id()==first
            second=h.start('Second question')
            current_after=h.current_subject_id()==second and second!=first
            old_recoverable=any(x['id']==first for x in h.lab.library(type='Subject'))
            connected=h.incoming()
            connected_view=('CONNECTED' in connected.upper() or 'INCOMING' in connected.upper() or len(connected)>20)
            next_hint=h.next_hint() if hasattr(h,'next_hint') else h.card()
            progressive=bool(next_hint)
            return {
                'passed':all([
                    no_raw_id,thought_separate,current_before,
                    current_after,old_recoverable,connected_view,progressive
                ]),
                'human_card': 'RESEARCH CARD' in card,
                'observation_inference_separate':thought_separate,
                'no_raw_id_default':no_raw_id,
                'progressive_disclosure':progressive,
                'recoverable_current':old_recoverable,
                'connected_human_view':connected_view,
            }
        finally:
            h.close()

if __name__=='__main__': print(json.dumps(run(),indent=2,sort_keys=True))
