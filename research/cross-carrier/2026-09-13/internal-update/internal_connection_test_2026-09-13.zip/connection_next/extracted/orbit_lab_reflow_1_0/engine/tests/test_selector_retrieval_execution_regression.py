
import unittest
import selector

class SelectorRetrievalExecutionRegression(unittest.TestCase):
    def test_retrieval_probe_is_present_in_full_s4_execution_list(self):
        names={getattr(fn,"__name__","") for fn in selector.PROBES["S4"]}
        self.assertIn("probe_s4_retrieval_neighborhood",names)

if __name__=="__main__":
    unittest.main()
