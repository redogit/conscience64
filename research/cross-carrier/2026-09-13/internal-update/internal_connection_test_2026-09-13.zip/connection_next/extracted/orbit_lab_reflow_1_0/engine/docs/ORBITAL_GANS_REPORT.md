# Orbital GANs — alpha 0.2 adversarial research report

## What this is

“Orbital GANs” is a GAN-like adversarial co-evolution harness, not a neural GAN.

A generator population mutates plausible research histories across authority, schema,
scope, epistemic, lineage, association, compatibility and state orbits.

A discriminator population checks higher-level invariants. Generator fitness is not
“make an exception”; it is “produce a novel history accepted by the normal API that
should have been impossible,” or expose an audit blind spot.

Every novel counterexample is preserved, repaired, and converted into a regression test.

## Three generations

- Generation 1: 180 trials → 4 novel counterexamples.
- Repair → 180/180 clean.
- Generation 2: 260 trials → 4 different novel counterexamples.
- Repair → 260/260 clean.
- Generation 3: 340 trials → 4 different novel counterexamples.
- Repair → 340/340 clean.

The 12 historical findings are preserved in `orbital_findings_archive.json`.

## What it unexpectedly found

1. Finite authority could produce an unbounded delegated child.
2. Revocation was not transitive through authority ancestry.
3. Revoked issuers left previously issued grants live.
4. Schema audit did not bind an admitted term to the gap that earned it.
5. `AUTHORIZE` accidentally behaved as a wildcard operation escalator.
6. A revoked negative authorization could continue blocking a valid grant.
7. Schema definitions could drift away from promoted proposals without audit failure.
8. Scope topology corruption could create cycles undetected by audit.
9. A TOOL_FAILED execution could certify persistent promotion.
10. UNKNOWN evidence could certify persistent promotion.
11. Legacy activation bypassed the current authority model.
12. Current working-set type corruption escaped alpha audit.

Each is now a regression.

## Current intended use

Keep the Orbital GAN population around the research kernel and add new generator
orbits as real research introduces new relations. It should pressure the joints
between independently valid subsystems, where most of the useful failures have appeared.

The harness must not auto-promote its own discoveries. A finding enters the novelty
archive; ordinary evidence/promotion/authority rules still govern changes to Orbit Lab.
