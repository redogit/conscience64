
import tempfile
from pathlib import Path
import unittest
from orbit_lab import OrbitLab

class V24Tests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.lab=OrbitLab(Path(self.tmp.name)/"t.db")
    def tearDown(self):
        self.lab.close(); self.tmp.cleanup()
    def add(self,t,title,key,**kw):
        return self.lab.add(t,title,provenance_class="TEST",provenance="test",identity_key=key,**kw)

    def setup_source(self):
        a=self.add("Context","A","ctxA"); b=self.add("Context","B","ctxB")
        content=self.lab.register_content(algorithm="sha256",digest="abc123",provenance_class="TEST",provenance="test")
        inst=self.lab.create_artifact_instance(content_id=content,title="source instance",
            provenance_class="TEST",provenance="test",identity_key="inst")
        occ=self.lab.record_instance_occurrence(instance_id=inst,context_id=a,locator="/A/x",
            mode="REGISTER",provenance_class="TEST",provenance="test",identity_key="occ")
        ob=self.add("Obligation","preserve bytes","ob")
        ev=self.add("Evidence","hash check","ev",epistemic="OBSERVED")
        return a,b,content,inst,occ,ob,ev

    def test_copy_creates_new_instance_same_content(self):
        a,b,content,inst,occ,ob,ev=self.setup_source()
        r=self.lab.custody_transfer(source_context_id=a,destination_context_id=b,
            source_occurrence_id=occ,destination_locator="/B/x",mode="COPY",
            obligation_ids=[ob],evidence_entity_ids=[ev],reason="copy",
            provenance_class="TEST",provenance="test")
        self.assertNotEqual(r["source_instance_id"],r["destination_instance_id"])
        self.assertTrue(r["content_preserved"])
        self.assertFalse(self.lab.same_instance(occ,r["destination_occurrence_id"]))

    def test_move_preserves_instance(self):
        a,b,content,inst,occ,ob,ev=self.setup_source()
        r=self.lab.custody_transfer(source_context_id=a,destination_context_id=b,
            source_occurrence_id=occ,destination_locator="/B/x",mode="MOVE",
            obligation_ids=[ob],evidence_entity_ids=[ev],reason="move",
            provenance_class="TEST",provenance="test")
        self.assertEqual(r["source_instance_id"],r["destination_instance_id"])
        self.assertTrue(self.lab.same_instance(occ,r["destination_occurrence_id"]))

    def test_reconstruction_new_instance_can_change_content(self):
        a,b,content,inst,occ,ob,ev=self.setup_source()
        other=self.lab.register_content(algorithm="sha256",digest="def456",
            provenance_class="TEST",provenance="test")
        r=self.lab.custody_transfer(source_context_id=a,destination_context_id=b,
            source_occurrence_id=occ,destination_locator="/B/rebuilt",mode="RECONSTRUCT",
            reconstructed_content_id=other,obligation_ids=[ob],evidence_entity_ids=[ev],
            reason="reconstruct",provenance_class="TEST",provenance="test")
        self.assertNotEqual(r["source_instance_id"],r["destination_instance_id"])
        self.assertFalse(r["content_preserved"])

if __name__=="__main__":
    unittest.main()
