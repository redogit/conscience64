
import tempfile
from pathlib import Path
import unittest
from orbit_lab import OrbitLab
class V20Tests(unittest.TestCase):
    def setUp(self): self.tmp=tempfile.TemporaryDirectory(); self.lab=OrbitLab(Path(self.tmp.name)/"t.db")
    def tearDown(self): self.lab.close(); self.tmp.cleanup()
    def add(self,t,title,key,**kw): return self.lab.add(t,title,provenance_class="TEST",provenance="test",identity_key=key,**kw)
    def test_authorization_is_principal_bound(self):
        c=self.add("Context","C","c"); owner=self.add("Actor","owner","owner"); reviewer=self.add("Actor","reviewer","reviewer"); other=self.add("Actor","other","other"); s=self.add("Scope","S","s"); x=self.add("Candidate","X","x"); e=self.add("Evidence","e","e",epistemic="OBSERVED")
        root=self.lab.establish_authority_root(context_id=c,scope_id=s,operations=["INSPECT"],holder_actor_id=owner,provenance_class="USER",provenance="user")
        self.lab.grant_authorization(context_id=c,entity_id=x,operation="INSPECT",scope_id=s,issuer_authority_id=root,issuer_actor_id=owner,principal_id=reviewer,basis_entity_ids=[e],reason="reviewer only",provenance_class="TEST",provenance="test")
        self.assertTrue(self.lab.check_authorized(context_id=c,actor_id=reviewer,entity_id=x,operation="INSPECT",scope_id=s)["authorized"])
        self.assertFalse(self.lab.check_authorized(context_id=c,actor_id=other,entity_id=x,operation="INSPECT",scope_id=s)["authorized"])
if __name__=="__main__": unittest.main()
