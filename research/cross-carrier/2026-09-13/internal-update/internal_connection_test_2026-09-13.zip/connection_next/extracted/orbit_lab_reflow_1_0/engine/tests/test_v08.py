
import tempfile
from pathlib import Path
import unittest
from orbit_lab import OrbitLab

class V08Tests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.lab=OrbitLab(Path(self.tmp.name)/"t.db")
    def tearDown(self):
        self.lab.close(); self.tmp.cleanup()
    def add(self,t,title,key,**kw):
        return self.lab.add(t,title,provenance_class="TEST",provenance="test",identity_key=key,**kw)

    def test_transport_type_contract(self):
        src=self.add("Claim","wrong source","src")
        dst=self.add("Artifact","dst","dst")
        ob=self.add("Obligation","ob","ob")
        ev=self.add("Evidence","ev","ev",epistemic="OBSERVED")
        with self.assertRaises(TypeError):
            self.lab.add_episode("FAITHFUL_TRANSPORT","bad",
                participants=[
                    {"role":"source","object_id":src},
                    {"role":"target","object_id":dst},
                    {"role":"obligation","object_id":ob},
                    {"role":"evidence","object_id":ev},
                ],
                provenance_class="TEST",provenance="test")

    def test_counterfactual_type_contract(self):
        c=self.add("Candidate","c","c")
        r=self.add("Artifact","reset","r")
        bad=self.add("Boundary","bad control","bad")
        out=self.add("Observation","result","out",epistemic="OBSERVED")
        with self.assertRaises(TypeError):
            self.lab.add_episode("MATCHED_COUNTERFACTUAL","bad",
                participants=[
                    {"role":"candidate","object_id":c},
                    {"role":"reset","object_id":r},
                    {"role":"control","object_id":bad},
                    {"role":"treatment","object_id":bad},
                    {"role":"result","object_id":out},
                ],
                provenance_class="TEST",provenance="test")

if __name__=="__main__":
    unittest.main()
