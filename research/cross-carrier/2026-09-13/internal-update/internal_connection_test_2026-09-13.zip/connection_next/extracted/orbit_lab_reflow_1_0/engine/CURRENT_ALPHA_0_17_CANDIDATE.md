# Orbit Lab Alpha 0.17 candidate

Adds a selective recovery-map → primary-branch evidence route and repairs full-selector retrieval execution.
