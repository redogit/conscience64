
from pathlib import Path
from orbit_lab import OrbitLab

# Representative recovered research. This is intentionally not a completeness claim.
# Imported legacy research begins QUARANTINED unless the record is a current control.

SEED = [
    {
        "key":"research:moonshot",
        "title":"Operator Moonshot — verified reusable computation",
        "source":"library:file_0000000029b081fdaaf7294b5ffbb502",
        "claim":"Bounded causal reuse and amortization events exist; repeated cumulative self-expansion was not established.",
        "boundary":"Do not treat routing/composition/reuse as unrestricted operator discovery or repeated self-expansion.",
        "status":"UNKNOWN",
    },
    {
        "key":"research:tbcl",
        "title":"TBCL — finite resolver and recoverability",
        "source":"library:file_00000000b27081f59e5714cb18c81deb",
        "claim":"A frozen finite resolver universe has exact query-to-selection/provenance evidence and recoverability obligations.",
        "boundary":"Finite resolver evidence is not a universal semantics result.",
        "status":"SUPPORTED",
    },
    {
        "key":"research:language-workbench",
        "title":"Language Structure Workbench",
        "source":"library:file_0000000023dc81f5835d2e4c7d830a60",
        "claim":"Current view should show fired/current/relevant outputs while inactive rules remain in audit/debug.",
        "boundary":"Bounded rule-based workbench; not a complete theory of language.",
        "status":"SUPPORTED",
    },
    {
        "key":"research:hodge-m45",
        "title":"Hodge/Fermat m=45 route",
        "source":"library:file_000000001bb081f591fd23bb1aff3233",
        "claim":"Explicit Y and finite normalization are available; the geometric intersection/eigenspace kernel remains load-bearing.",
        "boundary":"No Hodge proof. Keep external/unverified geometric steps distinct from finite arithmetic.",
        "status":"UNKNOWN",
    },
    {
        "key":"research:4d-codec",
        "title":"4D codec / observer",
        "source":"library:file_00000000d3dc81f592e0b29cf7c6d1e2",
        "claim":"Finite synthetic three-number compression succeeds on the tested identity task.",
        "boundary":"Raw 4D already solves the task; exact noisy-input inversion is not unique without extra retained information.",
        "status":"SUPPORTED",
    },
    {
        "key":"research:pulse",
        "title":"Pulse optimizer",
        "source":"library:file_000000001d7081f6a76e85a77ec7efe1",
        "claim":"Useful small-network training behavior was explored, but the mechanism carrying it remains unresolved.",
        "boundary":"Do not infer scalability or causal mechanism from small benchmark success.",
        "status":"UNKNOWN",
    },
    {
        "key":"research:fractal3d",
        "title":"Fractal3D recursive generator",
        "source":"library:file_00000000ebd481f5845c00263dcb9480",
        "claim":"Sparse symbolic recursive backbone plus finite-depth validators is the safest retained engineering direction.",
        "boundary":"Recursion is not proof of fractality; finite-depth evidence is not automatically an infinite-depth theorem.",
        "status":"SUPPORTED",
    },
    {
        "key":"research:llvm-wasm",
        "title":"LLVM → WASM dense-layer generator",
        "source":"library:file_000000000b7481f581218f53fbb5fb58",
        "claim":"Generator-owned genericity with concrete LLVM specializations and a scalar correctness fallback is technically defensible.",
        "boundary":"LLVM IR itself does not provide source-level generics and IR syntax does not guarantee one machine instruction sequence.",
        "status":"SUPPORTED",
    },
    {
        "key":"research:shadow",
        "title":"SHADOW behavioral-control experiments",
        "source":"library:file_00000000830081f5889956c79e2efe10",
        "claim":"Bounded behavioral-control results and failures are preserved under native-faithful constraints.",
        "boundary":"Finite panels remain finite claims; reported/reconstructed evidence must not be silently upgraded.",
        "status":"SUPPORTED",
    },
    {
        "key":"research:carrier",
        "title":"Composable Knowledge / Carrier Theory",
        "source":"library:file_000000006c7081f5a3db5878f2310620",
        "claim":"Finite-boundary carrier ideas remain a research synthesis; several reported numerical experiments lack primary execution artifacts.",
        "boundary":"Unverified reported experiments are not ACTUALLY_TESTED evidence.",
        "status":"UNKNOWN",
    },
    {
        "key":"research:tide",
        "title":"TIDE relational-wave language",
        "source":"library:file_0000000056b481f59cde02ed5ceafce2",
        "claim":"TIDE is a research candidate for mapping consequential relations into a machine-operable representation with human-readable projections.",
        "boundary":"Wave dimensions are provisional and must survive ablation; word != meaning != wave.",
        "status":"PROPOSED",
    },
]

def _expected_identity_keys():
    keys={
        "current:research-corpus",
        "control:obligation:minimal-research",
        "control:boundary:no-inherited-authority",
    }
    for row in SEED:
        keys.update({row["key"], row["key"]+":claim", row["key"]+":boundary"})
    return keys

def _existing_complete_seed(lab):
    expected=_expected_identity_keys()
    rows=lab.conn.execute(
        "SELECT id, identity_key FROM objects WHERE identity_key IS NOT NULL"
    ).fetchall()
    by_key={r["identity_key"]:r["id"] for r in rows}
    present=expected & set(by_key)
    if not present:
        return None
    if present != expected:
        missing=sorted(expected-present)
        raise RuntimeError(
            "partial research seed detected; use a fresh database or recover the partial run; "
            f"missing identity keys: {missing}"
        )
    root=by_key["current:research-corpus"]
    ids={
        row["key"]:{
            "subject":by_key[row["key"]],
            "claim":by_key[row["key"]+":claim"],
            "boundary":by_key[row["key"]+":boundary"],
        }
        for row in SEED
    }
    expected_relations=3*len(SEED)
    rel_count=lab.conn.execute("SELECT COUNT(*) AS n FROM relations").fetchone()["n"]
    if rel_count < expected_relations:
        raise RuntimeError(
            "seed identities exist but relation graph is incomplete; preserve/recover rather than silently reseed"
        )
    return root, ids, lab.stats()

def load(db_path="research_seed.db"):
    lab=OrbitLab(db_path)
    try:
        existing=_existing_complete_seed(lab)
        if existing is not None:
            return existing
        root=lab.add(
            "Subject","Recovered research corpus under minimal controls",
            provenance_class="CURRENT_CONVERSATION",
            provenance="conversation:2026-09-04",
            identity_key="current:research-corpus",
            lifecycle="ACTIVE"
        )
        lab.pin("subject",root)

        # Global current controls, not inherited research doctrine.
        ob=lab.add(
            "Obligation","Preserve evidence, failures, provenance, boundaries, and correctability while keeping Current small",
            provenance_class="CURRENT_CONVERSATION", provenance="conversation:2026-09-04",
            identity_key="control:obligation:minimal-research", lifecycle="ACTIVE"
        )
        lab.pin("obligation",ob)

        bd=lab.add(
            "Boundary","Legacy research enters without inherited authority; activate only for a current reason",
            provenance_class="CURRENT_CONVERSATION", provenance="conversation:2026-09-04",
            identity_key="control:boundary:no-inherited-authority", lifecycle="ACTIVE"
        )
        lab.pin("boundary",bd)

        ids={}
        for row in SEED:
            s=lab.add(
                "Subject",row["title"],
                data={"source":row["source"]},
                provenance_class="LIBRARY_ARTIFACT", provenance=row["source"],
                identity_key=row["key"], lifecycle="QUARANTINED"
            )
            claim=lab.add(
                "Claim",row["claim"],
                data={
                    "scope":"bounded to recovered source",
                    "claim_boundary":row["boundary"],
                    "recovered_epistemic_status":row["status"],
                    "recovered_status_is_current_assessment":False,
                },
                provenance_class="RECOVERY_PACKET", provenance=row["source"],
                identity_key=row["key"]+":claim", lifecycle="QUARANTINED"
            )
            boundary=lab.add(
                "Boundary",row["boundary"],
                provenance_class="RECOVERY_PACKET", provenance=row["source"],
                identity_key=row["key"]+":boundary", lifecycle="QUARANTINED"
            )
            lab.relate(claim,"ABOUT",s,
                       provenance_class="DERIVED",provenance="seed_research.py")
            lab.relate(boundary,"LIMITS",claim,
                       data={"role":"claim ceiling"},
                       provenance_class="DERIVED",provenance="seed_research.py")
            lab.relate(s,"RELEVANT_TO",root,
                       data={"reason":"research corpus member; inactive by default"},
                       provenance_class="DERIVED",provenance="seed_research.py")
            ids[row["key"]]={"subject":s,"claim":claim,"boundary":boundary}

        return root, ids, lab.stats()
    finally:
        lab.close()

if __name__=="__main__":
    root, ids, stats=load()
    print("root:",root)
    print("subjects:",len(ids))
    print(stats)
