
import unittest
from checks.research_card_negative_retrieval_probe import run

class ResearchCardNegativeRetrievalTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.r=run()

    def test_recovery_question_stays_open(self):
        self.assertTrue(self.r["recovery_records_preserve_open_execution_question"])
        self.assertTrue(self.r["association_map_has_no_primary_library_locator"])

    def test_negative_search_is_bounded(self):
        self.assertTrue(self.r["bounded_not_found_claim_supported"])
        self.assertTrue(self.r["not_found_does_not_support_never_existed"])

    def test_human_card_keeps_left_unresolved(self):
        self.assertTrue(self.r["left_remainder_preserved"])
        self.assertIn("Left",self.r["research_card_rendered"])

    def test_no_schema_growth(self):
        self.assertEqual(self.r["kernel_schema_additions"],0)
        self.assertTrue(self.r["audit_passed"])

if __name__=="__main__":
    unittest.main()
