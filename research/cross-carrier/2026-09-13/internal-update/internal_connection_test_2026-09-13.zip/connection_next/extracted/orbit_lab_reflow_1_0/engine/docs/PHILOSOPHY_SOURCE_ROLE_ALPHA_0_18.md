# Orbit Lab Alpha 0.18 — Philosophy / Source-Role Separation

Operator Moonshot's philosophy separation was used as an admission-pressure test.

## Earned failure

Alpha 0.17 could accept a source-role `PHILOSOPHY` Evidence object as empirical
support if the object simply carried the required empirical evidence tag.

Therefore evidence-kind qualification alone was insufficient.

## Smallest repair

Claims may now declare a task-local `evidence_source_role_contract`:

- allowed roles;
- forbidden roles;
- whether every cited evidence object must declare a role.

This role is local to the evidentiary relation. It is not a universal ontology of
the underlying source or concept.

The bounded probe demonstrates all four directions:

1. philosophy can motivate a Candidate question;
2. philosophy cannot support an empirical claim when the claim forbids that role;
3. empirical-result evidence can support the same empirical claim;
4. philosophy can support a descriptive claim about what the philosophy document says
   when that claim explicitly permits the philosophy role.

This preserves the source boundary rather than declaring philosophy irrelevant.

No new kernel object or Episode type was added.
