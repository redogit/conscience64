# Orbit Lab Alpha 0.12 — Current

Current consolidated checkpoint through the cross-shard Tree/Orbit generator-identity test.

Bounded result: recoverable recursive address != identified generator family/state. Extra state includes generator family, generator-specific parameters, and formation mechanism.

Validation: 145 regressions PASS; inherited Alpha 0.9 full selector 15/15 PASS; later direct branch probes PASS; direct S5 whole integration PASS; predecessor path continuity preserved.

Known remainder: the public selector process may linger under the current host wrapper after work completes.
