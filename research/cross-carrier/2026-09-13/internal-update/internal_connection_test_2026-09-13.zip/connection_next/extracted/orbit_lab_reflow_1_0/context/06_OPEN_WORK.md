# Open Work / Remainders

Only unresolved work that can change a future action belongs here.

## Orbit itself

- Human usability benefit of the Research Card has structural evidence but no formal human-subject usability study.
- The host/container wrapper can linger after complete selector JSON; root cause remains unresolved.
- Support retrieval is a routing/qualification capability, not a complete semantic index of the Library.

## Library

- Unclassified loose artifacts remain recoverable and should be opened only when a current obligation makes them relevant.
- A bounded search miss does not establish universal nonexistence.
- Private/ambiguous namespaces remain minimum-access.

## Finance sandbox

- The apparent low-exposure penny-stock boundary was discovered post hoc and needs unseen/holdout testing before it can even become a stronger paper rule.
- Real spreads, liquidity, taxes, country rules, broker constraints, and survivorship/data quality remain outside the development replay unless explicitly modeled.

## Parameter Differential Reflow

- PDR remains a candidate mechanism.
- Highest-value burden: compare full PDR with an otherwise identical fixed-parameter recurrent baseline to determine whether moving parameters add anything beyond recurrent context state.
- The repeated-row reflow's common-mode term is algebraically demonstrated; usefulness is not.

## SHADOW

- Preserve the bounded recovered campaign state and integrity stops.
- Do not turn recovery summaries into claim-specific primary evidence.
- At the recovery boundary used by Alpha 0.26, parent-campaign S0004 was pending and S0002 remained excluded.

## MoonShot repeated self-expansion

- The frozen bounded full claim was rejected by its confirmation experiment.
- Universal possibility/impossibility remains unresolved.
