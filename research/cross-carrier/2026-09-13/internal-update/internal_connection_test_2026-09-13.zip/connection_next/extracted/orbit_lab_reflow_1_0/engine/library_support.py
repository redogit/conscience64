from __future__ import annotations

from dataclasses import dataclass, asdict
from pathlib import Path
import csv
import json
import re
from collections import defaultdict

BASE = Path(__file__).resolve().parent
DATA = BASE / "data" / "library_support"
EDGES = DATA / "RECOVERY_LIBRARY_EDGES_v1.csv"
ANCHORS = DATA / "MOONSHOT_PROJECT_LEVEL_ASSOCIATION_ANCHORS_v1.json"
RELATION_SOURCE = BASE / "data" / "library_fold_stage2" / "sources" / "runtime_relation_index_non_corrupting_v1.md"

# These paths are intentionally excluded from automatic support search. They may
# be opened only for an explicit task/purpose that warrants the access.
DEFAULT_PRIVATE_NAMESPACES = (
    "/Homework",
    "/Your job is you move things from a to b.",
)

ASSOCIATION_TO_KIND = {
    "SOURCE_OR_EVIDENCE_ARTIFACT": "EVIDENCE_REFERENCE_CANDIDATE",
    "METHOD_CONTEXT": "METHOD_REFERENCE",
    "RECOVERY_OR_AUDIT_ARTIFACT": "RECOVERY_REFERENCE",
}

@dataclass(frozen=True)
class SupportCandidate:
    query: str
    target: str
    relation_kind: str
    status: str
    provenance: str
    scope: str
    file_id: str | None = None
    library_path: str | None = None
    recovery_file: str | None = None
    recovery_status: str | None = None
    basis: str = "association"
    can_self_certify_support: bool = False

    def as_dict(self) -> dict:
        return asdict(self)


def _norm(text: str) -> str:
    text = (text or "").casefold()
    text = re.sub(r"[^\w]+", " ", text, flags=re.UNICODE)
    return " ".join(text.split())


def _tokens(text: str) -> set[str]:
    return {x for x in _norm(text).split() if len(x) > 2}


def _private(path: str | None) -> bool:
    if not path:
        return False
    return any(path == p or path.startswith(p + "/") for p in DEFAULT_PRIVATE_NAMESPACES)


def load_edges() -> list[dict]:
    with EDGES.open(newline="", encoding="utf-8-sig") as f:
        return list(csv.DictReader(f))


def load_anchors() -> list[dict]:
    data = json.loads(ANCHORS.read_text(encoding="utf-8"))
    return data.get("anchors", [])


def static_summary() -> dict:
    rows = load_edges()
    return {
        "rows": len(rows),
        "resolved_exact": sum(r["resolution_status"] == "RESOLVED_EXACT_LIBRARY_ID" for r in rows),
        "resolved_file_ids": len({r["library_file_id"] for r in rows if r["library_file_id"]}),
        "association_classes": dict(sorted(__import__('collections').Counter(r["association_class"] for r in rows).items())),
        "private_namespaces_excluded_by_default": list(DEFAULT_PRIVATE_NAMESPACES),
        "relation_index_source_present": RELATION_SOURCE.exists(),
    }


def exact_reference_candidates(query: str, *, include_private: bool = False,
                               include_unresolved: bool = True) -> list[SupportCandidate]:
    """Return exact/declared association references only.

    The association map is a locator. Even SOURCE_OR_EVIDENCE_ARTIFACT rows are
    returned as evidence *reference candidates*, never as scientific support.
    """
    qn = _norm(query)
    if not qn:
        return []
    out: list[SupportCandidate] = []
    seen = set()
    for row in load_edges():
        fields = [row.get("recovery_file", ""), row.get("source_title", ""),
                  row.get("declared_reference", ""), row.get("normalized_name", ""),
                  row.get("library_file_id", ""), row.get("library_path", "")]
        exact = any(qn == _norm(x) for x in fields if x)
        contains = any(qn in _norm(x) for x in fields if x and len(qn) >= 5)
        if not (exact or contains):
            continue
        path = row.get("library_path") or None
        if _private(path) and not include_private:
            continue
        resolved = row.get("resolution_status") == "RESOLVED_EXACT_LIBRARY_ID"
        if not resolved and not include_unresolved:
            continue
        kind = ASSOCIATION_TO_KIND.get(row.get("association_class", ""), "RELATED_REFERENCE")
        status = "verified-reference" if resolved else "unresolved"
        target = path or row.get("normalized_name") or row.get("declared_reference") or row.get("recovery_file")
        key = (kind, target, row.get("recovery_file"), status)
        if key in seen:
            continue
        seen.add(key)
        out.append(SupportCandidate(
            query=query,
            target=target,
            relation_kind=kind,
            status=status,
            provenance="MOONSHOT_RECOVERY_LIBRARY_ASSOCIATION_MAP_v1 / RECOVERY_LIBRARY_EDGES_v1",
            scope=row.get("source_title") or row.get("recovery_file") or "recovery association",
            file_id=row.get("library_file_id") or None,
            library_path=path,
            recovery_file=row.get("recovery_file") or None,
            recovery_status=row.get("recovery_status") or None,
            basis="exact-association" if exact else "bounded-text-association",
            can_self_certify_support=False,
        ))
    return out


def lexical_route_candidates(query: str, *, limit: int = 12,
                             include_private: bool = False) -> list[SupportCandidate]:
    """Find nearby association-map rows by token overlap.

    These are explicitly RELATED_ONLY / search-routing candidates. This is not
    evidence matching and cannot establish support or identity.
    """
    qt = _tokens(query)
    if not qt:
        return []
    scored = []
    for row in load_edges():
        path = row.get("library_path") or None
        if _private(path) and not include_private:
            continue
        hay = " ".join([row.get("source_title", ""), row.get("recovery_file", ""),
                        row.get("normalized_name", ""), row.get("declared_reference", "")])
        ht = _tokens(hay)
        overlap = len(qt & ht)
        if not overlap:
            continue
        union = len(qt | ht) or 1
        score = overlap / union
        scored.append((score, overlap, row))
    scored.sort(key=lambda x: (-x[0], -x[1], x[2].get("normalized_name", "")))
    out=[]; seen=set()
    for score, overlap, row in scored:
        target = row.get("library_path") or row.get("normalized_name") or row.get("declared_reference")
        key=(target,row.get("recovery_file"))
        if key in seen: continue
        seen.add(key)
        out.append(SupportCandidate(
            query=query,
            target=target,
            relation_kind="RELATED_ONLY",
            status="candidate",
            provenance="lexical routing over RECOVERY_LIBRARY_EDGES_v1",
            scope=row.get("source_title") or row.get("recovery_file") or "association neighborhood",
            file_id=row.get("library_file_id") or None,
            library_path=row.get("library_path") or None,
            recovery_file=row.get("recovery_file") or None,
            recovery_status=row.get("recovery_status") or None,
            basis=f"lexical-overlap:{overlap};score:{score:.4f}",
            can_self_certify_support=False,
        ))
        if len(out)>=limit: break
    return out


def support_search_plan(query: str, *, project: str | None = None,
                        include_private: bool = False) -> dict:
    """Produce the staged search contract used by a connected Library caller."""
    exact = [x.as_dict() for x in exact_reference_candidates(query, include_private=include_private)]
    nearby = [x.as_dict() for x in lexical_route_candidates(query, include_private=include_private)]
    return {
        "query": query,
        "project_hint": project,
        "automatic_private_access": include_private,
        "private_namespaces_excluded": [] if include_private else list(DEFAULT_PRIVATE_NAMESPACES),
        "stages": [
            {
                "stage": 1,
                "name": "identity-and-declared-lineage",
                "rule": "stable file/library id > exact path/hash > exact filename > unresolved pointer; semantic similarity is not identity",
                "candidates": exact,
            },
            {
                "stage": 2,
                "name": "bounded-neighborhood-discovery",
                "rule": "lexical/semantic proximity may propose routes only; preserve ambiguity and provenance",
                "candidates": nearby,
                "dynamic_library_action": "search Library for primary evidence, dependencies, contradictions, predecessors/successors, applications, and helper methods using the item's own terminology and provenance",
            },
            {
                "stage": 3,
                "name": "qualification",
                "rule": "open the candidate source and classify the tested relation; related != supports; method != empirical evidence; recovery locator != primary evidence",
            },
            {
                "stage": 4,
                "name": "claim-bounded-return",
                "rule": "return supporting, contradicting, historical, method, helper, and unresolved items separately; do not merge them into one confidence score",
            },
        ],
        "claim_ceiling": [
            "This plan can find candidate supporting items; it does not itself establish scientific support.",
            "Association-map SOURCE_OR_EVIDENCE_ARTIFACT means a candidate evidence route, not evidence sufficiency for a particular claim.",
            "Unresolved pointers remain unresolved; semantic similarity cannot substitute an identity.",
            "Private/work namespaces are excluded by default and require an explicit task/purpose to widen access.",
        ],
    }


def render(query: str) -> str:
    plan=support_search_plan(query)
    exact=plan["stages"][0]["candidates"]
    near=plan["stages"][1]["candidates"]
    lines=[f"Library support search: {query}"]
    if exact:
        lines.append("\nDeclared/exact routes:")
        for c in exact[:8]:
            lines.append(f"- {c['relation_kind']}: {c['target']} [{c['status']}]\n  basis: {c['basis']}")
    else:
        lines.append("\nNo exact declared route in the static association seed.")
    if near:
        lines.append("\nNearby routes (candidate discovery only):")
        for c in near[:6]:
            lines.append(f"- {c['target']} ({c['basis']})")
    lines += [
        "\nNext: widen with a bounded Library search, then inspect the candidate source before calling it support.",
        "Boundary: related != supports; lookup != evidence; retrieval != proof.",
    ]
    return "\n".join(lines)

if __name__ == "__main__":
    import argparse
    ap=argparse.ArgumentParser()
    ap.add_argument("query", nargs="+")
    ap.add_argument("--json", action="store_true")
    args=ap.parse_args()
    q=" ".join(args.query)
    print(json.dumps(support_search_plan(q), indent=2, sort_keys=True) if args.json else render(q))
