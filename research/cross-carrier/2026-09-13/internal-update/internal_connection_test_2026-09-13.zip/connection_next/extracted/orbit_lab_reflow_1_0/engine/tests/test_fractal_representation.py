
import unittest
from checks.fractal_representation_probe import run

class FractalRepresentationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.r=run()

    def test_registered_bounded_roundtrip(self):
        self.assertEqual(self.r["cases_tested"],123032)
        self.assertEqual(self.r["scaled_integer_decoder_failures"],0)

    def test_original_floor_decoder_failure_is_preserved(self):
        self.assertGreater(self.r["original_floor_decoder_failures"],0)

    def test_stronger_claims_remain_blocked(self):
        self.assertTrue(self.r["address_roundtrip_does_not_certify_3d_generator"])
        self.assertTrue(self.r["simulation_timestep_does_not_certify_physical_timing"])
        self.assertTrue(self.r["implemented_detector_does_not_certify_measured_behavior"])
        self.assertTrue(self.r["raw_bit_accounting_does_not_certify_channel_capacity"])

    def test_no_schema_growth_required(self):
        self.assertEqual(self.r["kernel_schema_additions"],0)
        self.assertTrue(self.r["audit_passed"])

if __name__=="__main__":
    unittest.main()
