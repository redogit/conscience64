# Orbit Lab Alpha 0.12 — Generator Identity Boundary Candidate

The companion 3D Tree/Orbit recovery was connected to the verified fractal
address decoder.

A fixed recursive address was held constant while generator state varied:

- Tree: branch-gene angle/scale state + recursive formation mechanism.
- Orbit: recurrence and 3D embedding parameters + iterative formation mechanism.

The address remained identical while the generator states were materially
different.

Therefore the address carrier has a precise ceiling:

`recoverable recursive address != identified generator family/state`.

Extra state required for the tested distinction includes generator family,
generator-specific parameters, and formation mechanism.

No new kernel type was required. Existing qualified evidence and ObservationFrame
boundaries were sufficient.

The source recovery's runtime boundary remains intact: this probe does not claim
the final React Tree/Orbit/Hybrid artifact compiled or rendered successfully.
