# Orbit Lab Alpha 0.16 — Current

Alpha 0.16 extends Alpha 0.15's task-local verification carrier to research retrieval.

Bounded retrieval relation:

```text
question / obligation
    -> project identity
    -> source role
    -> smallest sufficient source neighborhood
    -> required distinctions + provenance
    -> widen only on consequential insufficiency
```

Five-source experiment:
- One_Level_Up current addendum
- CSOL START_HERE
- MoonShot atlas recovery
- R³ Agent method
- Operator Moonshot recovery mapping

Results:
- narrow answers matched broad five-source decision signatures on all 5 tasks;
- mean source-byte reduction ~7.75x; median ~8.60x;
- cross-project source swaps were blocked;
- missing primary sources widened and then remained UNRESOLVED rather than substituting adjacent vocabulary;
- method source could not stand in for empirical/recovery evidence;
- research-retrieval verification activates only core-sentinel + retrieval-neighborhood;
- 165/165 regressions PASS;
- direct S5 whole integration PASS;
- no new kernel schema type.

This is a finite source-role retrieval result, not a universal retrieval-optimality claim.
