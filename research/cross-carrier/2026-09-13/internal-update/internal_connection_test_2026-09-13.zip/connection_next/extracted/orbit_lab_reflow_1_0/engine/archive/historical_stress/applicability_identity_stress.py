
import tempfile
from pathlib import Path
from orbit_lab import OrbitLab

with tempfile.TemporaryDirectory() as td:
    lab=OrbitLab(Path(td)/"stress.db")
    passes=[]; breaks=[]
    try:
        c=lab.add("Context","Current context",provenance_class="TEST",provenance="stress",identity_key="c")
        recovery=lab.add("Scope","Recovery",provenance_class="TEST",provenance="stress",identity_key="recovery")
        old=lab.add("Method","Recovery Prompt v2",provenance_class="RECOVERY_PACKET",provenance="history",identity_key="old")
        new=lab.add("Method","Current one-conversation recovery procedure",provenance_class="CURRENT_CONVERSATION",provenance="current",identity_key="new")
        packet=lab.add("Artifact","schema-valid predecessor packet",data={"schema_valid":True},
                       provenance_class="PRIMARY_ARTIFACT",provenance="packet",identity_key="packet")
        basis=lab.add("Evidence","replacement status",provenance_class="PRIMARY_ARTIFACT",
                      provenance="status",identity_key="basis",epistemic="OBSERVED")
        lab.assess_method_compliance(context_id=c,entity_id=packet,method_id=old,scope_id=recovery,
            verdict="PREDECESSOR",basis_entity_ids=[basis],reason="method-stale but structurally valid",
            provenance_class="DERIVED",provenance="stress")
        lab.record_replacement(predecessor_entity_id=old,successor_entity_id=new,scope_id=recovery,
            relation="AUTHORITY_REPLACEMENT",basis_entity_ids=[basis],reason="replacement for recovery authority",
            provenance_class="DERIVED",provenance="stress")
        passes.append("Structural validity, method status, and scope-bounded replacement no longer collapse.")

        # Applicability pressure: an old method may remain historically supported while no longer
        # applicable because environment/tool/definition assumptions changed.
        historical=lab.add("Evidence","Method worked under environment E1",
                           data={"environment":"E1","tool_version":"1"},
                           provenance_class="PRIMARY_ARTIFACT",provenance="history",
                           identity_key="historical",epistemic="OBSERVED")
        current_env=lab.add("Artifact","Current environment E2",
                            data={"environment":"E2","tool_version":"2"},
                            provenance_class="CURRENT_CONVERSATION",provenance="current",
                            identity_key="current-env")
        breaks.append(
            "Method compliance is now explicit, but historical support vs current applicability still has "
            "no typed ValidityFrame. Context can contain environment facts, yet the kernel cannot state which "
            "assumptions/tools/definitions/domain made an old result applicable or prove that the frame changed."
        )

        # Identity pressure: two byte-identical artifacts can be distinct historical occurrences.
        a1=lab.add("Artifact","integration map copy A",data={"sha256":"samehash"},
                   provenance_class="PRIMARY_ARTIFACT",provenance="path:A",identity_key="occ:A")
        a2=lab.add("Artifact","integration map copy B",data={"sha256":"samehash"},
                   provenance_class="PRIMARY_ARTIFACT",provenance="path:B",identity_key="occ:B")
        breaks.append(
            "Artifact identity still mixes content and occurrence. Two objects can share a hash, but the kernel "
            "has no first-class ContentIdentity/Custody relation to say 'same bytes, different occurrence'."
        )

        print("V0.21 METHOD / NEXT-PRESSURE STRESS")
        print("-----------------------------------")
        print("PASS:")
        for x in passes: print("-",x)
        print("\nNEXT PRESSURES:")
        for i,x in enumerate(breaks,1): print(f"{i}. {x}")
    finally:
        lab.close()
