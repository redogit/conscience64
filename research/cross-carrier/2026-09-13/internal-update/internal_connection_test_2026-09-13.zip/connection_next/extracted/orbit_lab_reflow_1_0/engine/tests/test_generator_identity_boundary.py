
import unittest
from checks.generator_identity_boundary_probe import run

class GeneratorIdentityBoundaryTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.r=run()

    def test_same_address_different_generator_states(self):
        self.assertTrue(self.r["same_recursive_address"])
        self.assertTrue(self.r["distinct_generator_states"])

    def test_address_does_not_identify_generator(self):
        self.assertTrue(self.r["address_only_cannot_certify_generator_identity"])

    def test_runtime_boundary_preserved(self):
        self.assertFalse(self.r["final_react_runtime_claimed"])

    def test_no_schema_growth(self):
        self.assertEqual(self.r["kernel_schema_additions"],0)
        self.assertTrue(self.r["audit_passed"])

if __name__=="__main__":
    unittest.main()
