
import json, tempfile, unittest
from pathlib import Path
from verification_carrier import PROFILES, audit_carrier, plan, compile_carrier, registry_digest

class VerificationCarrierTests(unittest.TestCase):
    def test_carrier_audits_and_all_profiles_cover(self):
        a=audit_carrier()
        self.assertTrue(a["passed"])
        self.assertEqual(a["uncovered"],[])

    def test_unknown_obligation_refuses_certification(self):
        p=plan(["does-not-exist"])
        self.assertFalse(p["passed"])
        self.assertEqual(p["reason"],"UNCOVERED_OBLIGATION")

    def test_narrow_plan_does_not_activate_full_regression(self):
        p=plan(PROFILES["campaign-integrity"])
        self.assertTrue(p["passed"])
        self.assertIn("core-sentinel",p["probes"])
        self.assertIn("shadow-integrity",p["probes"])
        self.assertNotIn("compile+regression",p["probes"])
        self.assertLessEqual(p["active_probe_count"],2)

    def test_removing_required_provider_leaves_obligation_uncovered(self):
        # Mutate the binary carrier directly: zero the incidence bits for the
        # SHADOW denominator obligation. Digest/semantic registry audit must fail
        # or planning must refuse coverage.
        src=Path("data/verification_carrier.bin")
        blob=bytearray(src.read_bytes())
        n=int.from_bytes(blob[:4],"little")
        header=json.loads(blob[4:4+n])
        from verification_carrier import ROW
        target=header["obligations"].index("declared-denominator-linked")
        body=4+n
        for off in range(body,len(blob),ROW.size):
            oi,bits=ROW.unpack(bytes(blob[off:off+ROW.size]))
            if oi==target:
                blob[off:off+ROW.size]=ROW.pack(oi,0)
                break
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/"mut.bin"; p.write_bytes(blob)
            x=plan(["declared-denominator-linked"],p)
            self.assertFalse(x["passed"])

    def test_recompile_is_deterministic(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/"c.bin"
            a=compile_carrier(p); first=p.read_bytes()
            b=compile_carrier(p); second=p.read_bytes()
            self.assertEqual(first,second)
            self.assertEqual(a["sha256"],b["sha256"])

if __name__=="__main__":
    unittest.main()
