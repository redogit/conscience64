
import tempfile
from pathlib import Path
import unittest
from orbit_lab import OrbitLab
class V23Tests(unittest.TestCase):
    def setUp(self): self.tmp=tempfile.TemporaryDirectory(); self.lab=OrbitLab(Path(self.tmp.name)/"t.db")
    def tearDown(self): self.lab.close(); self.tmp.cleanup()
    def test_same_content_different_occurrence(self):
        content=self.lab.register_content(algorithm="sha256",digest="abc123",provenance_class="TEST",provenance="test")
        a=self.lab.record_occurrence(content_id=content,locator="/A/map.md",provenance_class="TEST",provenance="test",identity_key="occ:A")
        b=self.lab.record_occurrence(content_id=content,locator="/B/map.md",provenance_class="TEST",provenance="test",identity_key="occ:B")
        self.assertNotEqual(a,b)
        self.assertTrue(self.lab.same_content(a,b))
        self.assertEqual(self.lab.content_of_occurrence(a),content)
    def test_register_content_dedupes_digest(self):
        a=self.lab.register_content(algorithm="sha256",digest="abc123",provenance_class="TEST",provenance="one")
        b=self.lab.register_content(algorithm="sha256",digest="abc123",provenance_class="TEST",provenance="two")
        self.assertEqual(a,b)
if __name__=="__main__": unittest.main()
