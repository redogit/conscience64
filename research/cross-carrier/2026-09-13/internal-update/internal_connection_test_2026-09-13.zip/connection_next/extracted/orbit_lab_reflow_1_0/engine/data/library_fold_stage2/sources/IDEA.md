# Parameter Differential Reflow

**Status:** Experimental mechanism — clean baseline captured 2026-09-04  
**Purpose of this file:** Preserve the idea independently of any one implementation so it can be revised without losing the tested structure or confusing implementation choices with the mechanism itself.

## Essence

Parameter Differential Reflow (PDR) is a **stateful recurrent projection-and-context mechanism** with two levels of parameter state:

1. **Base projection matrices** provide a stable reference.
2. **Active projection matrices** are allowed to move in response to each input, while continuously decaying back toward the base reference.

Each input therefore has two roles: it is the signal being processed, and it produces a bounded differential change in the active projection state. Context is not retained as a growing token cache; it is compressed into fixed-size per-head recurrent accumulators. The previous output becomes the next query.

The intended question is not "is this a Transformer?" but:

> Can a small recurrent system gain useful short-term adaptation by letting its projection parameters reflow around a stable base while a fixed-size context state integrates what was seen?

## Current mathematical baseline

For input vector \(x_t\), active key/value projections \(W^K_t,W^V_t\), and stable base matrices \(B^K,B^V\):

\[
W^K_t = dW^K_{t-1} + (1-d)B^K + r\,\mathbf{1}x_t^T
\]

\[
W^V_t = dW^V_{t-1} + (1-d)B^V + r\,\mathbf{1}x_t^T
\]

where:

- \(d\) = parameter/state decay,
- \(r\) = reflow gain,
- \(\mathbf{1}x_t^T\) repeats the input-shaped differential across projection rows.

The current projections are:

\[
k_t = W^K_t x_t, \qquad v_t = W^V_t x_t
\]

and the recurrent query is:

\[
q_t = y_{t-1}.
\]

A positive feature map is used:

\[
\phi(a)=\operatorname{ELU}(a)+1
\]

or equivalently elementwise:

\[
\phi(a)=
\begin{cases}
e^a,&a<0\\
a+1,&a\ge 0.
\end{cases}
\]

For each head, fixed-size context state is updated as:

\[
S_t = dS_{t-1} + \phi(k_t)v_t^T
\]

\[
z_t = dz_{t-1} + \phi(k_t).
\]

The output is:

\[
y_t = \frac{\phi(q_t)^T S_t}{\max(\phi(q_t)^Tz_t,\epsilon)}.
\]

This produces a recurrent linear-attention-like state with constant memory in sequence length.

## Essential structure to preserve during experiments

These are the current defining relations of the idea:

- **Stable reference + active parameter state.** Active parameters may move; the base remains an anchor.
- **Input-dependent parameter differential.** The current signal changes the active projection state.
- **Reflow toward the base.** Without continued evidence/input, active parameters move back toward their reference.
- **Recurrent query.** The previous output is fed back as the next query.
- **Fixed-size contextual accumulator.** History is compressed into per-head state rather than retained as an ever-growing cache.
- **Matched context decay.** The state matrix and its normalizer use the same historical decay so numerator and denominator represent the same weighting of history.
- **Independent K and V base projections.** They must not accidentally begin identical through repeated random seeding.

Anything else should be treated as an implementation choice or experimental variable unless evidence promotes it to a required role.

## Important structural consequence of the current reflow rule

Because the current differential is repeated across every projection row,

\[
\Delta W_t = r\,\mathbf{1}x_t^T,
\]

projecting the same input immediately after reflow contributes

\[
\Delta W_t x_t = r\|x_t\|^2\mathbf{1}.
\]

So every projected component receives the same input-energy-dependent common-mode term. This is a **demonstrated algebraic consequence of the present rule**, not evidence that the rule is useful.

For a constant input and \(0<d<1\), the active-weight displacement approaches approximately

\[
\frac{r}{1-d}\mathbf{1}x^T.
\]

With the current defaults \(d=0.995\) and \(r=0.01\), the steady-state multiplier is \(2\). This means the nominally small per-step reflow can become consequential under repeated input.

## Current implementation baseline

The current rewritten C# implementation intentionally favors correctness and inspectability over low-level pointer optimization:

- .NET 8-compatible C#.
- Managed reusable arrays instead of exposed unmanaged pointers.
- Portable `System.Numerics.Vector<float>` SIMD when available.
- Scalar tail handling, so dimensions need not be multiples of SIMD width.
- Independent K/V initialization.
- Finite-input and dimension validation.
- Matching decay of context matrix and normalizer.
- Caller-owned output storage through `Span<float>`.
- Reusable buffers to avoid per-step allocation in the main `Step` path.
- Resettable recurrent state.
- Synchronized access and disposal checks.

These choices are **not the essence of PDR**. They are the current safe reference implementation.

## Variables that should remain experimentally separable

- Reflow gain \(r\).
- Decay \(d\).
- Whether parameter decay and context decay should share one coefficient or be independently controlled.
- Reflow timing: update-before-projection versus update-after-projection.
- Reflow geometry: repeated-row/rank-1 input injection versus learned, gated, signed, low-rank, head-local, or orthogonalized differentials.
- Whether K and V should receive the same differential.
- Query source: previous output versus projected current input versus a mixture.
- Feature map \(\phi\).
- Number of heads and head dimension.
- State reset/retention policy.

Change one consequential relation at a time when possible, and record the observed relation rather than globally declaring the whole architecture better or worse.

## Highest-value open questions

1. **Does parameter reflow carry information that the recurrent context state does not already capture?** Compare full PDR against an otherwise identical fixed-parameter recurrent baseline.
2. **Is the common-mode \(r\|x\|^2\mathbf{1}\) term useful, neutral, or harmful?** Replace only the repeated-row reflow geometry while preserving the rest of the system.
3. **Does reflow-before-projection create beneficial self-adaptation or merely self-interaction?** Counter-test update-after-projection.
4. **Should K and V reflow differently?** The present rule gives both the same input-shaped differential even though their bases are independent.
5. **What is the stable operating region in \((d,r)\)?** Measure boundedness, sensitivity, recovery to base, and long-run numerical behavior.
6. **What is gained per unit state/parameter cost?** Compare against a conventional recurrent linear-attention state of the same dimensional budget.
7. **What failures disappear specifically because active parameters can move?** This is the burden of proof for keeping parameter reflow as architecture rather than treating it as an interesting perturbation.

## Minimal experimental record

For every revision, preserve:

- **Baseline:** exact prior mechanism/version.
- **Change:** the one relation or parameter changed.
- **Observation:** what measurably changed.
- **Counter-probe:** reverse, remove, or minimally perturb the change.
- **Failure modes:** instability, collapse, common-mode domination, loss of memory, runaway state, numerical failure, or no measurable benefit.
- **Remainder:** what remains unexplained.
- **Verdict on the tested relation:** preserve, modify, remove, or unresolved.

Do not promote resemblance, intuition, or implementation complexity into evidence.

## Identity of this artifact

This file is the canonical **idea-level record**. The source code in `source/` is a snapshot of one implementation. The zip in `snapshots/` is retained only for reproducibility and transfer. Future updates should edit or supersede this idea record while preserving dated prior snapshots when a change is experimentally meaningful.
