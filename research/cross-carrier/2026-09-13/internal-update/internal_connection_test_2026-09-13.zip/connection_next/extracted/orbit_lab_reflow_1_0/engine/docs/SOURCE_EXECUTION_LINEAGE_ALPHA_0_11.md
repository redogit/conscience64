# Orbit Lab Alpha 0.11 — Source / Execution / Repair Lineage Candidate

Compact Branching Geometry was historically source-only. That historical state is preserved.

A new Orbit Lab execution of the exact recovered user source found:
1. original source fails on row assignment shape;
2. one-degree row-packing repair exposes a second child-length shape mismatch;
3. second one-degree repair executes deterministically through D=10;
4. the earlier integer-cast fragment can then be applied as a separate candidate and changes only lineage dtypes.

The original source, repair 1, and repair 2 are stored as distinct content identities linked by DERIVED_FROM.

Static source text cannot satisfy a claim requiring EXECUTED_RUNTIME_BEHAVIOR.

No kernel schema change was required.
