
import unittest
from checks.source_execution_lineage_probe import run

class SourceExecutionLineageTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.r=run()

    def test_historical_unknown_not_rewritten(self):
        self.assertEqual(self.r["historical_execution_status"],"UNKNOWN")

    def test_failures_and_repairs_are_distinct(self):
        self.assertIsNotNone(self.r["original_runtime_failure_now"])
        self.assertIsNotNone(self.r["repair_1_runtime_failure"])
        self.assertIsNone(self.r["repair_2_runtime_failure"])
        self.assertTrue(self.r["three_content_identities_remain_distinct"])

    def test_static_source_not_runtime_evidence(self):
        self.assertTrue(self.r["static_source_cannot_certify_runtime_behavior"])

    def test_typed_candidate_is_bounded_change(self):
        self.assertTrue(self.r["typed_return"]["preserves_numeric_values"])
        self.assertTrue(self.r["typed_return"]["preserves_other_columns"])
        self.assertEqual(set(self.r["typed_return"]["candidate_lineage_dtypes"].values()),{"int64"})

if __name__=="__main__":
    unittest.main()
