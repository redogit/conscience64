# Orbit Lab alpha 0.3 — Supporter Ecology

## Why diversify

Orbital GANs are good at adversarial composition pressure, but a research system can
fail in ways that an adversary is not the best instrument for. Alpha 0.3 adds helpers
whose mechanisms differ rather than merely giving several reviewers different names.

## Active supporter mechanisms

1. Exposure Custodian — temporal truth-access / holdout history.
2. Mutation Sentinel — persistence corruption and audit sensitivity.
3. Observer Ensemble — observation-frame / representation dependence.
4. Replay Custodian — state export/import differential replay.
5. Resource Accountant — multi-objective/Pareto resource accounting.
6. Wrapper Decomposer — component outcome vs wrapper outcome.
7. Residual Scout — preserves UNEXPLAINED remainders.
8. Bounded Explorer — exhaustive finite reference models.
9. Metamorphic Tester — transformations that should preserve consequences.
10. Counterfactual Referee — matched experimental construction.
11. Baseline Champion — local intervention benefit vs stronger comparator.
12. Grounding Oracle — internal agreement vs external truth.
13. Regime Scout — threshold/nonstationarity/boundary maps.
14. Counterexample Shrinker — delta-debugging minimal witnesses.
15. Independence Auditor — correlation and role-separation disclosure.
16. Ecology Auditor — mechanism-diversity accounting.

Orbital GANs remain available as a separate generative-adversarial supporter family.

## Findings earned by diversification

The first ecology pass found four issues not all exposed by the GAN population:
- holdout exposure leaked across disjoint cycles;
- history deletion was neither blocked nor audited;
- FAILURE records lacked ObservationFrame;
- UNEXPLAINED residual status was not representable.

After those repairs, the wider ecology exposed one more:
- MATCHED_COUNTERFACTUAL accepted a TOOL_FAILED arm.

All five are now regressions.

## Pressures retained without forced repair

Five current pressures remain intentionally non-promoted:
- resource tradeoffs can be Pareto-incomparable;
- wrapper success can mask component error;
- a local ablation benefit can coexist with loss to a stronger baseline;
- internal consensus cannot certify externally supplied truth;
- one global status can hide regime/threshold changes.

These affect how claims should be tested or routed, but do not yet force one new kernel object.

## Helper routing

`supporter_router.py` uses a small cost-aware set-cover router. It selects a useful
mechanism mix for:
- faithful transport;
- adaptive architecture;
- schema change;
- holdout experiments;
- language/representation work;
- pipeline/wrapper work.

The router explicitly reports that the built-in helpers share runtime lineage.
Mechanism diversity is not called independent replication.

## Run

```bash
python supporter_ecology.py
python supporter_router.py
python orbital_gans.py
python supporter_alpha_gate.py
```
