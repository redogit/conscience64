# Orbit Lab Alpha 0.16 — Selective Research Retrieval Candidate

Alpha 0.15 compressed verification activation. Alpha 0.16 applies the same distinction
to research retrieval.

Bounded corpus:
- One_Level_Up current addendum
- CSOL START_HERE
- MoonShot atlas recovery
- R³ Agent method
- Operator Moonshot recovery mapping

For each declared question:
`question -> project identity -> source role -> required facts -> provenance`

The broad control loads all five compact source heads. The narrow path loads only the
project/source role that can reconstruct the required distinction.

A nearby project is not permitted to substitute merely because its vocabulary overlaps.
If the primary source is unavailable or inadequate, the carrier widens. If the widened
neighborhood still cannot satisfy the source contract, the result is UNRESOLVED.

This is a bounded retrieval experiment, not a universal semantic-search result.
