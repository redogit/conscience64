# Orbit Lab Alpha 0.19 — X-LS-002 Weaker Recoding

The previously planned X-LS-002 weaker-recoding experiment was executed from the
exact X-LS-001 frozen_v2 panel.

The original X-LS-001 result was first rerun unchanged and its result-summary bytes
matched the archived result exactly.

Then the nine named state fields were replaced by:

`(probe_type, probe_state)`

where `probe_type` selects the one field that the frozen router already used.

Results:
- 54/54 exact stipulated route matches;
- exact same serializer partition as the nine-field L1 representation;
- 18 semantic atoms;
- 171 unordered pairwise cross-probe compositions tested;
- 0 composition aliases relative to the nine-field representation;
- serialized bytes: 24,156 -> 2,772 (~8.71x smaller);
- named state fields: 9 -> 1.

Therefore nine separately named state fields are not justified as the weaker sufficient
serializer on this frozen constructed panel.

This does not validate the stipulated routes as real-world actions, does not establish
open-world sufficiency, and does not establish global minimality.
