# OPERATOR MOONSHOT — STRUCTURED CROSS-CHAT RECOVERY PROMPT

Version: 2.0-structured
Purpose: recover evidence, ideas, experiment data, provenance, failures, contradictions, and reusable structures from one historical chat without rewriting history or continuing that chat's research.

## Governing objective

Recover the largest faithful evidence mass while presenting it through the smallest useful structure.

**Recover first. Interpret second. Preserve uncertainty.**

Do not continue the old project during this pass. Do not clean history into a theory. Do not promote repeated language into evidence. Do not convert a later Moonshot vocabulary into the historical observation itself.

The human-facing recovery surface is:

`SITUATION -> WHAT WERE WE TRYING TO DO? -> WHAT HAD TO REMAIN TRUE? -> WHAT HELPED / MIGHT HELP? -> WHAT DID WE TRY? -> WHAT ACTUALLY HAPPENED? -> WHAT CHANGED? -> WHAT REMAINS OPEN?`

The machine-facing lineage is:

`Human Situation -> Human Instruction -> Prompt -> Context Package -> Environment -> Workspace -> Tool/Agent Actions -> Execution -> Artifact -> Evidence -> Claim/Decision`

Preserve only the parts of that chain actually recoverable from this conversation. Never infer hidden prompt, context, environment, private reasoning, or execution state.

---

## 1. Establish the recovered Situation

Before cataloguing objects, reconstruct the smallest faithful Situation frame supported by this chat:

- **What was happening?**
- **What was the user trying to accomplish?**
- **Who or what was affected?**
- **What constraints/costs mattered?**
- **What did the conversation treat as something that must remain true?**
- **What uncertainty or decision drove the work?**
- **What changed over the course of the chat?**

If these changed materially, create multiple chronological Situations rather than flattening them into one.

---

## 2. Recover provenance before interpretation

For every important experiment, artifact, claim, decision, prompt, or result, recover as much of the provenance chain as observable evidence permits:

- source Situation;
- user instruction;
- assistant proposal or rendered prompt, when visible;
- supplied context/files/messages, when visible;
- environment/runtime/tool/model facts only when explicitly available;
- commands/tool/agent actions, when observable;
- execution/result;
- produced artifact and artifact identity/path/hash if available;
- evidence record;
- claim or decision derived from that evidence.

Use one of these lineage completeness labels:

- `DIRECT` — directly observable chain for the relevant step;
- `PARTIAL` — some required links are absent;
- `RECONSTRUCTED` — explicitly reconstructed from observable clues;
- `UNKNOWN` — lineage cannot be responsibly recovered.

Keep these distinctions explicit:

`USER_SAID`
`ASSISTANT_PROPOSED`
`ACTUALLY_TESTED`
`ACTUALLY_OBSERVED`
`EXTERNAL_SOURCE`
`DERIVED_INFERENCE`

Do not silently merge them.

---

## 3. Recover chronologically

Read from the earliest relevant point forward and recover:

- goals and changes of goal;
- constraints and affected reality;
- experiments and test runs;
- hypotheses;
- observations and measurements;
- failures, nulls, confounds, tool failures, interruptions, and blocked work;
- counterexamples;
- implementation attempts;
- architectures, algorithms, representations, datasets, and generated panels;
- ablations, interventions, inversions, randomizations, comparisons, and transfer tests;
- invariants and recurring transformations;
- ideas, conjectures, analogies, and cross-domain imports;
- user corrections that materially changed the work;
- changes of mind caused by evidence;
- artifacts, code, files, ledgers, hashes, reports, plots, or tables;
- claims later weakened, superseded, contradicted, or rejected;
- unresolved questions;
- procedures that reduced effort;
- potentially reusable carriers, bridges, or compositions;
- material that does not fit the current ontology.

Do not limit recovery to things already called "evidence" or "Moonshot".

---

## 4. Preserve epistemic status

Every recovered item receives one or more statuses as justified:

- `OBSERVED`
- `EXPERIMENTAL_RESULT`
- `FAILED_RESULT`
- `NULL_RESULT`
- `USER_OBSERVATION`
- `IDEA`
- `HYPOTHESIS`
- `INFERENCE`
- `OPEN_QUESTION`
- `PROCEDURE`
- `ARTIFACT`
- `SUPERSEDED`
- `UNCLASSIFIED_RECOVERED_SIGNAL`

Execution status remains separate when recoverable:

`PLANNED`, `RUNNING`, `PASSED`, `FAILED`, `NULL`, `CONFOUNDED`, `TOOL_FAILED`, `BLOCKED`, `ARCHIVED`.

If an item may matter but cannot be classified safely, preserve it as `UNCLASSIFIED_RECOVERED_SIGNAL`.

---

## 5. Route the recovered material through the applicability structure

Do not merely list files or topics. For each important recovered thing, ask:

### Obligation
**What behavior/outcome did this need to preserve?**

Do not confuse an implementation with an obligation.

### Helper / Carrier
**What could help carry that obligation?**

A Helper is a candidate source of help. Call it a Carrier only when bounded evidence supports that it actually preserved the obligation/distinction within scope.

### Bridge
**How could a source structure apply in the target context?**

Record the mapping, preserved distinctions, prerequisites, and known obstructions. A similarity is not automatically a Bridge.

### Composition
**Did usefulness belong to several things together?**

Preserve `JOINT`, `ORDERED`, `CONDITIONAL`, `REDUNDANT`, `SYNERGISTIC`, `INHIBITORY`, `ALTERNATIVE`, or `FALLBACK` relations when evidence warrants them. Singleton failure does not establish joint failure.

### Obstruction
**What stopped an attempted route from satisfying the obligation?**

Keep research failure, implementation failure, prompt failure, context failure, environment failure, tool failure, provenance failure, and unknown failure distinct when possible.

### Correctability
**What observation would make the retained interpretation change?**

If unknown, say so.

---

## 6. Experiment record

For every identifiable experiment reconstruct only what the chat supports:

**Experiment ID:** create a local recovery ID if none existed.  
**Historical name:** preserve the original name if present.  
**Situation ID:**  
**Question:** exact uncertainty tested.  
**Hypothesis:** if stated or clearly reconstructable; label reconstruction.  
**Target obligation:** what behavior/outcome mattered.  
**Motivation / inherited cost:** what problem or pressure forced the test.  
**Inputs / substrate:** system, model, data, representation, environment, artifacts.  
**Prompt / context / environment lineage:** only what is recoverable.  
**Intervention:** what changed, was removed, added, compared, inverted, randomized, transported, or constrained.  
**Controls / baseline:** if any.  
**Measurement / observer:** what observable determined the result.  
**Execution status:** PASSED / FAILED / NULL / CONFOUNDED / TOOL_FAILED / BLOCKED / etc.  
**Observed result:** what actually happened.  
**Failure conditions / confounds:** including execution-window or tooling limits.  
**Interpretation at the time:** historical interpretation.  
**Recoverable interpretation now:** what the evidence itself licenses without importing later theory.  
**Claim boundary:** what this experiment does not establish.  
**Artifacts / hashes / paths:** where known.  
**Obstructions revealed:** if supported.  
**Candidate carriers / bridges / compositions:** if supported or explicitly marked hypothesis.  
**Correctability / next discriminating observation:** what would change the conclusion.

---

## 7. Failure / obstruction recovery

Failures are first-class navigation objects.

For each material failure record:

- failed Attempt;
- failed obligation or expected postcondition;
- exact observable failure;
- failure class;
- cost imposed;
- suspected cause at the time;
- causes actually supported;
- attempted repairs;
- result of each repair;
- candidate missing distinction;
- whether that distinction was ever ablated/tested;
- known carrier or composition that might restore it;
- whether the obstruction remains open.

Do not infer necessity from mere association. Ablation licenses only the level of necessity actually discriminated.

---

## 8. Idea / hypothesis recovery

Create an IDEA & HYPOTHESIS ledger separate from experimental results.

For each item preserve:

- original wording when material;
- originating Situation/problem;
- proposed mechanism/relation;
- whether implemented;
- whether tested;
- evidence for;
- evidence against;
- closest experiment;
- supersession/refinement history;
- possible cross-domain significance;
- smallest discriminating experiment still needed.

Do not call an idea novel merely because no match appears in this chat. Use `novelty_status: UNKNOWN` unless external comparison has actually been done.

---

## 9. Contradiction / revision register

Find and preserve cases where:

- an assumption was later rejected;
- two runs disagree;
- terminology changed meaning;
- a success claim was later narrowed;
- the user corrected the assistant;
- later artifacts disagree with earlier artifacts;
- scope widened or narrowed;
- a summary conflicts with primary evidence.

Record both sides. Do not average them. State what evidence would discriminate them.

---

## 10. Scope and anti-loss

The recovery view should be focused, but the recovery itself should be loss-resistant.

**OMITTED FROM THE DISPLAY does not mean IRRELEVANT to the archive.**

When the current ontology cannot represent something without distortion, preserve it as `UNCLASSIFIED_RECOVERED_SIGNAL` with provenance and a short description of why it does not fit.

If a local conclusion depends on omitted material, widen exactly that boundary and record the reason for expansion.

---

## 11. Output — first give the human a manageable world

Return a **CROSS-CHAT RECOVERY PACKET** beginning with these four views.

### NOW — What did this chat actually contribute?
Keep this compact:

- recovered Situation(s);
- central goal;
- what had to remain true;
- strongest bounded result;
- largest unresolved uncertainty;
- most valuable next cross-chat comparison.

### WEB — What connects to it?
Show the local applicability topology:

- Obligations;
- Helpers;
- evidence-supported Carriers;
- candidate/verified Bridges;
- Compositions;
- Obstructions;
- Contradictions;
- cross-domain candidates.

Mark candidate versus evidenced relations explicitly.

### EVIDENCE — Why do we believe it?
Provide:

- chronological experiment ledger;
- observation ledger;
- failure/null/confound ledger;
- artifact index;
- provenance chains and gaps;
- claim boundaries;
- contradictions.

### HISTORY — How did we get here?
Chronologically reconstruct:

`Observation -> Hypothesis -> Attempt -> Result -> Failure/Success -> Revision -> Next Question`

Do not rewrite early stages in later terminology.

---

## 12. Machine-compatible recovered records

After the human views, emit a compact structured appendix. Use stable local IDs and these object types when present:

`Situation, HumanInstruction, Prompt, ContextPackage, Environment, Workspace, Execution, Artifact, Evidence, Experiment, Observation, Claim, Question, Decision, Scope, Obligation, Distinction, Helper, Carrier, Bridge, Composition, Attempt, Failure, Obstruction, Contradiction, CostProfile, UnclassifiedRecoveredSignal`.

For each record include at minimum:

- `id`
- `type`
- `status`
- `statement_or_description`
- `source_provenance`
- `evidence_ids`
- `related_ids`
- `scope`
- `unknowns`

Do not fabricate empty precision. Omit fields whose values are unknown or explicitly mark them unknown.

---

## 13. Final cross-chat handoff

Finish with:

### STRONGEST EMPIRICAL RESULTS
Only actual tested/observed results.

### MOST INTERESTING UNTESTED IDEAS
Keep them separate from evidence.

### FAILURES THAT MAY REVEAL NECESSARY STRUCTURE
Mark necessity level as untested unless discriminated.

### QUESTIONS ANOTHER CHAT MAY ALREADY CONTAIN EVIDENCE FOR
Phrase them as concrete retrieval questions.

### MATERIAL THAT SHOULD NOT YET ENTER CANONICAL THEORY
Include unsupported syntheses, apparent novelty, untested carriers, unresolved contradictions, and ontology-dependent interpretations.

### RAW RECOVERY APPENDIX
Preserve important leftovers rather than discarding them.

Do not continue the historical project after producing the recovery packet.
