
from __future__ import annotations
from pathlib import Path
import json, math

BASE = Path(__file__).resolve().parents[1]
FIXTURE = json.loads((BASE/"data"/"penny_monthly_attention"/"HISTORY_STRESS_PANEL.json").read_text())

HEAD = FIXTURE["headers"]
ROWS = FIXTURE["rows"]
MONTHS = [r[0] for r in ROWS]
TICKERS = HEAD[1:9]
PRICE = {name:[r[i+1] for r in ROWS] for i,name in enumerate(TICKERS)}
IWC = [r[9] for r in ROWS]

def max_drawdown(path):
    peak=None
    worst=0.0
    for v in path:
        peak = v if peak is None else max(peak,v)
        if peak and peak>0:
            worst=min(worst,v/peak-1.0)
    return worst

def replay(*, slots, slot_cap, one_way_cost, withdraw_share=0.50, lookback=3):
    cash=20.0
    withdrawn=0.0
    ledger=[]
    account_path=[]
    total_wealth_path=[]
    active_months=0
    missing_exit_writeoffs=0

    for t in range(lookback,len(MONTHS)-1):
        signals=[]
        for name in TICKERS:
            p_old=PRICE[name][t-lookback]
            p_now=PRICE[name][t]
            if p_old is None or p_now is None or p_old<=0 or p_now<=0:
                continue
            s=p_now/p_old-1.0
            if s>0:
                signals.append((s,name))
        signals.sort(reverse=True)
        chosen=[name for _,name in signals[:slots]]

        start_cash=cash
        allocations={}
        if chosen:
            active_months += 1
            per=min(slot_cap,cash/len(chosen))
            allocations={name:per for name in chosen}
            cash-=sum(allocations.values())

        outcomes=[]
        for name,amount in allocations.items():
            p0=PRICE[name][t]
            p1=PRICE[name][t+1]
            investable=amount*(1-one_way_cost)
            if p1 is None or p1<=0:
                end_value=0.0
                asset_return=-1.0
                missing=True
                missing_exit_writeoffs += 1
            else:
                asset_return=p1/p0-1.0
                end_value=investable*(p1/p0)*(1-one_way_cost)
                missing=False
            cash += end_value
            outcomes.append({
                "ticker":name,"allocated":amount,"asset_return":asset_return,
                "end_value":end_value,"missing_exit_writeoff":missing
            })

        pre_withdraw=cash
        eligible=max(0.0,cash-20.0)
        withdrawal=eligible*withdraw_share
        cash-=withdrawal
        withdrawn+=withdrawal
        account_path.append(cash)
        total_wealth_path.append(cash+withdrawn)

        ledger.append({
            "decision_month":MONTHS[t],"result_month":MONTHS[t+1],
            "chosen":chosen,"start_cash":start_cash,
            "pre_withdraw_cash":pre_withdraw,"withdrawal":withdrawal,
            "end_account_cash":cash,"cumulative_withdrawn":withdrawn,
            "total_wealth":cash+withdrawn,"outcomes":outcomes
        })

    return {
        "months":len(ledger),
        "active_months":active_months,
        "resolved_position_holds":sum(len(x["chosen"]) for x in ledger),
        "ending_account_cash":cash,
        "total_withdrawn":withdrawn,
        "ending_total_wealth":cash+withdrawn,
        "minimum_account_cash":min(account_path) if account_path else cash,
        "max_drawdown_account":max_drawdown(account_path),
        "max_drawdown_total_wealth":max_drawdown(total_wealth_path),
        "missing_exit_writeoffs":missing_exit_writeoffs,
    }

def iwc_baseline(lookback=3):
    start=IWC[lookback]
    path=[20.0*(x/start) for x in IWC[lookback:]]
    return {
        "start_month":MONTHS[lookback],
        "end_month":MONTHS[-1],
        "ending_total_wealth":path[-1],
        "total_return":path[-1]/20.0-1.0,
        "max_drawdown":max_drawdown(path),
        "assumption":"Buy-and-hold IWC from the same starting month; no transaction-cost model applied."
    }

def run():
    brake=FIXTURE["preexisting_controls"]["sleeve_drawdown_brake"]
    base_cost=FIXTURE["development_rule"]["base_one_way_cost"]
    results={}
    for v in FIXTURE["variants"]:
        results[v["id"]]=replay(
            slots=v["slots"],slot_cap=v["slot_cap"],
            one_way_cost=base_cost
        )
    sensitivity={}
    for c in FIXTURE["cost_sensitivity"]:
        sensitivity[f"{c:.4f}"]=replay(slots=1,slot_cap=4.0,one_way_cost=c)

    original=results["original_two_slot"]
    one10=results["one_slot_10"]
    one5=results["one_slot_5"]
    boundary=results["boundary_search_4"]
    baseline=iwc_baseline()

    # The pre-existing drawdown brake is evaluated on total wealth including prior
    # withdrawals, so "collecting" does not hide drawdown by moving cash off-book.
    original_brake_fail=original["max_drawdown_total_wealth"] < brake
    one10_brake_fail=one10["max_drawdown_total_wealth"] < brake
    one5_brake_fail=one5["max_drawdown_total_wealth"] < brake
    boundary_base_inside=boundary["max_drawdown_total_wealth"] >= brake
    boundary_highcost_fail=sensitivity["0.0100"]["max_drawdown_total_wealth"] < brake

    withdrawal_not_principal_protection=(
        original["total_withdrawn"]>0
        and original["ending_account_cash"]<20.0
    )
    exposure_reduction_observed=(
        original["max_drawdown_total_wealth"] < one10["max_drawdown_total_wealth"]
        < one5["max_drawdown_total_wealth"]
    )

    expected = {
      "original_two_slot_wealth": 37.52049505401389,
      "original_two_slot_mdd": -0.5333213503663179,
      "one_slot_10_wealth": 41.92538265787862,
      "one_slot_10_mdd": -0.40538527057690044,
      "one_slot_5_wealth": 30.962691328939304,
      "one_slot_5_mdd": -0.23526985102201514,
      "boundary4_wealth": 28.770153063151465,
      "boundary4_mdd": -0.19446691263934168,
      "boundary4_highcost_mdd": -0.2091710571158698,
      "iwc_wealth": 39.72720166521487,
      "iwc_mdd": -0.19695141768097568,
    }
    observed = {
      "original_two_slot_wealth": original["ending_total_wealth"],
      "original_two_slot_mdd": original["max_drawdown_total_wealth"],
      "one_slot_10_wealth": one10["ending_total_wealth"],
      "one_slot_10_mdd": one10["max_drawdown_total_wealth"],
      "one_slot_5_wealth": one5["ending_total_wealth"],
      "one_slot_5_mdd": one5["max_drawdown_total_wealth"],
      "boundary4_wealth": boundary["ending_total_wealth"],
      "boundary4_mdd": boundary["max_drawdown_total_wealth"],
      "boundary4_highcost_mdd": sensitivity["0.0100"]["max_drawdown_total_wealth"],
      "iwc_wealth": baseline["ending_total_wealth"],
      "iwc_mdd": baseline["max_drawdown"],
    }
    reproducible=all(math.isclose(observed[k],expected[k],rel_tol=0,abs_tol=1e-10) for k in expected)

    return {
        "passed":all([
            reproducible,
            original_brake_fail,one10_brake_fail,one5_brake_fail,
            boundary_base_inside,boundary_highcost_fail,
            withdrawal_not_principal_protection,
            exposure_reduction_observed,
            original["months"]==40,
            original["missing_exit_writeoffs"]>=1,
        ]),
        "source_boundary":{
            "panel_months":len(ROWS),
            "panel_start":MONTHS[0],"panel_end":MONTHS[-1],
            "tickers":TICKERS,
            "hand_selected_stress_panel":True,
            "random_or_confirmatory":False,
            "source_workbook_sha256":FIXTURE["source"]["materialized_sha256"]
        },
        "preexisting_drawdown_brake":brake,
        "development_rule_status":FIXTURE["development_rule"]["status"],
        "base_cost_one_way":base_cost,
        "results":results,
        "cost_sensitivity_boundary4":sensitivity,
        "iwc_baseline":baseline,
        "observations":{
            "original_two_slot_breaches_preexisting_brake":original_brake_fail,
            "one_slot_10_breaches_preexisting_brake":one10_brake_fail,
            "one_slot_5_breaches_preexisting_brake":one5_brake_fail,
            "exposure_reduction_reduced_drawdown_in_this_panel":exposure_reduction_observed,
            "post_hoc_4_dollar_boundary_inside_brake_at_base_cost":boundary_base_inside,
            "post_hoc_4_dollar_boundary_fails_at_1pct_one_way_cost":boundary_highcost_fail,
            "monthly_withdrawals_do_not_protect_original_20_from_later_losses":withdrawal_not_principal_protection,
            "iwc_baseline_narrowly_inside_same_drawdown_brake":baseline["max_drawdown"]>=brake,
        },
        "claim_ceiling":[
            "This is a development replay on a hand-selected stress panel, not a random or confirmatory backtest.",
            "The 3-month momentum selection rule and transaction-cost assumptions were not precommitted in the source workbook.",
            "The $4 exposure is a post-hoc boundary candidate discovered on the same panel and is not validated.",
            "Monthly closes cannot test intramonth stops, spreads, depth, halts, or executable fills.",
            "The historical replay does not satisfy the source workbook's live-paper-trade promotion gate.",
            "No future-return, country-transfer, or live-trading recommendation is supported."
        ]
    }

if __name__=="__main__":
    print(json.dumps(run(),indent=2,sort_keys=True))
