
from __future__ import annotations
from pathlib import Path
import json, hashlib, re, tempfile, sys
ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0,str(ROOT))
from orbit_lab import OrbitLab

DATA=ROOT/"data"/"philosophy_boundary"
MANIFEST=json.loads((DATA/"SOURCE_MANIFEST.json").read_text())

def _checked(name):
    meta=MANIFEST[name]
    p=DATA/meta["file"]
    raw=p.read_bytes()
    if hashlib.sha256(raw).hexdigest()!=meta["sha256"]:
        raise ValueError(f"digest mismatch: {name}")
    return raw.decode("utf-8")

def run():
    boundary=_checked("boundary")
    guide=_checked("update_guide")

    source_boundary_recovered=all([
        "Philosophy | Motivate questions, values, purposes, interpretive/generative lenses" in boundary,
        "Philosophical material does **not** become evidence" in boundary,
        "Philosophy: reference, don't carry." in boundary,
        "Classify the **tested relation or current role**, not the thing globally." in guide,
    ])

    with tempfile.TemporaryDirectory() as td:
        lab=OrbitLab(Path(td)/"philosophy.db")
        try:
            philosophy=lab.add(
                "Artifact","Nature-as-coupled lens",
                data={
                    "source_role":"PHILOSOPHY",
                    "evidence_tags":["EMPIRICAL_EVIDENCE"],
                    "source_sha256":MANIFEST["boundary"]["sha256"],
                },
                provenance_class="TEST",provenance="philosophy-boundary",identity_key="philosophy"
            )
            question=lab.add(
                "Candidate","Test whether two specified domains share transformation B",
                data={"candidate_role":"QUESTION","origin_role":"PHILOSOPHICAL_LENS"},
                provenance_class="TEST",provenance="philosophy-boundary",identity_key="question"
            )
            lab.relate(
                question,"DERIVED_FROM",philosophy,
                data={"role":"MOTIVATES_QUESTION_ONLY"},
                provenance_class="TEST",provenance="philosophy-boundary"
            )
            question_motivation_allowed=True

            frame=lab.add(
                "ObservationFrame","Constructed serializer experiment",
                data={
                    "observer":"philosophy-role-probe",
                    "apparatus":"X-LS-001 bounded record",
                    "accessible_variables":["baseline_collisions","candidate_collisions","routing_matches"],
                    "resolution":"constructed finite panel",
                    "intervention":"compare philosophy-only support with empirical-result support",
                    "boundary":"source-role admission test; not a claim that X-LS-001 labels are real-world actions"
                },
                provenance_class="TEST",provenance="philosophy-boundary",identity_key="frame"
            )

            # Deliberately malicious/misleading tag: philosophy self-declares the exact tag.
            empirical_claim=lab.add(
                "Claim","The tested status-only serializer loses distinctions on the frozen panel",
                data={
                    "required_evidence_tags":["EMPIRICAL_EVIDENCE"],
                    "evidence_source_role_contract":{
                        "allowed":["EMPIRICAL_RESULT","PRIMARY_RESULT"],
                        "forbidden":["PHILOSOPHY"],
                        "require_declared_role":True
                    }
                },
                provenance_class="TEST",provenance="philosophy-boundary",identity_key="empirical-claim"
            )
            philosophy_blocked=False
            try:
                lab.assess_claim(
                    empirical_claim,frame_id=frame,evidence_ids=[philosophy],
                    verdict="SUPPORTED",scope="frozen X-LS-001 constructed panel",
                    provenance_class="TEST",provenance="philosophy-boundary"
                )
            except ValueError:
                philosophy_blocked=True

            result=lab.add(
                "Evidence","X-LS-001 bounded serializer result",
                data={
                    "source_role":"EMPIRICAL_RESULT",
                    "evidence_tags":["EMPIRICAL_EVIDENCE"],
                    "baseline_collision_groups":9,
                    "candidate_collision_groups":0,
                    "routing_matches":"54/54",
                    "field_ablations":"9/9",
                    "target_isolation_violations":0,
                },
                epistemic="OBSERVED",
                provenance_class="TEST",provenance="philosophy-boundary",identity_key="result"
            )
            supported=lab.assess_claim(
                empirical_claim,frame_id=frame,evidence_ids=[result],
                verdict="SUPPORTED",scope="frozen constructed serializer panel only",
                provenance_class="TEST",provenance="philosophy-boundary"
            )

            # Philosophy may support a descriptive claim about the philosophy artifact itself
            # when the claim explicitly permits that source role.
            descriptive=lab.add(
                "Claim","The Moonshot philosophy boundary says philosophy may motivate questions",
                data={
                    "required_evidence_tags":["PHILOSOPHY_TEXT"],
                    "evidence_source_role_contract":{
                        "allowed":["PHILOSOPHY"],
                        "require_declared_role":True
                    }
                },
                provenance_class="TEST",provenance="philosophy-boundary",identity_key="descriptive"
            )
            phil_text=lab.add(
                "Evidence","Canonical philosophy boundary text",
                data={
                    "source_role":"PHILOSOPHY",
                    "evidence_tags":["PHILOSOPHY_TEXT"],
                    "sha256":MANIFEST["boundary"]["sha256"]
                },
                epistemic="OBSERVED",
                provenance_class="TEST",provenance="philosophy-boundary",identity_key="phil-text"
            )
            descriptive_ep=lab.assess_claim(
                descriptive,frame_id=frame,evidence_ids=[phil_text],
                verdict="SUPPORTED",scope="what the philosophy boundary document says",
                provenance_class="TEST",provenance="philosophy-boundary"
            )

            audit=lab.alpha_audit()
            empirical_supported=lab.episode(supported)["data"]["verdict"]=="SUPPORTED"
            descriptive_supported=lab.episode(descriptive_ep)["data"]["verdict"]=="SUPPORTED"
        finally:
            lab.close()

    return {
        "passed":(
            source_boundary_recovered
            and question_motivation_allowed
            and philosophy_blocked
            and empirical_supported
            and descriptive_supported
            and audit["passed"]
            and MANIFEST["independent_copy_equality"]["incoming_start_equals_canonical_start"]
            and MANIFEST["independent_copy_equality"]["incoming_manifest_equals_canonical_manifest"]
        ),
        "source_boundary_recovered":source_boundary_recovered,
        "philosophy_may_motivate_candidate_question":question_motivation_allowed,
        "philosophy_role_blocked_from_empirical_claim":philosophy_blocked,
        "empirical_result_role_can_support_empirical_claim":empirical_supported,
        "philosophy_can_support_descriptive_claim_about_its_own_text":descriptive_supported,
        "role_is_claim_local_not_global_ontology":True,
        "incoming_philosophy_start_duplicate":MANIFEST["independent_copy_equality"]["incoming_start_equals_canonical_start"],
        "incoming_philosophy_manifest_duplicate":MANIFEST["independent_copy_equality"]["incoming_manifest_equals_canonical_manifest"],
        "kernel_schema_additions":0,
        "audit_passed":audit["passed"],
        "claim_ceiling":"source-role admission invariant; no claim that philosophy is irrelevant to research or that source-role strings are a universal ontology"
    }

if __name__=="__main__":
    print(json.dumps(run(),indent=2,sort_keys=True))
