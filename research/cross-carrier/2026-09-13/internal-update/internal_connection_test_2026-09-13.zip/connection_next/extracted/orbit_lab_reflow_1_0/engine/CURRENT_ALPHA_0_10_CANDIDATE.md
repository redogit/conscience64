# Orbit Lab Alpha 0.10 candidate

Adds the Fractal Unroll/Mirror bounded round-trip and representation-boundary probe. No kernel schema change.
