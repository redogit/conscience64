# Orbit Lab Alpha 0.18 — Current

Alpha 0.18 integrates the Moonshot philosophy separation as a source-role admission boundary.

Core relation:

```text
philosophical orientation
    -> may motivate question / lens / ethical constraint
    -> does not thereby become empirical evidence
```

Claims may now declare a task-local evidence-source-role contract:
- allowed roles;
- forbidden roles;
- whether cited evidence must declare a role.

The role belongs to the current evidentiary relation. It is not a global ontology of the source.

Bounded verification:
- 174/174 regressions PASS
- 24 selector components
- 85 declared obligations
- philosophy-boundary task verification = core-sentinel + philosophy-source-role
- direct S5 whole integration PASS
- strict path successor of Alpha 0.17
- zero new kernel object/Episode types

The philosophy source can still support descriptive claims about what the philosophy
document says when the claim explicitly allows that role.

Do not interpret this as philosophy being irrelevant to science. It is a claim-boundary rule.
