# Orbit Lab Alpha 0.25 — Library Fold Stage 1

Purpose: fold the pre-existing Orbit Incoming queue into recoverable History and Current routing without treating ingestion as scientific admission.

## Stage 1 scope

The old `/Orbit Lab/Incoming/2026-09-04` queue is resolved first. Nine files are classified by role.

### New candidate imports
- **3D harmonic-subspace field generator** — retains the mathematically useful distinction between prescribed harmonic tracking, harmonic-subspace selection, and natural resonance. It is not promoted as a physical law.
- **Multi-Factor Abductive Ideation (MFAI)** — retains a tension-first creativity workflow that turns inspiration into a testable candidate. It is not promoted as a superior or universal ideation method.

### Already represented / historical
- Necessity-first / Musilanguage
- PulseNet GP
- Computer Mind
- Web-study / ethics / economics method thread
- MoonShot recovery-correction packet (historical method/provenance only)
- old Incoming indexes / large-source pointers

## Source custody
After promotion, the original Incoming artifacts move intact to:
`/Orbit Lab/History/Library Fold/Stage 1 Existing Incoming/`

No source artifact is deleted in Stage 1.

## Next staged scopes
1. Top-level named research/project folders — delta-only integration.
2. Loose root technical artifacts — cluster before deep reading.
3. Private/work/personal or ambiguous material — minimum-access review.
4. Duplicate/archive cleanup — only after verified custody.

## Verification
- profile: `library-fold-stage1`
- new kernel object/Episode types: 0
- candidate imports remain non-authorizing and non-evidentiary until separately tested.
