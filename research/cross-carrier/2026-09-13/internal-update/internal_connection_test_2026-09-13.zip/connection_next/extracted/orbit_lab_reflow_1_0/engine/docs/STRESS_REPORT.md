# Orbit Lab research-load stress report

## v0.1 breaks
1. No QUARANTINED lifecycle.
2. No first-class Claim object.
3. Relation edges could not carry task-local metadata.
4. Orbit was global instead of subject-scoped.
5. Duplicate identity was not constrained.
6. Current accepted arbitrarily many simultaneous probes.
7. SUPERSEDES/CORRECTS cycles were not prevented.
8. Provenance was only a nonempty free string.

## v0.2 response
All eight were addressed minimally and the structural tests pass.

## v0.2 second-order breaks

1. Library retrieval is lexical substring only; semantically related research is invisible without exact wording.
2. QUARANTINED objects can be launched directly; quarantine is a label, not an admission gate.
3. Relation vocabulary is unconstrained; nonsensical SUPPORTS edges are structurally legal.
4. Claim can be marked SUPPORTED without required scope, evidence link, or falsifier.
5. Object content can be rewritten in-place through the backing DB; immutable-content/version discipline is not enforced.

## Current disposition
Keep v0.2 as a useful internal beta. Do not add more structure yet except where one of these second-order failures becomes consequential in actual use.


## Wider Library pass

```text
WIDER STRESS PASS
-----------------
PASS: Loaded 12 wider research/control subjects without activating them.

NEW PRESSURES/BREAKS:
1. No first-class Experiment object: ValueError: unknown object type: Experiment
2. Experiment outcome/status vocabulary missing: CONFOUNDED, FAILED, NULL, PASSED, PLANNED, RUNNING, TOOL_FAILED
3. One epistemic status on Subject collapses mixed CSOL outcomes across families/budgets.
4. SUPPORTED Claim still needs no mandatory scope, comparator, evidence edge, or falsifier.
5. Execution identity is optional; same run locator admitted twice (artifact-c04b3a363d, artifact-08008a9139).
6. QUARANTINED legacy object launches directly; no UNDER_REVIEW/ADMIT transition.
7. Relation-schema validation absent; unrelated branches can be declared BASELINE.
8. Subject is overloaded: project/branch/container and examined subject use the same type.

```

## Tri-branch stress — observation delay / faithful transport / ACDN

### Observation-delay branch
Eight condition-indexed observations were represented without adding a new object type. The sharp measured collapse between 750 ms and 1000 ms can remain an inference over observations; no `Regime` object is yet forced.

### First forced break: higher-order tested relation
Faithful transport could only be represented as a binary `TRANSPORTS_TO` edge with `obligation_id` and `evidence_id` hidden in JSON. Deleting the obligation leaves the transport edge syntactically valid with a dangling semantic reference. The database cannot protect or query the actual research contract.

### Independent reproduction: ACDN matched counterfactual
The connection-OFF / connection-ON pair has to preserve candidate link, common reset condition, two executions, and the comparison result as one matched experimental relation. v0.2 can only hide the probe IDs in JSON; deleting one member leaves a malformed comparison record that still appears valid.

### Forced distinction
The kernel needs a first-class higher-order relation / episode representation with typed role-bearing participants and referential integrity. Do not add specialized `Transport` and `CounterfactualPair` object types yet; both failures point to the same general missing structure.


## v0.3 Episode repair + deeper attack

```text
V0.3 DEEP STRESS
----------------
PASS:
- Faithful-transport participant deletion is rejected.
- Matched-counterfactual member deletion is rejected.

FORCED/NEXT BREAKS:
1. Historical evidence survives an in-place semantic rewrite of a participant. Object identity is not a content/version snapshot.
2. Claim still exposes one intrinsic epistemic status even though two valid assessment episodes give opposite frame-scoped verdicts.

```


## v0.4 immutable snapshots + scoped claims

```text
V0.4 DEEPER STRESS
------------------
PASS:
- Historical participant semantics cannot be rewritten in place.
- Opposite frame-scoped verdicts coexist without rewriting Claim.

NEXT BREAKS:
1. Episode participant integrity is not enough: FAITHFUL_TRANSPORT accepted without obligation or evidence.
2. QUARANTINED remains only a lifecycle label; direct activation still bypasses an admission decision.
3. Remainder/UNKNOWN still cannot distinguish underdetermined from inaccessible without caller-invented free-form data, even though those require different next actions.

```


## v0.5 depth stress

```text
V0.5 DEPTH STRESS
-----------------
PASS:
- Known Episode kind rejects missing load-bearing roles.
- Remainder now requires a typed unknown.
- Quarantine blocks launch.
- Object can launch after explicit admission.

DEEP BREAK:
1. Higher-order Episode cannot itself participate in another Episode. Admission cannot cite the matched experiment as the evidence-bearing unit without flattening it into a duplicate Evidence object.

```


## v0.6 composable entity stress

```text
V0.6 COMPOSITION STRESS
-----------------------
PASS:
- Episode can participate directly in a later Episode.
- Nested evidence Episode is immutable.

NEXT DEPTH:
1. Observation frame is still only an arbitrary Artifact. The kernel cannot require observer/apparatus/access/resolution/intervention/boundary fields even when the same Observation supports different actions under different frames.
2. Subject still serves both persistent project/branch container and current examined thing; the same type carries two different operational roles.

```


## v0.7 frame / collection / typed-role stress

```text
V0.7 FRAME/COLLECTION STRESS
----------------------------
PASS:
- ObservationFrame now carries the fields that determine observability.
- Persistent branch container is separated from current Subject.

NEXT BREAK:
1. Episode contracts enforce role presence but not role type. FAITHFUL_TRANSPORT accepted Claim→Remainder as source/target.
2. MATCHED_COUNTERFACTUAL accepts non-execution control/treatment participants. Role semantics are not machine-checkable yet.

```


## v0.8 typed-role / execution stress

```text
V0.8 TYPED-ROLE STRESS
----------------------
PASS:
- FAITHFUL_TRANSPORT rejects type-invalid source/target.

NEXT BREAK:
1. Typed roles still collapse planned Probe with executed run. MATCHED_COUNTERFACTUAL can certify two Probes that never actually executed.

```


## v0.9 Probe / Execution / parameter stress

```text
V0.9 EXECUTION STRESS
---------------------
PASS:
- Matched comparison now requires actual EXECUTION Episodes, not bare Probes.

NEXT BREAK:
1. The two executions changed connection state AND learning_rate, but Parameters are buried inside Probe.data. MATCHED_COUNTERFACTUAL cannot verify that nuisance parameters were held fixed.

```


## v0.10 Parameters / execution identity stress

```text
V0.10 PARAMETERS / IDENTITY STRESS
---------------------------------
PASS:
- Matched counterfactual now rejects nuisance-parameter drift and accepts shared Parameters.

NEXT BREAK:
1. The exact same run locator and participants can be recorded as two distinct EXECUTION Episodes when identity_key is omitted. A replay/duplicate can masquerade as independent replication.

```


## v0.11 run / replication stress

```text
V0.11 RUN / REPLICATION STRESS
------------------------------
PASS:
- A RunIdentity can be consumed by only one Execution.

NEXT BREAK:
1. Distinct RunIdentity proves two executions occurred, but the kernel has no relation that says whether e2 is replay/repeatability/partial replication/independent replication. Different runs are not automatically independent evidence.

```


## v0.12 replication / economic stress

```text
V0.12 REPLICATION / ECONOMIC STRESS
----------------------------------
PASS:
- Execution identity and replication grade are separate.

NEXT BREAK:
1. The kernel can record a Decision that calls one candidate 'better/minimal' without any declared objective vector, feasibility thresholds, ordering, or Pareto rule. Compact uses less state but loses quality and latency; 'minimal' is undefined until the comparison order is explicit.

```


## v0.13 Order / measurement stress

```text
V0.13 ORDER STRESS
------------------
PASS:
- The kernel no longer invents one 'best' candidate when objectives conflict.

NEXT BREAK:
1. Order is explicit, but comparison values are still trusted from Candidate.data. Unmeasured/self-asserted metrics can defeat real evidence. Measurement provenance must bind candidate + metric + value + frame/execution.

```


## v0.14 Measurement / transfer stress

```text
V0.14 MEASUREMENT / TRANSFER STRESS
----------------------------------
PASS:
- Evidence-bound metrics and lifecycle-cost terms fit Measurement + Order without a new Cost primitive.

BREAK:
1. Admission is global to the object. Verification/admission in Branch A leaks into Branch B, so the kernel cannot express context-local authority/applicability or force transfer review.

```


## v0.15 context / One-Level-Up boundary stress

```text
V0.15 CONTEXT / ONE-LEVEL-UP STRESS
----------------------------------
PASS:
- Preservation no longer carries admission authority across contexts.
- Successor context must independently admit predecessor material.

BOUNDARY:
1. Context-local admission prevents accidental authority leakage, but the kernel still permits a predecessor method/evidence to justify admission of that same predecessor method into the successor. It cannot represent the governing boundary that says destination rules, not source rules, own the transfer. The transfer mechanism itself needs an authority outside the predecessor context.

```


## v0.16 authority/history restructuring

```text
V0.16 AUTHORITY/HISTORY STRESS
------------------------------
PASS:
- Successful transfer does not manufacture destination activation authority.
- Evidence use and activation are independently authorized.
- Eligibility changes from access history rather than a mutable contamination flag.

NEXT BREAK:
1. Authority is now operation/context/history scoped, but Scope itself is opaque exact text. The kernel cannot distinguish narrower-within-authorized-scope from unrelated scope, nor prove containment/disjointness.

```


## v0.17 Scope / issuer stress

```text

```


## v0.18 issuer / delegation stress

```text
V0.18 ISSUER / DELEGATION STRESS
-------------------------------
PASS:
- Predecessor evidence may be considered, but it cannot issue its own destination grant.

NEXT BREAK:
1. Issuer chain now has a destination root, but there is no bounded delegation relation. The kernel cannot give a helper authority to grant/perform only INSPECT within Hodge, with depth/expiry/revocation, without either keeping all grants at the root or creating another root.

```


## v0.19 delegation / actor stress

```text

```


## v0.20 Actor / authentication stress

```text

```


## v0.21 Method / applicability / identity stress

```text
V0.21 METHOD / NEXT-PRESSURE STRESS
-----------------------------------
PASS:
- Structural validity, method status, and scope-bounded replacement no longer collapse.

NEXT PRESSURES:
1. Method compliance is now explicit, but historical support vs current applicability still has no typed ValidityFrame. Context can contain environment facts, yet the kernel cannot state which assumptions/tools/definitions/domain made an old result applicable or prove that the frame changed.
2. Artifact identity still mixes content and occurrence. Two objects can share a hash, but the kernel has no first-class ContentIdentity/Custody relation to say 'same bytes, different occurrence'.

```


## v0.22 applicability / identity stress

```text
V0.22 APPLICABILITY / IDENTITY STRESS
------------------------------------
PASS:
- Historical support and current applicability are now separate and frame-bounded.

NEXT BREAKS:
1. The same-byte/different-occurrence distinction is still only implied by duplicate hash strings. There is no ContentIdentity object shared by occurrences, and no custody/occurrence event chain. This makes deduplication, provenance, and transfer identity depend on caller conventions.
2. Transfer currently targets an Entity occurrence. It cannot separately preserve content identity and occurrence/custody identity, so 'same bytes arrived' and 'this historical occurrence moved' cannot be distinguished.

```


## v0.23 identity / custody stress

```text
V0.23 IDENTITY / CUSTODY STRESS
-------------------------------
PASS:
- Same content and different historical occurrence are now first-class.

NEXT BREAKS:
1. Identity is split, but TRANSFER still names only the source Entity and contexts. It does not bind the destination Occurrence, so it cannot distinguish COPY (new occurrence), MOVE (same occurrence changes custody/location), or CONTENT_RECONSTRUCTION (new occurrence with same content).
2. No custody chain exists. An Occurrence stores context/actor as immutable data, but later custody changes cannot be represented without either creating a new occurrence or inventing free-form history. The model has identity, but not possession/location transition semantics.

```


## v0.24 instance / lineage stress

```text
V0.24 INSTANCE / LINEAGE STRESS
------------------------------
PASS:
- COPY and MOVE are now distinguishable without using byte identity as occurrence identity.

NEXT PRESSURES:
1. Custody lineage now works for one instance through locations, but derivation lineage does not. A new artifact produced from multiple source occurrences has no typed transformation/provenance Episode that binds inputs + Method/Execution + output occurrence. Custody cannot stand in for derivation.
2. Association/indexing remains structurally different from custody transfer. The kernel still lacks a typed non-evidentiary Association relation, so a locator relationship is currently forced into generic relations or caller metadata.

```


## v0.25 derivation / association stress

```text
V0.25 DERIVATION / ASSOCIATION STRESS
------------------------------------
PASS:
- Multi-parent derivation is distinct from custody and preserves reconstructibility status.

NEXT BREAK:
1. Association still lives in the generic binary relation table with free-form metadata. The kernel cannot enforce that association is navigation-only, cannot type resolution status, and cannot prevent an association relation from being mistaken for evidence elsewhere.

```


## v0.26 association / promotion stress

```text
V0.26 ASSOCIATION / PROMOTION STRESS
-----------------------------------
PASS:
- Association is machine-visible as navigation-only and cannot satisfy evidence wildcards.
- Collection membership does not promote a Candidate.

NEXT PRESSURE:
1. The corpus now presses on provisional adaptation versus structural promotion. Current lifecycle ACTIVE only means working-set activation; there is no typed persistent Promotion Episode requiring a change witness/revalidation, nor a distinct reversible Adaptation Episode.

```


## v0.27 change / failure stress

```text
V0.27 CHANGE / FAILURE STRESS
-----------------------------
PASS:
- Temporary reversible action and persistent scientific promotion are separate history Episodes.

NEXT PRESSURE:
1. Failure location and failure cause still collapse into free-form Observation data. The corpus explicitly requires them separate because cause may be unknown or multicausal. We need a failure record that can preserve observed location without inventing cause.

```


## v0.28 failure / language-collision stress

```text
V0.28 FAILURE / LANGUAGE-COLLISION STRESS
----------------------------------------
PASS:
- Observed failure location can be retained without inventing a cause.
- Competing causal explanations can coexist without overwriting the observed failure.

NEXT PRESSURE:
1. The research corpus explicitly tracks LANGUAGE_COLLISION / ONTOLOGY_LEAKAGE: when one schema description covers cases requiring different actions, the failure belongs to the representation itself, not either scientific case. Orbit Lab has no first-class way to record that its own vocabulary is insufficient and require a schema repair before inference continues.

```


## v0.29 runtime-schema / form-growth stress

```text
V0.29 RUNTIME-SCHEMA STRESS
---------------------------
PASS:
- A vocabulary failure can now be recorded and repaired without editing Python source.

NEW FORM BOUNDARY:
1. The form has grown out of the fixed Python ontology, but schema repair authority is not yet governed. Any caller that can record a gap can immediately activate a new type. The next layer must treat schema change itself as an authorized, evidence-bound promotion rather than a privileged helper call.

```


## v0.30 governed schema / persistence stress

```text
V0.30 GOVERNED-SCHEMA / PERSISTENCE STRESS
-----------------------------------------
PASS:
- Language can grow without source edits, but only after evidence, promotion, and authority.
- Earned schema survives process restart and remains enforceable.

NEXT ALPHA PRESSURE:
1. The learned schema survives SQLite restart, but export_jsonl still exports only objects, relations, episodes, and history. A portable export can therefore omit schema terms/roles/gaps/changes and cannot reconstruct the exact learned language. Alpha needs a state-complete export/audit path.

```
