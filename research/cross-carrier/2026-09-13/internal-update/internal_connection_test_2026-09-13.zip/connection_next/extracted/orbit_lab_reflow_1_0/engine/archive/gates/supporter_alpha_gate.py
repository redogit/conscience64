
from __future__ import annotations
import json, subprocess, sys
from orbital_gans import OrbitalGAN
from supporter_ecology import SupporterEcology
from supporter_router import PROFILES, route_profile

def main():
    tests=subprocess.run([sys.executable,"-m","unittest","discover","-v"],
                         text=True,capture_output=True)
    alpha=subprocess.run([sys.executable,"alpha_gate.py"],
                         text=True,capture_output=True)

    orbital=OrbitalGAN(seed=20260904).run(rounds=1000)
    ecology=SupporterEcology().run()
    routes={name:route_profile(name) for name in PROFILES}
    routes_cover=all(not r["uncovered"] for r in routes.values())

    result={
        "gate":"Orbit Lab internal alpha 0.3-supporter-ecology",
        "passed": bool(
            tests.returncode==0
            and alpha.returncode==0
            and orbital["novel_findings"]==0
            and len(orbital["harness_errors"])==0
            and ecology["findings"]==0
            and routes_cover
        ),
        "checks":{
            "full_regression_suite":tests.returncode==0,
            "alpha_state_gate":alpha.returncode==0,
            "orbital_trials":orbital["trials"],
            "orbital_novel_findings":orbital["novel_findings"],
            "orbital_harness_errors":len(orbital["harness_errors"]),
            "supporter_signals":len(ecology["signals"]),
            "supporter_passes":ecology["passes"],
            "supporter_pressures_retained":ecology["pressures"],
            "supporter_findings":ecology["findings"],
            "router_profiles":len(routes),
            "router_profiles_fully_covered":routes_cover,
        },
        "retained_pressures":[
            x for x in ecology["signals"] if x["status"]=="PRESSURE"
        ],
        "known_boundaries":[
            "Built-in supporters are role-separated mechanisms, not independent replication.",
            "Actor authentication remains an embedding-runtime trust boundary.",
            "Supporter pressures are not automatically promoted into kernel structure.",
            "No finite GAN/supporter/test run establishes completeness."
        ],
    }
    print(json.dumps(result,indent=2,sort_keys=True))
    if not result["passed"]:
        if tests.returncode:
            print(tests.stdout); print(tests.stderr,file=sys.stderr)
        if alpha.returncode:
            print(alpha.stdout); print(alpha.stderr,file=sys.stderr)
        raise SystemExit(1)

if __name__=="__main__":
    main()
