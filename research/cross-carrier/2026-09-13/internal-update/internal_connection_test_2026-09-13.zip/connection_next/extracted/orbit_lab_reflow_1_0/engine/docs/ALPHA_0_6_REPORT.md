# Orbit Lab Alpha 0.6 — Connected Research Candidate

Alpha 0.6 connects the controlled Library ingress to the selector and human interface.

## Earned changes from Alpha 0.5

- 14-branch quarantined connection map.
- 32 non-evidentiary source-to-component associations.
- `incoming` and `why <area>` human views.
- `compare <text>` human action separating derived comparison from observation and interpretation.
- cross-branch connection audit.
- paired-condition empirical-record probe.

## Non-changes

- no new kernel object type;
- no new episode kind;
- no imported branch authority;
- no cross-branch equivalence assertion;
- no independent-replication claim from agreement among sources.

## Gate

Final values are recorded in `artifacts/latest_selector_run.json` and the package manifest.
