
import tempfile
from pathlib import Path
from orbit_lab import OrbitLab

with tempfile.TemporaryDirectory() as td:
    lab=OrbitLab(Path(td)/"stress.db"); passes=[]; breaks=[]
    try:
        pre=lab.add("Artifact","Observed cost but no preservation contract",
                    provenance_class="TEST",provenance="stress",identity_key="pre")
        post=lab.add("Artifact","Verified obligation after intervention",
                     provenance_class="TEST",provenance="stress",identity_key="post")
        ctx=lab.add("Context","Schema context",provenance_class="TEST",provenance="stress",identity_key="ctx")
        actor=lab.add("Actor","Schema owner",provenance_class="TEST",provenance="stress",identity_key="actor")
        scope=lab.add("Scope","Schema",provenance_class="TEST",provenance="stress",identity_key="scope")
        frame=lab.add("ValidityFrame","Schema frame",data={"conditions":{"kernel":"v30"}},
                      provenance_class="TEST",provenance="stress",identity_key="frame")
        witness=lab.add("Evidence","controlled collision",provenance_class="TEST",
                        provenance="stress",identity_key="witness",epistemic="OBSERVED")
        gap=lab.record_schema_gap(gap_kind="LANGUAGE_COLLISION",current_term="Obligation",
            case_a_id=pre,case_b_id=post,required_action_a="explore/measure",
            required_action_b="verify/preserve",missing_distinction="pre-obligation pressure",
            provenance_class="DERIVED",provenance="stress")
        proposal=lab.propose_schema_object_type(gap_id=gap,type_name="Pressure",
            definition="Observed discrepancy/cost/tension before a preservation contract is earned.",
            provenance_class="DERIVED",provenance="stress")
        promotion=lab.record_promotion(context_id=ctx,entity_id=proposal,scope_id=scope,
            validity_frame_id=frame,witness_entity_id=witness,basis_entity_ids=[witness],
            change_claim="Pressure distinction required",revalidation_rule="rerun collision cases",
            provenance_class="DERIVED",provenance="stress")
        root=lab.establish_authority_root(context_id=ctx,scope_id=scope,
            operations=["SCHEMA_CHANGE"],holder_actor_id=actor,
            provenance_class="USER",provenance="explicit user schema authority")
        lab.grant_authorization(context_id=ctx,entity_id=proposal,operation="SCHEMA_CHANGE",
            scope_id=scope,issuer_authority_id=root,issuer_actor_id=actor,principal_id=actor,
            basis_entity_ids=[witness,promotion],reason="earned schema repair",
            provenance_class="DERIVED",provenance="stress")
        lab.apply_schema_object_type(proposal_id=proposal,promotion_episode_id=promotion,
            context_id=ctx,actor_id=actor,scope_id=scope,reason="apply smallest repair",
            provenance_class="DERIVED",provenance="stress")
        pressure=lab.add("Pressure","Measured unexplained cost",
                         provenance_class="TEST",provenance="stress",identity_key="pressure")
        if lab.get(pressure).type=="Pressure":
            passes.append("Language can grow without source edits, but only after evidence, promotion, and authority.")

        # Persistence attack: close/reopen must retain the learned language.
        db=Path(td)/"stress.db"
        lab.close()
        lab=OrbitLab(db)
        if lab.schema_term("Pressure")["status"]=="ACTIVE":
            p2=lab.add("Pressure","Pressure after restart",
                       provenance_class="TEST",provenance="stress",identity_key="pressure2")
            passes.append("Earned schema survives process restart and remains enforceable.")

        # Remaining alpha pressure is portable export/recovery rather than in-process persistence.
        breaks.append(
            "The learned schema survives SQLite restart, but export_jsonl still exports only objects, relations, "
            "episodes, and history. A portable export can therefore omit schema terms/roles/gaps/changes and "
            "cannot reconstruct the exact learned language. Alpha needs a state-complete export/audit path."
        )

        print("V0.30 GOVERNED-SCHEMA / PERSISTENCE STRESS")
        print("-----------------------------------------")
        print("PASS:"); [print("-",x) for x in passes]
        print("\nNEXT ALPHA PRESSURE:"); [print(f"{i}. {x}") for i,x in enumerate(breaks,1)]
    finally:
        lab.close()
