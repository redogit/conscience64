
import tempfile
from pathlib import Path
import unittest
from orbit_lab import OrbitLab
class V15Tests(unittest.TestCase):
    def setUp(self): self.tmp=tempfile.TemporaryDirectory(); self.lab=OrbitLab(Path(self.tmp.name)/"t.db")
    def tearDown(self): self.lab.close(); self.tmp.cleanup()
    def add(self,t,title,key,**kw): return self.lab.add(t,title,provenance_class="TEST",provenance="test",identity_key=key,**kw)
    def test_admission_is_context_local(self):
        a=self.add("Context","A","A"); b=self.add("Context","B","B")
        x=self.add("Candidate","legacy","x",lifecycle="QUARANTINED")
        e=self.add("Evidence","A evidence","e",epistemic="OBSERVED")
        self.lab.admit_in_context(a,x,support_entity_ids=[e],reason="A verified",provenance_class="TEST",provenance="test")
        self.assertEqual(self.lab.context_admission_status(a,x)["status"],"ADMITTED")
        self.assertEqual(self.lab.context_admission_status(b,x)["status"],"UNREVIEWED")
        with self.assertRaises(PermissionError): self.lab.launch_in_context(b,x)
        with self.assertRaises(PermissionError): self.lab.launch_in_context(a,x)
if __name__=="__main__": unittest.main()
