
import tempfile
from pathlib import Path
import datetime as dt
import unittest
from orbit_lab import OrbitLab

class OrbitalFindingRegressions(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.lab=OrbitLab(Path(self.tmp.name)/"t.db")
    def tearDown(self):
        self.lab.close(); self.tmp.cleanup()
    def add(self,t,title,key,**kw):
        return self.lab.add(t,title,provenance_class="TEST",provenance="test",identity_key=key,**kw)

    def authority_world(self):
        c=self.add("Context","C","c"); owner=self.add("Actor","owner","owner")
        child_actor=self.add("Actor","child","child"); s=self.add("Scope","S","s")
        target=self.add("Candidate","X","x"); basis=self.add("Evidence","E","e",epistemic="OBSERVED")
        root=self.lab.establish_authority_root(context_id=c,scope_id=s,
            operations=["INSPECT"],holder_actor_id=owner,max_delegation_depth=1,
            provenance_class="USER",provenance="user")
        child=self.lab.delegate_authority(parent_authority_id=root,grantee_id=child_actor,
            scope_id=s,operations=["INSPECT"],max_delegation_depth=0,reason="child",
            provenance_class="TEST",provenance="test")
        return c,owner,child_actor,s,target,basis,root,child

    def test_ancestor_revocation_invalidates_descendant_and_grant(self):
        c,owner,child_actor,s,target,basis,root,child=self.authority_world()
        self.lab.grant_authorization(context_id=c,entity_id=target,operation="INSPECT",scope_id=s,
            issuer_authority_id=child,issuer_actor_id=child_actor,principal_id=child_actor,
            basis_entity_ids=[basis],reason="grant",provenance_class="TEST",provenance="test")
        self.lab.revoke_authority(root,reason="root revoked",provenance_class="TEST",provenance="test")
        with self.assertRaises(PermissionError):
            self.lab.authority_info(child)
        self.assertFalse(self.lab.check_authorized(context_id=c,actor_id=child_actor,
            entity_id=target,operation="INSPECT",scope_id=s)["authorized"])

    def test_revoked_issuer_invalidates_existing_grant(self):
        c=self.add("Context","C","c"); owner=self.add("Actor","owner","owner")
        principal=self.add("Actor","p","p"); s=self.add("Scope","S","s")
        target=self.add("Candidate","X","x"); basis=self.add("Evidence","E","e",epistemic="OBSERVED")
        root=self.lab.establish_authority_root(context_id=c,scope_id=s,
            operations=["INSPECT"],holder_actor_id=owner,provenance_class="USER",provenance="user")
        self.lab.grant_authorization(context_id=c,entity_id=target,operation="INSPECT",scope_id=s,
            issuer_authority_id=root,issuer_actor_id=owner,principal_id=principal,
            basis_entity_ids=[basis],reason="grant",provenance_class="TEST",provenance="test")
        self.lab.revoke_authority(root,reason="revoke",provenance_class="TEST",provenance="test")
        self.assertFalse(self.lab.check_authorized(context_id=c,actor_id=principal,
            entity_id=target,operation="INSPECT",scope_id=s)["authorized"])

    def test_child_inherits_parent_expiry_if_omitted(self):
        c=self.add("Context","C","c"); owner=self.add("Actor","owner","owner")
        child_actor=self.add("Actor","child","child"); s=self.add("Scope","S","s")
        expiry=(dt.datetime.now(dt.timezone.utc)+dt.timedelta(days=1)).isoformat()
        root=self.lab.establish_authority_root(context_id=c,scope_id=s,
            operations=["INSPECT"],holder_actor_id=owner,max_delegation_depth=1,
            expires_at=expiry,provenance_class="USER",provenance="user")
        child=self.lab.delegate_authority(parent_authority_id=root,grantee_id=child_actor,
            scope_id=s,operations=["INSPECT"],max_delegation_depth=0,expires_at=None,
            reason="child",provenance_class="TEST",provenance="test")
        self.assertEqual(self.lab.authority_info(child)["expires_at"],expiry)

    def test_alpha_audit_detects_schema_gap_relink(self):
        c=self.add("Context","C","c"); actor=self.add("Actor","owner","actor")
        s=self.add("Scope","Schema","s"); frame=self.add("ValidityFrame","F","f",data={"conditions":{"k":"v"}})
        witness=self.add("Evidence","W","w",epistemic="OBSERVED")
        gap=self.lab.record_schema_gap(gap_kind="LANGUAGE_COLLISION",current_term="Candidate",
            missing_distinction="earned",provenance_class="TEST",provenance="test")
        proposal=self.lab.propose_schema_object_type(gap_id=gap,type_name="EarnedX",
            definition="earned",provenance_class="TEST",provenance="test")
        promotion=self.lab.record_promotion(context_id=c,entity_id=proposal,scope_id=s,
            validity_frame_id=frame,witness_entity_id=witness,basis_entity_ids=[witness],
            change_claim="earned",revalidation_rule="rerun",provenance_class="TEST",provenance="test")
        root=self.lab.establish_authority_root(context_id=c,scope_id=s,operations=["SCHEMA_CHANGE"],
            holder_actor_id=actor,provenance_class="USER",provenance="user")
        self.lab.grant_authorization(context_id=c,entity_id=proposal,operation="SCHEMA_CHANGE",
            scope_id=s,issuer_authority_id=root,issuer_actor_id=actor,principal_id=actor,
            basis_entity_ids=[witness,promotion],reason="grant",provenance_class="TEST",provenance="test")
        self.lab.apply_schema_object_type(proposal_id=proposal,promotion_episode_id=promotion,
            context_id=c,actor_id=actor,scope_id=s,reason="apply",provenance_class="TEST",provenance="test")
        gap2=self.lab.record_schema_gap(gap_kind="ONTOLOGY_LEAKAGE",current_term="Artifact",
            missing_distinction="unrelated",provenance_class="TEST",provenance="test")
        self.lab.conn.execute("UPDATE schema_changes SET gap_id=? WHERE term_name='EarnedX'",(gap2,))
        self.lab.conn.commit()
        audit=self.lab.alpha_audit()
        self.assertFalse(audit["passed"])
        self.assertTrue(any(x["check"]=="schema_governance" for x in audit["failures"]))

if __name__=="__main__":
    unittest.main()
