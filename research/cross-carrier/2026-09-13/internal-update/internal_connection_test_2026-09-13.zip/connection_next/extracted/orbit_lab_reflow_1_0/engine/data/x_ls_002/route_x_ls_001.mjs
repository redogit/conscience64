import fs from "node:fs/promises";
import crypto from "node:crypto";
import path from "node:path";

const featuresPath = process.argv[2];
const outputDir = process.argv[3];
if (!featuresPath || !outputDir) throw new Error("usage: route_x_ls_001.mjs FEATURES OUTPUT_DIR");
const sha256 = data => crypto.createHash("sha256").update(data).digest("hex");
const canonicalize = value => Array.isArray(value) ? value.map(canonicalize) : value && typeof value === "object" ? Object.fromEntries(Object.keys(value).sort().map(k => [k, canonicalize(value[k])])) : value;
const canonicalJson = value => JSON.stringify(canonicalize(value));

const featureBytes = await fs.readFile(featuresPath);
const pkg = JSON.parse(featureBytes);
const fields = pkg.fields;
const routeTable = {
  carrier: ["carrier_witness", {PRESENT:"CHECK_BRIDGE",ABSENT:"SEARCH_CARRIER"}],
  bridge: ["bridge_witness", {VERIFIED:"CHECK_COMPOSITION",ABSENT:"CONSTRUCT_BRIDGE"}],
  composition: ["composition_witness", {SUFFICIENT:"CHECK_BOUNDARY",UNTESTED:"TEST_COMPOSITION"}],
  boundary: ["boundary_ablation_effect", {RESTORES:"REMOVE_FALSE_OBSTRUCTION",DOES_NOT_RESTORE:"CHECK_ROUTING"}],
  retrieval: ["retrieval_state", {REACHABLE:"CHECK_COST",UNRECOGNIZED:"REPAIR_ROUTING"}],
  economics: ["net_value_state", {POSITIVE:"CHECK_CORRECTABILITY",NONPOSITIVE:"ARCHIVE_OR_REJECT"}],
  correction: ["correction_route_state", {OPEN:"ADMIT_BOUNDED_REUSE",CLOSED:"RESTORE_CORRECTION_ROUTE"}],
  measurement: ["measurement_state", {VALID:"ALLOW_MEASUREMENT_DEPENDENT_INFERENCE",INVALID:"REPAIR_MEASUREMENT"}],
  evidence: ["evidence_resolution", {DECISIVE:"APPLY_DECLARED_ROUTE",UNDERDETERMINED:"DESIGN_DISCRIMINATING_TEST"}],
};
const l0 = p => canonicalJson({probe_type:p.probe_type,routing_status:p.routing_status});
const l1 = (p, omit=null) => canonicalJson({probe_type:p.probe_type,routing_status:p.routing_status,probe_states:Object.fromEntries(fields.filter(f=>f!==omit).map(f=>[f,p.probe_states[f]]))});
const route = p => {
  const [field, values] = routeTable[p.probe_type] ?? [];
  return values?.[p.probe_states[field]] ?? "ROUTER_ERROR";
};
const project = f => ({probe_type:f.probe_type,routing_status:f.routing_status,probe_states:Object.fromEntries(fields.map(x=>[x,f.probe_states[x]]))});
const makeRows = features => features.map(f => {
  const p = project(f);
  return {
    case_id:f.case_id,pair_id:f.pair_id,surface_id:f.surface_id,
    input_sha256:sha256(canonicalJson(p)),l0_signature:l0(p),l1_signature:l1(p),
    ablation_signatures:Object.fromEntries(fields.map(field=>[field,l1(p,field)])),
    predicted_route_label:route(p),
  };
});
const baseRows = makeRows(pkg.features);
const attacks = [];
for (const [name, features] of [
  ["reversed", [...pkg.features].reverse()],
  ["hash_sorted", [...pkg.features].sort((a,b)=>sha256(canonicalJson(project(a))).localeCompare(sha256(canonicalJson(project(b)))))],
]) attacks.push({attack:name,rows:makeRows(features)});
const perms = [["S1","S2","S3"],["S1","S3","S2"],["S2","S1","S3"],["S2","S3","S1"],["S3","S1","S2"],["S3","S2","S1"]];
for (const perm of perms) {
  const remap = new Map(["S1","S2","S3"].map((x,i)=>[x,perm[i]]));
  const mutated = pkg.features.map(f=>({...f,source_ref:`source-${remap.get(f.surface_id)}`,target_ref:`target-${remap.get(f.surface_id)}`}));
  attacks.push({attack:`surface_reference_permutation_${perm.join("_")}`,rows:makeRows(mutated)});
}
const routeOutput = {
  experiment_id:pkg.experiment_id,panel_version:pkg.panel_version,
  phase:"ROUTING_WITH_FEATURES_ONLY",feature_file_sha256:sha256(featureBytes),fields,
  label_file_loaded:false,global_route_table_sha256:sha256(canonicalJson(routeTable)),
  rows:baseRows,attacks,
};
await fs.mkdir(outputDir,{recursive:true});
const outputPath=path.join(outputDir,"route_output.json");
await fs.writeFile(outputPath,JSON.stringify(routeOutput,null,2)+"\n");
const outputBytes=await fs.readFile(outputPath);
const phaseReport={phase:routeOutput.phase,records:baseRows.length,attacks:attacks.length,feature_file_sha256:routeOutput.feature_file_sha256,route_output_sha256:sha256(outputBytes),label_file_loaded:false};
await fs.writeFile(path.join(outputDir,"route_phase_report.json"),JSON.stringify(phaseReport,null,2)+"\n");
console.log(JSON.stringify(phaseReport));
