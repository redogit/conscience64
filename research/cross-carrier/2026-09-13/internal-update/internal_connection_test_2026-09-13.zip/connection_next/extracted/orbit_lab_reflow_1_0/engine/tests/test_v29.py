
import tempfile
from pathlib import Path
import unittest
from orbit_lab import OrbitLab

class V29Tests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.lab=OrbitLab(Path(self.tmp.name)/"t.db")
    def tearDown(self): self.lab.close(); self.tmp.cleanup()
    def add(self,t,title,key,**kw):
        return self.lab.add(t,title,provenance_class="TEST",provenance="test",identity_key=key,**kw)

    def governed_fixture(self, gap_kind, current_term, missing, proposal_kind="OBJECT"):
        ctx=self.add("Context","Schema context","ctx")
        actor=self.add("Actor","Schema owner","actor")
        scope=self.add("Scope","Schema","scope")
        frame=self.add("ValidityFrame","Schema frame","frame",data={"conditions":{"kernel":"test"}})
        witness=self.add("Evidence","collision witness","w",epistemic="OBSERVED")
        gap=self.lab.record_schema_gap(gap_kind=gap_kind,current_term=current_term,
            missing_distinction=missing,provenance_class="TEST",provenance="test")
        root=self.lab.establish_authority_root(context_id=ctx,scope_id=scope,
            operations=["SCHEMA_CHANGE"],holder_actor_id=actor,
            provenance_class="USER",provenance="test-user")
        return ctx,actor,scope,frame,witness,gap,root

    def promote_and_authorize(self, proposal, ctx, actor, scope, frame, witness, root):
        promotion=self.lab.record_promotion(context_id=ctx,entity_id=proposal,scope_id=scope,
            validity_frame_id=frame,witness_entity_id=witness,basis_entity_ids=[witness],
            change_claim="schema distinction earned",revalidation_rule="retest collision",
            provenance_class="TEST",provenance="test")
        self.lab.grant_authorization(context_id=ctx,entity_id=proposal,operation="SCHEMA_CHANGE",
            scope_id=scope,issuer_authority_id=root,issuer_actor_id=actor,principal_id=actor,
            basis_entity_ids=[witness,promotion],reason="promoted schema repair",
            provenance_class="TEST",provenance="test")
        return promotion

    def test_unknown_object_type_blocked_until_governed_repair(self):
        with self.assertRaises(ValueError):
            self.add("Pressure","pre-obligation pressure","p")
        ctx,actor,scope,frame,witness,gap,root=self.governed_fixture(
            "LANGUAGE_COLLISION","Obligation","pre-obligation pressure differs from obligation")
        proposal=self.lab.propose_schema_object_type(gap_id=gap,type_name="Pressure",
            definition="Observed tension before obligation is earned.",
            provenance_class="TEST",provenance="test")
        promotion=self.promote_and_authorize(proposal,ctx,actor,scope,frame,witness,root)
        self.lab.apply_schema_object_type(proposal_id=proposal,promotion_episode_id=promotion,
            context_id=ctx,actor_id=actor,scope_id=scope,reason="controlled cases require it",
            provenance_class="TEST",provenance="test")
        p=self.add("Pressure","pre-obligation pressure","p2")
        self.assertEqual(self.lab.get(p).type,"Pressure")

    def test_unknown_episode_kind_requires_governed_schema(self):
        a=self.add("Artifact","A","a"); b=self.add("Artifact","B","b")
        ctx,actor,scope,frame,witness,gap,root=self.governed_fixture(
            "LANGUAGE_COLLISION","generic relation","direction matters")
        proposal=self.lab.propose_schema_episode_type(gap_id=gap,kind="NEW_RELATION",
            definition="directional relation",
            roles={"left":{"required":True,"allowed":["OBJECT:Artifact"]},
                   "right":{"required":True,"allowed":["OBJECT:Artifact"]}},
            provenance_class="TEST",provenance="test")
        promotion=self.promote_and_authorize(proposal,ctx,actor,scope,frame,witness,root)
        self.lab.apply_schema_episode_type(proposal_id=proposal,promotion_episode_id=promotion,
            context_id=ctx,actor_id=actor,scope_id=scope,reason="direction changes action",
            provenance_class="TEST",provenance="test")
        ep=self.lab.add_episode("NEW_RELATION","x",
            participants=[{"role":"left","object_id":a},{"role":"right","object_id":b}],
            provenance_class="TEST",provenance="test")
        self.assertEqual(self.lab.episode(ep)["kind"],"NEW_RELATION")

if __name__=="__main__": unittest.main()
