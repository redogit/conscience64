
from __future__ import annotations
from pathlib import Path
import json, tempfile, sys, math
ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0,str(ROOT))
from orbit_lab import OrbitLab

def encode_address(path, branches=3, max_depth=6):
    u=0.0
    for j,c in enumerate(path, start=1):
        u += c/(branches**j)
    theta=2.0*math.pi*u
    r=len(path)/max_depth
    return {"depth":len(path),"theta":theta,"r":r}

def run():
    # Same recursive address, two materially different generator states.
    path=(1,0,2,1)
    address=encode_address(path)

    tree_state={
        "family":"Tree",
        "branch_genes":[
            {"theta_delta":0.35,"phi_delta":0.20,"scale":0.72},
            {"theta_delta":-0.40,"phi_delta":0.18,"scale":0.68},
        ],
        "formation":"stack_recursive_branch_expansion",
    }
    orbit_state={
        "family":"Orbit",
        "a":1.4,"b":-1.8,"c":0.7,"d":0.9,
        "spread":1.2,"height":0.35,"twist":0.15,
        "formation":"iterative_nonlinear_recurrence",
    }

    same_address = encode_address(path) == address
    distinct_generator_states = tree_state != orbit_state and tree_state["family"] != orbit_state["family"]

    with tempfile.TemporaryDirectory() as td:
        lab=OrbitLab(Path(td)/"generator-boundary.db")
        try:
            frame=lab.add(
                "ObservationFrame","Cross-shard representation comparison",
                data={
                    "observer":"generator-identity-probe",
                    "apparatus":"recovered Tree/Orbit state descriptors + verified address encoder",
                    "accessible_variables":["path","depth","address","generator_family","generator_parameters"],
                    "resolution":"structural finite witness",
                    "intervention":"hold address fixed while varying generator family/state",
                    "boundary":"structural non-identifiability witness; not a runtime test of the final React artifact"
                },
                provenance_class="TEST",provenance="generator-boundary",identity_key="frame"
            )

            address_ev=lab.add(
                "Evidence","Same path/depth address under Tree and Orbit candidate states",
                data={"evidence_tags":["ADDRESS_IDENTITY_WITNESS"],"address":address},
                epistemic="OBSERVED",provenance_class="TEST",provenance="generator-boundary",identity_key="address-evidence"
            )
            tree_ev=lab.add(
                "Artifact","Recovered Tree generator-state descriptor",
                data={"evidence_tags":["GENERATOR_STATE_DESCRIPTOR"],**tree_state},
                provenance_class="TEST",provenance="generator-boundary",identity_key="tree"
            )
            orbit_ev=lab.add(
                "Artifact","Recovered Orbit generator-state descriptor",
                data={"evidence_tags":["GENERATOR_STATE_DESCRIPTOR"],**orbit_state},
                provenance_class="TEST",provenance="generator-boundary",identity_key="orbit"
            )

            address_claim=lab.add(
                "Claim","Recursive address is recoverable for this encoded path",
                data={"required_evidence_tags":["ADDRESS_IDENTITY_WITNESS"]},
                provenance_class="TEST",provenance="generator-boundary",identity_key="address-claim"
            )
            lab.assess_claim(
                address_claim,frame_id=frame,evidence_ids=[address_ev],verdict="SUPPORTED",
                scope="one explicit cross-family witness using verified path/depth encoder",
                provenance_class="TEST",provenance="generator-boundary"
            )

            generator_claim=lab.add(
                "Claim","Recovered address uniquely identifies generator family/state",
                data={"required_evidence_tags":["GENERATOR_IDENTIFICATION_EVIDENCE"]},
                provenance_class="TEST",provenance="generator-boundary",identity_key="generator-claim"
            )
            address_only_blocked=False
            try:
                lab.assess_claim(
                    generator_claim,frame_id=frame,evidence_ids=[address_ev],verdict="SUPPORTED",
                    scope="cross-family witness",
                    provenance_class="TEST",provenance="generator-boundary"
                )
            except ValueError:
                address_only_blocked=True

            # Preserve the extra state explicitly as separate evidence; it is what
            # distinguishes the two generator families in this witness.
            extra_state_present = (
                "branch_genes" in tree_state
                and all(k in orbit_state for k in ("a","b","c","d","spread","height","twist"))
            )

            audit=lab.alpha_audit()
        finally:
            lab.close()

    return {
        "passed": (
            same_address and distinct_generator_states and address_only_blocked
            and extra_state_present and audit["passed"]
        ),
        "same_recursive_address":same_address,
        "distinct_generator_states":distinct_generator_states,
        "address":address,
        "tree_state":tree_state,
        "orbit_state":orbit_state,
        "address_only_cannot_certify_generator_identity":address_only_blocked,
        "extra_state_needed":[
            "generator family",
            "Tree branch-gene parameters or Orbit recurrence/embedding parameters",
            "formation mechanism"
        ],
        "final_react_runtime_claimed":False,
        "kernel_schema_additions":0,
        "audit_passed":audit["passed"]
    }

if __name__=="__main__":
    print(json.dumps(run(),indent=2,sort_keys=True))
