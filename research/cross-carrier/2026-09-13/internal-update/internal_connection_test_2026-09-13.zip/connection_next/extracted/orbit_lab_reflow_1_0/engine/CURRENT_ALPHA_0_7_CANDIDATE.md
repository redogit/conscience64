# Orbit Lab Alpha 0.7 — Wave 2 Candidate

Status: TESTED CANDIDATE / NOT AUTO-PROMOTED

Adds two earned distinctions over Alpha 0.6.1:
1. declared Claim justification dependencies cannot be bypassed by terminal `SUPPORTED` assessments;
2. Human Lab `Saw` exposes a non-blocking language-surface warning distilled from the Language Structure Workbench.

Verification: 124 tests; selector 13/13 components; no unresolved obligations.

See `docs/WAVE2_INTEGRATION_REPORT.md` and the two Wave 2 probe artifacts.
