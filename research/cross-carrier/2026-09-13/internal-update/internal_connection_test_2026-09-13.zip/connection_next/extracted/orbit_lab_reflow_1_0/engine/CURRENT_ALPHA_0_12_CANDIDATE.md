# Orbit Lab Alpha 0.12 candidate

Adds the cross-shard generator-identity boundary probe. No kernel schema change.
