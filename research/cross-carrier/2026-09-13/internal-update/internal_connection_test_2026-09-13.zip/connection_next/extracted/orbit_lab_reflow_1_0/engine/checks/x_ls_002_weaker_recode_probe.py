
from __future__ import annotations
from pathlib import Path
import hashlib,itertools,json,statistics,sys,tempfile
ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0,str(ROOT))
from orbit_lab import OrbitLab

DATA=ROOT/"data"/"x_ls_002"
MANIFEST=json.loads((DATA/"SOURCE_MANIFEST.json").read_text())

ROUTE={
    "carrier":("carrier_witness",{"PRESENT":"CHECK_BRIDGE","ABSENT":"SEARCH_CARRIER"}),
    "bridge":("bridge_witness",{"VERIFIED":"CHECK_COMPOSITION","ABSENT":"CONSTRUCT_BRIDGE"}),
    "composition":("composition_witness",{"SUFFICIENT":"CHECK_BOUNDARY","UNTESTED":"TEST_COMPOSITION"}),
    "boundary":("boundary_ablation_effect",{"RESTORES":"REMOVE_FALSE_OBSTRUCTION","DOES_NOT_RESTORE":"CHECK_ROUTING"}),
    "retrieval":("retrieval_state",{"REACHABLE":"CHECK_COST","UNRECOGNIZED":"REPAIR_ROUTING"}),
    "economics":("net_value_state",{"POSITIVE":"CHECK_CORRECTABILITY","NONPOSITIVE":"ARCHIVE_OR_REJECT"}),
    "correction":("correction_route_state",{"OPEN":"ADMIT_BOUNDED_REUSE","CLOSED":"RESTORE_CORRECTION_ROUTE"}),
    "measurement":("measurement_state",{"VALID":"ALLOW_MEASUREMENT_DEPENDENT_INFERENCE","INVALID":"REPAIR_MEASUREMENT"}),
    "evidence":("evidence_resolution",{"DECISIVE":"APPLY_DECLARED_ROUTE","UNDERDETERMINED":"DESIGN_DISCRIMINATING_TEST"}),
}

def _checked(name):
    p=DATA/name
    meta=MANIFEST["files"].get(name)
    if meta and hashlib.sha256(p.read_bytes()).hexdigest()!=meta["sha256"]:
        raise ValueError(f"digest mismatch: {name}")
    return p

def canon(x):
    return json.dumps(x,sort_keys=True,separators=(",",":"))

def run():
    feat=json.loads(_checked("features_frozen.json").read_text())
    labels=json.loads(_checked("labels_frozen.json").read_text())
    fields=feat["fields"]; rows=feat["features"]
    label_by={r["case_id"]:r["stipulated_route_label"] for r in labels["labels"]}

    def l1(r):
        return canon({
            "probe_type":r["probe_type"],
            "routing_status":r["routing_status"],
            "probe_states":{f:r["probe_states"][f] for f in fields},
        })
    def generic(r):
        field,_=ROUTE[r["probe_type"]]
        return canon({"probe_type":r["probe_type"],"probe_state":r["probe_states"][field]})
    def route(r):
        field,table=ROUTE[r["probe_type"]]
        return table[r["probe_states"][field]]

    partition_mismatch=[]
    for a,b in itertools.combinations(rows,2):
        if (l1(a)==l1(b)) != (generic(a)==generic(b)):
            partition_mismatch.append((a["case_id"],b["case_id"]))
    route_mismatch=[r["case_id"] for r in rows if route(r)!=label_by[r["case_id"]]]

    atom_by={}
    for r in rows:
        atom_by.setdefault(generic(r),r)
    atoms=list(atom_by.values())

    comp_map={}; comp_alias=[]; compositions=0
    for i,a in enumerate(atoms):
        for j in range(i,len(atoms)):
            b=atoms[j]; compositions+=1
            gs=tuple(sorted((generic(a),generic(b))))
            ls=tuple(sorted((l1(a),l1(b))))
            old=comp_map.setdefault(gs,ls)
            if old!=ls:
                comp_alias.append({"generic":gs,"first":old,"second":ls})

    l1_bytes=sum(len(l1(r).encode()) for r in rows)
    generic_bytes=sum(len(generic(r).encode()) for r in rows)
    x1=json.loads(_checked("x_ls_001_archived_result_summary.json").read_text())
    x1_recovered=(
        x1["protocol_passed"] is True
        and x1["baseline_collision_groups"]==9
        and x1["candidate_collision_groups"]==0
        and x1["router_exact_matches"]==54
        and MANIFEST["x_ls_001_rerun"]["byte_identical"]
    )

    with tempfile.TemporaryDirectory() as td:
        lab=OrbitLab(Path(td)/"xls002.db")
        try:
            frame=lab.add(
                "ObservationFrame","X-LS-002 weaker recoding",
                data={
                    "observer":"xls002-orbit-probe",
                    "apparatus":"exact frozen X-LS-001 panel + exhaustive Python recoder",
                    "accessible_variables":["probe_type","probe_state","L1_signature","route_label"],
                    "resolution":"54 records + 171 unordered pairwise compositions",
                    "intervention":"replace nine named probe-state fields with one probe_state selected by probe_type",
                    "boundary":"constructed serializer/routing panel; stipulated labels are not real-world action truth"
                },
                provenance_class="TEST",provenance="xls002",identity_key="frame"
            )
            candidate=lab.add(
                "Candidate","(probe_type, probe_state) weaker recoding",
                data={"candidate_role":"REPRESENTATION","named_state_fields":1},
                provenance_class="TEST",provenance="xls002",identity_key="candidate"
            )
            result=lab.add(
                "Evidence","X-LS-002 bounded weaker-recoding result",
                data={
                    "source_role":"EMPIRICAL_RESULT",
                    "evidence_tags":["WEAKER_RECODING_RESULT"],
                    "records":len(rows),
                    "partition_mismatches":len(partition_mismatch),
                    "route_mismatches":len(route_mismatch),
                    "composition_cases":compositions,
                    "composition_aliases":len(comp_alias),
                    "serialized_byte_reduction_ratio":l1_bytes/generic_bytes,
                },
                epistemic="OBSERVED",
                provenance_class="TEST",provenance="xls002",identity_key="result"
            )
            claim=lab.add(
                "Claim","Nine named state fields are not required as the weaker sufficient serializer on the frozen X-LS panel",
                data={
                    "required_evidence_tags":["WEAKER_RECODING_RESULT"],
                    "evidence_source_role_contract":{
                        "allowed":["EMPIRICAL_RESULT"],
                        "require_declared_role":True
                    }
                },
                provenance_class="TEST",provenance="xls002",identity_key="claim"
            )
            ep=lab.assess_claim(
                claim,frame_id=frame,evidence_ids=[result],verdict="SUPPORTED",
                scope="X-LS-001 frozen 54-record panel + 171 synthetic pairwise composition cases only",
                provenance_class="TEST",provenance="xls002"
            )
            supported=lab.episode(ep)["data"]["verdict"]=="SUPPORTED"
            audit=lab.alpha_audit()
        finally:
            lab.close()

    return {
        "passed":(
            x1_recovered and not partition_mismatch and not route_mismatch
            and not comp_alias and compositions==171 and len(atoms)==18
            and generic_bytes<l1_bytes and supported and audit["passed"]
        ),
        "x_ls_001_archived_result_recovered":x1_recovered,
        "x_ls_001_source_package_sha256":MANIFEST["x_ls_001_package_sha256"],
        "records":len(rows),
        "semantic_atoms":len(atoms),
        "nine_field_partition_equals_generic":not partition_mismatch,
        "partition_mismatches":partition_mismatch[:20],
        "generic_router_exact_matches":len(rows)-len(route_mismatch),
        "generic_router_mismatches":route_mismatch,
        "cross_probe_pairwise_compositions":compositions,
        "cross_probe_composition_aliases":len(comp_alias),
        "serialized_bytes":{"nine_field":l1_bytes,"generic":generic_bytes},
        "serialized_byte_reduction_ratio":l1_bytes/generic_bytes,
        "named_state_fields":{"prior":9,"weaker":1},
        "bounded_reduction_claim_supported":supported,
        "conversation_record_independent_copy_byte_identical":MANIFEST["conversation_record"]["independent_copy_byte_identical"],
        "kernel_schema_additions":0,
        "audit_passed":audit["passed"],
        "claim_ceiling":[
            "frozen constructed X-LS-001 panel plus synthetic pairwise composition panel only",
            "stipulated route labels are not validated as correct real-world actions",
            "one generic probe_state is not established sufficient for open-world MoonShot",
            "global minimality is not claimed"
        ]
    }

if __name__=="__main__":
    print(json.dumps(run(),indent=2,sort_keys=True))
