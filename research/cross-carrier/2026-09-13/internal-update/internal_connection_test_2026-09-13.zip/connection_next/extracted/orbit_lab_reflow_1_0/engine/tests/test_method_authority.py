import unittest
from checks.method_authority_probe import run
class MethodAuthorityTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls): cls.r=run()
    def test_relevance_not_authority(self):
        self.assertTrue(self.r["predecessor_relevant_but_blocked_from_current_method_claim"])
        self.assertTrue(self.r["current_method_can_satisfy_current_method_claim"])
    def test_method_drift_is_audited(self):
        self.assertTrue(self.r["post_support_method_drift_detected"])
    def test_custody_cleanup_is_backed(self):
        self.assertTrue(self.r["guide_duplicate_verified"])
        self.assertTrue(self.r["mapping_duplicate_verified"])
    def test_no_schema_growth(self): self.assertEqual(self.r["kernel_schema_additions"],0)
if __name__=="__main__": unittest.main()
