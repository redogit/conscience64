
from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import hashlib, json, struct

# This module is a task-local verification index, not a new kernel ontology.
# The verbose registry is preserved as source/recovery state. The active binary
# carrier contains only obligation->probe incidence.

BASE=Path(__file__).resolve().parent
ROW=struct.Struct("<HQ")  # obligation index, probe bitset (<=64 probes)

@dataclass(frozen=True)
class ProbeSpec:
    name:str
    level:str
    obligations:tuple[str,...]
    callable_name:str
    release_only:bool=False

PROBES=(
    ProbeSpec("task-compile","S0",("compile",),"probe_task_compile"),
    ProbeSpec("human-interface-core","S0",(
        "human-card","observation-inference-separation","no-raw-id-default",
        "progressive-disclosure","recoverable-current","connected-human-view",
    ),"probe_human_interface_core"),
    ProbeSpec("core-sentinel","S5",(
        "authority","schema","scope","state","epistemic","lineage","whole-integration",
    ),"probe_s5_whole"),
    ProbeSpec("state-recovery","S1",(
        "roundtrip","tamper-reject","audit",
    ),"probe_s1_state"),
    ProbeSpec("historical-lineage","S1",(
        "historical-classification","no-unexplained-historical-failure","historical-status","history",
    ),"probe_s1_historical"),
    ProbeSpec("research-loader","S1",("research-load",),"probe_s1_loader"),
    ProbeSpec("connections-ingress","S1",(
        "connection-map","quarantine-preserved","non-evidentiary-bridges","source-boundaries",
    ),"probe_s1_connections"),
    ProbeSpec("connections-cross-branch","S4",("cross-branch-no-merge",),"probe_s4_connections"),
    ProbeSpec("human-pair","S4",("comparison-interpretation-separation",),"probe_s4_human_pair"),
    ProbeSpec("hodge-justification","S4",(
        "claim-dependency-containment","theorem-application-separation",
    ),"probe_s4_hodge_justification"),
    ProbeSpec("language-surface","S4",(
        "epistemic-surface-warning","workbench-transfer-bounded",
    ),"probe_s4_language_transfer"),
    ProbeSpec("bgzf-carrier","S4",(
        "exact-vs-learned-separation","weak-label-not-ground-truth","resource-accounting-scope",
    ),"probe_s4_bgzf_carrier"),
    ProbeSpec("bridge-transfer","S4",(
        "bridge-obligation-qualification","insufficient-transfer-evidence-unresolved",
        "transfer-authority-separation",
    ),"probe_s4_bridge_obligation"),
    ProbeSpec("fractal-frame","S4",(
        "designed-inverse-vs-generic-inference","simulation-not-physical",
        "implementation-not-measurement","bookkeeping-not-capacity",
    ),"probe_s4_fractal_representation"),
    ProbeSpec("source-lineage","S4",(
        "static-source-not-runtime-evidence","failure-repair-lineage","variant-identity-preserved",
    ),"probe_s4_source_execution_lineage"),
    ProbeSpec("generator-boundary","S4",(
        "address-not-generator-identity","generator-extra-state-visible","runtime-boundary-preserved",
    ),"probe_s4_generator_identity_boundary"),
    ProbeSpec("shadow-integrity","S4",(
        "declared-denominator-linked","unknown-observation-preserved",
        "same-label-identity-separated","post-support-evidence-drift-detected",
    ),"probe_s4_shadow_evidence_integrity"),
    ProbeSpec("tbcl-active-carrier","S4",(
        "compact-action-equivalence","harmless-recoding-invariance",
        "consequential-ablation-detected","provenance-recoverable-after-compression",
    ),"probe_s4_tbcl_active_carrier"),
    ProbeSpec("retrieval-neighborhood","S4",(
        "narrow-equals-broad","project-source-role-preserved",
        "widen-on-missing-source","provenance-recoverable-on-retrieval",
    ),"probe_s4_retrieval_neighborhood"),
    ProbeSpec("operator-primary-route","S4",(
        "map-to-primary-route","locator-not-primary-evidence",
        "primary-source-identity-recoverable","bounded-consensus-grounding-counterexample",
    ),"probe_s4_operator_primary_route"),
    ProbeSpec("philosophy-source-role","S4",(
        "philosophy-not-empirical-evidence","philosophy-may-motivate-question",
        "claim-local-source-role","source-role-audit",
    ),"probe_s4_philosophy_source_role"),
    ProbeSpec("language-weaker-recoding","S4",(
        "weaker-recode-partition-equivalence","weaker-recode-route-equivalence",
        "cross-probe-composition-no-alias","language-schema-cost-reduced",
    ),"probe_s4_x_ls_002_weaker_recode"),
    ProbeSpec("gr-qm-tidal-bridge","S4",(
        "affine-gravity-ablation","recoil-tidal-formula","curvature-transport-convention",
        "structural-empirical-witness-separation","quantum-gravity-nonupgrade",
        "source-output-lineage-preserved",
    ),"probe_s4_gr_qm_tidal_phase"),
    ProbeSpec("method-authority-boundary","S4",(
        "method-relevance-not-authority","current-method-compliance-required",
        "method-drift-audited","method-custody-recoverable",
    ),"probe_s4_method_authority"),
    ProbeSpec("research-card-negative-retrieval","S4",(
        "card-to-bounded-search","negative-search-not-nonexistence",
        "unresolved-remainder-preserved","negative-retrieval-custody",
    ),"probe_s4_research_card_negative_retrieval"),
    ProbeSpec("low-attention-penny-pilot","S4",(
        "monthly-only-replay","preexisting-risk-brake-enforced",
        "withdrawal-not-principal-protection","exposure-reduction-bounded",
        "posthoc-boundary-not-promoted","stress-panel-source-boundary",
    ),"probe_s4_penny_monthly_attention"),
    ProbeSpec("gdsn-work-helper","S4",(
        "gdsn-task-local-vocabulary","gdsn-status-boundary",
        "gdsn-rfcin-subscription-boundary","gdsn-local-implementation-boundary",
        "gdsn-work-privacy-boundary",
    ),"probe_s4_gdsn_work_helper"),
    ProbeSpec("library-fold-stage1","S4",(
        "incoming-stage-classified","historical-method-not-current",
        "candidate-import-boundary","source-custody-to-history","remaining-library-staged",
    ),"probe_s4_library_fold_stage1"),
    ProbeSpec("library-fold-remaining","S4",(
        "project-delta-only","bounded-negative-imported","pdr-candidate-boundary",
        "shadow-campaign-boundary","source-roots-preserved","privacy-stage-reserved",
        "loose-root-progressive-retrieval",
    ),"probe_s4_library_fold_remaining"),
    ProbeSpec("library-support-retrieval","S4",(
        "support-exact-identity-first","support-association-not-evidence",
        "support-ambiguity-preserved","support-unresolved-not-substituted",
        "support-provenance-scope-preserved","support-private-default-exclusion",
        "support-progressive-widening",
    ),"probe_s4_library_support"),
    ProbeSpec("bounded-reference","S4",("bounded-exact","metamorphic"),"probe_s4_bounded"),
    ProbeSpec("orbital-adversary","S2",(
        "random-composition","no-novel-counterexample","no-harness-error",
    ),"probe_s2_orbital"),
    ProbeSpec("supporter-ecology","S3",(
        "mechanism-diversity","no-supporter-finding","retain-pressure",
    ),"probe_s3_ecology"),
    ProbeSpec("supporter-router","S3",(
        "applicability-routing","minimum-cost-cover","no-false-independence","profile-coverage",
    ),"probe_s3_router"),
    # The full regression suite is intentionally not in the active carrier.
    # It remains the release/promotion gate in selector.probe_s0_compile_tests().
)

# Named task profiles are convenience views over declared obligations.
PROFILES={
    "claim-admission":(
        "claim-dependency-containment","theorem-application-separation",
        "exact-vs-learned-separation","weak-label-not-ground-truth",
        "declared-denominator-linked","post-support-evidence-drift-detected",
    ),
    "transfer-safety":(
        "bridge-obligation-qualification","insufficient-transfer-evidence-unresolved",
        "transfer-authority-separation",
    ),
    "representation-boundary":(
        "designed-inverse-vs-generic-inference","simulation-not-physical",
        "implementation-not-measurement","bookkeeping-not-capacity",
        "address-not-generator-identity","generator-extra-state-visible",
    ),
    "human-surface":(
        "comparison-interpretation-separation","epistemic-surface-warning",
        "workbench-transfer-bounded",
    ),
    "campaign-integrity":(
        "declared-denominator-linked","unknown-observation-preserved",
        "same-label-identity-separated","post-support-evidence-drift-detected",
    ),
    "recovery-integrity":(
        "roundtrip","tamper-reject","audit","historical-classification",
        "no-unexplained-historical-failure",
    ),
    "supporter-selection":(
        "applicability-routing","minimum-cost-cover","no-false-independence","profile-coverage",
    ),
    "active-compression":(
        "compact-action-equivalence","harmless-recoding-invariance",
        "consequential-ablation-detected","provenance-recoverable-after-compression",
    ),
    "research-retrieval":(
        "narrow-equals-broad","project-source-role-preserved",
        "widen-on-missing-source","provenance-recoverable-on-retrieval",
    ),
    "primary-evidence-route":(
        "map-to-primary-route","locator-not-primary-evidence",
        "primary-source-identity-recoverable","bounded-consensus-grounding-counterexample",
    ),
    "philosophy-boundary":(
        "philosophy-not-empirical-evidence","philosophy-may-motivate-question",
        "claim-local-source-role","source-role-audit",
    ),
    "language-recoding":(
        "weaker-recode-partition-equivalence","weaker-recode-route-equivalence",
        "cross-probe-composition-no-alias","language-schema-cost-reduced",
    ),
    "gr-qm-tidal":(
        "affine-gravity-ablation","recoil-tidal-formula","curvature-transport-convention",
        "structural-empirical-witness-separation","quantum-gravity-nonupgrade",
        "source-output-lineage-preserved",
    ),
    "method-authority":(
        "method-relevance-not-authority","current-method-compliance-required",
        "method-drift-audited","method-custody-recoverable",
    ),
    "research-card":(
        "card-to-bounded-search","negative-search-not-nonexistence",
        "unresolved-remainder-preserved","negative-retrieval-custody",
    ),
    "gdsn-work":(
        "gdsn-task-local-vocabulary","gdsn-status-boundary",
        "gdsn-rfcin-subscription-boundary","gdsn-local-implementation-boundary",
        "gdsn-work-privacy-boundary",
    ),
    "library-fold-stage1":(
        "incoming-stage-classified","historical-method-not-current",
        "candidate-import-boundary","source-custody-to-history","remaining-library-staged",
    ),
    "library-fold":(
        "project-delta-only","bounded-negative-imported","pdr-candidate-boundary",
        "shadow-campaign-boundary","source-roots-preserved","privacy-stage-reserved",
        "loose-root-progressive-retrieval",
    ),
    "library-support":(
        "support-exact-identity-first","support-association-not-evidence",
        "support-ambiguity-preserved","support-unresolved-not-substituted",
        "support-provenance-scope-preserved","support-private-default-exclusion",
        "support-progressive-widening",
    ),
    "penny-monthly-attention":(
        "monthly-only-replay","preexisting-risk-brake-enforced",
        "withdrawal-not-principal-protection","exposure-reduction-bounded",
        "posthoc-boundary-not-promoted","stress-panel-source-boundary",
    ),
}

def source_registry():
    return {
        "probes":[{
            "name":p.name,"level":p.level,"obligations":list(p.obligations),
            "callable_name":p.callable_name
        } for p in PROBES],
        "profiles":{k:list(v) for k,v in sorted(PROFILES.items())},
    }

def registry_digest():
    raw=json.dumps(source_registry(),sort_keys=True,separators=(",",":")).encode()
    return hashlib.sha256(raw).hexdigest()

def compile_carrier(path:Path):
    obligations=sorted({o for p in PROBES for o in p.obligations})
    oidx={o:i for i,o in enumerate(obligations)}
    pidx={p.name:i for i,p in enumerate(PROBES)}
    rows=[]
    for obligation in obligations:
        bits=0
        for p in PROBES:
            if obligation in p.obligations:
                bits |= 1 << pidx[p.name]
        rows.append(ROW.pack(oidx[obligation],bits))
    header={
        "format":"ORBIT-VERIFY-REL-1",
        "registry_sha256":registry_digest(),
        "obligations":obligations,
        "probes":[p.name for p in PROBES],
        "row_size":ROW.size,
    }
    h=json.dumps(header,sort_keys=True,separators=(",",":")).encode()
    blob=len(h).to_bytes(4,"little")+h+b"".join(rows)
    path.write_bytes(blob)
    return {"bytes":len(blob),"rows":len(rows),"sha256":hashlib.sha256(blob).hexdigest()}

def load_carrier(path:Path):
    blob=path.read_bytes()
    n=int.from_bytes(blob[:4],"little")
    header=json.loads(blob[4:4+n])
    if header["registry_sha256"]!=registry_digest():
        raise ValueError("verification carrier registry digest mismatch")
    body=blob[4+n:]
    if len(body)%ROW.size:
        raise ValueError("verification carrier row alignment mismatch")
    relation={}
    for off in range(0,len(body),ROW.size):
        oi,bits=ROW.unpack(body[off:off+ROW.size])
        relation[header["obligations"][oi]]=bits
    if set(relation)!=set(header["obligations"]):
        raise ValueError("verification carrier obligation coverage mismatch")
    return header,relation

def plan(obligations,carrier_path:Path|None=None,include_core=True):
    carrier_path=carrier_path or BASE/"data"/"verification_carrier.bin"
    header,relation=load_carrier(carrier_path)
    obligations=tuple(dict.fromkeys(obligations))
    unknown=sorted(set(obligations)-set(relation))
    if unknown:
        return {"passed":False,"reason":"UNCOVERED_OBLIGATION","uncovered":unknown,"probes":[]}

    selected=set()
    # Exact minimum number of probes over the usually tiny candidate set.
    # Enumerate only providers that touch requested obligations.
    candidates=set()
    for o in obligations:
        bits=relation[o]
        for i,name in enumerate(header["probes"]):
            if bits & (1<<i): candidates.add(name)
    cand=sorted(candidates)
    target=set(obligations)

    best=None
    from itertools import combinations
    for r in range(len(cand)+1):
        for combo in combinations(cand,r):
            covered=set()
            for name in combo:
                spec=next(p for p in PROBES if p.name==name)
                covered.update(spec.obligations)
            if target <= covered:
                best=list(combo); break
        if best is not None: break

    if best is None:
        return {"passed":False,"reason":"NO_COVER","uncovered":list(obligations),"probes":[]}
    if include_core and "core-sentinel" not in best:
        best=["core-sentinel"]+best
    return {
        "passed":True,
        "obligations":list(obligations),
        "probes":best,
        "active_probe_count":len(best),
        "cold_full_regression_gate":"selector.probe_s0_compile_tests",
    }

def audit_carrier(path:Path|None=None):
    path=path or BASE/"data"/"verification_carrier.bin"
    try:
        header,relation=load_carrier(path)
    except Exception as exc:
        return {"passed":False,"error":str(exc)}
    uncovered=[o for o,b in relation.items() if b==0]
    profiles={}
    for name,obs in PROFILES.items():
        profiles[name]=plan(obs,path)
    return {
        "passed":not uncovered and all(x["passed"] for x in profiles.values()),
        "carrier_bytes":path.stat().st_size,
        "registry_sha256":header["registry_sha256"],
        "obligations":len(relation),
        "probes":len(header["probes"]),
        "uncovered":uncovered,
        "profiles":profiles,
    }

if __name__=="__main__":
    p=BASE/"data"/"verification_carrier.bin"
    p.parent.mkdir(exist_ok=True)
    print(json.dumps({"compile":compile_carrier(p),"audit":audit_carrier(p)},indent=2,sort_keys=True))
