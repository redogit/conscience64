import tempfile, unittest
from pathlib import Path
from connections import ConnectionMap
from orbit_lab import OrbitLab

class ConnectionTests(unittest.TestCase):
    def test_manifest_valid_and_all_quarantined(self):
        m=ConnectionMap(); self.assertTrue(m.validate())
        self.assertTrue(all(b['status']=='QUARANTINED' for b in m.branches))

    def test_seed_preserves_quarantine_and_non_evidentiary_associations(self):
        m=ConnectionMap(); r=m.check()
        self.assertTrue(r['passed'],r)
        self.assertTrue(r['all_quarantined'])
        self.assertTrue(r['all_non_evidentiary'])
        self.assertGreaterEqual(r['branches'],12)

    def test_human_why_preserves_separate_sources(self):
        m=ConnectionMap(); text=m.why('selector')
        self.assertIn('One_Level_Up',text)
        self.assertIn('R3 Scientific Method',text)
        self.assertIn('candidate connections with separate provenance',text)

    def test_every_current_connection_has_nonclaim(self):
        m=ConnectionMap()
        for b in m.branches:
            self.assertTrue(b['does_not_establish'],b['id'])

    def test_connected_seed_is_idempotent_after_complete_seed(self):
        import tempfile
        from pathlib import Path
        m=ConnectionMap()
        with tempfile.TemporaryDirectory() as td:
            db=Path(td)/"connected.db"
            a=m.seed(db)
            b=m.seed(db)
            self.assertEqual(a["subject"],b["subject"])
            self.assertEqual(a["sources"],b["sources"])
            self.assertEqual(a["associations"],b["associations"])
            self.assertTrue(b["audit"]["passed"])

if __name__=='__main__': unittest.main()
