# Orbit Lab Alpha 0.10 — Fractal Representation Boundary Candidate

The recovered Fractal Unroll / Mirror branch was used as an external laboratory.

## Newly executed experiment

Recovered source SHA-256:

`03565359c53cdc655c76bd2a140267d058680a572c0ee0a294f798739a4f9acf`

Registered exhaustive universe:

- branches: 2, 3, 4, 5
- depths: 1 through 7
- encoded non-root paths: 123,032

Results:

- repeated floating `floor(k*u)` decoder: 53,589 failures;
- finite-radix scaled-integer decoder: 0 failures.

The result repairs the numerical decoder, not the claim ceiling.

## Preserved distinctions

- designed address round-trip != arbitrary 2D-to-3D inverse inference;
- address recovery != unique 3D generator identification;
- 1 ns simulation increment != physical timing capability;
- implemented sensing logic != measured detector behavior;
- idealized raw bit accounting != physical channel capacity.

No kernel schema addition was required. Existing Claim evidence qualifications and
ObservationFrame boundaries were sufficient.

This branch therefore earned a new regression/support probe, not a new ontology.
