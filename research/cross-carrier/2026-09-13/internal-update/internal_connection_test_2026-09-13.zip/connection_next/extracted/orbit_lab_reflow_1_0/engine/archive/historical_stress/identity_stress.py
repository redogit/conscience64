
import tempfile
from pathlib import Path
from orbit_lab import OrbitLab

with tempfile.TemporaryDirectory() as td:
    lab=OrbitLab(Path(td)/"stress.db")
    passes=[]; breaks=[]
    try:
        f=lab.add("ObservationFrame","frame",data={"observer":"t","apparatus":"sim","accessible_variables":["y"],"resolution":"1","intervention":"toggle","boundary":"b"},provenance_class="TEST",provenance="run:42",identity_key="f")
        params=lab.add("Parameters","params",data={"lr":0.1},provenance_class="TEST",provenance="run:42",identity_key="params")
        reset=lab.add("Artifact","reset",provenance_class="TEST",provenance="run:42",identity_key="reset")
        p=lab.add("Probe","same probe",provenance_class="TEST",provenance="run:42",identity_key="p")
        o=lab.add("Observation","same observation",data={"score":0.7},provenance_class="TEST",provenance="run:42",identity_key="o",epistemic="OBSERVED")
        ex1=lab.record_execution(probe_id=p,frame_id=f,parameters_id=params,reset_id=reset,observation_ids=[o],status="COMPLETED",provenance_class="PRIMARY_ARTIFACT",provenance="run:42")
        ex2=lab.record_execution(probe_id=p,frame_id=f,parameters_id=params,reset_id=reset,observation_ids=[o],status="COMPLETED",provenance_class="PRIMARY_ARTIFACT",provenance="run:42")
        if ex1 != ex2:
            breaks.append(
                "The exact same run locator and participants can be recorded as two distinct EXECUTION Episodes "
                "when identity_key is omitted. A replay/duplicate can masquerade as independent replication."
            )

        # Verify nuisance matching itself now works.
        p2=lab.add("Probe","second condition",provenance_class="TEST",provenance="stress",identity_key="p2")
        o2=lab.add("Observation","second obs",provenance_class="TEST",provenance="stress",identity_key="o2",epistemic="OBSERVED")
        ex3=lab.record_execution(probe_id=p2,frame_id=f,parameters_id=params,reset_id=reset,observation_ids=[o2],status="COMPLETED",provenance_class="TEST",provenance="run:43")
        c=lab.add("Candidate","candidate",provenance_class="TEST",provenance="stress",identity_key="c")
        out=lab.add("Observation","delta",provenance_class="TEST",provenance="stress",identity_key="out",epistemic="OBSERVED")
        lab.add_episode("MATCHED_COUNTERFACTUAL","matched",
            participants=[{"role":"candidate","object_id":c},{"role":"reset","object_id":reset},
                          {"role":"control","episode_id":ex1},{"role":"treatment","episode_id":ex3},
                          {"role":"result","object_id":out}],
            provenance_class="TEST",provenance="stress")
        passes.append("Matched counterfactual now rejects nuisance-parameter drift and accepts shared Parameters.")

        print("V0.10 PARAMETERS / IDENTITY STRESS")
        print("---------------------------------")
        print("PASS:")
        for x in passes: print("-",x)
        print("\nNEXT BREAK:")
        for i,x in enumerate(breaks,1): print(f"{i}. {x}")
    finally:
        lab.close()
