import tempfile, unittest
from pathlib import Path
from human_lab import HumanLab, dispatch
from supporters.surface_guard import inspect_surface

class SurfaceGuardTests(unittest.TestCase):
    def test_workbench_derived_inference_markers_warn_on_saw(self):
        r=inspect_surface('Therefore the change may help.',intended_role='Observation')
        kinds={x['kind'] for x in r['signals']}
        self.assertIn('INFERENCE_LIKE',kinds); self.assertIn('MODAL_UNCERTAINTY',kinds)
        self.assertTrue(r['warnings']); self.assertFalse(r['blocked'])

    def test_plain_bounded_observation_is_not_blocked_or_rewritten(self):
        r=inspect_surface('The score was 13 after the change.',intended_role='Observation')
        self.assertFalse(r['blocked'])
        # comparison/change wording may warn, but the guard never changes the role itself.

    def test_human_lab_preserves_observation_but_surfaces_warning(self):
        with tempfile.TemporaryDirectory() as td:
            h=HumanLab(Path(td)/'t.db')
            try:
                h.start('Does the change help?')
                out=dispatch(h,['saw','Therefore the change may help.'])
                obs=h.lab.scan()['observation'][-1]
                self.assertEqual(obs['type'],'Observation')
                self.assertEqual(obs['epistemic'],'OBSERVED')
                self.assertIn('Surface check:',out)
                self.assertTrue(obs['data']['surface_guard']['warnings'])
            finally: h.close()

if __name__=='__main__': unittest.main()
