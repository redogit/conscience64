# Alpha 0.6 — Connected Research

## Purpose

Connect recovered Library branches to Orbit Lab without inheriting their authority or merging their vocabularies.

A connection is currently **navigation + test pressure**. It has no evidentiary, authority, applicability, activation, or movement effect by itself.

## Current connection layer

Fourteen recovered branches are represented through `data/research_connections.json`.

Each branch retains:
- source path;
- QUARANTINED status;
- candidate roles;
- bounded contributions;
- explicit non-claims;
- candidate connections to existing Orbit Lab components.

`connections.py` loads those records into existing kernel structures:
- `Collection` for branch organization;
- quarantined `Artifact` for the reviewed source;
- `Scope` for the intake review;
- non-evidentiary `ASSOCIATION` episodes for candidate relevance.

No new kernel object or episode kind was required.

## Cross-branch joints retained without merging

1. **Observation before interpretation** — CSOL + One_Level_Up + R3.
2. **Agreement is not grounding** — 4D observer + R3.
3. **Local validity is not whole sufficiency** — PulseNet GP + Musilanguage + Computer Mind.
4. **Small active / large recoverable** — One_Level_Up + R3 + Operator Moonshot + MoonShot root + TBCL.

These are convergent pressures/counterexamples, not equivalence proofs or independent replications.

## Earned human-interface repair

The first paired-condition test exposed a real collision:

- `Saw` is raw observation.
- `Thought` is interpretation.
- a deterministic/derived comparison is neither.

Alpha 0.6 therefore adds the human command:

```text
compare <text>
```

The implementation uses the existing `Inference` kernel object with task-local metadata `human_surface=Comparison` and explicit `DERIVED_FROM` links to the current observations. No kernel schema type was added.

A bounded probe verified that two raw observations, one comparison, and one interpretation remain distinct while raw IDs stay hidden from the Research Card.

## Human surface additions

```text
incoming
why <area>
compare <text>
```

`incoming` shows the connected quarantined branches.

`why <area>` explains which recovered branches pressure a current lab area and what those sources do **not** establish.

## Current gate result

See `artifacts/latest_selector_run.json`.

At this checkpoint:
- 11 active components pass;
- 41/41 declared obligations resolve;
- 113 regression/invariant tests pass;
- 14 recovered branches remain quarantined;
- 32 candidate associations remain non-evidentiary;
- 4 cross-branch joints pass without forced merging;
- zero kernel schema additions were required for the connection layer.

## Boundary

This is not an integration of all source theories into one theory.

The active rule remains:

> Connect enough to retrieve, test, and compare. Admit only when a concrete action-relevant failure or verified benefit earns the transfer.
