# Alpha 0.8 candidate — BGZF carrier / evidence qualification

## Source pressure

BGZF recovered obligations require exact deterministic summaries to remain distinct from learned state, child-state learning to remain local, file-level labels not to become block truth, and storage claims to stay scoped to what was actually counted.

## Independent source recheck

- source SHA-256: `344907f2ada9462e658aadf74fa404ca99325bebf9e424a934d50e7d7e265e51`
- rebuilt stripped executable: 92,624 bytes
- selftest: 8/8
- direct embedding max error: 0
- split embedding max error: 0

## Earned failure

Alpha 0.7 allowed any Artifact/Observation/Evidence to be supplied to a Claim assessment. A learned-state artifact could therefore be used to SUPPORT a Claim whose obligation explicitly required an exact deterministic carrier.

## Smallest repair

No new object or episode type was added. Claims may declare `required_evidence_tags`; cited Evidence/Observation/Artifact objects may declare `evidence_tags`. A `SUPPORTED` assessment now requires every declared tag to be supplied by the cited evidence. `alpha_audit()` rechecks the same condition.

This is qualification, not authentication: a tag does not prove the evidence is truthful. Provenance, execution, and domain-specific verification still matter.

## BGZF consequences

- learned adaptive state cannot satisfy an exact-carrier claim;
- a file-level weak label cannot satisfy block-level ground truth;
- exact independently rebuilt selftest evidence can support the bounded exact-summary claim;
- documented executable+model bytes fit the declared artifact budget;
- the stronger full-deployment-footprint claim remains blocked until runtime dependency accounting is supported.
