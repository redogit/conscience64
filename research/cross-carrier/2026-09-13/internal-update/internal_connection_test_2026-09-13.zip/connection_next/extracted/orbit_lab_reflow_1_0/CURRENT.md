# Orbit Lab — Current: Reflow 1.0

## Start here

Orbit Lab is now organized as **Work → Verify → Library**.

For normal use, begin with one question:

```text
python orbit.py start "<question>"
```

Then fill only what becomes necessary:

```text
need "..."
limit "..."
try "..."
saw "..."
left "..."
```

Use `find-support` when Library material could change the answer.
Use `gdsn` for non-persistent GDSN triage.
Use the verifier profiles when a result matters enough to promote or release.

## Current contract

- Ethics can constrain/reject action; it is not evidence.
- Observation remains separate from interpretation and decision.
- Retrieval is candidate generation, not proof.
- Exact identity/provenance outrank semantic similarity.
- Support is claim- and scope-specific.
- Current remains small; history/evidence remains recoverable.
- Private/ambiguous Library namespaces are not swept automatically.
- Unknown/unresolved stays visible.
- No result self-authorizes promotion.

## Verified substrate

`engine/` is an exact copy of the Alpha 0.26 verified implementation used as the substrate for this reflow.
During the reflow its regression suite was rerun: **209/209 PASS**.

Reflow 1.0 changes organization and active context; it does not rewrite prior experimental outcomes.
