# Orbit Lab Alpha 0.16 candidate

Adds source-role-aware selective research retrieval with explicit widening.
