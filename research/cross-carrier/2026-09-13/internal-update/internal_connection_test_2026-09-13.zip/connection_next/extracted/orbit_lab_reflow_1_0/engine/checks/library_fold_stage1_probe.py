from __future__ import annotations
from pathlib import Path
import json

BASE=Path(__file__).resolve().parents[1]
M=json.loads((BASE/"data"/"library_fold_stage1"/"STAGE1_MANIFEST.json").read_text())
I=json.loads((BASE/"data"/"library_fold_stage1"/"NEW_CANDIDATE_IMPORTS.json").read_text())

def run():
    entries=M["entries"]
    ids={e["id"] for e in entries}
    current_authority_safe=all(not e.get("current_authority",False) for e in entries if e["classification"] in {"HISTORICAL_METHOD_AND_PROVENANCE","SUPERSEDED_QUEUE_METADATA"})
    source_custody=all(e.get("final_library_path","").startswith("/Orbit Lab/History/Library Fold/Stage 1") for e in entries)
    new_imports={e["id"] for e in entries if e["classification"]=="NEW_CANDIDATE_IMPORT"}
    candidate_only=(new_imports==set(I) and all(v["status"].startswith("CANDIDATE_") for v in I.values()))
    no_universal_upgrade=("physical" in I["harmonic-subspace-field"]["boundary"].lower() and "universal" in I["multifactorial-creativity"]["boundary"].lower())
    passed=all([len(entries)==9,current_authority_safe,source_custody,candidate_only,no_universal_upgrade,M["stage_result"]["kernel_schema_additions"]==0])
    return {
      "passed":passed,
      "observations":{
        "stage1_sources_classified":len(entries)==9,
        "historical_method_does_not_override_current":current_authority_safe,
        "source_custody_routes_to_history":source_custody,
        "new_imports_remain_candidates":candidate_only,
        "candidate_claim_boundaries_preserved":no_universal_upgrade,
      },
      "new_candidate_imports":sorted(new_imports),
      "kernel_schema_additions":0,
      "claim_ceiling":[
        "Stage 1 resolves the pre-existing Orbit Incoming queue only.",
        "Classification as already represented does not prove every detail of the source has been experimentally validated by Orbit.",
        "The two new imports are retrievable candidates, not admitted scientific laws or mandatory architecture.",
        "The rest of the Library remains for later stages."
      ]
    }

if __name__=="__main__":
    print(json.dumps(run(),indent=2,sort_keys=True))
