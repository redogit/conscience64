
import tempfile
from pathlib import Path
from orbit_lab import OrbitLab

with tempfile.TemporaryDirectory() as td:
    lab=OrbitLab(Path(td)/"stress.db"); passes=[]; breaks=[]
    try:
        scope=lab.add("Scope","Recovery branch",provenance_class="TEST",provenance="stress",identity_key="scope")
        packet=lab.add("Artifact","Recovery packet",provenance_class="RECOVERY_PACKET",
                       provenance="packet",identity_key="packet")
        source=lab.add("Artifact","Primary source locator",provenance_class="LIBRARY_ARTIFACT",
                       provenance="library",identity_key="source")
        assoc=lab.record_association(source_entity_id=packet,target_entity_id=source,scope_id=scope,
            relation="DECLARED_SOURCE",resolution_status="LIBRARY_ID_EXACT",
            provenance_class="DERIVED",provenance="stress")
        if lab.episode(assoc)["data"]["evidence_effect"]=="NONE":
            passes.append("Association is machine-visible as navigation-only and cannot satisfy evidence wildcards.")

        # Proposal collection pressure.
        collection=lab.add("Collection","Candidate ideas",provenance_class="TEST",
                           provenance="stress",identity_key="collection")
        candidate=lab.add("Candidate","interesting proposed mechanism",epistemic="PROPOSED",
                          provenance_class="RECOVERY_PACKET",provenance="old",identity_key="candidate")
        lab.add_to_collection(collection,candidate,note="harvested from predecessor")
        # Nothing promotes it automatically, which is good.
        if lab.get(candidate).epistemic=="PROPOSED":
            passes.append("Collection membership does not promote a Candidate.")

        # But lifecycle/promotion semantics are still scattered: a Candidate can be launched ACTIVE
        # independently of a scientific promotion decision if authority permits it. "Active work" and
        # "persistent structural promotion" are not represented as different change classes.
        breaks.append(
            "The corpus now presses on provisional adaptation versus structural promotion. "
            "Current lifecycle ACTIVE only means working-set activation; there is no typed persistent Promotion "
            "Episode requiring a change witness/revalidation, nor a distinct reversible Adaptation Episode."
        )

        print("V0.26 ASSOCIATION / PROMOTION STRESS")
        print("-----------------------------------")
        print("PASS:"); [print("-",x) for x in passes]
        print("\nNEXT PRESSURE:"); [print(f"{i}. {x}") for i,x in enumerate(breaks,1)]
    finally: lab.close()
