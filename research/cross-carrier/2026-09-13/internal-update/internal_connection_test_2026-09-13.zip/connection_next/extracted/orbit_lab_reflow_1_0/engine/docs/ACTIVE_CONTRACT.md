# Active Contract

## Purpose

Use accumulated research to improve a small correctable research kernel while reducing active cognitive/tooling burden.

## Non-goals

- completeness;
- universal ontology;
- automatic canonization of recovered work;
- calling correlated helpers independent;
- maximizing helper count;
- maximizing test count;
- architecture accumulation for its own sake.

## Current obligations

1. Evidence/history remain recoverable and correction does not rewrite what occurred.
2. Current stays small and type-correct.
3. Authority is use/context/scope/actor/history sensitive.
4. Imported/recovered material does not inherit destination authority automatically.
5. Schema change requires an earned collision, proposal, adequate witness, promotion, and authorization.
6. Association/navigation does not silently become evidence or authority.
7. Failure and experiment claims remain bound to their observation/execution conditions.
8. Supporters retain their limitations, costs, and shared-lineage warning.
9. Selector escalation stops when the current declared obligation is resolved.
10. Historical probes remain accessible even when intentionally stale.

## Change rule

Add or revise structure only when a reproduced, consequential failure shows that the current representation causes a different required action to collapse, imports unearned ontology, loses a protected obligation, or prevents necessary discrimination.
