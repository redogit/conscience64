
import tempfile
from pathlib import Path
from orbit_lab import OrbitLab

with tempfile.TemporaryDirectory() as td:
    lab=OrbitLab(Path(td)/"stress.db")
    passes=[]; breaks=[]
    try:
        src=lab.add("Claim","wrong source",provenance_class="TEST",provenance="stress",identity_key="src")
        dst=lab.add("Artifact","dst",provenance_class="TEST",provenance="stress",identity_key="dst")
        ob=lab.add("Obligation","preserve",provenance_class="TEST",provenance="stress",identity_key="ob")
        ev=lab.add("Evidence","evidence",provenance_class="TEST",provenance="stress",identity_key="ev",epistemic="OBSERVED")
        try:
            lab.add_episode("FAITHFUL_TRANSPORT","bad",
                participants=[
                    {"role":"source","object_id":src},
                    {"role":"target","object_id":dst},
                    {"role":"obligation","object_id":ob},
                    {"role":"evidence","object_id":ev},
                ],
                provenance_class="TEST",provenance="stress")
            breaks.append("typed transport role failed")
        except TypeError:
            passes.append("FAITHFUL_TRANSPORT rejects type-invalid source/target.")

        # But Probe is still only an intended action; nothing proves these two probes ran.
        cand=lab.add("Candidate","link",provenance_class="TEST",provenance="stress",identity_key="cand")
        reset=lab.add("Artifact","reset R0",provenance_class="TEST",provenance="stress",identity_key="reset")
        control=lab.add("Probe","planned OFF condition; never executed",
                        provenance_class="TEST",provenance="stress",identity_key="off")
        treatment=lab.add("Probe","planned ON condition; never executed",
                          provenance_class="TEST",provenance="stress",identity_key="on")
        claimed_result=lab.add("Observation","comparison result with no execution lineage",
                               provenance_class="TEST",provenance="stress",identity_key="result",epistemic="OBSERVED")
        ep=lab.add_episode(
            "MATCHED_COUNTERFACTUAL","syntactically valid imaginary experiment",
            participants=[
                {"role":"candidate","object_id":cand},
                {"role":"reset","object_id":reset},
                {"role":"control","object_id":control},
                {"role":"treatment","object_id":treatment},
                {"role":"result","object_id":claimed_result},
            ],
            provenance_class="TEST",provenance="stress"
        )
        breaks.append(
            "Typed roles still collapse planned Probe with executed run. "
            "MATCHED_COUNTERFACTUAL can certify two Probes that never actually executed."
        )

        print("V0.8 TYPED-ROLE STRESS")
        print("----------------------")
        print("PASS:")
        for x in passes: print("-",x)
        print("\nNEXT BREAK:")
        for i,x in enumerate(breaks,1): print(f"{i}. {x}")
    finally:
        lab.close()
