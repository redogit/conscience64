
import tempfile
from pathlib import Path
import unittest
from orbit_lab import OrbitLab

class V25Tests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.lab=OrbitLab(Path(self.tmp.name)/"t.db")
    def tearDown(self): self.lab.close(); self.tmp.cleanup()
    def add(self,t,title,key,**kw):
        return self.lab.add(t,title,provenance_class="TEST",provenance="test",identity_key=key,**kw)
    def occurrence(self,key,digest):
        c=self.add("Context","C"+key,"ctx"+key)
        content=self.lab.register_content(algorithm="sha256",digest=digest,provenance_class="TEST",provenance="test")
        inst=self.lab.create_artifact_instance(content_id=content,provenance_class="TEST",provenance="test",identity_key="i"+key)
        return self.lab.record_instance_occurrence(instance_id=inst,context_id=c,locator="/"+key,
            mode="REGISTER",provenance_class="TEST",provenance="test",identity_key="o"+key)

    def test_multi_input_derivation(self):
        a=self.occurrence("a","aa"); b=self.occurrence("b","bb"); out=self.occurrence("out","cc")
        m=self.add("Method","merge method","m")
        ep=self.lab.record_derivation(input_occurrence_ids=[a,b],method_id=m,output_occurrence_id=out,
            transformation="merge two sources",reconstructibility="DIRECT",
            provenance_class="TEST",provenance="test")
        self.assertEqual(len(self.lab.episode_role_ids(ep,"input")),2)
        self.assertEqual(self.lab.episode_role_ids(ep,"output"),[out])

    def test_derivation_cycle_rejected(self):
        a=self.occurrence("a","aa"); b=self.occurrence("b","bb"); m=self.add("Method","m","m")
        self.lab.record_derivation(input_occurrence_ids=[a],method_id=m,output_occurrence_id=b,
            transformation="a to b",reconstructibility="DIRECT",
            provenance_class="TEST",provenance="test")
        with self.assertRaises(ValueError):
            self.lab.record_derivation(input_occurrence_ids=[b],method_id=m,output_occurrence_id=a,
                transformation="b to a",reconstructibility="DIRECT",
                provenance_class="TEST",provenance="test")
if __name__=="__main__": unittest.main()
