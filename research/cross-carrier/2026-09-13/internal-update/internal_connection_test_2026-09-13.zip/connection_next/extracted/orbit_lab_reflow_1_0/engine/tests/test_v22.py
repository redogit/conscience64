
import tempfile
from pathlib import Path
import unittest
from orbit_lab import OrbitLab
class V22Tests(unittest.TestCase):
    def setUp(self): self.tmp=tempfile.TemporaryDirectory(); self.lab=OrbitLab(Path(self.tmp.name)/"t.db")
    def tearDown(self): self.lab.close(); self.tmp.cleanup()
    def add(self,t,title,key,**kw): return self.lab.add(t,title,provenance_class="TEST",provenance="test",identity_key=key,**kw)
    def test_validity_frame_diff_and_applicability(self):
        method=self.add("Method","method","m")
        old=self.add("ValidityFrame","E1","old",data={"conditions":{"tool":"1","domain":"D"}})
        new=self.add("ValidityFrame","E2","new",data={"conditions":{"tool":"2","domain":"D"}})
        scope=self.add("Scope","task","s")
        evidence=self.add("Evidence","historical support","e",epistemic="OBSERVED")
        self.assertEqual(self.lab.validity_frame_diff(old,new)["tool"],{"historical":"1","current":"2"})
        ep=self.lab.assess_applicability(entity_id=method,historical_frame_id=old,current_frame_id=new,
            scope_id=scope,verdict="CONDITIONALLY_APPLICABLE",basis_entity_ids=[evidence],
            reason="tool changed; revalidate",provenance_class="TEST",provenance="test")
        self.assertEqual(self.lab.episode(ep)["data"]["verdict"],"CONDITIONALLY_APPLICABLE")
if __name__=="__main__": unittest.main()
