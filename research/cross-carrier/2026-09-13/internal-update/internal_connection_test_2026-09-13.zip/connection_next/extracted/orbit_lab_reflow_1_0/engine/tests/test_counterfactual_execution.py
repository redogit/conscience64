
import tempfile
from pathlib import Path
import unittest
from orbit_lab import OrbitLab

class CounterfactualExecutionRegression(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.lab=OrbitLab(Path(self.tmp.name)/"t.db")
    def tearDown(self): self.lab.close(); self.tmp.cleanup()
    def add(self,t,title,key,**kw):
        return self.lab.add(t,title,provenance_class="TEST",provenance="test",identity_key=key,**kw)

    def test_failed_arm_cannot_form_matched_counterfactual(self):
        candidate=self.add("Candidate","X","x"); reset=self.add("Artifact","reset","reset")
        probe=self.add("Probe","probe","probe")
        frame=self.add("ObservationFrame","frame","frame",data={"observer":"test","apparatus":"sim","accessible_variables":["y"],"resolution":"1","intervention":"on/off","boundary":"test"})
        params=self.add("Parameters","params","params",data={})
        rc=self.add("RunIdentity","control","rc"); rt=self.add("RunIdentity","treatment","rt")
        oc=self.add("Observation","control failed","oc",epistemic="OBSERVED")
        ot=self.add("Observation","treatment ok","ot",epistemic="OBSERVED")
        control=self.lab.record_execution(run_id=rc,probe_id=probe,frame_id=frame,parameters_id=params,
            reset_id=reset,observation_ids=[oc],status="TOOL_FAILED",provenance_class="TEST",provenance="test")
        treatment=self.lab.record_execution(run_id=rt,probe_id=probe,frame_id=frame,parameters_id=params,
            reset_id=reset,observation_ids=[ot],status="COMPLETED",provenance_class="TEST",provenance="test")
        result=self.add("Evidence","result","result",epistemic="OBSERVED")
        with self.assertRaises(ValueError):
            self.lab.add_episode("MATCHED_COUNTERFACTUAL","bad",
                participants=[
                    {"role":"candidate","object_id":candidate},{"role":"reset","object_id":reset},
                    {"role":"control","episode_id":control},{"role":"treatment","episode_id":treatment},
                    {"role":"result","object_id":result}],
                provenance_class="TEST",provenance="test")

if __name__=="__main__": unittest.main()
