# Orbit Lab Alpha 0.23 — Low-Attention Penny Stress Replay

Question:
Can the proposed $20 penny-stock experiment operate with one scheduled monthly
review while respecting the existing risk controls?

## Source
Moonshot Penny-Stock Research System v0.3, Historical Stress Panel.
The source labels the panel hand-selected and exploratory, not random or
confirmatory.

## Existing risk criterion
Sleeve drawdown brake: -20%.

## Development replay
- $20 starting cash
- 3-month trailing momentum selection
- positive signals only
- one-month holding period
- 0.5% modeled one-way transaction friction
- missing next exchange-listed price => zero under exit stress
- monthly withdrawal = 50% of cash above $20

## Primary result
The original two-slot, $10-per-slot version breached the existing risk brake:

- ending active account: $15.61
- cash collected: $21.91
- account + collected: $37.52
- max total-wealth drawdown: -53.3%

This is a NEGATIVE result for the original sizing on this stress panel.

## Reduction result
One-slot $10 and $5 reduced drawdown but still breached the -20% brake.

A post-hoc $4 single-slot probe landed at -19.4%
under 0.5% one-way cost, but failed at -20.9%
when cost was raised to 1% one way.

Therefore $4 is a boundary candidate only, not a rule.

## Important distinction
Monthly withdrawal != principal protection.
The strategy can distribute profit and later leave the active account below the
original $20.

## Validation
- 198/198 regressions PASS
- 29 selector components / 109 obligations
- penny-monthly-attention task profile PASS
- direct S5 whole integration PASS
- 0 new kernel object/Episode types

No live-trading promotion is supported.
