
import tempfile
from pathlib import Path
import sqlite3
import unittest
from orbit_lab import OrbitLab

class SupporterFindingRegressions(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.lab=OrbitLab(Path(self.tmp.name)/"t.db")
    def tearDown(self): self.lab.close(); self.tmp.cleanup()
    def add(self,t,title,key,**kw):
        return self.lab.add(t,title,provenance_class="TEST",provenance="test",identity_key=key,**kw)

    def test_unexplained_is_representable(self):
        r=self.add("Remainder","residual","r",epistemic="UNEXPLAINED")
        self.assertEqual(self.lab.get(r).epistemic,"UNEXPLAINED")

    def test_history_is_append_only(self):
        self.add("Artifact","A","a")
        with self.assertRaises(sqlite3.DatabaseError):
            self.lab.conn.execute("DELETE FROM history")
        self.lab.conn.rollback()

    def test_failure_requires_frame(self):
        subject=self.add("Probe","p","p"); location=self.add("Artifact","loc","loc")
        obs=self.add("Observation","failed","o",epistemic="OBSERVED")
        frame=self.add("ObservationFrame","F","f",data={"observer":"test","apparatus":"a","accessible_variables":["x"],"resolution":"1","intervention":"none","boundary":"b"})
        ep=self.lab.record_failure(subject_entity_id=subject,location_entity_id=location,
            observation_id=obs,frame_id=frame,cause_status="UNKNOWN",
            provenance_class="TEST",provenance="test")
        self.assertEqual(self.lab.episode_role_ids(ep,"frame"),[frame])

    def test_exposure_is_scope_local_but_overlaps_nested_scope(self):
        c=self.add("Context","C","c"); actor=self.add("Actor","A","a")
        cycle1=self.add("Scope","cycle1","c1"); cycle1child=self.add("Scope","cycle1 child","c1ch")
        cycle2=self.add("Scope","cycle2","c2"); self.lab.link_scope(cycle1,cycle1child)
        truth=self.add("Artifact","truth","truth"); e=self.add("Evidence","basis","e",epistemic="OBSERVED")
        root=self.lab.establish_authority_root(context_id=c,scope_id=cycle1,operations=["INSPECT"],
            holder_actor_id=actor,provenance_class="USER",provenance="user")
        self.lab.grant_authorization(context_id=c,entity_id=truth,operation="INSPECT",scope_id=cycle1,
            issuer_authority_id=root,issuer_actor_id=actor,principal_id=actor,basis_entity_ids=[e],
            reason="access",provenance_class="TEST",provenance="test")
        self.lab.record_access(context_id=c,actor_id=actor,entity_id=truth,operation="INSPECT",
            scope_id=cycle1,exposure_tags=["CONFIRMATION_TRUTH"],provenance_class="TEST",provenance="test")
        self.assertIn("CONFIRMATION_TRUTH",self.lab.exposure_tags(c,cycle1child))
        self.assertNotIn("CONFIRMATION_TRUTH",self.lab.exposure_tags(c,cycle2))

if __name__=="__main__": unittest.main()
