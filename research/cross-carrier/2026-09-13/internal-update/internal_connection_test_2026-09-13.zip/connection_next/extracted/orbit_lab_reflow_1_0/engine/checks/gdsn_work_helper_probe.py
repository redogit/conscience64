from __future__ import annotations
from work_helpers.gdsn import classify, triage


def run():
    confirmation=triage('Retailer sent CIC REVIEW for an item that was previously synchronised')
    pub=triage('RFCIN resend did not arrive after publication')
    hierarchy=triage('case hierarchy says a GTIN level is missing')
    general=triage('item is not flowing correctly')

    sync_distinction=any('SYNCHRONISED does not' in x for x in confirmation['known_distinctions'])
    rfcin_distinction=any('RFCIN is a one-time request' in x for x in pub['known_distinctions'])
    local_boundary=any('local data-pool' in x or 'local data-pool' in confirmation['claim_ceiling'] for x in confirmation['boundaries'])
    privacy_boundary=any('credentials' in x and 'confidential' in x for x in confirmation['boundaries'])
    no_cause_upgrade='cannot certify' in confirmation['claim_ceiling']

    passed=all([
        confirmation['route']=='confirmation',
        pub['route']=='publication-subscription',
        hierarchy['route']=='hierarchy',
        general['route']=='general',
        sync_distinction,rfcin_distinction,local_boundary,privacy_boundary,no_cause_upgrade,
    ])
    return {
        'passed':passed,
        'routes':{
            'confirmation':confirmation['route'],
            'publication':pub['route'],
            'hierarchy':hierarchy['route'],
            'general':general['route'],
        },
        'observations':{
            'synchronised_not_business_activation':sync_distinction,
            'rfcin_not_subscription':rfcin_distinction,
            'standard_not_local_implementation':local_boundary,
            'work_privacy_boundary_present':privacy_boundary,
            'helper_does_not_certify_unseen_production_cause':no_cause_upgrade,
        },
        'kernel_schema_additions':0,
        'claim_ceiling':[
            'The helper is a task-local troubleshooting organizer, not a GDSN conformance engine.',
            'It does not encode employer/customer/data-pool-specific rules unless separately supplied and authorized.',
            'No production diagnosis is supported without case-specific evidence.'
        ]
    }

if __name__=='__main__':
    import json; print(json.dumps(run(),indent=2,sort_keys=True))
