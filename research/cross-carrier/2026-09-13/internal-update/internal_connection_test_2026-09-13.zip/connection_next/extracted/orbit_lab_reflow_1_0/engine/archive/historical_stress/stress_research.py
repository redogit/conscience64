
from pathlib import Path
import tempfile, json
from orbit_lab import OrbitLab
from seed_research import load

with tempfile.TemporaryDirectory() as td:
    db=Path(td)/"loaded.db"
    root, ids, stats=load(db)
    lab=OrbitLab(db)
    found=[]
    passed=[]
    try:
        # The same Hodge item can orbit one subject without polluting another.
        h=ids["research:hodge-m45"]["subject"]
        pulse=ids["research:pulse"]["subject"]
        lab.orbit(h,root,reason="stress: inspect one mathematical residual")
        passed.append("Subject-scoped orbit isolates selected research.")

        other=lab.add("Subject","Unrelated compiler task",provenance_class="TEST",provenance="stress",identity_key="stress:compiler")
        if len(lab.orbit_list(other))==0:
            passed.append("Unrelated subject sees an empty orbit.")

        # Duplicate source identity should fail.
        try:
            lab.add("Subject","Duplicate Hodge",provenance_class="LIBRARY_ARTIFACT",
                    provenance="library:file_000000001bb081f591fd23bb1aff3233",
                    identity_key="research:hodge-m45",lifecycle="QUARANTINED")
            found.append("identity dedupe failed")
        except ValueError:
            passed.append("Identity-key duplicate rejected.")

        # Current expansion requires an explicit reason.
        for i in range(3):
            p=lab.add("Probe",f"stress probe {i}",provenance_class="TEST",provenance="stress",identity_key=f"stress:p{i}")
            lab.launch(p,slot="probe")
        p4=lab.add("Probe","stress probe 4",provenance_class="TEST",provenance="stress",identity_key="stress:p4")
        try:
            lab.launch(p4,slot="probe")
            found.append("probe limit not enforced")
        except RuntimeError:
            passed.append("Probe attention limit enforced.")

        # Second-order weakness 1: q retrieval is still substring-only.
        # Search for a conceptual synonym not present literally.
        q=lab.library(q="generic compilation")
        if not q:
            found.append("Library retrieval is lexical substring only; semantically related research is invisible without exact wording.")

        # Second-order weakness 2: quarantine currently doesn't prevent launch by itself.
        qobj=ids["research:carrier"]["claim"]
        try:
            lab.launch(qobj,reason="stress direct launch")
            found.append("QUARANTINED objects can be launched directly; quarantine is a label, not an admission gate.")
        except PermissionError:
            passed.append("Quarantine prevented launch.")

        # Second-order weakness 3: relation type safety is intentionally open and can create nonsense.
        c=ids["research:tbcl"]["claim"]
        b=ids["research:tbcl"]["boundary"]
        lab.relate(b,"SUPPORTS",c,provenance_class="TEST",provenance="stress")
        found.append("Relation vocabulary is unconstrained; nonsensical SUPPORTS edges are structurally legal.")

        # Second-order weakness 4: Claim schema does not require scope/falsifier.
        bare=lab.add("Claim","A bare scientific-sounding assertion",provenance_class="TEST",
                     provenance="stress",identity_key="stress:bare-claim",epistemic="SUPPORTED")
        found.append("Claim can be marked SUPPORTED without required scope, evidence link, or falsifier.")

        # Second-order weakness 5: objects are mutable at SQL level; kernel has no content-version method.
        lab.conn.execute("UPDATE objects SET title='silently rewritten' WHERE id=?",(bare,))
        lab.conn.commit()
        found.append("Object content can be rewritten in-place through the backing DB; immutable-content/version discipline is not enforced.")

        print("V0.2 RELOAD")
        print("-----------")
        print(json.dumps(stats,indent=2))
        print("\nPASS:")
        for x in passed: print("-",x)
        print("\nSECOND-ORDER BREAKS:")
        for i,x in enumerate(found,1): print(f"{i}. {x}")
    finally:
        lab.close()
