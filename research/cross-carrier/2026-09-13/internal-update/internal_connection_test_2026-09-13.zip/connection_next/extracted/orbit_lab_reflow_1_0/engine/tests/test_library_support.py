import unittest
from library_support import exact_reference_candidates, lexical_route_candidates, support_search_plan, static_summary
from checks.library_support_probe import run

class LibrarySupportTests(unittest.TestCase):
    def test_static_seed_is_bounded_and_non_corrupting(self):
        s=static_summary(); self.assertEqual(s["rows"],633); self.assertEqual(s["resolved_exact"],124)
        self.assertTrue(run()["passed"])
    def test_exact_reference_is_not_support_proof(self):
        xs=exact_reference_candidates("4d_codec_inversion_observer_conversation_archive.zip",include_unresolved=False)
        self.assertTrue(xs)
        self.assertTrue(all(not x.can_self_certify_support for x in xs))
    def test_related_search_stays_related(self):
        xs=lexical_route_candidates("shared well composable knowledge",limit=5)
        self.assertTrue(xs)
        self.assertTrue(all(x.relation_kind=="RELATED_ONLY" for x in xs))
    def test_private_namespaces_default_excluded(self):
        p=support_search_plan("homework")
        self.assertIn("/Homework",p["private_namespaces_excluded"])
        self.assertFalse(p["automatic_private_access"])

if __name__=="__main__": unittest.main()
