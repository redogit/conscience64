
import tempfile, sqlite3
from pathlib import Path
import unittest
from orbit_lab import OrbitLab

class V06Tests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.lab=OrbitLab(Path(self.tmp.name)/"t.db")
    def tearDown(self): self.lab.close(); self.tmp.cleanup()
    def add(self,t,title,key,**kw):
        return self.lab.add(t,title,provenance_class="TEST",provenance="test",identity_key=key,**kw)
    def frame(self,key):
        return self.add("ObservationFrame","frame",key,data={"observer":"t","apparatus":"s","accessible_variables":["y"],"resolution":"1","intervention":"none","boundary":"b"})
    def execution(self,key,frame,params,reset):
        p=self.add("Probe",key,key+"p"); o=self.add("Observation",key+"o",key+"o",epistemic="OBSERVED")
        run=self.add("RunIdentity",key+" run",key+"run"); return self.lab.record_execution(run_id=run,probe_id=p,frame_id=frame,parameters_id=params,reset_id=reset,
                                         observation_ids=[o],status="COMPLETED",provenance_class="TEST",provenance="test")
    def matched(self):
        c=self.add("Candidate","link","c"); r=self.add("Artifact","reset","r")
        f=self.frame("sharedf"); params=self.add("Parameters","params","params",data={"lr":0.1})
        off=self.execution("off",f,params,r); on=self.execution("on",f,params,r); out=self.add("Observation","result","out",epistemic="OBSERVED")
        return self.lab.add_episode("MATCHED_COUNTERFACTUAL","matched",
            participants=[{"role":"candidate","object_id":c},{"role":"reset","object_id":r},
                          {"role":"control","episode_id":off},{"role":"treatment","episode_id":on},
                          {"role":"result","object_id":out}],
            provenance_class="TEST",provenance="test")
    def test_episode_can_participate_in_episode(self):
        matched=self.matched(); q=self.add("Candidate","legacy","q",lifecycle="QUARANTINED")
        ep=self.lab.admit(q,support_object_ids=[matched],reason="matched experiment",provenance_class="TEST",provenance="test")
        parts=self.lab.episode(ep)["participants"]
        self.assertTrue(any(p["participant_id"]==matched and p["entity_kind"]=="EPISODE" for p in parts))
    def test_episode_semantics_immutable(self):
        matched=self.matched()
        with self.assertRaises(sqlite3.IntegrityError): self.lab.conn.execute("UPDATE episodes SET title='changed' WHERE id=?",(matched,))
        self.lab.conn.rollback()
    def test_episode_participants_immutable(self):
        matched=self.matched()
        with self.assertRaises(sqlite3.IntegrityError): self.lab.conn.execute("DELETE FROM episode_participants WHERE episode_id=?",(matched,))
        self.lab.conn.rollback()
if __name__=="__main__": unittest.main()
