
import tempfile, sqlite3
from pathlib import Path
from orbit_lab import OrbitLab

with tempfile.TemporaryDirectory() as td:
    lab=OrbitLab(Path(td)/"deep.db")
    passes=[]; breaks=[]
    try:
        c=lab.add("Candidate","candidate link",provenance_class="TEST",provenance="stress",identity_key="c")
        reset=lab.add("Artifact","reset R0",provenance_class="TEST",provenance="stress",identity_key="reset")
        off=lab.add("Probe","off",provenance_class="TEST",provenance="stress",identity_key="off")
        on=lab.add("Probe","on",provenance_class="TEST",provenance="stress",identity_key="on")
        result=lab.add("Observation","matched result",provenance_class="TEST",provenance="stress",identity_key="result",epistemic="OBSERVED")
        matched=lab.add_episode(
            "MATCHED_COUNTERFACTUAL","matched experiment",
            participants=[
                {"role":"candidate","object_id":c},
                {"role":"reset","object_id":reset},
                {"role":"control","object_id":off},
                {"role":"treatment","object_id":on},
                {"role":"result","object_id":result},
            ],
            provenance_class="TEST",provenance="stress",identity_key="matched"
        )
        q=lab.add("Candidate","legacy candidate",provenance_class="RECOVERY_PACKET",
                  provenance="legacy",identity_key="q",lifecycle="QUARANTINED")
        admission=lab.admit(q,support_object_ids=[matched],reason="matched experiment is the evidence unit",
                            provenance_class="TEST",provenance="stress")
        ap=lab.episode(admission)["participants"]
        if any(x["participant_id"]==matched and x["entity_kind"]=="EPISODE" for x in ap):
            passes.append("Episode can participate directly in a later Episode.")
        try:
            lab.conn.execute("UPDATE episodes SET data_json='{}' WHERE id=?",(matched,))
            lab.conn.commit()
            breaks.append("nested evidence episode mutated in place")
        except sqlite3.IntegrityError:
            lab.conn.rollback()
            passes.append("Nested evidence Episode is immutable.")

        # Next attack: observational frame semantics.
        # Two frames with the same raw observation can imply different admissible conclusions,
        # but frame is still represented as a generic Artifact with no frame contract.
        obs=lab.add("Observation","same measured value",data={"value":1.0},
                    provenance_class="TEST",provenance="stress",identity_key="obs",epistemic="OBSERVED")
        frame_a=lab.add("Artifact","frame A: direct measurement",data={"access":"direct"},
                        provenance_class="TEST",provenance="stress",identity_key="fa")
        frame_b=lab.add("Artifact","frame B: aliased measurement",data={"access":"aliased"},
                        provenance_class="TEST",provenance="stress",identity_key="fb")
        claim=lab.add("Claim","value identifies hidden state",
                      provenance_class="TEST",provenance="stress",identity_key="claim")
        lab.assess_claim(claim,frame_id=frame_a,evidence_ids=[obs],verdict="SUPPORTED",scope="direct",
                         provenance_class="TEST",provenance="stress")
        lab.assess_claim(claim,frame_id=frame_b,evidence_ids=[obs],verdict="UNRESOLVED",scope="aliased",
                         provenance_class="TEST",provenance="stress")
        breaks.append(
            "Observation frame is still only an arbitrary Artifact. The kernel cannot require "
            "observer/apparatus/access/resolution/intervention/boundary fields even when the same "
            "Observation supports different actions under different frames."
        )

        # Next attack: subject/container collision still survives.
        branch=lab.add("Subject","Micro-Ouro project branch",
                       provenance_class="LIBRARY_ARTIFACT",provenance="library",
                       identity_key="branch")
        current=lab.add("Subject","Does adaptive recurrence improve exact recall?",
                        provenance_class="CURRENT_CONVERSATION",provenance="conversation",
                        identity_key="current")
        breaks.append(
            "Subject still serves both persistent project/branch container and current examined thing; "
            "the same type carries two different operational roles."
        )

        print("V0.6 COMPOSITION STRESS")
        print("-----------------------")
        print("PASS:")
        for x in passes: print("-",x)
        print("\nNEXT DEPTH:")
        for i,x in enumerate(breaks,1): print(f"{i}. {x}")
    finally:
        lab.close()
