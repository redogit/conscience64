
import tempfile
from pathlib import Path
from orbit_lab import OrbitLab

with tempfile.TemporaryDirectory() as td:
    lab=OrbitLab(Path(td)/"stress.db")
    passes=[]; breaks=[]
    try:
        # Immutability + scoped assessment now hold.
        a=lab.add("Artifact","carrier v1",data={"behavior":"A"},
                  provenance_class="TEST",provenance="stress",identity_key="a")
        try:
            lab.conn.execute("UPDATE objects SET data_json='{}' WHERE id=?",(a,))
            lab.conn.commit()
            breaks.append("semantic mutation unexpectedly succeeded")
        except Exception:
            lab.conn.rollback()
            passes.append("Historical participant semantics cannot be rewritten in place.")

        c=lab.add("Claim","method dominates",provenance_class="TEST",provenance="stress",identity_key="c")
        f1=lab.add("Artifact","frame A",provenance_class="TEST",provenance="stress",identity_key="f1")
        f2=lab.add("Artifact","frame B",provenance_class="TEST",provenance="stress",identity_key="f2")
        e1=lab.add("Evidence","win",provenance_class="TEST",provenance="stress",identity_key="e1",epistemic="OBSERVED")
        e2=lab.add("Evidence","loss",provenance_class="TEST",provenance="stress",identity_key="e2",epistemic="OBSERVED")
        lab.assess_claim(c,frame_id=f1,evidence_ids=[e1],verdict="SUPPORTED",scope="A",
                         provenance_class="TEST",provenance="stress")
        lab.assess_claim(c,frame_id=f2,evidence_ids=[e2],verdict="CONTRADICTED",scope="B",
                         provenance_class="TEST",provenance="stress")
        if lab.get(c).epistemic=="UNKNOWN" and len(lab.claim_assessments(c))==2:
            passes.append("Opposite frame-scoped verdicts coexist without rewriting Claim.")

        # Attack Episode structural contract itself:
        # A transport with only source+target is semantically malformed, but v0.4 accepts it.
        s=lab.add("Artifact","src",provenance_class="TEST",provenance="stress",identity_key="src")
        t=lab.add("Artifact","dst",provenance_class="TEST",provenance="stress",identity_key="dst")
        malformed=lab.add_episode(
            "FAITHFUL_TRANSPORT","malformed transport",
            participants=[
                {"role":"source","object_id":s},
                {"role":"target","object_id":t},
            ],
            provenance_class="TEST",provenance="stress"
        )
        breaks.append(
            "Episode participant integrity is not enough: FAITHFUL_TRANSPORT accepted "
            "without obligation or evidence."
        )

        # Attack quarantine/admission:
        q=lab.add("Candidate","legacy candidate",
                  provenance_class="RECOVERY_PACKET",provenance="legacy",
                  identity_key="q",lifecycle="QUARANTINED")
        lab.launch(q,reason="stress direct launch")
        if lab.get(q).lifecycle=="ACTIVE":
            breaks.append(
                "QUARANTINED remains only a lifecycle label; direct activation still bypasses an admission decision."
            )

        # Attack UNKNOWN:
        r1=lab.add("Remainder","Cannot decide",
                   provenance_class="TEST",provenance="stress",identity_key="r1")
        r2=lab.add("Remainder","Cannot decide",
                   provenance_class="TEST",provenance="stress",identity_key="r2")
        breaks.append(
            "Remainder/UNKNOWN still cannot distinguish underdetermined from inaccessible "
            "without caller-invented free-form data, even though those require different next actions."
        )

        print("V0.4 DEEPER STRESS")
        print("------------------")
        print("PASS:")
        for x in passes: print("-",x)
        print("\nNEXT BREAKS:")
        for i,x in enumerate(breaks,1): print(f"{i}. {x}")
    finally:
        lab.close()
