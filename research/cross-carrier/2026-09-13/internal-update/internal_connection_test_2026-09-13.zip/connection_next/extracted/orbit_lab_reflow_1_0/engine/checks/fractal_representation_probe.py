
from __future__ import annotations
from pathlib import Path
import itertools, math, hashlib, importlib.util, json, tempfile, sys

ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0,str(ROOT))
from orbit_lab import OrbitLab

SOURCE=ROOT/"data"/"angled_wrapper_fractal_demo.py"

def _load_source():
    spec=importlib.util.spec_from_file_location("fractal_unroll_fixture",SOURCE)
    mod=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod

def _floor_decode(x,y,branches,max_depth):
    r=math.hypot(x,y)
    depth=int(round(r*max_depth))
    theta=math.atan2(y,x)%(2.0*math.pi)
    u=theta/(2.0*math.pi)
    out=[]
    for _ in range(depth):
        z=branches*u
        c=int(math.floor(z))
        if c>=branches: c=branches-1
        out.append(c)
        u=z-c
    return tuple(out)

def _scaled_integer_decode(x,y,branches,max_depth):
    r=math.hypot(x,y)
    depth=int(round(r*max_depth))
    theta=math.atan2(y,x)%(2.0*math.pi)
    u=theta/(2.0*math.pi)
    modulus=branches**depth
    n=int(round(u*modulus))%modulus
    out=[0]*depth
    for j in range(depth-1,-1,-1):
        out[j]=n%branches
        n//=branches
    return tuple(out)

def run():
    m=_load_source()
    total=0; floor_fail=0; robust_fail=0; samples=[]
    max_depth=7
    for branches in range(2,6):
        for depth in range(1,max_depth+1):
            r=m.depth_to_radius(depth,max_depth,1.0)
            for path in itertools.product(range(branches),repeat=depth):
                theta=m.path_to_angle(path,branches)
                x,y=m.polar_to_xy(r,theta)
                total+=1
                a=_floor_decode(x,y,branches,max_depth)
                b=_scaled_integer_decode(x,y,branches,max_depth)
                if a!=path:
                    floor_fail+=1
                    if len(samples)<8:
                        samples.append({"branches":branches,"depth":depth,"path":list(path),"decoded":list(a)})
                if b!=path:
                    robust_fail+=1

    # Feed the resulting evidence distinctions through the current claim system.
    with tempfile.TemporaryDirectory() as td:
        lab=OrbitLab(Path(td)/"fractal.db")
        try:
            frame=lab.add(
                "ObservationFrame","Bounded numerical simulation",
                data={
                    "observer":"finite-roundtrip-harness",
                    "apparatus":"python-double-precision",
                    "accessible_variables":["path","x","y","decoded_path"],
                    "resolution":"IEEE-754 double",
                    "intervention":"exhaustive bounded enumeration",
                    "boundary":"designed encoding; not physical sensing"
                },
                provenance_class="TEST",provenance="fractal-probe",identity_key="frame"
            )
            roundtrip_ev=lab.add(
                "Evidence","123032-case robust address round-trip",
                data={"evidence_tags":["BOUNDED_DESIGNED_ENCODING_ROUNDTRIP"]},
                epistemic="OBSERVED",provenance_class="TEST",provenance="fractal-probe",identity_key="rt"
            )
            simulation_ev=lab.add(
                "Evidence","1 ns simulation increment",
                data={"evidence_tags":["SIMULATION_TIMESTEP"]},
                epistemic="OBSERVED",provenance_class="TEST",provenance="fractal-probe",identity_key="sim"
            )
            detector_code=lab.add(
                "Evidence","Detector logic implemented",
                data={"evidence_tags":["IMPLEMENTED_DETECTOR_LOGIC"]},
                epistemic="OBSERVED",provenance_class="TEST",provenance="fractal-probe",identity_key="det"
            )
            arithmetic_ev=lab.add(
                "Evidence","Idealized raw two-way bit bookkeeping",
                data={"evidence_tags":["IDEALIZED_RAW_BIT_ACCOUNTING"]},
                epistemic="OBSERVED",provenance_class="TEST",provenance="fractal-probe",identity_key="bits"
            )

            address_claim=lab.add(
                "Claim","Designed address map round-trips on registered bounded universe",
                data={"required_evidence_tags":["BOUNDED_DESIGNED_ENCODING_ROUNDTRIP"]},
                provenance_class="TEST",provenance="fractal-probe",identity_key="claim-address"
            )
            lab.assess_claim(
                address_claim,frame_id=frame,evidence_ids=[roundtrip_ev],verdict="SUPPORTED",
                scope="branches 2-5, depths 1-7, recovered radial/base-k encoding",
                provenance_class="TEST",provenance="fractal-probe"
            )

            def blocked(title,tag,evidence,key):
                claim=lab.add(
                    "Claim",title,data={"required_evidence_tags":[tag]},
                    provenance_class="TEST",provenance="fractal-probe",identity_key=key
                )
                try:
                    lab.assess_claim(
                        claim,frame_id=frame,evidence_ids=[evidence],verdict="SUPPORTED",
                        scope="probe",provenance_class="TEST",provenance="fractal-probe"
                    )
                    return False
                except ValueError:
                    return True

            generator_blocked=blocked(
                "2D address uniquely recovers original 3D generator",
                "GENERATOR_IDENTIFICATION_EVIDENCE",roundtrip_ev,"claim-generator"
            )
            physical_time_blocked=blocked(
                "Hardware supports 1 ns physical timing",
                "PHYSICAL_TIMING_MEASUREMENT",simulation_ev,"claim-physical"
            )
            sensing_blocked=blocked(
                "Mirror detector has measured sensing performance",
                "MEASURED_DETECTOR_BEHAVIOR",detector_code,"claim-sensing"
            )
            capacity_blocked=blocked(
                "1.458 Tbit/s is realizable channel capacity",
                "PHYSICAL_CHANNEL_CAPACITY_MEASUREMENT",arithmetic_ev,"claim-capacity"
            )
            audit=lab.alpha_audit()
        finally:
            lab.close()

    return {
        "passed": (
            total==123032 and floor_fail>0 and robust_fail==0
            and generator_blocked and physical_time_blocked
            and sensing_blocked and capacity_blocked and audit["passed"]
        ),
        "source_sha256":hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
        "bounded_universe":{"branches":[2,3,4,5],"depths":[1,2,3,4,5,6,7]},
        "cases_tested":total,
        "original_floor_decoder_failures":floor_fail,
        "original_floor_failure_examples":samples,
        "scaled_integer_decoder_failures":robust_fail,
        "designed_address_roundtrip_supported_bounded":robust_fail==0,
        "address_roundtrip_does_not_certify_3d_generator":generator_blocked,
        "simulation_timestep_does_not_certify_physical_timing":physical_time_blocked,
        "implemented_detector_does_not_certify_measured_behavior":sensing_blocked,
        "raw_bit_accounting_does_not_certify_channel_capacity":capacity_blocked,
        "kernel_schema_additions":0,
        "audit_passed":audit["passed"],
    }

if __name__=="__main__":
    print(json.dumps(run(),indent=2,sort_keys=True))
