
from __future__ import annotations
from pathlib import Path
import hashlib, json, re

BASE=Path(__file__).resolve().parent
SOURCE_DIR=BASE/"data"/"retrieval_sources"
MANIFEST=json.loads((SOURCE_DIR/"SOURCE_MANIFEST.json").read_text())

# Task-local source contracts. These are retrieval obligations, not project ontology.
TASKS={
    "olu-empirical-record":{
        "project":"One_Level_Up",
        "primary":"OLU_ADDENDUM",
        "role":"CURRENT_ADDENDUM",
        "required_facts":{
            "empirical_tuple":r"E=\(C_0,C_1,M,S,Y_0,Y_1\)",
            "derived_comparison":r"D=f\(Y_0,Y_1\)",
            "interpretation_separate":r"I=g\(E,D,K\)",
            "relation_verdicts":r"SURVIVES / FAILS / NULL / UNRESOLVED / INVALID / CONSTRUCTED",
            "active_not_destroyed":r"richer preserved record \+ small active representation",
        },
        "widen_if_missing":True,
    },
    "csol-human-representation":{
        "project":"CSOL",
        "primary":"CSOL_START",
        "role":"START_HERE",
        "required_facts":{
            "preserve_before_minimize":r"preserves all task-consequential distinctions first",
            "task_local_definition":r"task-local definition",
            "arrangement_meaning":r"Arrangement can carry meaning",
            "bounded_reopen":r"Reopen the bound when a consequential crossing appears",
            "no_forced_unification":r"Do not elevate structural resemblance into ontology or unification",
        },
        "widen_if_missing":True,
    },
    "moonshot-recovery-scope":{
        "project":"MoonShot",
        "primary":"MOONSHOT_ATLAS",
        "role":"RECOVERY_ONLY",
        "required_facts":{
            "recover_not_modify":r"Recovery, not modification",
            "federation_not_theory":r"federation of many separate works and ideas, not one theory",
            "atlas_counts":r"84 work units.*38 typed supported edges.*12 prioritized source-level recovery targets",
            "source_level_not_done":r"No further source-level Moonshot rerecovery has yet been performed",
            "separate_recovery_strength":r"Keep scientific evidence strength separate from recovery-contract freshness",
        },
        "widen_if_missing":True,
    },
    "r3-reduction-boundary":{
        "project":"R3",
        "primary":"R3_AGENT",
        "role":"METHOD",
        "required_facts":{
            "minimality_subordinate":r"Minimality is subordinate to faithful encounter",
            "active_vs_preserved":r"ACTIVE KNOWLEDGE != PRESERVED EXPERIENCE",
            "reconstruction_not_other":r"W_hat != W_other",
            "authority_separation":r"PROPOSE/SEARCH -> VERIFY -> ADMIT/RETAIN",
            "no_irreversible_delete":r"do not irreversibly discard evidential distinctions",
        },
        "widen_if_missing":True,
    },
    "operator-recovery-map":{
        "project":"Operator_Moonshot",
        "primary":"OPERATOR_RECOVERY",
        "role":"CURRENT_RECOVERY_HANDOFF",
        "required_facts":{
            "preserve_gaps":r"preserve gaps explicitly",
            "summary_not_primary":r"do not promote summaries, analogies, repeated mentions, or inaccessible history into primary evidence",
            "authority_precedence":r"establish authority/precedence",
            "bridge_before_transfer":r"requiring a concrete bridge test before transfer",
            "small_root_deep_packets":r"small root control plane plus deep branch packets",
        },
        "widen_if_missing":True,
    },
}

def source_path(source_id):
    meta=MANIFEST[source_id]
    return SOURCE_DIR/meta["file"]

def verify_source(source_id):
    p=source_path(source_id)
    if not p.exists():
        return {"passed":False,"reason":"SOURCE_MISSING","source_id":source_id}
    b=p.read_bytes()
    got=hashlib.sha256(b).hexdigest()
    exp=MANIFEST[source_id]["sha256"]
    return {
        "passed":got==exp,
        "reason":"OK" if got==exp else "SOURCE_DIGEST_MISMATCH",
        "source_id":source_id,
        "bytes":len(b),
        "sha256":got,
    }

def extract(task_id, source_ids):
    task=TASKS[task_id]
    chunks=[]
    provenance=[]
    for sid in source_ids:
        check=verify_source(sid)
        if not check["passed"]:
            return {"status":"WIDEN_REQUIRED","reason":check["reason"],"source_id":sid}
        text=source_path(sid).read_text(encoding="utf-8")
        chunks.append(text)
        provenance.append({
            "source_id":sid,
            "sha256":MANIFEST[sid]["sha256"],
            "role":task["role"] if sid==task["primary"] else "ADDITIONAL_CONTEXT",
        })
    text="\n".join(chunks)
    facts={}
    missing=[]
    for name,pattern in task["required_facts"].items():
        m=re.search(pattern,text,re.I|re.S)
        facts[name]=bool(m)
        if not m: missing.append(name)
    return {
        "status":"ANSWERABLE" if not missing else "WIDEN_REQUIRED",
        "task_id":task_id,
        "project":task["project"],
        "facts":facts,
        "missing":missing,
        "provenance":provenance,
        "bytes_loaded":sum(MANIFEST[s]["size_bytes"] for s in source_ids),
        "sources_loaded":list(source_ids),
    }

def broad(task_id):
    return extract(task_id, list(MANIFEST))

def narrow(task_id):
    return extract(task_id, [TASKS[task_id]["primary"]])

def decide(task_id, available_sources=None):
    available=set(MANIFEST if available_sources is None else available_sources)
    primary=TASKS[task_id]["primary"]
    if primary in available:
        result=extract(task_id,[primary])
        if result["status"]=="ANSWERABLE":
            result["selection_mode"]="NARROW_PRIMARY"
            return result

    # Widen to the available neighborhood only if primary is missing/inadequate.
    widened=[sid for sid in MANIFEST if sid in available and sid!=primary]
    if not widened:
        return {
            "status":"UNRESOLVED",
            "reason":"NO_SOURCE_NEIGHBORHOOD",
            "task_id":task_id,
            "project":TASKS[task_id]["project"],
            "sources_loaded":[],
            "bytes_loaded":0,
        }
    result=extract(task_id,widened)
    result["selection_mode"]="WIDENED_AFTER_PRIMARY_FAILURE"
    if result["status"]!="ANSWERABLE":
        result["status"]="UNRESOLVED"
        result["reason"]="WIDENED_CONTEXT_STILL_INSUFFICIENT"
    return result

def audit_registry():
    failures=[]
    for task_id,t in TASKS.items():
        if t["primary"] not in MANIFEST:
            failures.append({"task":task_id,"reason":"PRIMARY_NOT_IN_MANIFEST"})
            continue
        check=verify_source(t["primary"])
        if not check["passed"]:
            failures.append({"task":task_id,"reason":check["reason"]})
        n=narrow(task_id)
        if n["status"]!="ANSWERABLE":
            failures.append({"task":task_id,"reason":"PRIMARY_DOES_NOT_SATISFY_CONTRACT","missing":n.get("missing")})
    return {"passed":not failures,"tasks":len(TASKS),"sources":len(MANIFEST),"failures":failures}

if __name__=="__main__":
    print(json.dumps({"audit":audit_registry()},indent=2,sort_keys=True))
