# Orbit Lab Alpha 0.14 — TBCL Active-Carrier Compression Candidate

TBCL was used as a compression pressure rather than imported as a replacement ontology.

The finite corpus is made from already-integrated Orbit Lab distinctions:
Hodge dependencies, BGZF evidence kind, bridge preservation/authority,
SHADOW denominator/unknown/identity, and fractal generator/physical-measurement boundaries.

Two representations are compared:

1. verbose active records carrying repeated human-readable metadata;
2. a task-local fixed-row relation image carrying only the fields needed to make
   the current action decision, with provenance/scope/source records retained cold.

Acceptance requires:
- exact action/reconstruction equivalence;
- harmless reorder/encoding invariance;
- smaller active footprint;
- retained provenance/recoverability;
- counterexamples when consequential distinctions are removed.

This follows TBCL 0.2's bounded lesson: the compiled relation need not be necessary
for correctness; it earns a role when it removes repeated effort while preserved
source semantics remain recoverable.

No claim of global minimality is made and no kernel schema type was added.
