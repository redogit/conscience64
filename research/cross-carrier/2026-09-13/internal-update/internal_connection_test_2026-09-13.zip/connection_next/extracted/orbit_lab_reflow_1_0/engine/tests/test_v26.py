
import tempfile
from pathlib import Path
import unittest
from orbit_lab import OrbitLab

class V26Tests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.lab=OrbitLab(Path(self.tmp.name)/"t.db")
    def tearDown(self): self.lab.close(); self.tmp.cleanup()
    def add(self,t,title,key,**kw):
        return self.lab.add(t,title,provenance_class="TEST",provenance="test",identity_key=key,**kw)

    def test_association_is_typed_and_navigation_only(self):
        s=self.add("Scope","branch","s")
        a=self.add("Artifact","recovery packet","a")
        b=self.add("Artifact","library source","b")
        ep=self.lab.record_association(source_entity_id=a,target_entity_id=b,scope_id=s,
            relation="DECLARED_SOURCE",resolution_status="LIBRARY_ID_EXACT",
            provenance_class="TEST",provenance="test")
        data=self.lab.episode(ep)["data"]
        self.assertEqual(data["evidence_effect"],"NONE")
        self.assertEqual(data["movement_effect"],"NONE")

    def test_association_cannot_satisfy_generic_evidence_slot(self):
        s=self.add("Scope","branch","s")
        a=self.add("Artifact","packet","a"); b=self.add("Artifact","source","b")
        assoc=self.lab.record_association(source_entity_id=a,target_entity_id=b,scope_id=s,
            relation="DECLARED_SOURCE",resolution_status="LIBRARY_ID_EXACT",
            provenance_class="TEST",provenance="test")
        c=self.add("Context","C","c")
        method=self.add("Method","M","m")
        packet=self.add("Artifact","P","p")
        with self.assertRaises(TypeError):
            self.lab.assess_method_compliance(context_id=c,entity_id=packet,method_id=method,
                scope_id=s,verdict="CURRENT",basis_entity_ids=[assoc],reason="association is not evidence",
                provenance_class="TEST",provenance="test")

if __name__=="__main__": unittest.main()
