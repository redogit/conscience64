
import tempfile, sqlite3, json
from pathlib import Path
from orbit_lab import OrbitLab

with tempfile.TemporaryDirectory() as td:
    lab=OrbitLab(Path(td)/"deep.db")
    breaks=[]
    passes=[]
    try:
        # --- Re-run the two cases that forced Episode ---

        src=lab.add("Artifact","Original state representation",
                    data={"version":"A","semantics":"support-state-v1"},
                    provenance_class="PRIMARY_ARTIFACT",
                    provenance="library:file_000000004be481f59a600270c9337065",
                    identity_key="deep:transport:src")
        dst=lab.add("Artifact","Wrapper z=(x,y,vx,vy)",
                    provenance_class="PRIMARY_ARTIFACT",
                    provenance="library:file_000000004be481f59a600270c9337065",
                    identity_key="deep:transport:dst")
        obligation=lab.add("Obligation","Preserve support target, action offset, viability decision",
                           provenance_class="PRIMARY_ARTIFACT",
                           provenance="library:file_000000004be481f59a600270c9337065",
                           identity_key="deep:transport:ob")
        evidence=lab.add("Evidence","100000-state zero-mismatch comparison",
                         data={"states_tested":100000,"mismatches":0},
                         provenance_class="PRIMARY_ARTIFACT",
                         provenance="library:file_000000004be481f59a600270c9337065",
                         identity_key="deep:transport:evidence",
                         epistemic="OBSERVED")
        transport=lab.add_episode(
            "FAITHFUL_TRANSPORT","100000-state faithful transport",
            participants=[
                {"role":"source","object_id":src},
                {"role":"target","object_id":dst},
                {"role":"obligation","object_id":obligation},
                {"role":"evidence","object_id":evidence},
            ],
            data={"scope":"100000 tested states"},
            provenance_class="DERIVED",provenance="deep_stress",
            identity_key="deep:transport:episode"
        )
        try:
            lab.conn.execute("DELETE FROM objects WHERE id=?",(obligation,))
            lab.conn.commit()
            breaks.append("Episode participant FK failed to protect load-bearing obligation.")
        except sqlite3.IntegrityError:
            lab.conn.rollback()
            passes.append("Faithful-transport participant deletion is rejected.")

        candidate=lab.add("Candidate","Proposed G1->G3 link",
                          provenance_class="LIBRARY_ARTIFACT",provenance="acdn",
                          identity_key="deep:acdn:c")
        reset=lab.add("Artifact","Matched reset state R0",
                      provenance_class="DERIVED",provenance="deep_stress",
                      identity_key="deep:acdn:reset")
        off=lab.add("Probe","Connection OFF",provenance_class="DERIVED",
                    provenance="deep_stress",identity_key="deep:acdn:off")
        on=lab.add("Probe","Connection ON",provenance_class="DERIVED",
                   provenance="deep_stress",identity_key="deep:acdn:on")
        result=lab.add("Observation","Matched comparison result",
                       provenance_class="DERIVED",provenance="deep_stress",
                       identity_key="deep:acdn:result",epistemic="OBSERVED")
        matched=lab.add_episode(
            "MATCHED_COUNTERFACTUAL","ACDN link on/off",
            participants=[
                {"role":"candidate","object_id":candidate},
                {"role":"reset","object_id":reset},
                {"role":"control","object_id":off},
                {"role":"treatment","object_id":on},
                {"role":"result","object_id":result},
            ],
            provenance_class="DERIVED",provenance="deep_stress",
            identity_key="deep:acdn:episode"
        )
        try:
            lab.conn.execute("DELETE FROM objects WHERE id=?",(off,))
            lab.conn.commit()
            breaks.append("Matched-counterfactual FK failed.")
        except sqlite3.IntegrityError:
            lab.conn.rollback()
            passes.append("Matched-counterfactual member deletion is rejected.")

        # --- Deeper attack 1: identity over change ---
        # The transport episode points to src by object ID. If src content can be rewritten
        # in place, old evidence silently certifies new semantics.
        before=lab.get(src).data
        lab.conn.execute(
            "UPDATE objects SET title=?, data_json=? WHERE id=?",
            ("Original state representation — behavior changed",
             json.dumps({"version":"B","semantics":"support-state-v2-different-function"}),
             src)
        )
        lab.conn.commit()
        after=lab.get(src).data
        if before != after and lab.episode(transport):
            breaks.append(
                "Historical evidence survives an in-place semantic rewrite of a participant. "
                "Object identity is not a content/version snapshot."
            )

        # --- Deeper attack 2: scoped mixed evidence ---
        claim=lab.add("Claim","Adaptive probing beats uniform sampling",
                      provenance_class="DERIVED",provenance="deep_stress",
                      identity_key="deep:claim",epistemic="SUPPORTED")

        frame_peak=lab.add("Artifact","Observation frame: localized peak / budget 17",
                           data={"family":"single_peak","budget":17},
                           provenance_class="PRIMARY_ARTIFACT",
                           provenance="library:file_00000000495881f5890d127eefc122b9",
                           identity_key="deep:frame:peak")
        frame_osc=lab.add("Artifact","Observation frame: oscillatory / budget 17",
                          data={"family":"oscillatory","budget":17},
                          provenance_class="PRIMARY_ARTIFACT",
                          provenance="library:file_00000000495881f5890d127eefc122b9",
                          identity_key="deep:frame:osc")
        ev_peak=lab.add("Evidence","Adaptive wins on localized peak",
                        provenance_class="PRIMARY_ARTIFACT",
                        provenance="library:file_00000000495881f5890d127eefc122b9",
                        identity_key="deep:ev:peak",epistemic="OBSERVED")
        ev_osc=lab.add("Evidence","Adaptive loses on oscillatory family",
                       provenance_class="PRIMARY_ARTIFACT",
                       provenance="library:file_00000000495881f5890d127eefc122b9",
                       identity_key="deep:ev:osc",epistemic="OBSERVED")

        lab.add_episode(
            "CLAIM_ASSESSMENT","localized-peak assessment",
            participants=[
                {"role":"claim","object_id":claim},
                {"role":"frame","object_id":frame_peak},
                {"role":"evidence","object_id":ev_peak},
            ],
            data={"verdict":"SUPPORTED_IN_FRAME"},
            provenance_class="DERIVED",provenance="deep_stress",
            identity_key="deep:assessment:peak"
        )
        lab.add_episode(
            "CLAIM_ASSESSMENT","oscillatory assessment",
            participants=[
                {"role":"claim","object_id":claim},
                {"role":"frame","object_id":frame_osc},
                {"role":"evidence","object_id":ev_osc},
            ],
            data={"verdict":"CONTRADICTED_IN_FRAME"},
            provenance_class="DERIVED",provenance="deep_stress",
            identity_key="deep:assessment:osc"
        )
        if lab.get(claim).epistemic == "SUPPORTED":
            breaks.append(
                "Claim still exposes one intrinsic epistemic status even though two valid "
                "assessment episodes give opposite frame-scoped verdicts."
            )

        print("V0.3 DEEP STRESS")
        print("----------------")
        print("PASS:")
        for p in passes: print("-",p)
        print("\nFORCED/NEXT BREAKS:")
        for i,b in enumerate(breaks,1): print(f"{i}. {b}")
    finally:
        lab.close()
