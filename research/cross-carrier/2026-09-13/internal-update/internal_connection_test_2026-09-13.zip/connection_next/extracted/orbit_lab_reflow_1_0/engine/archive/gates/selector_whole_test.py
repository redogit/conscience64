from __future__ import annotations
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Callable
import json, subprocess, sys, time, tempfile

from orbital_gans import OrbitalGAN
from orbit_lab import OrbitLab
from supporter_ecology import SupporterEcology
from supporter_router import route_profile, PROFILES

BASE=Path(__file__).resolve().parent
SELECTOR_PREORDER=("S0","S1","S2","S3","S4","S5")

@dataclass(frozen=True)
class Component:
    name: str
    obligations: frozenset[str]

COMPONENTS=[
    Component("kernel",frozenset({"compile","regression","authority","schema","history","scope","state","epistemic","lineage"})),
    Component("active-loader",frozenset({"research-load","historical-status"})),
    Component("historical-probes",frozenset({"historical-classification","no-unexplained-historical-failure"})),
    Component("orbital-adversary",frozenset({"random-composition","no-novel-counterexample","no-harness-error"})),
    Component("supporter-ecology",frozenset({"mechanism-diversity","no-supporter-finding","retain-pressure"})),
    Component("supporter-router",frozenset({"applicability-routing","cost-aware","no-false-independence","profile-coverage"})),
    Component("bounded-reference",frozenset({"bounded-exact","metamorphic"})),
    Component("persistence",frozenset({"roundtrip","tamper-reject","audit"})),
    Component("whole",frozenset({"whole-integration"})),
]

@dataclass
class ProbeResult:
    name: str
    selector: str
    passed: bool
    resolves: set[str]
    seconds: float
    detail: dict

class ProbeCache:
    def __init__(self):
        self.results: dict[str,ProbeResult]={}
    def run(self,name: str, fn: Callable[[],ProbeResult]) -> ProbeResult:
        if name not in self.results:
            self.results[name]=fn()
        return self.results[name]

CACHE=ProbeCache()

def cmd(args,timeout=180):
    t=time.time()
    p=subprocess.run(args,cwd=BASE,text=True,capture_output=True,timeout=timeout)
    return p,round(time.time()-t,3)

def probe_s0_compile_tests():
    t=time.time()
    compile_p=subprocess.run([sys.executable,"-m","compileall","-q","."],cwd=BASE,text=True,capture_output=True,timeout=60)
    tests_p=subprocess.run([sys.executable,"-m","unittest","discover","-q"],cwd=BASE,text=True,capture_output=True,timeout=120)
    passed=compile_p.returncode==0 and tests_p.returncode==0
    count=None
    import re
    m=re.search(r"Ran (\d+) tests",tests_p.stderr+tests_p.stdout)
    if m: count=int(m.group(1))
    return ProbeResult("compile+full-regression","S0",passed,
        {"compile","regression","authority","schema","history","scope","state","epistemic","lineage"} if passed else set(),
        round(time.time()-t,3),{"tests":count,"compile_rc":compile_p.returncode,"test_rc":tests_p.returncode,"tail":(tests_p.stderr+tests_p.stdout)[-1200:]})

def probe_s1_loader():
    t=time.time()
    with tempfile.TemporaryDirectory() as td:
        p=subprocess.run([sys.executable,str(BASE/"seed_research.py")],cwd=td,text=True,capture_output=True,timeout=60)
    secs=round(time.time()-t,3)
    return ProbeResult("active-research-loader","S1",p.returncode==0,
        {"research-load","historical-status"} if p.returncode==0 else set(),secs,
        {"rc":p.returncode,"tail":(p.stdout+p.stderr)[-1800:]})

def probe_s1_historical():
    p,secs=cmd([sys.executable,"historical_stress_audit.py"],180)
    detail={"rc":p.returncode,"tail":(p.stdout+p.stderr)[-2200:]}
    try:
        obj=json.loads(p.stdout)
        detail.update({k:obj.get(k) for k in ["historical_total","historical_pass","historical_expected_stale","historical_unexpected_failures","active_loaders"]})
    except Exception: pass
    return ProbeResult("historical-stress-audit","S1",p.returncode==0,
        {"historical-classification","no-unexplained-historical-failure"} if p.returncode==0 else set(),secs,detail)

def probe_s1_alpha_state():
    p,secs=cmd([sys.executable,"alpha_gate.py"],180)
    detail={"rc":p.returncode,"tail":(p.stdout+p.stderr)[-2200:]}
    try: detail["gate"]=json.loads(p.stdout)
    except Exception: pass
    return ProbeResult("alpha-state-gate","S1",p.returncode==0,
        {"roundtrip","tamper-reject","audit"} if p.returncode==0 else set(),secs,detail)

def probe_s2_orbital():
    t=time.time(); r=OrbitalGAN(seed=1701).run(rounds=128); secs=round(time.time()-t,3)
    passed=r["novel_findings"]==0 and len(r["harness_errors"])==0
    return ProbeResult("bounded-random-orbital","S2",passed,
        {"random-composition","no-novel-counterexample","no-harness-error"} if passed else set(),secs,
        {"trials":r["trials"],"novel_findings":r["novel_findings"],"harness_errors":len(r["harness_errors"]),"signatures":[x["signature"] for x in r["findings"]]})

def probe_s3_ecology():
    t=time.time(); r=SupporterEcology().run(); secs=round(time.time()-t,3)
    passed=r["findings"]==0
    return ProbeResult("supporter-ecology","S3",passed,
        {"mechanism-diversity","no-supporter-finding","retain-pressure"} if passed else set(),secs,
        {"signals":len(r["signals"]),"passes":r["passes"],"pressures":r["pressures"],"findings":r["findings"],"finding_signatures":[x["signature"] for x in r["signals"] if x["status"]=="FINDING"]})

def probe_s3_router():
    t=time.time(); routes={n:route_profile(n) for n in PROFILES}; secs=round(time.time()-t,3)
    passed=all(not r["uncovered"] for r in routes.values()) and all(r["independent"] is False for r in routes.values())
    return ProbeResult("supporter-applicability-router","S3",passed,
        {"applicability-routing","cost-aware","no-false-independence","profile-coverage"} if passed else set(),secs,
        {"profiles":{n:{"uncovered":r["uncovered"],"cost":r["total_cost"],"mechanisms":r["mechanisms"],"independent":r["independent"]} for n,r in routes.items()}})

def probe_s4_bounded():
    t=time.time(); e=SupporterEcology(); a=e.bounded_scope_explorer(); b=e.metamorphic_navigation_supporter(); secs=round(time.time()-t,3)
    passed=a.status!="FINDING" and b.status!="FINDING"
    return ProbeResult("bounded-distinguishing-search","S4",passed,
        {"bounded-exact","metamorphic"} if passed else set(),secs,
        {"signals":[asdict(a),asdict(b)]})

def probe_s5_whole():
    """Integrated fresh-world scenario; stronger selector only for whole composition."""
    t=time.time()
    with tempfile.TemporaryDirectory() as td:
        td=Path(td)
        lab=OrbitLab(td/"whole.db")
        try:
            def add(t_,title,key,**kw):
                return lab.add(t_,title,provenance_class="TEST",provenance="selector-whole",identity_key=key,**kw)

            source=add("Context","Source","ctx:source")
            dest=add("Context","Destination","ctx:dest")
            actor=add("Actor","Operator","actor")
            schema_scope=add("Scope","Schema","scope:schema")
            cycle1=add("Scope","Cycle 1","scope:c1")
            cycle2=add("Scope","Cycle 2","scope:c2")
            evidence=add("Evidence","Observed witness","ev",epistemic="OBSERVED")
            frame=add("ValidityFrame","Whole frame","vf",data={"conditions":{"mode":"whole-selector"}})

            # Governed schema growth.
            gap=lab.record_schema_gap(gap_kind="LANGUAGE_COLLISION",current_term="Obligation",
                missing_distinction="pre-obligation pressure",provenance_class="TEST",provenance="selector-whole")
            proposal=lab.propose_schema_object_type(gap_id=gap,type_name="SelectorPressure",
                definition="Pressure earned inside the selector whole test.",provenance_class="TEST",provenance="selector-whole")
            promotion=lab.record_promotion(context_id=dest,entity_id=proposal,scope_id=schema_scope,
                validity_frame_id=frame,witness_entity_id=evidence,basis_entity_ids=[evidence],
                change_claim="distinction required",revalidation_rule="rerun whole selector",
                provenance_class="TEST",provenance="selector-whole")
            root_schema=lab.establish_authority_root(context_id=dest,scope_id=schema_scope,
                operations=["SCHEMA_CHANGE"],holder_actor_id=actor,
                provenance_class="USER",provenance="selector-user")
            lab.grant_authorization(context_id=dest,entity_id=proposal,operation="SCHEMA_CHANGE",
                scope_id=schema_scope,issuer_authority_id=root_schema,issuer_actor_id=actor,principal_id=actor,
                basis_entity_ids=[evidence,promotion],reason="whole-test earned repair",
                provenance_class="TEST",provenance="selector-whole")
            lab.apply_schema_object_type(proposal_id=proposal,promotion_episode_id=promotion,
                context_id=dest,actor_id=actor,scope_id=schema_scope,reason="apply whole-test repair",
                provenance_class="TEST",provenance="selector-whole")
            pressure=add("SelectorPressure","Observed pressure","pressure")

            # Content -> instance -> occurrence -> custody copy.
            content=lab.register_content(algorithm="sha256",digest="0123456789abcdef",
                provenance_class="TEST",provenance="selector-whole")
            instance=lab.create_artifact_instance(content_id=content,title="Source artifact",
                provenance_class="TEST",provenance="selector-whole",identity_key="inst")
            source_occ=lab.record_instance_occurrence(instance_id=instance,context_id=source,
                locator="/source/a",mode="REGISTER",provenance_class="TEST",provenance="selector-whole",identity_key="occ:source")
            obligation=add("Obligation","Preserve content","ob")
            copy=lab.custody_transfer(source_context_id=source,destination_context_id=dest,
                source_occurrence_id=source_occ,destination_locator="/dest/a",mode="COPY",
                obligation_ids=[obligation],evidence_entity_ids=[evidence],actor_id=actor,
                reason="whole-test copy",provenance_class="TEST",provenance="selector-whole")
            if not copy["content_preserved"] or copy["source_instance_id"]==copy["destination_instance_id"]:
                raise AssertionError("COPY identity/content invariant failed")

            # Navigation-only association must not become authority/evidence.
            lab.record_association(source_entity_id=pressure,target_entity_id=copy["destination_occurrence_id"],
                scope_id=schema_scope,relation="MENTIONS",resolution_status="LOGICAL_ARTIFACT_ID",
                provenance_class="TEST",provenance="selector-whole")

            # Scope-local exposure: cycle-1 truth access must not poison disjoint cycle-2.
            truth=add("Artifact","Holdout truth","truth")
            model=add("Candidate","Model","model")
            root1=lab.establish_authority_root(context_id=dest,scope_id=cycle1,operations=["INSPECT"],
                holder_actor_id=actor,provenance_class="USER",provenance="selector-user")
            root2=lab.establish_authority_root(context_id=dest,scope_id=cycle2,operations=["CLEAN_EVALUATE"],
                holder_actor_id=actor,provenance_class="USER",provenance="selector-user")
            lab.grant_authorization(context_id=dest,entity_id=truth,operation="INSPECT",scope_id=cycle1,
                issuer_authority_id=root1,issuer_actor_id=actor,principal_id=actor,basis_entity_ids=[evidence],
                reason="cycle1 truth access",provenance_class="TEST",provenance="selector-whole")
            lab.grant_authorization(context_id=dest,entity_id=model,operation="CLEAN_EVALUATE",scope_id=cycle2,
                issuer_authority_id=root2,issuer_actor_id=actor,principal_id=actor,basis_entity_ids=[evidence],
                prerequisites={"forbid_exposure_tags":["CONFIRMATION_TRUTH"]},reason="cycle2 clean eval",
                provenance_class="TEST",provenance="selector-whole")
            lab.record_access(context_id=dest,actor_id=actor,entity_id=truth,operation="INSPECT",scope_id=cycle1,
                exposure_tags=["CONFIRMATION_TRUTH"],provenance_class="TEST",provenance="selector-whole")
            if not lab.check_authorized(context_id=dest,actor_id=actor,entity_id=model,
                operation="CLEAN_EVALUATE",scope_id=cycle2)["authorized"]:
                raise AssertionError("disjoint-cycle exposure leaked")

            # Preserve a genuinely unexplained remainder.
            remainder=add("Remainder","Unexplained residual","rem",epistemic="UNEXPLAINED")

            before=lab.alpha_audit()
            if not before["passed"]:
                raise AssertionError(f"pre-export audit failed: {before['failures']}")
            exported=lab.export_state(td/"state.json")
            digest=exported["sha256"]
        finally:
            lab.close()

        restored=OrbitLab(td/"restored.db")
        try:
            restored.import_state(td/"state.json")
            after=restored.alpha_audit()
            if not after["passed"]:
                raise AssertionError(f"post-import audit failed: {after['failures']}")
            if restored.state_snapshot()["sha256"]!=digest:
                raise AssertionError("whole-state digest changed on roundtrip")
            if restored.get(pressure).type!="SelectorPressure" or restored.get(remainder).epistemic!="UNEXPLAINED":
                raise AssertionError("learned schema/remainder lost on roundtrip")
        finally:
            restored.close()

    return ProbeResult("integrated-whole-scenario","S5",True,{"whole-integration"},round(time.time()-t,3),
        {"checks":["governed-schema","custody-copy","association","scope-local-exposure","unexplained-remainder","audit","roundtrip"]})

PROBES={
    "S0":[probe_s0_compile_tests],
    "S1":[probe_s1_loader,probe_s1_historical,probe_s1_alpha_state],
    "S2":[probe_s2_orbital],
    "S3":[probe_s3_ecology,probe_s3_router],
    "S4":[probe_s4_bounded],
    "S5":[probe_s5_whole],
}

# Which obligations each selector is permitted to resolve. This is the applicability
# selector: if no unresolved obligation intersects a selector's potential, it is skipped.
POTENTIAL={
    "S0":{"compile","regression","authority","schema","history","scope","state","epistemic","lineage"},
    "S1":{"research-load","historical-status","historical-classification","no-unexplained-historical-failure","roundtrip","tamper-reject","audit"},
    "S2":{"random-composition","no-novel-counterexample","no-harness-error"},
    "S3":{"mechanism-diversity","no-supporter-finding","retain-pressure","applicability-routing","cost-aware","no-false-independence","profile-coverage"},
    "S4":{"bounded-exact","metamorphic"},
    "S5":{"whole-integration"},
}

def main():
    required=set().union(*(set(c.obligations) for c in COMPONENTS))
    resolved=set(); trace=[]; escalations=[]
    stopped=False
    for level in SELECTOR_PREORDER:
        unresolved=required-resolved
        applicable=unresolved & POTENTIAL[level]
        if not applicable:
            trace.append({"selector":level,"status":"SKIP","because":"no applicable unresolved obligation"})
            continue
        if level!="S0":
            escalations.append({"to":level,"because":sorted(applicable)})
        level_results=[]
        for fn in PROBES[level]:
            result=CACHE.run(fn.__name__,fn)
            level_results.append({
                "probe":result.name,"passed":result.passed,"seconds":result.seconds,
                "resolved":sorted(result.resolves),"detail":result.detail,
            })
            if result.passed:
                resolved |= result.resolves
            else:
                stopped=True
        trace.append({"selector":level,"status":"PASS" if all(x["passed"] for x in level_results) else "FAIL","applicable_obligations":sorted(applicable),"probes":level_results})
        if stopped:
            break

    component_results=[]
    for c in COMPONENTS:
        missing=set(c.obligations)-resolved
        component_results.append({"component":c.name,"passed":not missing,"obligations":sorted(c.obligations),"unresolved":sorted(missing)})
    out={
        "selector_preorder":SELECTOR_PREORDER,
        "policy":"Use the weakest applicable selector. Escalate only while a preregistered obligation remains unresolved. Probe results are cached and shared across components.",
        "required_obligations":sorted(required),
        "resolved_obligations":sorted(resolved),
        "unresolved_obligations":sorted(required-resolved),
        "components":component_results,
        "passed_components":sum(x["passed"] for x in component_results),
        "total_components":len(component_results),
        "escalations":escalations,
        "trace":trace,
        "passed":not (required-resolved) and all(x["passed"] for x in component_results) and not stopped,
    }
    print(json.dumps(out,indent=2,sort_keys=True))
    if not out["passed"]:
        raise SystemExit(1)

if __name__=="__main__":
    main()
