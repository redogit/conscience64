import tempfile, unittest, sqlite3
from pathlib import Path
from orbit_lab import OrbitLab
from checks.bgzf_carrier_probe import run

class BGZFEvidenceQualificationTests(unittest.TestCase):
    def add(self,lab,t,title,key,**kw):
        return lab.add(t,title,provenance_class='TEST',provenance='test',identity_key=key,**kw)

    def test_bgzf_probe(self):
        r=run(); self.assertTrue(r['passed'],r)
        self.assertTrue(r['learned_state_cannot_satisfy_exact_carrier_claim'])
        self.assertTrue(r['weak_file_label_cannot_satisfy_block_truth_claim'])
        self.assertEqual(r['kernel_schema_additions'],0)

    def test_claim_evidence_tags_are_enforced(self):
        with tempfile.TemporaryDirectory() as td:
            lab=OrbitLab(Path(td)/'t.db')
            try:
                frame=self.add(lab,'ObservationFrame','F','f',data={'observer':'t','apparatus':'t','accessible_variables':['x'],'resolution':'exact','intervention':'none','boundary':'test'})
                claim=self.add(lab,'Claim','needs exact','c',data={'required_evidence_tags':['EXACT']})
                learned=self.add(lab,'Artifact','learned','l',data={'evidence_tags':['LEARNED']})
                exact=self.add(lab,'Artifact','exact','e',data={'evidence_tags':['EXACT']})
                with self.assertRaises(ValueError):
                    lab.assess_claim(claim,frame_id=frame,evidence_ids=[learned],verdict='SUPPORTED',scope='x',provenance_class='TEST',provenance='test')
                ep=lab.assess_claim(claim,frame_id=frame,evidence_ids=[exact],verdict='SUPPORTED',scope='x',provenance_class='TEST',provenance='test')
                self.assertEqual(lab.episode(ep)['data']['verdict'],'SUPPORTED')
            finally: lab.close()

    def test_audit_detects_persisted_qualification_bypass(self):
        with tempfile.TemporaryDirectory() as td:
            lab=OrbitLab(Path(td)/'t.db')
            try:
                frame=self.add(lab,'ObservationFrame','F','f',data={'observer':'t','apparatus':'t','accessible_variables':['x'],'resolution':'exact','intervention':'none','boundary':'test'})
                claim=self.add(lab,'Claim','needs exact','c',data={'required_evidence_tags':['EXACT']})
                learned=self.add(lab,'Artifact','learned','l',data={'evidence_tags':['LEARNED']})
                # Storage adversary first removes the semantic-immutability trigger, then forges the verdict.
                ep=lab.assess_claim(claim,frame_id=frame,evidence_ids=[learned],verdict='UNRESOLVED',scope='x',provenance_class='TEST',provenance='test')
                data=lab.episode(ep)['data']; data['verdict']='SUPPORTED'
                lab.conn.execute('DROP TRIGGER trg_episodes_semantic_immutable')
                lab.conn.execute('UPDATE episodes SET data_json=? WHERE id=?',( __import__('json').dumps(data,sort_keys=True), ep)); lab.conn.commit()
                audit=lab.alpha_audit()
                self.assertFalse(audit['passed'])
                self.assertTrue(any(x['check']=='claim_evidence_qualifications' for x in audit['failures']))
            finally: lab.close()

if __name__=='__main__': unittest.main()
