# Orbit Lab Alpha 0.11 candidate

Adds Compact Branching Geometry as a source/execution/repair-lineage regression branch. No kernel schema change.
