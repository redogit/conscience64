import unittest
from checks.human_pair_record_probe import run
class HumanPairRecordProbeTests(unittest.TestCase):
    def test_pair_record_preserves_observation_comparison_interpretation(self):
        r=run(); self.assertTrue(r['passed'],r); self.assertEqual(r['comparison_sources'],2)
if __name__=='__main__': unittest.main()
