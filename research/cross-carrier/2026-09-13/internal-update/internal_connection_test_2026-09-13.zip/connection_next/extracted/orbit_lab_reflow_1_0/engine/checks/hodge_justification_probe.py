from __future__ import annotations
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path: sys.path.insert(0,str(ROOT))
import tempfile, json
from orbit_lab import OrbitLab

def add(lab,t,title,key,**kw):
    return lab.add(t,title,identity_key=key,provenance_class=kw.pop('provenance_class','TEST'),provenance=kw.pop('provenance','hodge-053'),**kw)

def run():
    with tempfile.TemporaryDirectory() as td:
        lab=OrbitLab(Path(td)/'hodge.db')
        try:
            frame=add(lab,'ObservationFrame','Hodge 053 theorem-dependency frame','frame',data={
                'observer':'Orbit Lab','apparatus':'theorem-dependency audit',
                'accessible_variables':['finite_character_witness','theorem_source_status','application_hypotheses'],
                'resolution':'claim edge','intervention':'none','boundary':'Fermat fourfold bounded audit'})
            finite=add(lab,'Evidence','Finite character witness verified for bounded residual','finite',epistemic='OBSERVED')
            source=add(lab,'Artifact','Theorem source identified but proof not independently reconstructed','source',data={
                'sources':['Shioda-Katsura 1979','Aoki 1987','Jumagulov arXiv:2608.18134'],
                'status':'SOURCE_IDENTIFIED_NOT_INDEPENDENTLY_RECONSTRUCTED'})
            finite_claim=add(lab,'Claim','The finite character witness satisfies the recorded combinatorial predicate','finite-claim')
            theorem_claim=add(lab,'Claim','The required closure theorem is valid with the exact needed statement','theorem-claim')
            application_claim=add(lab,'Claim','All theorem hypotheses hold for this finite witness','application-claim')
            terminal=add(lab,'Claim','The target rational Hodge block is algebraic','terminal')
            lab.relate(application_claim,'REQUIRES',theorem_claim,data={'role':'theorem_validity'},provenance_class='TEST',provenance='hodge-053')
            lab.relate(terminal,'REQUIRES',application_claim,data={'role':'application_validity'},provenance_class='TEST',provenance='hodge-053')
            lab.assess_claim(finite_claim,frame_id=frame,evidence_ids=[finite],verdict='SUPPORTED',scope='bounded finite character arithmetic',provenance_class='TEST',provenance='hodge-053')
            lab.assess_claim(theorem_claim,frame_id=frame,evidence_ids=[source],verdict='UNRESOLVED',scope='theorem statement/source identified; proof not independently reconstructed',provenance_class='TEST',provenance='hodge-053')
            blocked=False
            try:
                lab.assess_claim(terminal,frame_id=frame,evidence_ids=[finite],verdict='SUPPORTED',scope='finite witness only',provenance_class='TEST',provenance='hodge-053')
            except ValueError:
                blocked=True
            dep=lab.claim_dependency_status(terminal)
            audit=lab.alpha_audit()
            return {
                'passed':blocked and not dep['satisfied'] and audit['passed'],
                'finite_witness_claim':'SUPPORTED',
                'theorem_validity':'UNRESOLVED',
                'application_validity':'UNRESOLVED',
                'terminal_algebraicity':'UNRESOLVED',
                'direct_finite_to_algebraicity_support_blocked':blocked,
                'dependency_status':dep,
                'audit_passed':audit['passed'],
                'claim_ceiling':'Finite character arithmetic is verified; theorem-backed geometric algebraicity remains unresolved until theorem validity and application validity are separately supported.'
            }
        finally: lab.close()

if __name__=='__main__': print(json.dumps(run(),indent=2,sort_keys=True))
