
import tempfile, unittest
from pathlib import Path
from orbit_lab import OrbitLab
from checks.philosophy_source_role_probe import run

class PhilosophySourceRoleTests(unittest.TestCase):
    def test_full_boundary_probe(self):
        r=run()
        self.assertTrue(r["passed"])
        self.assertTrue(r["philosophy_may_motivate_candidate_question"])
        self.assertTrue(r["philosophy_role_blocked_from_empirical_claim"])
        self.assertTrue(r["empirical_result_role_can_support_empirical_claim"])
        self.assertTrue(r["philosophy_can_support_descriptive_claim_about_its_own_text"])

    def test_source_role_contract_requires_declared_role_when_requested(self):
        with tempfile.TemporaryDirectory() as td:
            lab=OrbitLab(Path(td)/"t.db")
            try:
                frame=lab.add("ObservationFrame","f",data={
                    "observer":"t","apparatus":"t","accessible_variables":["role"],
                    "resolution":"one","intervention":"none","boundary":"test"
                },provenance_class="TEST",provenance="t",identity_key="f")
                ev=lab.add("Evidence","untagged role",data={"evidence_tags":["X"]},
                    epistemic="OBSERVED",provenance_class="TEST",provenance="t",identity_key="e")
                claim=lab.add("Claim","c",data={
                    "required_evidence_tags":["X"],
                    "evidence_source_role_contract":{
                        "allowed":["EMPIRICAL_RESULT"],"require_declared_role":True
                    }
                },provenance_class="TEST",provenance="t",identity_key="c")
                with self.assertRaises(ValueError):
                    lab.assess_claim(claim,frame_id=frame,evidence_ids=[ev],verdict="SUPPORTED",
                        scope="test",provenance_class="TEST",provenance="t")
            finally:
                lab.close()

    def test_audit_detects_post_support_source_role_corruption(self):
        with tempfile.TemporaryDirectory() as td:
            lab=OrbitLab(Path(td)/"audit.db")
            try:
                frame=lab.add("ObservationFrame","f",data={
                    "observer":"t","apparatus":"t","accessible_variables":["role"],
                    "resolution":"one","intervention":"corrupt source role","boundary":"test"
                },provenance_class="TEST",provenance="t",identity_key="af")
                ev=lab.add("Evidence","empirical",data={
                    "source_role":"EMPIRICAL_RESULT","evidence_tags":["X"]
                },epistemic="OBSERVED",provenance_class="TEST",provenance="t",identity_key="ae")
                claim=lab.add("Claim","c",data={
                    "required_evidence_tags":["X"],
                    "evidence_source_role_contract":{
                        "allowed":["EMPIRICAL_RESULT"],
                        "forbidden":["PHILOSOPHY"],
                        "require_declared_role":True
                    }
                },provenance_class="TEST",provenance="t",identity_key="ac")
                lab.assess_claim(claim,frame_id=frame,evidence_ids=[ev],verdict="SUPPORTED",
                    scope="test",provenance_class="TEST",provenance="t")

                # Simulate hostile persistence corruption by changing only data_json.
                import json as _json
                data=lab.get(ev).data
                data["source_role"]="PHILOSOPHY"
                lab.conn.execute("DROP TRIGGER trg_objects_semantic_immutable")
                lab.conn.execute("UPDATE objects SET data_json=? WHERE id=?",
                    (_json.dumps(data,sort_keys=True),ev))
                lab.conn.commit()
                audit=lab.alpha_audit()
                self.assertFalse(audit["passed"])
                self.assertTrue(any(
                    f["check"]=="claim_evidence_source_roles"
                    for f in audit["failures"]
                ))
            finally:
                lab.close()


if __name__=="__main__":
    unittest.main()
