
import tempfile
from pathlib import Path
import unittest
from orbit_lab import OrbitLab

class V10Tests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.lab=OrbitLab(Path(self.tmp.name)/"t.db")
    def tearDown(self): self.lab.close(); self.tmp.cleanup()
    def add(self,t,title,key,**kw):
        return self.lab.add(t,title,provenance_class="TEST",provenance="test",identity_key=key,**kw)
    def frame(self):
        return self.add("ObservationFrame","frame","f",data={"observer":"t","apparatus":"sim","accessible_variables":["y"],"resolution":"1","intervention":"toggle","boundary":"b"})
    def exec(self,key,frame,params,reset):
        p=self.add("Probe",key,key+"p"); o=self.add("Observation",key,key+"o",epistemic="OBSERVED")
        run=self.add("RunIdentity",key+" run",key+"run"); return self.lab.record_execution(run_id=run,probe_id=p,frame_id=frame,parameters_id=params,reset_id=reset,
                                         observation_ids=[o],status="COMPLETED",provenance_class="TEST",provenance="test")
    def test_matched_requires_same_parameters(self):
        f=self.frame(); r=self.add("Artifact","reset","r")
        p1=self.add("Parameters","p1","p1",data={"lr":0.1}); p2=self.add("Parameters","p2","p2",data={"lr":0.2})
        e1=self.exec("off",f,p1,r); e2=self.exec("on",f,p2,r)
        c=self.add("Candidate","link","c"); out=self.add("Observation","delta","out",epistemic="OBSERVED")
        with self.assertRaises(ValueError):
            self.lab.add_episode("MATCHED_COUNTERFACTUAL","bad",
                participants=[{"role":"candidate","object_id":c},{"role":"reset","object_id":r},
                              {"role":"control","episode_id":e1},{"role":"treatment","episode_id":e2},
                              {"role":"result","object_id":out}],
                provenance_class="TEST",provenance="test")
    def test_matched_accepts_shared_parameters(self):
        f=self.frame(); r=self.add("Artifact","reset","r"); params=self.add("Parameters","p","p",data={"lr":0.1})
        e1=self.exec("off",f,params,r); e2=self.exec("on",f,params,r)
        c=self.add("Candidate","link","c"); out=self.add("Observation","delta","out",epistemic="OBSERVED")
        ep=self.lab.add_episode("MATCHED_COUNTERFACTUAL","good",
            participants=[{"role":"candidate","object_id":c},{"role":"reset","object_id":r},
                          {"role":"control","episode_id":e1},{"role":"treatment","episode_id":e2},
                          {"role":"result","object_id":out}],
            provenance_class="TEST",provenance="test")
        self.assertEqual(self.lab.episode(ep)["kind"],"MATCHED_COUNTERFACTUAL")
if __name__=="__main__": unittest.main()
