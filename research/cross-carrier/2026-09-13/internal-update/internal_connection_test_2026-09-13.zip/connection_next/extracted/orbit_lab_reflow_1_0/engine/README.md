# Orbit Lab — Alpha 0.5 Human Interface Candidate

Start with [`START_HERE.md`](START_HERE.md).

The active surface is intentionally small:

```text
orbit_lab.py      kernel
selector.py       weakest-applicable escalation policy
supporters/       interchangeable helper mechanisms + exact capability routing
seed_research.py  representative recovered-research loader
tests/            current regressions
archive/          passive historical probes and superseded gates
docs/             evidence/reports/synthesis
```

Run the current whole contract:

```bash
python selector.py
```

Run only current regressions:

```bash
python -m unittest discover -s tests -q
```

The selector writes its latest structured result to `artifacts/latest_selector_run.json`.

## Alpha 0.5 candidate — human-facing Research Card

`human_lab.py` provides a console interface centered on a person's current research step
rather than kernel object names. The default view is:

- Question
- Need
- Limit
- Try
- Saw
- Left

Interpretation (`think`) and decision (`decide`) remain explicitly separate from observation.
The selector now tests the human interface as an active component; it is not merely UI decoration.

```bash
python human_lab.py --demo
python human_lab.py --db my_research.db
python selector.py
```


# Alpha 0.6.1 — Battery-Hardened Connected Research

Recovered Library branches now enter through `data/research_connections.json` and `connections.py`. They remain quarantined and connect to current lab components only through non-evidentiary associations until a branch-specific test earns more.

Human commands added: `incoming`, `why <area>`, `compare <text>`.

```bash
python connections.py --check
python checks/connection_probe.py
python checks/human_pair_record_probe.py
python selector.py
python human_lab.py --demo
```

# Wave 2 candidate

Alpha 0.7 adds no new kernel noun. It constrains declared Claim `REQUIRES` dependencies and adds a small non-blocking Human Lab surface guard derived from a verified Language Structure Workbench fixture. See `docs/WAVE2_INTEGRATION_REPORT.md`.


## Alpha 0.8 BGZF carrier/evidence candidate

The BGZF branch forced one generic claim-containment refinement: evidence qualification is now explicit when a claim requires a specific evidence class. This prevents learned/adaptive state from satisfying an exact deterministic carrier claim and prevents file-level weak labels from being silently promoted into block-level ground truth. See `docs/BGZF_INTEGRATION_ALPHA_0_8.md`.

# Alpha 0.9 — Obligation-Preserving Transfer

Recovered Society/Recovery/Bridge work produced one generic transfer invariant:
a `PRESERVED` `TRANSFER` or `CUSTODY_TRANSFER` may not bypass evidence
qualifications declared by its participating `Obligation`s.

No `Bridge` object or Episode type was added.

```bash
python checks/bridge_obligation_probe.py
python -m unittest discover -s tests -q
```
