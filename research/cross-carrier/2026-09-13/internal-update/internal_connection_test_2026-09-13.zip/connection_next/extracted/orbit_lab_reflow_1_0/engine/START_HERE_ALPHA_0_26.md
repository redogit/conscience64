# Orbit Lab Alpha 0.26 — Library Fold + Support Retrieval

Purpose: finish the staged Library fold without bulk-ingesting everything, and add a bounded way to find potentially supporting Library items for any current item.

## Stages completed

1. Stage 1 — old Orbit Incoming queue resolved to History (Alpha 0.25).
2. Stage 2 — named research/project roots reviewed from current/recovery entrypoints; only consequential deltas imported.
3. Stage 3 — loose root artifacts remain in place and are handled by progressive/on-demand retrieval rather than a bulk dump.
4. Stage 4 — private/ambiguous namespaces are minimum-access and excluded from automatic support search.
5. Stage 5 — support retrieval added.

## New consequential deltas

- MoonShot full repeated-self-expansion claim: `VERIFIED_NO_FOR_FROZEN_BOUNDED_SYSTEM`; universal possibility/impossibility remains unresolved.
- Parameter Differential Reflow: retained as a candidate mechanism; its burden of proof is comparison with an otherwise identical fixed-parameter recurrent baseline.
- SHADOW Phase B recovery: committed denominator 12,288/130,825; S0002 remains `INTEGRITY_STOP_UNCOMMITTED`; parent S0004 was pending at export.
- Runtime Relation Index: imported as a retrieval helper candidate, never as evidence authority.

## Library support command

`find-support <item, claim, file, or concept>`

Search order:
`exact identity / declared lineage -> bounded neighborhood -> inspect source -> classify tested relation -> bounded return`

Hard boundary:
`related != supports`
`lookup != evidence`
`retrieval != proof`

The static seed contains 633 declared recovery/library associations, 124 exact-resolved rows, and 77 distinct resolved file IDs. It is a seed, not a completeness claim. New/loose items can trigger bounded live Library search.

## Privacy

Automatic support search excludes `/Homework` and `/Your job is you move things from a to b.` by default. Widen only for an explicit task and retrieve the minimum relevant material.

## Verification

- 209/209 regressions PASS
- 33 components / 133 declared obligations PASS
- `library-fold` task profile PASS
- `library-support` task profile PASS
- direct S5 whole integration PASS
- zero kernel schema additions
- full selector JSON completed with zero unresolved obligations; the known host-wrapper linger occurred after complete output and remains a wrapper boundary rather than an Orbit result failure.
