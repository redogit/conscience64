from pathlib import Path
import os, runpy, sys
ROOT=Path(__file__).resolve().parent
ENGINE=ROOT/"engine"
os.chdir(ENGINE)
sys.path.insert(0,str(ENGINE))
runpy.run_path(str(ENGINE/"human_lab.py"), run_name="__main__")
