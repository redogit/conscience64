import sys, tempfile, json
from pathlib import Path
sys.path.insert(0,'/mnt/data/orbit_lab_internal_v02')
from orbit_lab import OrbitLab

DELAY = [
(4,0.7525,0.9975,0.2450),(20,0.7525,0.9966666667,0.2441666667),
(100,0.7525,0.995,0.2425),(250,0.7525,0.9941666667,0.2416666667),
(500,0.7525,0.9833333333,0.2308333333),(750,0.7516666667,0.9566666667,0.205),
(1000,0.6058333333,0.0058333333,-0.6),(1500,0.0033333333,0.0,-0.0033333333)]

with tempfile.TemporaryDirectory() as td:
    lab=OrbitLab(Path(td)/'stress.db')
    try:
        root=lab.add('Subject','Tri-branch stress',provenance_class='CURRENT_CONVERSATION',provenance='conversation:2026-09-04',identity_key='tri:root',lifecycle='ACTIVE')
        lab.pin('subject',root)
        # Branch 1: observation delay
        p=lab.add('Probe','Sweep observation refresh delay against single/pair success',data={'independent':'observation_refresh_ms'},provenance_class='PRIMARY_ARTIFACT',provenance='library:file_000000009a5c81f58d8cb161857a1fa1',identity_key='tri:delay:probe',lifecycle='ACTIVE')
        lab.pin('probe',p)
        obs=[]
        for ms,single,pair,gain in DELAY:
            o=lab.add('Observation',f'{ms} ms observation',data={'refresh_ms':ms,'single_success':single,'pair_success':pair,'pair_gain':gain},provenance_class='PRIMARY_ARTIFACT',provenance='library:file_000000009a5c81f58d8cb161857a1fa1',identity_key=f'tri:delay:{ms}',lifecycle='ACTIVE',epistemic='OBSERVED')
            lab.relate(o,'OBSERVED_IN',p,provenance_class='DERIVED',provenance='tri_stress')
            obs.append(o)
        inf=lab.add('Inference','Pair benefit collapses between 750 and 1000 ms in this sweep',data={'lower_ms':750,'upper_ms':1000,'scope':'this finite sweep only'},provenance_class='DERIVED',provenance='tri_stress',identity_key='tri:delay:inference',epistemic='PROPOSED')
        for o in obs[-3:]:
            lab.relate(inf,'DERIVED_FROM',o,provenance_class='DERIVED',provenance='tri_stress')
        print('DELAY_ENCODED', len(obs), 'observations')

        # Branch 2: faithful transport as tested relation
        src=lab.add('Artifact','Original state representation',provenance_class='PRIMARY_ARTIFACT',provenance='library:file_000000004be481f59a600270c9337065',identity_key='tri:transport:src')
        dst=lab.add('Artifact','Wrapper z=(x,y,vx,vy)',provenance_class='PRIMARY_ARTIFACT',provenance='library:file_000000004be481f59a600270c9337065',identity_key='tri:transport:dst')
        obligation=lab.add('Obligation','Preserve support target, action offset, and viability decision over tested states',data={'states_tested':100000},provenance_class='PRIMARY_ARTIFACT',provenance='library:file_000000004be481f59a600270c9337065',identity_key='tri:transport:ob')
        verifier=lab.add('Evidence','100000-state transport comparison',data={'max_support_target_error':0.0,'max_action_offset_error':0.0,'viability_decision_mismatches':0,'faithful_transport':True},provenance_class='PRIMARY_ARTIFACT',provenance='library:file_000000004be481f59a600270c9337065',identity_key='tri:transport:evidence',epistemic='OBSERVED')
        # v0.2 can only encode transport as a binary edge and stash the obligation/verifier IDs in untyped JSON.
        rel=lab.relate(src,'TRANSPORTS_TO',dst,data={'obligation_id':obligation,'evidence_id':verifier,'scope':'100000 tested states'},provenance_class='DERIVED',provenance='tri_stress')
        # Now intentionally delete referenced obligation: FK does not protect JSON ref.
        lab.conn.execute('DELETE FROM objects WHERE id=?',(obligation,))
        lab.conn.commit()
        g=lab.graph(src)
        dangling=g['outgoing'][0]['data']['obligation_id']
        still_exists=lab.conn.execute('SELECT 1 FROM objects WHERE id=?',(dangling,)).fetchone() is not None
        print('TRANSPORT_DANGLING_REF', dangling, 'exists=',still_exists)

        # Branch 3: matched counterfactual ACDN experiment
        cand=lab.add('Candidate','Proposed sparse connection G1->G3',provenance_class='LIBRARY_ARTIFACT',provenance='library:file_000000003f2c722f948ad03ae1d125d1',identity_key='tri:acdn:candidate',lifecycle='QUARANTINED')
        off=lab.add('Probe','Connection OFF matched forward pass',data={'reset_state':'R0','candidate':cand,'condition':'off'},provenance_class='DERIVED',provenance='tri_stress',identity_key='tri:acdn:off')
        on=lab.add('Probe','Connection ON matched forward pass',data={'reset_state':'R0','candidate':cand,'condition':'on'},provenance_class='DERIVED',provenance='tri_stress',identity_key='tri:acdn:on')
        # The fact that OFF and ON are a single matched experiment is only encoded in shared strings / JSON.
        pair=lab.add('Inference','Matched comparison says whether candidate link helps',data={'off_probe':off,'on_probe':on,'same_reset_required':True},provenance_class='DERIVED',provenance='tri_stress',identity_key='tri:acdn:pair',epistemic='PROPOSED')
        # Delete one member; pair remains semantically malformed with no graph integrity check.
        lab.conn.execute('DELETE FROM objects WHERE id=?',(off,))
        lab.conn.commit()
        print('ACDN_MATCH_DANGLING', lab.get(pair).data)
    finally:
        lab.close()
