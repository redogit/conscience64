# Library Support Retrieval — Alpha 0.26

Purpose: let Orbit use the Library to find items that may support, challenge, explain, reproduce, qualify, or help test another Library item.

## Human command

`find-support <item, claim, file, or concept>`

The local command consults the exact/static association seed and proposes a bounded widening plan. When running with connected Library access, follow that plan with Library search and source inspection.

## Search order

1. **Identity / declared lineage** — stable file/library ID, exact path/hash/name, explicit source pointers.
2. **Bounded neighborhood discovery** — search terminology, dependencies, methods, contradictions, predecessors/successors, applications, and helper mechanisms.
3. **Qualification** — inspect the candidate source and classify the tested relation.
4. **Bounded return** — keep evidence candidates, methods, contradictions, history, helpers, and unresolved routes separate.

## Non-corruption contract

- lookup != evidence
- retrieval != proof
- related != supports
- resemblance != applicability
- bridge candidate != bridge result
- recovery locator != primary evidence
- historical relevance != current authority
- unresolved pointer != resolved identity

An association classified `SOURCE_OR_EVIDENCE_ARTIFACT` is an evidence **route candidate**. Whether it supports a particular claim depends on source identity, evidence role, scope, method validity, applicability, and the tested relation.

## Privacy

Automatic support search excludes these task-private namespaces:
- `/Homework`
- `/Your job is you move things from a to b.`

Widen only for an explicit task or purpose, and retrieve the minimum relevant material.

## Static seed

The imported MoonShot association map provides 633 declared associations:
- 498 source/evidence routes
- 88 method-context routes
- 47 recovery/audit routes
- 124 exact-resolved association rows
- 77 distinct resolved file IDs

These numbers describe the imported seed, not the full Library and not a completeness target.

## Dynamic behavior

Loose or newly created Library items do not have to be pre-indexed. When no exact route exists, create a search plan from the item's own title/content/provenance, run bounded Library search, inspect the strongest candidate sources, and retain unresolved remainder if support cannot be established.
