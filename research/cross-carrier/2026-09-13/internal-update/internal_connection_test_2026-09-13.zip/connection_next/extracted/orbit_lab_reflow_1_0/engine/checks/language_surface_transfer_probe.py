from __future__ import annotations
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path: sys.path.insert(0,str(ROOT))
import json, tempfile
from human_lab import HumanLab, dispatch
from supporters.surface_guard import inspect_surface

BASE=Path(__file__).resolve().parents[1]

def run():
    fixture=json.loads((BASE/'data/language_workbench_guard_fixture.json').read_text())
    cases={x['id']:x for x in fixture['cases']}
    inferred=cases['derived_interpretation']
    mixed=cases['mixed_sentence']
    # Actual transferred guard should preserve the two useful workbench signals.
    g1=inspect_surface(inferred['text'],intended_role='Observation')
    g2=inspect_surface(mixed['text'],intended_role='Observation')
    kinds1={x['kind'] for x in g1['signals']}; kinds2={x['kind'] for x in g2['signals']}
    with tempfile.TemporaryDirectory() as td:
        h=HumanLab(Path(td)/'human.db')
        try:
            h.start('Does the change help?')
            h.add('saw',cases['observation_before']['text'])
            h.add('saw',cases['observation_after']['text'])
            h.compare('Observed score difference: +3.')
            h.think(inferred['text'])
            warning_output=dispatch(h,['saw',inferred['text']])
            obs=h.lab.scan()['observation']
            comparisons=[x for x in h.lab.library(type='Inference') if x.get('data',{}).get('human_surface')=='Comparison']
            thoughts=[x for x in h.lab.library(type='Inference') if x.get('data',{}).get('human_surface')=='Thought']
            semantics_ok=len(obs)>=3 and len(comparisons)==1 and len(thoughts)==1
        finally: h.close()
    return {
      'passed': semantics_ok and 'INFERENCE_LIKE' in kinds1 and 'MODAL_UNCERTAINTY' in kinds1 and 'COMPARISON_LIKE' in kinds2 and 'Surface check:' in warning_output,
      'workbench_source_sha256':fixture['source_sha256'],
      'fixture_cases':len(fixture['cases']),
      'guard_signals_inference':sorted(kinds1),
      'guard_signals_mixed':sorted(kinds2),
      'human_semantics_preserved':semantics_ok,
      'warning_is_nonblocking':not g1['blocked'],
      'claim_limit':'This is a bounded transfer of surface-warning capability, not evidence of general language understanding or measured human cognitive-load reduction.'
    }

if __name__=='__main__': print(json.dumps(run(),indent=2,sort_keys=True))
