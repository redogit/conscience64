
import tempfile
from pathlib import Path
import unittest
from orbit_lab import OrbitLab

class V11Tests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.lab=OrbitLab(Path(self.tmp.name)/"t.db")
    def tearDown(self): self.lab.close(); self.tmp.cleanup()
    def add(self,t,title,key,**kw):
        return self.lab.add(t,title,provenance_class="TEST",provenance="test",identity_key=key,**kw)
    def frame(self):
        return self.add("ObservationFrame","frame","f",data={"observer":"t","apparatus":"sim","accessible_variables":["y"],"resolution":"1","intervention":"none","boundary":"b"})
    def test_run_identity_one_execution(self):
        run=self.add("RunIdentity","run","run")
        p=self.add("Probe","p","p"); f=self.frame(); params=self.add("Parameters","p","params",data={}); reset=self.add("Artifact","r","r")
        o=self.add("Observation","o","o",epistemic="OBSERVED")
        self.lab.record_execution(run_id=run,probe_id=p,frame_id=f,parameters_id=params,reset_id=reset,observation_ids=[o],status="COMPLETED",provenance_class="TEST",provenance="test")
        with self.assertRaises(ValueError):
            self.lab.record_execution(run_id=run,probe_id=p,frame_id=f,parameters_id=params,reset_id=reset,observation_ids=[o],status="COMPLETED",provenance_class="TEST",provenance="test")
    def test_run_identity_requires_stable_key(self):
        with self.assertRaises(ValueError):
            self.lab.add("RunIdentity","run",provenance_class="TEST",provenance="test")
if __name__=="__main__": unittest.main()
