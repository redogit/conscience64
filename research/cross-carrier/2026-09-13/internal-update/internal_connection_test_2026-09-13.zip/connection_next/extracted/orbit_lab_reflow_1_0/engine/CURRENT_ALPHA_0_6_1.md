# Orbit Lab — Current Alpha 0.6.1

**Checkpoint:** Battery-Hardened Connected Research Candidate

This patch does not add a kernel/schema distinction. It hardens direct-use and repeatability boundaries found by the 2026-09-04 battery.

Verified intent:
- connected research remains quarantined/non-evidentiary;
- human `compare` remains separate from observation and interpretation;
- completed seed loaders are repeatable;
- partial seed state stops explicitly rather than being silently reconstructed;
- supporter modules execute both directly and by module import;
- current selector/kernel/supporter/recovery obligations remain unchanged.
