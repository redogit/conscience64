
from __future__ import annotations
from pathlib import Path
import json, statistics, sys
ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0,str(ROOT))
from retrieval_carrier import TASKS, MANIFEST, narrow, broad, decide, audit_registry

def run():
    comparisons={}
    ratios=[]
    same=[]
    for task_id in TASKS:
        n=narrow(task_id)
        b=broad(task_id)
        eq=(
            n["status"]=="ANSWERABLE"
            and b["status"]=="ANSWERABLE"
            and n["facts"]==b["facts"]
        )
        ratio=b["bytes_loaded"]/n["bytes_loaded"]
        ratios.append(ratio)
        same.append(eq)
        comparisons[task_id]={
            "narrow_status":n["status"],
            "broad_status":b["status"],
            "same_decision_signature":eq,
            "narrow_bytes":n["bytes_loaded"],
            "broad_bytes":b["bytes_loaded"],
            "byte_reduction_ratio":ratio,
            "narrow_sources":n["sources_loaded"],
            "broad_source_count":len(b["sources_loaded"]),
            "provenance_recoverable":bool(n["provenance"]),
        }

    # Attack 1: primary source absent. Adjacent projects may share vocabulary but
    # must not silently stand in for the missing project-specific source.
    missing_primary={}
    for task_id,t in TASKS.items():
        available=[s for s in MANIFEST if s!=t["primary"]]
        r=decide(task_id,available)
        missing_primary[task_id]={
            "status":r["status"],
            "passed":r["status"]=="UNRESOLVED",
            "reason":r.get("reason"),
        }

    # Attack 2: explicit neighboring-project swaps for the two strongest lexical collisions.
    swaps={
        "olu-via-csol": decide("olu-empirical-record",["CSOL_START"]),
        "csol-via-olu": decide("csol-human-representation",["OLU_ADDENDUM"]),
        "moonshot-via-operator-map": decide("moonshot-recovery-scope",["OPERATOR_RECOVERY"]),
        "operator-via-moonshot-atlas": decide("operator-recovery-map",["MOONSHOT_ATLAS"]),
    }
    swap_blocked={k:(v["status"]=="UNRESOLVED") for k,v in swaps.items()}

    # Attack 3: method source cannot answer a project empirical/recovery question simply
    # because the language is similar.
    method_not_evidence=decide("operator-recovery-map",["R3_AGENT"])["status"]=="UNRESOLVED"

    audit=audit_registry()
    total_broad=sum(v["size_bytes"] for v in MANIFEST.values())

    return {
        "passed":(
            audit["passed"]
            and all(same)
            and all(v["passed"] for v in missing_primary.values())
            and all(swap_blocked.values())
            and method_not_evidence
        ),
        "tasks":len(TASKS),
        "sources":len(MANIFEST),
        "broad_corpus_bytes":total_broad,
        "comparisons":comparisons,
        "mean_byte_reduction_ratio":statistics.mean(ratios),
        "median_byte_reduction_ratio":statistics.median(ratios),
        "primary_missing_attacks":missing_primary,
        "cross_project_swap_blocked":swap_blocked,
        "method_source_not_empirical_evidence":method_not_evidence,
        "registry_audit":audit,
        "widen_rule":"primary missing/inadequate -> widen; if widened neighborhood still cannot satisfy source contract -> UNRESOLVED",
        "kernel_schema_additions":0,
        "claim_ceiling":"five-source bounded retrieval corpus; no universal retrieval-optimality claim",
    }

if __name__=="__main__":
    print(json.dumps(run(),indent=2,sort_keys=True))
