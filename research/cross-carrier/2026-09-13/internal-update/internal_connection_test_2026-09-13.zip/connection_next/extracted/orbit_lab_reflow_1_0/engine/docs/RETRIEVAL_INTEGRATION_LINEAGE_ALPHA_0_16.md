# Alpha 0.16 — Selective Retrieval Integration

## Earned distinction

Relevance alone is not enough for faithful retrieval.

One_Level_Up and CSOL intentionally overlap in language about compression,
reconstruction, preservation, and boundedness, but they remain different projects
with different source roles and action-relevant content.

Therefore the active retrieval relation is:

`question -> project identity -> source role -> required facts -> provenance`

rather than merely:

`query -> nearest text`.

## Widening

If the primary source is unavailable or does not satisfy the declared source contract:
1. widen to additional reachable context;
2. rerun the same contract;
3. if the contract still cannot be satisfied, return `UNRESOLVED`.

No adjacent project may silently substitute for the missing source.

## Preserved sources

The full source files remain cold/recoverable. The active retrieval carrier stores
only the task/source relation and source digests.

No universal semantic retrieval or global minimum is claimed.
