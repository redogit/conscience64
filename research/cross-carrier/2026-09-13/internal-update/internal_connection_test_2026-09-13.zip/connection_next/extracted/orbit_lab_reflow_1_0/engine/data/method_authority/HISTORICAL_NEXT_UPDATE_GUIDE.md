# Next Update Guide

## Immediate use

Use `02_REUSABLE_BRIDGE_PRIMITIVE.md` in other Moonshot chats that do not yet share the full context.

Use `OPERATOR_MOONSHOT_CROSS_CHAT_RECOVERY_PROMPT_v2.md` to recover evidence, ideas, experiment data, failures, contradictions, artifacts, and provenance from those chats.

## Integration order for recovered packets

For each recovered chat:

1. preserve the raw packet independently;
2. classify provenance before synthesis;
3. place the current local view into `NOW / WEB / EVIDENCE / HISTORY`;
4. identify obligation(s);
5. identify known/candidate carrier(s);
6. identify candidate bridge(s);
7. preserve compositions and singleton failures;
8. preserve contradictions without forced reconciliation;
9. preserve unclassifiable material as `UNCLASSIFIED_RECOVERED_SIGNAL`;
10. only then compare across chats.

## Cross-chat comparison questions

For each apparently related result ask:

- Is the obligation actually the same?
- Is the carrier the same, substitutable, or merely analogous?
- Does a real bridge preserve the required distinctions?
- Is the bridge supplied or discovered?
- Which distinction fails under equality-ablation?
- Is useful behavior carried by a composition rather than a singleton?
- Does the conversion survive representation/domain change?
- What is the lifecycle cost of maintaining the bridge?
- What evidence could overturn the current organization?

## Priority historical recovery

Recover the prior conversation identified by the user as **Conversation Low Rank Training** using the bridge primitive and cross-chat recovery prompt.

Do not assume the current conversation's interpretation of that old work is correct. Recover its actual experiments, artifacts, failures, and claim boundaries first.

## Recommended first discriminating experiment

Test whether the integrated applicability structure actually improves historical evidence recovery.

Compare:

- **A:** broad/context-heavy recovery;
- **B:** Situation → Obligation → required distinctions → local applicability topology, with failure-triggered scope expansion;
- **B-minus-expansion:** same as B but scope widening disabled.

Measure at minimum:

- correct primary artifact recovered;
- correct experimental verdict;
- failures preserved;
- contradictions recovered;
- unsupported claims;
- relevant records omitted;
- irrelevant records loaded;
- total context/tool cost;
- number of scope expansions;
- time/effort to decision.

If B succeeds where B-minus-expansion fails on cases requiring omitted evidence, that is evidence that the correctability/expansion channel carries a consequential obligation.

## Canonicality boundary

Do not promote a candidate Society prompt, applicability/provenance contract, bridge definition, schema, or recovery procedure merely because it is internally coherent or named canonical.

Activation/canonical status should remain separately governed and verifiable.
