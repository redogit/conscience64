
import tempfile
from pathlib import Path
import unittest
from orbit_lab import OrbitLab
class V28Tests(unittest.TestCase):
    def setUp(self): self.tmp=tempfile.TemporaryDirectory(); self.lab=OrbitLab(Path(self.tmp.name)/"t.db")
    def tearDown(self): self.lab.close(); self.tmp.cleanup()
    def add(self,t,title,key,**kw): return self.lab.add(t,title,provenance_class="TEST",provenance="test",identity_key=key,**kw)
    def test_unknown_cause_preserves_location(self):
        subject=self.add("Probe","confirmation","p")
        location=self.add("Artifact","confirmation harness","h")
        obs=self.add("Observation","process exited 1","o",epistemic="OBSERVED")
        frame=self.add("ObservationFrame","failure frame","f",data={"observer":"test","apparatus":"h","accessible_variables":["exit"],"resolution":"1","intervention":"run","boundary":"test"})
        ep=self.lab.record_failure(subject_entity_id=subject,location_entity_id=location,
            observation_id=obs,frame_id=frame,cause_status="UNKNOWN",provenance_class="TEST",provenance="test")
        self.assertEqual(self.lab.episode(ep)["data"]["cause_status"],"UNKNOWN")
        self.assertEqual(self.lab.episode_role_ids(ep,"location"),[location])
        self.assertEqual(self.lab.episode_role_ids(ep,"cause"),[])
    def test_multicausal_requires_multiple_causes(self):
        subject=self.add("Probe","p","p"); location=self.add("Artifact","h","h")
        obs=self.add("Observation","failed","o",epistemic="OBSERVED")
        frame=self.add("ObservationFrame","failure frame","f",data={"observer":"test","apparatus":"h","accessible_variables":["status"],"resolution":"1","intervention":"run","boundary":"test"})
        c1=self.add("Inference","cause1","c1")
        with self.assertRaises(ValueError):
            self.lab.record_failure(subject_entity_id=subject,location_entity_id=location,
                observation_id=obs,frame_id=frame,cause_status="MULTICAUSAL",cause_entity_ids=[c1],
                provenance_class="TEST",provenance="test")
if __name__=="__main__": unittest.main()
