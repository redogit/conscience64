
import tempfile
from pathlib import Path
import unittest
from orbit_lab import OrbitLab
class V13Tests(unittest.TestCase):
    def setUp(self): self.tmp=tempfile.TemporaryDirectory(); self.lab=OrbitLab(Path(self.tmp.name)/"t.db")
    def tearDown(self): self.lab.close(); self.tmp.cleanup()
    def add(self,t,title,key,**kw): return self.lab.add(t,title,provenance_class="TEST",provenance="test",identity_key=key,**kw)
    def test_pareto_incomparability(self):
        order=self.add("Order","quality/state/latency","ord",data={"rule":"PARETO","metrics":[{"name":"state","direction":"MIN"},{"name":"nll","direction":"MIN","max_allowed":2.4},{"name":"latency","direction":"MIN"}]})
        a=self.add("Candidate","compact","a"); b=self.add("Candidate","gru","b")
        ea=self.add("Evidence","A metrics","ea",epistemic="OBSERVED"); eb=self.add("Evidence","B metrics","eb",epistemic="OBSERVED")
        mids=[]
        for cid,basis,vals,prefix in [(a,ea,{"state":0.4,"nll":2.34,"latency":1.2},"a"),(b,eb,{"state":1.0,"nll":2.27,"latency":0.8},"b")]:
            for k,v in vals.items(): mids.append(self.lab.record_measurement(candidate_id=cid,metric=k,value=v,unit="",basis_entity_id=basis,provenance_class="TEST",provenance="test",identity_key=f"{prefix}:{k}"))
        ep=self.lab.compare_candidates(order_id=order,candidate_ids=[a,b],measurement_episode_ids=mids,provenance_class="TEST",provenance="test")
        d=[x for x in self.lab.episode(ep)["participants"] if x["role"]=="result"][0]
        self.assertEqual(self.lab.get(d["participant_id"]).data["verdict"],"PARETO_SET")
if __name__=="__main__": unittest.main()
