# Orbit Lab Alpha 0.18 candidate

Adds claim-local evidence source-role contracts, forced by the Moonshot philosophy separation.
