
import tempfile
from pathlib import Path
from orbit_lab import OrbitLab

with tempfile.TemporaryDirectory() as td:
    lab=OrbitLab(Path(td)/"stress.db"); passes=[]; breaks=[]
    try:
        a=lab.add("Context","Source",provenance_class="TEST",provenance="stress",identity_key="A")
        b=lab.add("Context","Destination",provenance_class="TEST",provenance="stress",identity_key="B")
        content=lab.register_content(algorithm="sha256",digest="cafebabe",
            provenance_class="PRIMARY_ARTIFACT",provenance="hash")
        inst=lab.create_artifact_instance(content_id=content,title="source instance",
            provenance_class="PRIMARY_ARTIFACT",provenance="source",identity_key="inst")
        occ=lab.record_instance_occurrence(instance_id=inst,context_id=a,locator="/A/data",
            mode="REGISTER",provenance_class="PRIMARY_ARTIFACT",provenance="source",identity_key="occ")
        ob=lab.add("Obligation","preserve content and lineage",provenance_class="TEST",
                   provenance="stress",identity_key="ob")
        ev=lab.add("Evidence","hash verified",provenance_class="TEST",
                   provenance="stress",identity_key="ev",epistemic="OBSERVED")

        copied=lab.custody_transfer(source_context_id=a,destination_context_id=b,
            source_occurrence_id=occ,destination_locator="/B/copy",mode="COPY",
            obligation_ids=[ob],evidence_entity_ids=[ev],reason="copy",
            provenance_class="TEST",provenance="stress")
        moved=lab.custody_transfer(source_context_id=a,destination_context_id=b,
            source_occurrence_id=occ,destination_locator="/B/moved",mode="MOVE",
            obligation_ids=[ob],evidence_entity_ids=[ev],reason="move",
            provenance_class="TEST",provenance="stress")
        if copied["source_instance_id"] != copied["destination_instance_id"] \
           and moved["source_instance_id"] == moved["destination_instance_id"]:
            passes.append("COPY and MOVE are now distinguishable without using byte identity as occurrence identity.")

        # Next pressure: derived artifacts may have several parents, and the relation between
        # those parents is not custody. A generated report can combine two source occurrences,
        # transform content, and still need reconstructible provenance.
        c2=lab.register_content(algorithm="sha256",digest="feedface",
            provenance_class="PRIMARY_ARTIFACT",provenance="hash2")
        inst2=lab.create_artifact_instance(content_id=c2,title="second input",
            provenance_class="PRIMARY_ARTIFACT",provenance="source2",identity_key="inst2")
        occ2=lab.record_instance_occurrence(instance_id=inst2,context_id=a,locator="/A/other",
            mode="REGISTER",provenance_class="PRIMARY_ARTIFACT",provenance="source2",identity_key="occ2")
        breaks.append(
            "Custody lineage now works for one instance through locations, but derivation lineage does not. "
            "A new artifact produced from multiple source occurrences has no typed transformation/provenance Episode "
            "that binds inputs + Method/Execution + output occurrence. Custody cannot stand in for derivation."
        )

        # Another pressure from recovery: association can point at an occurrence without moving it.
        breaks.append(
            "Association/indexing remains structurally different from custody transfer. The kernel still lacks a "
            "typed non-evidentiary Association relation, so a locator relationship is currently forced into generic "
            "relations or caller metadata."
        )

        print("V0.24 INSTANCE / LINEAGE STRESS")
        print("------------------------------")
        print("PASS:"); [print("-",x) for x in passes]
        print("\nNEXT PRESSURES:"); [print(f"{i}. {x}") for i,x in enumerate(breaks,1)]
    finally:
        lab.close()
