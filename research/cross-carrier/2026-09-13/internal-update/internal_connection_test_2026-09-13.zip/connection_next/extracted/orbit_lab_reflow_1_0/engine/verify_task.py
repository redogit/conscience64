
from __future__ import annotations
from pathlib import Path
import argparse, json, time, sys
ROOT=Path(__file__).resolve().parent
if str(ROOT) not in sys.path: sys.path.insert(0,str(ROOT))
import selector
from verification_carrier import PROBES, PROFILES, plan, audit_carrier

CALLABLES={p.name:getattr(selector,p.callable_name) for p in PROBES}

def run_plan(obligations):
    planned=plan(obligations)
    if not planned["passed"]:
        return planned
    results=[]
    resolved=set()
    t0=time.perf_counter()
    for name in planned["probes"]:
        fn=CALLABLES[name]
        t=time.perf_counter()
        r=fn()
        secs=time.perf_counter()-t
        results.append({
            "probe":name,"passed":r.passed,"seconds":secs,
            "resolved":sorted(r.resolves),
        })
        if not r.passed:
            return {
                **planned,"passed":False,"reason":"PROBE_FAILED",
                "results":results,"seconds":time.perf_counter()-t0,
            }
        resolved.update(r.resolves)
    missing=sorted(set(obligations)-resolved)
    return {
        **planned,
        "passed":not missing,
        "unresolved":missing,
        "results":results,
        "seconds":time.perf_counter()-t0,
    }

def main():
    ap=argparse.ArgumentParser()
    g=ap.add_mutually_exclusive_group(required=True)
    g.add_argument("--profile",choices=sorted(PROFILES))
    g.add_argument("--obligation",action="append")
    g.add_argument("--audit-carrier",action="store_true")
    args=ap.parse_args()
    if args.audit_carrier:
        out=audit_carrier()
    else:
        obligations=PROFILES[args.profile] if args.profile else tuple(args.obligation)
        out=run_plan(obligations)
    print(json.dumps(out,indent=2,sort_keys=True))
    raise SystemExit(0 if out.get("passed") else 1)

if __name__=="__main__":
    main()
