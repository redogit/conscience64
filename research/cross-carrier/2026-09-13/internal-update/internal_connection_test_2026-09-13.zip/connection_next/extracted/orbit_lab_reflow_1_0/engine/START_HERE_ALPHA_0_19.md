# Orbit Lab Alpha 0.19 — Current

Alpha 0.19 executes the previously planned X-LS-002 weaker-recoding experiment.

Historical X-LS-001 remains valid for what it tested:
deleting each one of nine named fields from the fixed L1 serializer restored its
assigned constructed collision.

X-LS-002 tested a different relation:

```text
nine named state fields
        ↓ recode
(probe_type, probe_state)
```

Bounded result:
- exact X-LS-001 archived result-summary reproduced byte-for-byte;
- 54 records;
- same serializer partition as nine-field L1;
- 54/54 stipulated route matches;
- 18 semantic atoms;
- 171 unordered pairwise cross-probe compositions;
- 0 new composition aliases;
- serialized state 24,156 -> 2,772 bytes (~8.71x);
- named state fields 9 -> 1.

Therefore the nine named fields are not justified as the weaker sufficient serializer
on this frozen constructed panel.

Validation:
- 179/179 regressions PASS
- 25 selector components / 89 obligations
- language-recoding task profile PASS
- direct S5 whole integration PASS
- strict path successor of Alpha 0.18
- zero new kernel object/Episode types

No real-world route correctness, open-world sufficiency, or global minimality is claimed.
