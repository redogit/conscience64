
import unittest
from retrieval_carrier import TASKS, MANIFEST, narrow, broad, decide, audit_registry
from checks.retrieval_neighborhood_probe import run

class RetrievalNeighborhoodTests(unittest.TestCase):
    def test_registry_audits(self):
        self.assertTrue(audit_registry()["passed"])

    def test_narrow_matches_broad_on_bounded_corpus(self):
        for task_id in TASKS:
            n=narrow(task_id); b=broad(task_id)
            self.assertEqual(n["status"],"ANSWERABLE")
            self.assertEqual(b["status"],"ANSWERABLE")
            self.assertEqual(n["facts"],b["facts"])
            self.assertLess(n["bytes_loaded"],b["bytes_loaded"])

    def test_missing_primary_refuses_substitution(self):
        for task_id,t in TASKS.items():
            available=[s for s in MANIFEST if s!=t["primary"]]
            r=decide(task_id,available)
            self.assertEqual(r["status"],"UNRESOLVED")

    def test_cross_project_collisions_do_not_substitute(self):
        self.assertEqual(decide("olu-empirical-record",["CSOL_START"])["status"],"UNRESOLVED")
        self.assertEqual(decide("csol-human-representation",["OLU_ADDENDUM"])["status"],"UNRESOLVED")

    def test_full_probe(self):
        self.assertTrue(run()["passed"])

if __name__=="__main__":
    unittest.main()
