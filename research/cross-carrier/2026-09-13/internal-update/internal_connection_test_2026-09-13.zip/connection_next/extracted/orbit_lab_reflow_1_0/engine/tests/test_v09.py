
import tempfile
from pathlib import Path
import unittest
from orbit_lab import OrbitLab

class V09Tests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.lab=OrbitLab(Path(self.tmp.name)/"t.db")
    def tearDown(self): self.lab.close(); self.tmp.cleanup()
    def add(self,t,title,key,**kw):
        return self.lab.add(t,title,provenance_class="TEST",provenance="test",identity_key=key,**kw)
    def frame(self,key):
        return self.add("ObservationFrame","frame",key,data={"observer":"t","apparatus":"sim","accessible_variables":["y"],"resolution":"1","intervention":"none","boundary":"b"})
    def test_execution_separates_probe_from_occurrence(self):
        p=self.add("Probe","planned","p"); f=self.frame("f"); o=self.add("Observation","observed","o",epistemic="OBSERVED")
        params=self.add("Parameters","params","params",data={"lr":0.1}); reset=self.add("Artifact","reset","reset"); run=self.add("RunIdentity","run","run"); ex=self.lab.record_execution(run_id=run,probe_id=p,frame_id=f,parameters_id=params,reset_id=reset,observation_ids=[o],status="COMPLETED",provenance_class="TEST",provenance="test")
        self.assertEqual(self.lab.episode(ex)["kind"],"EXECUTION")
    def test_counterfactual_rejects_raw_probe(self):
        c=self.add("Candidate","c","c"); r=self.add("Artifact","reset","r")
        p=self.add("Probe","p","p"); out=self.add("Observation","o","o",epistemic="OBSERVED")
        with self.assertRaises(TypeError):
            self.lab.add_episode("MATCHED_COUNTERFACTUAL","bad",
                participants=[{"role":"candidate","object_id":c},{"role":"reset","object_id":r},
                              {"role":"control","object_id":p},{"role":"treatment","object_id":p},
                              {"role":"result","object_id":out}],
                provenance_class="TEST",provenance="test")
if __name__=="__main__": unittest.main()
