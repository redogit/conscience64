import tempfile, unittest
from pathlib import Path
from orbit_lab import OrbitLab

class HodgeJustificationTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.lab=OrbitLab(Path(self.tmp.name)/'t.db')
    def tearDown(self): self.lab.close(); self.tmp.cleanup()
    def add(self,t,title,key,**kw):
        return self.lab.add(t,title,identity_key=key,provenance_class=kw.pop('provenance_class','TEST'),provenance=kw.pop('provenance','wave2-hodge'),**kw)
    def frame(self):
        return self.add('ObservationFrame','Hodge audit frame','frame',data={'observer':'wave2','apparatus':'theorem-dependency-audit','accessible_variables':['finite_witness','theorem_source','application_hypotheses'],'resolution':'claim-edge','intervention':'none','boundary':'Fermat-fourfold bounded audit'})

    def test_terminal_support_cannot_bypass_declared_theorem_dependencies(self):
        frame=self.frame(); finite=self.add('Evidence','finite character witness verified','finite',epistemic='OBSERVED')
        theorem=self.add('Claim','closure theorem is valid for the declared statement','theorem')
        app=self.add('Claim','the theorem hypotheses hold for this character','application')
        algebraic=self.add('Claim','the target Hodge block is algebraic','algebraic')
        self.lab.relate(algebraic,'REQUIRES',theorem,data={'role':'theorem_validity'},provenance_class='TEST',provenance='wave2-hodge')
        self.lab.relate(algebraic,'REQUIRES',app,data={'role':'application_validity'},provenance_class='TEST',provenance='wave2-hodge')
        with self.assertRaises(ValueError):
            self.lab.assess_claim(algebraic,frame_id=frame,evidence_ids=[finite],verdict='SUPPORTED',scope='m=45 finite witness',provenance_class='TEST',provenance='wave2-hodge')

    def test_terminal_support_succeeds_after_required_claims_are_supported(self):
        frame=self.frame(); finite=self.add('Evidence','finite witness','finite',epistemic='OBSERVED')
        source=self.add('Artifact','primary theorem source inspected','source')
        theorem=self.add('Claim','closure theorem statement/source accepted for this audit','theorem')
        app=self.add('Claim','all declared theorem hypotheses checked for this witness','application')
        algebraic=self.add('Claim','the target Hodge block is algebraic','algebraic')
        self.lab.relate(app,'REQUIRES',theorem,data={'role':'uses_theorem'},provenance_class='TEST',provenance='wave2-hodge')
        self.lab.relate(algebraic,'REQUIRES',app,data={'role':'application_validity'},provenance_class='TEST',provenance='wave2-hodge')
        self.lab.assess_claim(theorem,frame_id=frame,evidence_ids=[source],verdict='SUPPORTED',scope='theorem statement/source audit',provenance_class='TEST',provenance='wave2-hodge')
        self.lab.assess_claim(app,frame_id=frame,evidence_ids=[finite,source],verdict='SUPPORTED',scope='application hypotheses',provenance_class='TEST',provenance='wave2-hodge')
        ep=self.lab.assess_claim(algebraic,frame_id=frame,evidence_ids=[finite,source],verdict='SUPPORTED',scope='bounded theorem-backed conclusion',provenance_class='TEST',provenance='wave2-hodge')
        self.assertEqual(self.lab.episode(ep)['data']['verdict'],'SUPPORTED')
        self.assertTrue(self.lab.alpha_audit()['passed'])

    def test_requires_is_claim_only_and_acyclic(self):
        a=self.add('Claim','A','a'); b=self.add('Claim','B','b'); e=self.add('Evidence','E','e',epistemic='OBSERVED')
        self.lab.relate(a,'REQUIRES',b,data={},provenance_class='TEST',provenance='wave2-hodge')
        with self.assertRaises(ValueError): self.lab.relate(b,'REQUIRES',a,data={},provenance_class='TEST',provenance='wave2-hodge')
        with self.assertRaises(TypeError): self.lab.relate(a,'REQUIRES',e,data={},provenance_class='TEST',provenance='wave2-hodge')

if __name__=='__main__': unittest.main()
