
import tempfile
from pathlib import Path
from orbit_lab import OrbitLab
with tempfile.TemporaryDirectory() as td:
    lab=OrbitLab(Path(td)/"stress.db"); passes=[]; breaks=[]
    try:
        predecessor=lab.add("Context","Predecessor research context",data={"method":"legacy admission rules"},provenance_class="RECOVERY_PACKET",provenance="predecessor",identity_key="ctx:A")
        successor=lab.add("Context","Successor research context",data={"method":"new independent rules"},provenance_class="CURRENT_CONVERSATION",provenance="current",identity_key="ctx:B")
        artifact=lab.add("Candidate","recovered operator",provenance_class="RECOVERY_PACKET",provenance="predecessor",identity_key="op",lifecycle="QUARANTINED")
        old_ev=lab.add("Evidence","predecessor verification",data={"authority":"predecessor"},provenance_class="RECOVERY_PACKET",provenance="predecessor",identity_key="old-e",epistemic="OBSERVED")
        lab.admit_in_context(predecessor,artifact,support_entity_ids=[old_ev],reason="valid under predecessor rules",provenance_class="RECOVERY_PACKET",provenance="predecessor")
        if lab.context_admission_status(successor,artifact)["status"]=="UNREVIEWED": passes.append("Preservation no longer carries admission authority across contexts.")
        try:
            lab.launch_in_context(successor,artifact)
            breaks.append("cross-context activation leaked")
        except PermissionError:
            passes.append("Successor context must independently admit predecessor material.")

        # Now transfer the predecessor's METHOD/AUTHORITY itself as material.
        method=lab.add("Candidate","Predecessor admission/recovery method",data={"claims_to_govern_transfer":True},provenance_class="RECOVERY_PACKET",provenance="predecessor",identity_key="legacy-method",lifecycle="QUARANTINED")
        method_ev=lab.add("Evidence","method worked inside predecessor",provenance_class="RECOVERY_PACKET",provenance="predecessor",identity_key="method-e",epistemic="OBSERVED")
        lab.admit_in_context(predecessor,method,support_entity_ids=[method_ev],reason="predecessor method authority",provenance_class="RECOVERY_PACKET",provenance="predecessor")

        # The kernel can ask successor to admit it, but it has no object defining WHO/WHAT supplies the successor's governing transfer rules.
        # If we use predecessor evidence/method to decide that admission, authority crosses the very boundary being reviewed.
        lab.admit_in_context(successor,method,support_entity_ids=[method_ev],reason="use predecessor evidence to decide whether predecessor method governs transfer",provenance_class="DERIVED",provenance="stress")
        breaks.append("Context-local admission prevents accidental authority leakage, but the kernel still permits a predecessor method/evidence to justify admission of that same predecessor method into the successor. It cannot represent the governing boundary that says destination rules, not source rules, own the transfer. The transfer mechanism itself needs an authority outside the predecessor context.")

        print("V0.15 CONTEXT / ONE-LEVEL-UP STRESS\n----------------------------------")
        print("PASS:"); [print("-",x) for x in passes]
        print("\nBOUNDARY:"); [print(f"{i}. {x}") for i,x in enumerate(breaks,1)]
    finally: lab.close()
