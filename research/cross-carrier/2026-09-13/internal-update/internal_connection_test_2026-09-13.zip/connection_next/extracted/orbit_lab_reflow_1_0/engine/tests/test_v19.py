
import tempfile
from pathlib import Path
import unittest
from orbit_lab import OrbitLab
class V19Tests(unittest.TestCase):
    def setUp(self): self.tmp=tempfile.TemporaryDirectory(); self.lab=OrbitLab(Path(self.tmp.name)/"t.db")
    def tearDown(self): self.lab.close(); self.tmp.cleanup()
    def add(self,t,title,key,**kw): return self.lab.add(t,title,provenance_class="TEST",provenance="test",identity_key=key,**kw)
    def setup_root(self):
        c=self.add("Context","C","c"); owner=self.add("Actor","owner","owner"); broad=self.add("Scope","broad","broad"); narrow=self.add("Scope","narrow","narrow"); self.lab.link_scope(broad,narrow)
        root=self.lab.establish_authority_root(context_id=c,scope_id=broad,operations=["INSPECT","AUTHORIZE"],holder_actor_id=owner,max_delegation_depth=2,provenance_class="USER",provenance="user")
        return c,owner,broad,narrow,root
    def test_delegation_narrows(self):
        c,owner,broad,narrow,root=self.setup_root(); reviewer=self.add("Actor","reviewer","r")
        d=self.lab.delegate_authority(parent_authority_id=root,grantee_id=reviewer,scope_id=narrow,operations=["INSPECT"],max_delegation_depth=0,reason="review",provenance_class="TEST",provenance="test")
        self.assertEqual(self.lab.authority_info(d)["holder_id"],reviewer)
    def test_revocation_and_depth(self):
        c,owner,broad,narrow,root=self.setup_root(); a1=self.add("Actor","a1","a1"); a2=self.add("Actor","a2","a2")
        d1=self.lab.delegate_authority(parent_authority_id=root,grantee_id=a1,scope_id=narrow,operations=["INSPECT"],max_delegation_depth=1,reason="one hop",provenance_class="TEST",provenance="test")
        d2=self.lab.delegate_authority(parent_authority_id=d1,grantee_id=a2,scope_id=narrow,operations=["INSPECT"],max_delegation_depth=0,reason="last",provenance_class="TEST",provenance="test")
        self.lab.revoke_authority(d2,reason="done",provenance_class="TEST",provenance="test")
        with self.assertRaises(PermissionError): self.lab.authority_info(d2)
if __name__=="__main__": unittest.main()
