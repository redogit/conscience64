
from __future__ import annotations
from pathlib import Path
import hashlib,json,subprocess,sys,tempfile
import sympy as sp
ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path: sys.path.insert(0,str(ROOT))
from orbit_lab import OrbitLab

DATA=ROOT/"data"/"gr_qm_tidal"
MANIFEST=json.loads((DATA/"SOURCE_MANIFEST.json").read_text())
EXTERNAL=json.loads((DATA/"ASENBAUM_2017_EMPIRICAL_SOURCE.json").read_text())

def _checked(name):
    p=DATA/name
    meta=MANIFEST["files"][name]
    if hashlib.sha256(p.read_bytes()).hexdigest()!=meta["sha256"]:
        raise ValueError(f"digest mismatch: {name}")
    return p

def run():
    # Reproduce the pre-existing exact second-difference source, while preserving
    # the fact that its archived output is not byte-identical to what the frozen
    # source prints now (a label differs: "series" vs "through h^4").
    src=_checked("finite_difference_curvature_filter.py")
    archived=_checked("finite_difference_curvature_filter_output.txt").read_text()
    rerun=subprocess.run([sys.executable,str(src)],cwd=DATA,text=True,capture_output=True,timeout=30)
    source_executes=rerun.returncode==0
    output_byte_equal=(rerun.stdout==archived)

    # Mathematical lines are checked independently rather than trusting either text label.
    z,h,Phi0,g0,q,K,v,Tzz,T,hbar,m,c,R=sp.symbols(
        "z h Phi0 g0 q K v Tzz T hbar m c R"
    )
    Phi=Phi0+g0*z+sp.Rational(1,2)*q*z**2
    D2=lambda e: sp.simplify(e.subs(z,z+h)-2*e+e.subs(z,z-h))
    d2_affine=sp.simplify(D2(Phi0+g0*z))
    d2_quad=sp.simplify(D2(Phi))

    phi_lab=K*g0*T**2+K*v*Tzz*T**3+sp.Rational(7,12)*K*g0*Tzz*T**4
    vr=hbar*K/m
    tidal=sp.factor(phi_lab.subs(v,v+vr/2)-phi_lab)
    expected=hbar*K**2*Tzz*T**3/(2*m)
    formula_match=sp.simplify(tidal-expected)==0

    constant_invariant=sp.simplify(sp.diff(tidal,Phi0))==0
    linear_invariant=sp.simplify(sp.diff(tidal,g0))==0
    no_gradient=sp.simplify(tidal.subs(Tzz,0))==0

    # Registered weak-field/Fermi-normal convention.
    # Phi''=q, acceleration gradient Tzz=-q, R_0z0z=q/c^2.
    curvature_form=sp.factor(expected.subs(Tzz,-c**2*R))
    curvature_transport=(
        sp.simplify((-q)-(-c**2*(q/c**2)))==0
        and str(curvature_form)=="-K**2*R*T**3*c**2*hbar/(2*m)"
    )

    local_reconstruction=json.loads(
        _checked("GR_QM_TIDAL_PHASE_RECONSTRUCTION_ORBIT_R1.json").read_text()
    )
    local_record_consistent=all([
        local_reconstruction["structural"]["formula_exact_match"],
        local_reconstruction["structural"]["constant_potential_invariant"],
        local_reconstruction["structural"]["uniform_linear_term_invariant_in_tidal_difference"],
        local_reconstruction["structural"]["Tzz_zero_makes_tidal_phase_zero"],
    ])

    with tempfile.TemporaryDirectory() as td:
        lab=OrbitLab(Path(td)/"grqm.db")
        try:
            frame=lab.add(
                "ObservationFrame","Tidal phase structural/empirical bridge",
                data={
                    "observer":"gr-qm-tidal-probe",
                    "apparatus":"exact SymPy reconstruction + external 2017 atom-interferometer source",
                    "accessible_variables":["tidal_phase_formula","affine_ablation","Tzz","R_0z0z","measurement_status"],
                    "resolution":"uniform-gradient Mach-Zehnder relation and cited experimental result",
                    "intervention":"separate structural derivation from empirical measurement",
                    "boundary":"quantum probe of classical curvature; no quantum-gravity or unification claim"
                },
                provenance_class="TEST",provenance="gr-qm-tidal",identity_key="frame"
            )
            structural=lab.add(
                "Evidence","Exact recoil/curvature derivation",
                data={
                    "source_role":"STRUCTURAL_DERIVATION",
                    "evidence_tags":["STRUCTURAL_DERIVATION"],
                    "formula":str(tidal),
                    "curvature_form":str(curvature_form),
                    "sign_convention":"Tzz=-q=-c^2 R_0z0z under registered convention",
                    "archived_output_byte_equal_to_source_rerun":output_byte_equal,
                },
                epistemic="OBSERVED",provenance_class="TEST",provenance="gr-qm-tidal",identity_key="structural"
            )
            empirical=lab.add(
                "Evidence","Asenbaum et al. 2017 tidal atom-interferometer measurement",
                data={
                    "source_role":"EXTERNAL_EMPIRICAL_SOURCE",
                    "evidence_tags":["EMPIRICAL_MEASUREMENT"],
                    "doi":EXTERNAL["doi"],
                    "measured_relation":EXTERNAL["bounded_empirical_result"]["measured_relation"],
                    "formula":EXTERNAL["bounded_empirical_result"]["tidal_formula"]
                },
                epistemic="OBSERVED",provenance_class="EXTERNAL_SOURCE",provenance="doi:"+EXTERNAL["doi"],identity_key="empirical"
            )
            claim=lab.add(
                "Claim","Specified atom-interferometer tidal phase is structurally curvature-sensitive and has an empirical measurement witness",
                data={
                    "required_evidence_tags":["STRUCTURAL_DERIVATION","EMPIRICAL_MEASUREMENT"],
                    "evidence_source_role_contract":{
                        "allowed":["STRUCTURAL_DERIVATION","EXTERNAL_EMPIRICAL_SOURCE"],
                        "require_declared_role":True
                    }
                },
                provenance_class="TEST",provenance="gr-qm-tidal",identity_key="claim"
            )
            structural_only_blocked=False
            try:
                lab.assess_claim(
                    claim,frame_id=frame,evidence_ids=[structural],verdict="SUPPORTED",
                    scope="registered weak-field/Asenbaum relation",
                    provenance_class="TEST",provenance="gr-qm-tidal"
                )
            except ValueError:
                structural_only_blocked=True
            empirical_only_blocked=False
            try:
                lab.assess_claim(
                    claim,frame_id=frame,evidence_ids=[empirical],verdict="SUPPORTED",
                    scope="registered weak-field/Asenbaum relation",
                    provenance_class="TEST",provenance="gr-qm-tidal"
                )
            except ValueError:
                empirical_only_blocked=True

            combined=lab.assess_claim(
                claim,frame_id=frame,evidence_ids=[structural,empirical],verdict="SUPPORTED",
                scope="uniform-gradient tidal term + cited 2017 tidal atom-interferometer measurement",
                provenance_class="TEST",provenance="gr-qm-tidal"
            )
            combined_supported=lab.episode(combined)["data"]["verdict"]=="SUPPORTED"

            # Explicitly keep stronger quantum-gravity claim unresolved: neither cited
            # evidence kind can satisfy NONCLASSICAL_GRAVITY_WITNESS.
            qg=lab.add(
                "Claim","Gravitational degrees of freedom are quantum",
                data={
                    "required_evidence_tags":["NONCLASSICAL_GRAVITY_WITNESS"],
                    "evidence_source_role_contract":{
                        "allowed":["EXTERNAL_EMPIRICAL_SOURCE","STRUCTURAL_DERIVATION"],
                        "require_declared_role":True
                    }
                },
                provenance_class="TEST",provenance="gr-qm-tidal",identity_key="qg"
            )
            quantum_gravity_blocked=False
            try:
                lab.assess_claim(
                    qg,frame_id=frame,evidence_ids=[structural,empirical],verdict="SUPPORTED",
                    scope="same evidence set",
                    provenance_class="TEST",provenance="gr-qm-tidal"
                )
            except ValueError:
                quantum_gravity_blocked=True
            audit=lab.alpha_audit()
        finally:
            lab.close()

    return {
        "passed":all([
            source_executes,
            d2_affine==0,
            sp.simplify(d2_quad-q*h**2)==0,
            formula_match,
            constant_invariant,
            linear_invariant,
            no_gradient,
            curvature_transport,
            local_record_consistent,
            structural_only_blocked,
            empirical_only_blocked,
            combined_supported,
            quantum_gravity_blocked,
            audit["passed"],
            MANIFEST["incoming_start_equals_independent_start"],
        ]),
        "finite_difference_source_executes":source_executes,
        "finite_difference_archived_output_byte_identical":output_byte_equal,
        "finite_difference_output_lineage_note":"mathematical expressions match; one printed label differs, so source/output byte lineage is not claimed exact",
        "D2_affine_zero":d2_affine==0,
        "D2_quadratic_qh2":sp.simplify(d2_quad-q*h**2)==0,
        "recoil_tidal_formula_exact":formula_match,
        "constant_potential_ablation_invariant":constant_invariant,
        "linear_potential_ablation_invariant_for_tidal_difference":linear_invariant,
        "Tzz_zero_kills_tidal_phase":no_gradient,
        "curvature_transport_registered_convention":curvature_transport,
        "curvature_phase_form":str(curvature_form),
        "structural_only_cannot_certify_empirical_bridge":structural_only_blocked,
        "empirical_only_cannot_certify_structural_bridge":empirical_only_blocked,
        "combined_structural_plus_empirical_supported":combined_supported,
        "same_evidence_cannot_certify_quantum_gravity":quantum_gravity_blocked,
        "external_doi":EXTERNAL["doi"],
        "incoming_start_duplicate_verified":MANIFEST["incoming_start_equals_independent_start"],
        "kernel_schema_additions":0,
        "audit_passed":audit["passed"],
        "claim_ceiling":[
            "uniform-gradient recoil tidal term and registered weak-field curvature transport",
            "external empirical witness is Asenbaum et al. 2017; full apparatus is not re-simulated",
            "Riemann/axis sign convention is explicit and may differ under other conventions",
            "quantum matter probing classical curvature is not evidence gravity itself is quantum",
            "no GR/QM unification or ontology claim"
        ]
    }

if __name__=="__main__":
    print(json.dumps(run(),indent=2,sort_keys=True))
