
import tempfile
from pathlib import Path
import unittest
from orbit_lab import OrbitLab

class V05Tests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.lab=OrbitLab(Path(self.tmp.name)/"t.db")
    def tearDown(self):
        self.lab.close(); self.tmp.cleanup()
    def add(self,t,title,key,**kw):
        return self.lab.add(t,title,provenance_class="TEST",provenance="test",identity_key=key,**kw)

    def test_episode_contract(self):
        s=self.add("Artifact","s","s"); t=self.add("Artifact","t","t")
        with self.assertRaises(ValueError):
            self.lab.add_episode("FAITHFUL_TRANSPORT","bad",
                participants=[{"role":"source","object_id":s},{"role":"target","object_id":t}],
                provenance_class="TEST",provenance="test")

    def test_legacy_admission_does_not_bypass_authority(self):
        q=self.add("Candidate","legacy","q",lifecycle="QUARANTINED")
        e=self.add("Evidence","review evidence","e",epistemic="OBSERVED")
        self.lab.admit(q,support_object_ids=[e],reason="bounded review passed",
                       provenance_class="TEST",provenance="test")
        with self.assertRaises(PermissionError):
            self.lab.launch(q)
        self.assertNotEqual(self.lab.get(q).lifecycle,"ACTIVE")

    def test_remainder_unknown_type_required(self):
        with self.assertRaises(ValueError):
            self.add("Remainder","cannot decide","r")
        r=self.add("Remainder","cannot decide","r2",
                   data={"unknown_type":"UNDERDETERMINED"})
        self.assertEqual(self.lab.get(r).data["unknown_type"],"UNDERDETERMINED")

if __name__=="__main__":
    unittest.main()
