# Orbit Lab Alpha 0.20 candidate

Integrates one GR/QM seam relation: structural tidal-phase reconstruction + separate empirical witness, with explicit curvature transport and non-upgrade boundary.
