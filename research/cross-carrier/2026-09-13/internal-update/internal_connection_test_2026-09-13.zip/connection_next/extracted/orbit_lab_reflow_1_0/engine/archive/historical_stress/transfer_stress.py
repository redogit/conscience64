
import tempfile
from pathlib import Path
from orbit_lab import OrbitLab
with tempfile.TemporaryDirectory() as td:
    lab=OrbitLab(Path(td)/"stress.db"); passes=[]; breaks=[]
    try:
        compact=lab.add("Candidate","compact memory",provenance_class="TEST",provenance="stress",identity_key="compact")
        gru=lab.add("Candidate","GRU",provenance_class="TEST",provenance="stress",identity_key="gru")
        basis=lab.add("Evidence","bounded experiment report",provenance_class="PRIMARY_ARTIFACT",provenance="compact-memory-report",identity_key="basis",epistemic="OBSERVED")
        vals={compact:{"state":0.4,"nll":2.34,"latency":1.2,"acquisition_cost":8.0,"reuse_cost":2.0},gru:{"state":1.0,"nll":2.27,"latency":0.8,"acquisition_cost":3.0,"reuse_cost":1.0}}
        mids=[]
        for cid,vv in vals.items():
            for metric,val in vv.items(): mids.append(lab.record_measurement(candidate_id=cid,metric=metric,value=val,unit="relative",basis_entity_id=basis,provenance_class="DERIVED",provenance="stress"))
        order=lab.add("Order","full-cost bounded order",data={"rule":"PARETO","metrics":[{"name":"state","direction":"MIN"},{"name":"nll","direction":"MIN","max_allowed":2.4},{"name":"latency","direction":"MIN"},{"name":"acquisition_cost","direction":"MIN"},{"name":"reuse_cost","direction":"MIN"}]},provenance_class="TEST",provenance="stress",identity_key="order")
        comp=lab.compare_candidates(order_id=order,candidate_ids=[compact,gru],measurement_episode_ids=mids,provenance_class="DERIVED",provenance="stress")
        rid=[p["participant_id"] for p in lab.episode(comp)["participants"] if p["role"]=="result"][0]
        if lab.get(rid).data["verdict"]=="PARETO_SET": passes.append("Evidence-bound metrics and lifecycle-cost terms fit Measurement + Order without a new Cost primitive.")
        branch_a=lab.add("Collection","Branch A",provenance_class="TEST",provenance="stress",identity_key="A")
        branch_b=lab.add("Collection","Branch B",provenance_class="TEST",provenance="stress",identity_key="B")
        legacy=lab.add("Candidate","legacy operator",provenance_class="RECOVERY_PACKET",provenance="predecessor",identity_key="legacy",lifecycle="QUARANTINED")
        review=lab.add("Evidence","A-specific verification",data={"scope":"Branch A"},provenance_class="TEST",provenance="stress",identity_key="review",epistemic="OBSERVED")
        lab.add_to_collection(branch_a,legacy)
        lab.admit(legacy,support_object_ids=[review],reason="verified for Branch A",provenance_class="TEST",provenance="stress")
        lab.add_to_collection(branch_b,legacy)
        if lab.admission_status(legacy)["status"]=="ADMITTED":
            lab.launch(legacy,reason="Branch B uses inherited admission")
            breaks.append("Admission is global to the object. Verification/admission in Branch A leaks into Branch B, so the kernel cannot express context-local authority/applicability or force transfer review.")
        print("V0.14 MEASUREMENT / TRANSFER STRESS\n----------------------------------")
        print("PASS:"); [print("-",x) for x in passes]
        print("\nBREAK:"); [print(f"{i}. {x}") for i,x in enumerate(breaks,1)]
    finally: lab.close()
