
import tempfile
from pathlib import Path
from orbit_lab import OrbitLab

with tempfile.TemporaryDirectory() as td:
    lab=OrbitLab(Path(td)/"stress.db")
    passes=[]; breaks=[]
    try:
        frame=lab.add("ObservationFrame","shared frame",data={"observer":"t","apparatus":"sim","accessible_variables":["score"],"resolution":"1","intervention":"link toggle","boundary":"ACDN panel"},provenance_class="TEST",provenance="stress",identity_key="frame")
        reset=lab.add("Artifact","R0",provenance_class="TEST",provenance="stress",identity_key="reset")
        cand=lab.add("Candidate","G1->G3",provenance_class="TEST",provenance="stress",identity_key="cand")

        # Two actual execution episodes exist now.
        p_off=lab.add("Probe","OFF; lr=0.1",data={"connection":"off","learning_rate":0.1},
                      provenance_class="TEST",provenance="stress",identity_key="poff")
        p_on=lab.add("Probe","ON; lr=0.2",data={"connection":"on","learning_rate":0.2},
                     provenance_class="TEST",provenance="stress",identity_key="pon")
        o_off=lab.add("Observation","off score",data={"score":0.6},provenance_class="TEST",provenance="stress",identity_key="ooff",epistemic="OBSERVED")
        o_on=lab.add("Observation","on score",data={"score":0.7},provenance_class="TEST",provenance="stress",identity_key="oon",epistemic="OBSERVED")
        ex_off=lab.record_execution(probe_id=p_off,frame_id=frame,observation_ids=[o_off],status="COMPLETED",provenance_class="TEST",provenance="stress")
        ex_on=lab.record_execution(probe_id=p_on,frame_id=frame,observation_ids=[o_on],status="COMPLETED",provenance_class="TEST",provenance="stress")
        result=lab.add("Observation","ON - OFF = +0.1",data={"delta":0.1},provenance_class="TEST",provenance="stress",identity_key="result",epistemic="OBSERVED")
        lab.add_episode("MATCHED_COUNTERFACTUAL","confounded but structurally valid",
            participants=[{"role":"candidate","object_id":cand},{"role":"reset","object_id":reset},
                          {"role":"control","episode_id":ex_off},{"role":"treatment","episode_id":ex_on},
                          {"role":"result","object_id":result}],
            provenance_class="TEST",provenance="stress")
        passes.append("Matched comparison now requires actual EXECUTION Episodes, not bare Probes.")
        breaks.append(
            "The two executions changed connection state AND learning_rate, but Parameters are buried "
            "inside Probe.data. MATCHED_COUNTERFACTUAL cannot verify that nuisance parameters were held fixed."
        )

        print("V0.9 EXECUTION STRESS")
        print("---------------------")
        print("PASS:")
        for x in passes: print("-",x)
        print("\nNEXT BREAK:")
        for i,x in enumerate(breaks,1): print(f"{i}. {x}")
    finally:
        lab.close()
