import json, unittest
from pathlib import Path
from supporters.surface_guard import inspect_surface

class TransferFixtureTests(unittest.TestCase):
    def test_guard_preserves_bounded_workbench_inference_signal(self):
        p=Path(__file__).resolve().parents[1]/'data/language_workbench_guard_fixture.json'
        fixture=json.loads(p.read_text())
        case=next(x for x in fixture['cases'] if x['id']=='derived_interpretation')
        self.assertIn('infer_or_conclude',case['functions'])
        self.assertIn('express_possibility',case['functions'])
        guard=inspect_surface(case['text'],intended_role='Observation')
        kinds={x['kind'] for x in guard['signals']}
        self.assertIn('INFERENCE_LIKE',kinds)
        self.assertIn('MODAL_UNCERTAINTY',kinds)
        self.assertTrue(guard['warnings'])

if __name__=='__main__': unittest.main()
