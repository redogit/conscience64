# OPERATOR MOONSHOT — CONTEXT-FREE CONVERSATION RECOVERY PROCEDURE

**Mode:** RECOVERY ONLY  
**Scope:** One conversation at a time  
**Output carrier:** `MOONSHOT_CROSS_CHAT_RECOVERY_PACKET_v2.schema.json`

## Governing order

`RECOVER -> CENTRALIZE FAITHFULLY -> SYNTHESIZE LATER`

Do not continue the research during recovery.

Do not improve the theory, repair caveats, resolve contradictions, optimize architecture, select a preferred interpretation, or import later terminology into earlier work.

The objective is:

> Recover the largest faithful evidence mass while presenting it through the smallest useful human view.

---

## 1. Do not assume the subject

A named subject in the conversation is not automatically the thing the user ultimately wanted.

It may have been:

- a historical frame;
- a teaching device;
- a composition used to communicate a thought process;
- a mapping technique;
- an analogy;
- a temporary experimental substrate;
- an example;
- a candidate representation;
- a tool;
- a route toward another question;
- or the actual target.

Recover which role it had from the chronology and explicit user statements.

Do not infer:

`conversation talks about X -> therefore user's target = X`

Likewise, do not turn a mapping or representation into an agent, mechanism, ontology, or theory unless the evidence explicitly supports that role.

When uncertain, record the role as `UNKNOWN` or `UNCLASSIFIED_RECOVERED_SIGNAL`.

---

## 2. Start with the human recovery view

Read the conversation chronologically from its earliest relevant point.

Recover:

`SITUATION -> WHAT WERE WE TRYING TO DO? -> WHAT HAD TO REMAIN TRUE? -> WHAT HELPED / MIGHT HELP? -> WHAT DID WE TRY? -> WHAT ACTUALLY HAPPENED? -> WHAT CHANGED? -> WHAT REMAINS OPEN?`

If the Situation, purpose, constraints, or target changed materially, create multiple chronological Situations.

Do not flatten the conversation into one stable objective when it did not have one.

---

## 3. Recover purpose separately from subject matter

For every major phase, distinguish:

- `SUBJECT / MATERIAL BEING USED`
- `ROLE IT PLAYED`
- `USER'S PURPOSE AT THAT TIME`
- `EXPERIMENTAL QUESTION`
- `EVENTUAL TARGET, IF KNOWN`

These are not interchangeable.

Safe distinctions include:

- historical frame != research target
- mapping technique != mechanism
- representation != ontology
- experimental substrate != intended application
- assistant interpretation != user intention
- later usefulness != original purpose

If the eventual target was not yet known, say so.

---

## 4. Recover provenance before interpretation

Preserve as much of this lineage as the conversation actually exposes:

`Human Situation -> Human Instruction -> Prompt -> Context Package -> Environment -> Workspace -> Tool / Agent Actions -> Execution -> Artifact -> Evidence -> Claim / Decision`

Never invent missing links.

Use lineage completeness labels:

- `DIRECT`
- `PARTIAL`
- `RECONSTRUCTED`
- `UNKNOWN`

Keep these provenance classes separate:

- `USER_SAID`
- `ASSISTANT_PROPOSED`
- `ACTUALLY_TESTED`
- `ACTUALLY_OBSERVED`
- `EXTERNAL_SOURCE`
- `DERIVED_INFERENCE`
- `MIXED`
- `UNKNOWN`

A later summary may locate earlier evidence, but it may not silently become that evidence.

---

## 5. Recover chronology, not the final story

Proceed from earliest relevant point forward.

Recover:

- changes in purpose;
- changes in scope;
- user corrections;
- assistant proposals;
- hypotheses;
- experiments;
- controls and baselines;
- measurements;
- statistics;
- interventions;
- ablations;
- randomizations;
- comparisons;
- transfers;
- mappings;
- representations;
- algorithms;
- code;
- datasets;
- generated panels;
- artifacts;
- failures;
- null results;
- confounds;
- tool failures;
- interrupted or blocked work;
- counterexamples;
- corrections;
- revised interpretations;
- superseded results;
- provenance gaps;
- unresolved questions.

Do not skip failed or awkward branches merely because later work became cleaner.

---

## 6. Give caveats and repairs special attention

When a later artifact appears intended to address an earlier caveat, recover the entire chain:

`EARLIER CLAIM / ASSUMPTION -> CAVEAT / WEAKNESS / FAILURE -> OBSERVATION THAT EXPOSED IT -> PROPOSED REPAIR -> ACTUAL EXECUTION -> ACTUAL RESULT -> WHAT CHANGED -> WHAT DID NOT CHANGE -> WHAT REMAINED OPEN`

Do not infer that the caveat was solved merely because:

- a new file was created;
- a corrected artifact exists;
- a rerun completed;
- a procedure was written;
- terminology changed;
- a later summary sounds more confident.

A repair is only a repair to the extent supported by execution evidence.

---

## 7. Recover experiments literally

For each identifiable experiment, preserve only what the conversation supports:

```text
EXPERIMENT ID:
HISTORICAL NAME:
SITUATION:
QUESTION:
HYPOTHESIS:
PURPOSE AT THE TIME:
INPUT / SUBSTRATE:
MAPPING / REPRESENTATION, IF ANY:
INTERVENTION:
CONTROL / BASELINE:
OBSERVER / MEASUREMENT:
EXECUTION STATUS:
ACTUAL OBSERVATION:
METRICS / STATISTICS:
FAILURE / NULL / CONFOUND:
INTERPRETATION AT THE TIME:
LATER CORRECTION, IF ANY:
CLAIM BOUNDARY:
ARTIFACTS / HASHES / PATHS:
PROVENANCE GAP:
OPEN QUESTION:
```

Do not reinterpret a mapping experiment as evidence for a larger named system unless that larger claim was explicitly tested.

---

## 8. Preserve failed assumptions

Create a contradiction / revision register.

Recover cases where:

- the user corrected the assistant;
- an assumption was rejected;
- a successful result became a false positive;
- a metric looked sufficient locally but failed globally;
- an implementation was later corrected;
- two artifacts disagree;
- an experiment was rerun under a changed panel;
- a named mechanism was later demoted to a mapping or representation;
- a later artifact narrowed an earlier claim;
- a historical purpose was misunderstood and later clarified;
- a summary conflicts with primary evidence.

Record both sides. Do not average them.

Use:

```text
EARLIER:
LATER:
WHY IT CHANGED:
PRIMARY EVIDENCE:
RESOLUTION STATUS:
WHAT REMAINS UNCERTAIN:
```

---

## 9. Preserve nulls, confounds, and tool failures

Maintain a separate failure/null/confound ledger.

At minimum distinguish:

- `FAILED_RESULT`
- `NULL_RESULT`
- `CONFOUNDED`
- `TOOL_FAILED`
- `BLOCKED`
- `SUPERSEDED`
- `PROVENANCE_GAP`
- `UNKNOWN_CAUSE`

A failed execution is not automatically a failed hypothesis.

A null result is not evidence that the tested distinction can never matter.

A tool failure does not become scientific evidence.

A corrected artifact does not erase the failed predecessor.

---

## 10. Preserve mappings as mappings

When the conversation creates a transformation such as `X -> Y`, first recover it neutrally as a mapping, conversion, encoding, projection, quotient, representation, or reconstruction test according to what was actually done.

Do not automatically assign:

- agency;
- cognition;
- semantics;
- communication;
- biological meaning;
- ontology;
- mechanism identity;
- general necessity.

Recover those stronger meanings only if separately supported.

For a mapping test, preserve:

```text
SOURCE:
TARGET:
DISTINCTIONS EXPOSED:
DISTINCTIONS PRESERVED:
DISTINCTIONS LOST:
DECODER / RECONSTRUCTION:
TEST PANEL:
RESULT:
CLAIM CEILING:
```

---

## 11. Preserve compositions without assuming their meaning

A conversation may compose several structures only to create a useful thought environment.

Do not assume the composition itself was the final subject.

Recover:

```text
COMPONENTS:
WHY THEY WERE COMBINED:
WHAT THE COMPOSITION LET THE USER/ASSISTANT SEE OR TEST:
WHETHER THE COMPOSITION WAS CLAIMED AS REAL ARCHITECTURE:
WHETHER THAT CLAIM WAS TESTED:
```

A composition can be historically important even when none of its named parts are later retained.

---

## 12. Preserve language failure

If an important recovered item does not fit the current schema or vocabulary without distortion, retain it as:

`UNCLASSIFIED_RECOVERED_SIGNAL`

Possible uncertainty types include:

- `UNKNOWN_PURPOSE`
- `UNKNOWN_APPLICABILITY`
- `UNKNOWN_CAUSE`
- `UNKNOWN_CARRIER`
- `UNKNOWN_MAPPING`
- `UNKNOWN_NECESSITY`
- `UNKNOWN_GENERALIZATION`
- `UNKNOWN_PROVENANCE`
- `UNKNOWN_ROLE`

Failure to classify is not evidence of irrelevance.

---

## 13. Keep later terminology from rewriting earlier work

Later terms may be useful indexes, but they must not be attributed backward unless the earlier conversation actually used or earned them.

Preserve when needed:

```text
HISTORICAL WORDING:
CURRENT RECOVERY LABEL:
RELATION BETWEEN THEM:
```

Use the current label only as a retrieval/indexing aid.

Do not rewrite `what happened then` into `what later theory says it meant` during recovery.

---

## 14. Artifact recovery

For every material artifact recover, when available:

- filename;
- artifact type;
- originating phase;
- purpose;
- predecessor/successor relation;
- whether it was generated, uploaded, imported, corrected, fixed, superseded, or patched;
- size;
- hash;
- execution identity;
- associated experiment/result;
- known caveats;
- whether the artifact itself is evidence or merely carries evidence.

If there are several corrected or fixed variants, preserve them separately.

Do not silently choose the newest as the truth.

---

## 15. Use the supplied recovery schema

Produce the machine-facing packet using:

`MOONSHOT_CROSS_CHAT_RECOVERY_PACKET_v2.schema.json`

Do not invent a parallel recovery format.

Validate the final packet against the schema when execution tools permit.

If schema validation fails:

1. preserve the validation failure;
2. correct only the formatting/schema mismatch;
3. validate again;
4. do not alter historical content merely to make validation pass.

---

## 16. Human-facing output

Begin with:

### NOW

- recovered Situation(s);
- purpose at each major phase;
- what had to remain true;
- strongest bounded observations;
- largest unresolved uncertainties.

### WEB

Only recovered connections:

- obligations;
- helpers;
- mappings;
- representations;
- carriers when actually evidenced;
- candidate bridges if historically proposed;
- compositions;
- obstructions;
- contradictions.

Mark proposal versus evidence explicitly.

### EVIDENCE

- chronological experiment ledger;
- actual observations;
- metrics/statistics;
- failure/null/confound ledger;
- artifact index;
- provenance chains/gaps;
- contradiction/revision register;
- claim boundaries.

### HISTORY

Reconstruct the chronological path needed to understand how the conversation changed.

Do not rewrite early stages in later terminology.

---

## 17. Final recovery checks

Before saving the packet, ask:

**PURPOSE** — Did I accidentally turn the subject matter into the user's goal?

**ROLE** — Did I distinguish frame, mapping, representation, example, tool, substrate, and target?

**PROVENANCE** — Did I keep `USER_SAID`, `ASSISTANT_PROPOSED`, `ACTUALLY_TESTED`, `ACTUALLY_OBSERVED`, and `DERIVED_INFERENCE` separate?

**FAILURES** — Did I preserve false positives, nulls, confounds, corrections, tool failures, and superseded artifacts?

**RETROACTIVITY** — Did later terminology rewrite earlier work?

**ARTIFACTS** — Did I mistake artifact creation for successful repair?

**CLAIMS** — Does each recovered claim remain inside the evidence actually available at that historical point?

**UNKNOWN** — Did I preserve unresolved gaps instead of completing the story?

If any check fails, correct the recovery before synthesis.

---

## 18. Stop condition

Recovery ends when the conversation has been faithfully centralized enough that another chat can inspect:

- what the user was doing;
- why each phase existed;
- what was actually tried;
- what actually happened;
- what failed;
- what was corrected;
- what artifacts exist;
- what claims were bounded;
- what remains unresolved;
- and where provenance is incomplete.

Then stop.

`RECOVER FIRST. CENTRALIZE FAITHFULLY. SYNTHESIZE LATER.`

Do not continue the recovered research in the same pass.
