import unittest
import selector

class SelectorMethodAuthorityExecutionRegression(unittest.TestCase):
    def test_method_authority_probe_is_in_full_s4_execution_list(self):
        names={getattr(fn,'__name__','') for fn in selector.PROBES['S4']}
        self.assertIn('probe_s4_method_authority',names)

if __name__=='__main__':
    unittest.main()
