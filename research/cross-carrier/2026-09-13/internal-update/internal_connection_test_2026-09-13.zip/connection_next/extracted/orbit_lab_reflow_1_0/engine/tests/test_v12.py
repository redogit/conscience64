
import tempfile
from pathlib import Path
import unittest
from orbit_lab import OrbitLab

class V12Tests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.lab=OrbitLab(Path(self.tmp.name)/"t.db")
    def tearDown(self): self.lab.close(); self.tmp.cleanup()
    def add(self,t,title,key,**kw):
        return self.lab.add(t,title,provenance_class="TEST",provenance="test",identity_key=key,**kw)
    def frame(self):
        return self.add("ObservationFrame","frame","f",data={"observer":"t","apparatus":"sim","accessible_variables":["y"],"resolution":"1","intervention":"none","boundary":"b"})
    def execution(self,key,frame,params,reset):
        run=self.add("RunIdentity",key+" run",key+"run")
        p=self.add("Probe",key+" probe",key+"p")
        o=self.add("Observation",key+" obs",key+"o",epistemic="OBSERVED")
        return self.lab.record_execution(run_id=run,probe_id=p,frame_id=frame,parameters_id=params,reset_id=reset,
                                         observation_ids=[o],status="COMPLETED",provenance_class="TEST",provenance="test")
    def test_replication_is_relational(self):
        f=self.frame(); params=self.add("Parameters","p","p",data={}); reset=self.add("Artifact","r","r")
        e1=self.execution("one",f,params,reset); e2=self.execution("two",f,params,reset)
        basis=self.add("Evidence","same code/data","basis",epistemic="OBSERVED")
        ra=self.lab.assess_replication(original_execution_id=e1,candidate_execution_id=e2,
                                       grade="REPEATABILITY",basis_ids=[basis],reason="same lineage",
                                       provenance_class="TEST",provenance="test")
        self.assertEqual(self.lab.episode(ra)["data"]["grade"],"REPEATABILITY")
    def test_replication_needs_basis(self):
        f=self.frame(); params=self.add("Parameters","p","p",data={}); reset=self.add("Artifact","r","r")
        e1=self.execution("one",f,params,reset); e2=self.execution("two",f,params,reset)
        with self.assertRaises(ValueError):
            self.lab.assess_replication(original_execution_id=e1,candidate_execution_id=e2,
                                        grade="INDEPENDENT",basis_ids=[],reason="",
                                        provenance_class="TEST",provenance="test")
if __name__=="__main__": unittest.main()
