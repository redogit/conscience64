# Orbit Lab Alpha 0.24 — GDSN Work Helper

Purpose: add a small, task-local GDSN troubleshooting helper so work problems can be organized without turning company-specific assumptions into GDSN facts.

## Human command

`gdsn <short problem description>`

The command is intentionally non-persistent: it triages the problem but does not add the work text to Orbit history. If a sanitized problem should become a Research Card, use `start` explicitly afterward.

## Initial routes

- confirmation / CIC state
- publication / subscription / CIN / RFCIN
- hierarchy
- data quality / validation
- identity / targeting (GTIN, GLN, target market)
- message lineage / correlation
- general unknown layer

## Preserved boundaries

- SYNCHRONISED does not itself mean active, complete, or purchasable.
- REVIEW and REJECTED are not collapsed.
- RFCIN is not treated as a persistent subscription.
- GS1/GDSN standard behavior is separated from employer, trading-partner, retailer, and data-pool implementation rules.
- Credentials, confidential customer records, and raw production payloads are not to be preserved by default.

## Verification

- 200/200 regressions PASS
- 30 selector components / 114 obligations
- gdsn-work task profile PASS
- active task probes: core-sentinel + gdsn-work-helper
- direct S5 whole integration PASS
- zero kernel schema additions

This is a troubleshooting organizer, not a GDSN conformance engine and not a substitute for local production evidence.
