# Orbit Lab — Integration Lineage through Alpha 0.13

Alpha 0.13 extends the consolidated Alpha 0.12 checkpoint with one SHADOW-forced invariant.

## SHADOW transfer

A supported campaign/coverage claim may declare an `evidence_set_contract` over an existing `Collection`:

- exact member count;
- member identity field;
- exact identity set and/or canonical SHA-256;
- optional required evidence tags on every member.

The contract is enforced at SUPPORT time and rechecked by `alpha_audit`, so later link loss or identity substitution invalidates the supported claim.

No Campaign, Shard, Denominator, Timeout, or new Episode type was added. Existing `RunIdentity` preserves same-label/different-run identity, and `UNKNOWN` observations remain epistemically unknown.

## Source boundary

This imports a research-integrity distinction from SHADOW, not SHADOW behavioral conclusions. The root `/SHADOW` source project remains authoritative/recoverable. The duplicate Orbit Lab intake copy can be removed after promotion.
