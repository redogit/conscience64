# Orbit Lab Alpha 0.13 — Current

Alpha 0.13 adds SHADOW-forced evidence-set integrity to the Alpha 0.12 consolidated lab.

Current bounded rule:

`SUPPORTED denominator / coverage claim` requires the linked evidence collection to reconstruct its declared count and identity set.

This does not convert timeout observations into misses and does not collapse two runs that share a human-readable label.

Validation:
- 147/147 regressions PASS
- 19/19 selector components PASS
- zero unresolved selector obligations
- post-support evidence-link loss detected
- wrong scheduled identity detected
- strict path continuity from Alpha 0.12

Known orchestration remainder: the public selector process can linger under this host wrapper after writing a complete passing result.
