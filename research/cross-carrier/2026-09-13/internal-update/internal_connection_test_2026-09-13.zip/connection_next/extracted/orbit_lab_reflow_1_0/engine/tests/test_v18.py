
import tempfile
from pathlib import Path
import unittest
from orbit_lab import OrbitLab
class V18Tests(unittest.TestCase):
    def setUp(self): self.tmp=tempfile.TemporaryDirectory(); self.lab=OrbitLab(Path(self.tmp.name)/"t.db")
    def tearDown(self): self.lab.close(); self.tmp.cleanup()
    def add(self,t,title,key,**kw): return self.lab.add(t,title,provenance_class="TEST",provenance="test",identity_key=key,**kw)
    def test_predecessor_cannot_establish_destination_root(self):
        c=self.add("Context","C","c"); s=self.add("Scope","S","s"); a=self.add("Actor","user","a")
        with self.assertRaises(PermissionError):
            self.lab.establish_authority_root(context_id=c,scope_id=s,operations=["ACTIVATE"],holder_actor_id=a,provenance_class="RECOVERY_PACKET",provenance="old")
    def test_wrong_actor_cannot_issue_root_grant(self):
        c=self.add("Context","C","c"); s=self.add("Scope","S","s"); owner=self.add("Actor","owner","owner"); impostor=self.add("Actor","impostor","imp"); x=self.add("Candidate","X","x"); e=self.add("Evidence","e","e",epistemic="OBSERVED")
        root=self.lab.establish_authority_root(context_id=c,scope_id=s,operations=["INSPECT"],holder_actor_id=owner,provenance_class="USER",provenance="user")
        with self.assertRaises(PermissionError):
            self.lab.grant_authorization(context_id=c,entity_id=x,operation="INSPECT",scope_id=s,issuer_authority_id=root,issuer_actor_id=impostor,principal_id=owner,basis_entity_ids=[e],reason="spoof",provenance_class="TEST",provenance="test")
if __name__=="__main__": unittest.main()
