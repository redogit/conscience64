
import tempfile
from pathlib import Path
import unittest
from orbit_lab import OrbitLab

class OrbitalSecondGenerationRegressions(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.lab=OrbitLab(Path(self.tmp.name)/"t.db")
    def tearDown(self): self.lab.close(); self.tmp.cleanup()
    def add(self,t,title,key,**kw):
        return self.lab.add(t,title,provenance_class="TEST",provenance="test",identity_key=key,**kw)

    def test_authorize_does_not_mint_undeclared_operation(self):
        c=self.add("Context","C","c"); owner=self.add("Actor","owner","owner")
        principal=self.add("Actor","p","p"); s=self.add("Scope","S","s")
        x=self.add("Candidate","X","x"); e=self.add("Evidence","E","e",epistemic="OBSERVED")
        root=self.lab.establish_authority_root(context_id=c,scope_id=s,
            operations=["AUTHORIZE"],holder_actor_id=owner,provenance_class="USER",provenance="user")
        with self.assertRaises(PermissionError):
            self.lab.grant_authorization(context_id=c,entity_id=x,operation="ACTIVATE",scope_id=s,
                issuer_authority_id=root,issuer_actor_id=owner,principal_id=principal,
                basis_entity_ids=[e],reason="escalate",provenance_class="TEST",provenance="test")

    def test_revoked_denial_no_longer_blocks_live_grant(self):
        c=self.add("Context","C","c"); owner=self.add("Actor","owner","owner")
        denier=self.add("Actor","denier","denier"); p=self.add("Actor","p","p")
        s=self.add("Scope","S","s"); x=self.add("Candidate","X","x")
        e=self.add("Evidence","E","e",epistemic="OBSERVED")
        root=self.lab.establish_authority_root(context_id=c,scope_id=s,operations=["INSPECT"],
            holder_actor_id=owner,max_delegation_depth=1,provenance_class="USER",provenance="user")
        self.lab.grant_authorization(context_id=c,entity_id=x,operation="INSPECT",scope_id=s,
            issuer_authority_id=root,issuer_actor_id=owner,principal_id=p,basis_entity_ids=[e],
            reason="allow",provenance_class="TEST",provenance="test")
        d=self.lab.delegate_authority(parent_authority_id=root,grantee_id=denier,scope_id=s,
            operations=["INSPECT"],max_delegation_depth=0,reason="deny helper",
            provenance_class="TEST",provenance="test")
        self.lab.grant_authorization(context_id=c,entity_id=x,operation="INSPECT",scope_id=s,
            issuer_authority_id=d,issuer_actor_id=denier,principal_id=p,basis_entity_ids=[e],
            result="DENIED",reason="deny",provenance_class="TEST",provenance="test")
        self.lab.revoke_authority(d,reason="revoke denier",provenance_class="TEST",provenance="test")
        self.assertTrue(self.lab.check_authorized(context_id=c,actor_id=p,entity_id=x,
            operation="INSPECT",scope_id=s)["authorized"])

    def test_audit_detects_scope_cycle(self):
        a=self.add("Scope","A","a"); b=self.add("Scope","B","b"); self.lab.link_scope(a,b)
        self.lab.conn.execute("INSERT INTO scope_edges(parent_scope_id,child_scope_id,created_at) VALUES(?,?,datetime('now'))",(b,a))
        self.lab.conn.commit()
        audit=self.lab.alpha_audit()
        self.assertFalse(audit["passed"])
        self.assertTrue(any(x["check"]=="scope_acyclic" for x in audit["failures"]))

if __name__=="__main__": unittest.main()
