
from pathlib import Path
import tempfile, json
from orbit_lab import OrbitLab

def main():
    with tempfile.TemporaryDirectory() as td:
        td=Path(td)
        db=td/"alpha.db"
        lab=OrbitLab(db)

        # Basic working state.
        subject=lab.add("Subject","Can the kernel safely learn one new distinction?",
            provenance_class="CURRENT_CONVERSATION",provenance="alpha-gate",identity_key="subject")
        obligation=lab.add("Obligation","Preserve evidence/authority/history separation",
            provenance_class="CURRENT_CONVERSATION",provenance="alpha-gate",identity_key="obligation")
        lab.pin("subject",subject); lab.pin("obligation",obligation)

        ctx=lab.add("Context","Alpha schema context",provenance_class="TEST",
                    provenance="alpha-gate",identity_key="ctx")
        actor=lab.add("Actor","Internal operator",provenance_class="TEST",
                      provenance="alpha-gate",identity_key="actor")
        scope=lab.add("Scope","Schema",provenance_class="TEST",
                      provenance="alpha-gate",identity_key="scope")
        frame=lab.add("ValidityFrame","Alpha frame",data={"conditions":{"kernel":"alpha-0.1","mode":"internal"}},
                      provenance_class="TEST",provenance="alpha-gate",identity_key="frame")
        case_a=lab.add("Artifact","Cost before obligation",provenance_class="TEST",
                       provenance="alpha-gate",identity_key="case-a")
        case_b=lab.add("Artifact","Verified preservation obligation",provenance_class="TEST",
                       provenance="alpha-gate",identity_key="case-b")
        witness=lab.add("Evidence","Controlled cases require different actions",epistemic="OBSERVED",
                        provenance_class="TEST",provenance="alpha-gate",identity_key="witness")

        gap=lab.record_schema_gap(gap_kind="LANGUAGE_COLLISION",current_term="Obligation",
            case_a_id=case_a,case_b_id=case_b,
            required_action_a="explore/measure",required_action_b="verify/preserve",
            missing_distinction="pre-obligation pressure",
            provenance_class="TEST",provenance="alpha-gate")
        proposal=lab.propose_schema_object_type(gap_id=gap,type_name="Pressure",
            definition="Observed discrepancy/cost/tension before a preservation contract is earned.",
            provenance_class="TEST",provenance="alpha-gate",identity_key="proposal")
        promotion=lab.record_promotion(context_id=ctx,entity_id=proposal,scope_id=scope,
            validity_frame_id=frame,witness_entity_id=witness,basis_entity_ids=[witness],
            change_claim="Pressure distinction required",revalidation_rule="rerun controlled collision",
            provenance_class="TEST",provenance="alpha-gate")
        root=lab.establish_authority_root(context_id=ctx,scope_id=scope,
            operations=["SCHEMA_CHANGE"],holder_actor_id=actor,
            provenance_class="USER",provenance="explicit internal-user authority",
            identity_key="root")
        authorization=lab.grant_authorization(context_id=ctx,entity_id=proposal,
            operation="SCHEMA_CHANGE",scope_id=scope,issuer_authority_id=root,
            issuer_actor_id=actor,principal_id=actor,basis_entity_ids=[witness,promotion],
            reason="evidence-bound promoted schema repair",
            provenance_class="TEST",provenance="alpha-gate")
        lab.apply_schema_object_type(proposal_id=proposal,promotion_episode_id=promotion,
            context_id=ctx,actor_id=actor,scope_id=scope,reason="smallest earned repair",
            provenance_class="TEST",provenance="alpha-gate")
        pressure=lab.add("Pressure","Unexpected acquisition burden",
            provenance_class="TEST",provenance="alpha-gate",identity_key="pressure")

        audit_before=lab.alpha_audit()
        exported=lab.export_state(td/"state.json")
        lab.close()

        restored=OrbitLab(td/"restored.db")
        restored.import_state(td/"state.json")
        audit_after=restored.alpha_audit()
        same_digest=(audit_before["state_sha256"]==audit_after["state_sha256"]==exported["sha256"])
        learned_ok=(restored.get(pressure).type=="Pressure")
        restored.close()

        result={
            "gate":"Orbit Lab internal alpha 0.3-supporters",
            "passed": bool(audit_before["passed"] and audit_after["passed"] and same_digest and learned_ok),
            "checks":{
                "governed_schema_change":audit_before["passed"],
                "state_complete_roundtrip":same_digest,
                "learned_schema_survives_roundtrip":learned_ok,
                "post_restore_audit":audit_after["passed"],
            },
            "known_boundary":audit_after["warnings"],
            "state_sha256":exported["sha256"],
        }
        print(json.dumps(result,indent=2,sort_keys=True))
        if not result["passed"]:
            raise SystemExit(1)

if __name__=="__main__":
    main()
