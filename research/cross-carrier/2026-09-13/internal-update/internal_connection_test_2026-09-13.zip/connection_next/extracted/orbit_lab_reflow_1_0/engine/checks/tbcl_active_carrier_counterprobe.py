
from __future__ import annotations
from pathlib import Path
import json, struct, sys
ROOT=Path(__file__).resolve().parents[1]

# Deliberately re-declared here rather than importing the candidate compiler/evaluator.
ROW=struct.Struct("<BBBBIIIHH")
KIND_CLAIM=1
KIND_IDENTITY=3
KIND_OBSERVE=4
EPI_OBSERVED=1
EPI_UNKNOWN=2
EPI_UNRESOLVED=3

def independent_row_decision(row: bytes) -> str:
    kind,epi,_expected,_flags,required,satisfied,_ident,_pref,_sref=ROW.unpack(row)
    if kind==KIND_OBSERVE and epi in (EPI_UNKNOWN,EPI_UNRESOLVED):
        return "KEEP_OPEN"
    if kind==KIND_IDENTITY:
        return "DISTINCT"
    return "ALLOW" if (required & ~satisfied)==0 else "BLOCK"

def run():
    mismatches=[]
    checked=0
    # Seven task-local requirement bits => 128 possible required masks and
    # 128 possible satisfied masks. Exercise the relation exhaustively.
    for required in range(128):
        for satisfied in range(128):
            row=ROW.pack(KIND_CLAIM,EPI_OBSERVED,0,0,required,satisfied,123,0,0)
            got=independent_row_decision(row)
            expected="ALLOW" if (required & ~satisfied)==0 else "BLOCK"
            checked+=1
            if got!=expected and len(mismatches)<20:
                mismatches.append({"required":required,"satisfied":satisfied,"got":got,"expected":expected})

    unknown_checks=[]
    for epi in (EPI_UNKNOWN,EPI_UNRESOLVED):
        row=ROW.pack(KIND_OBSERVE,epi,0,0,0,0,456,0,0)
        unknown_checks.append(independent_row_decision(row)=="KEEP_OPEN")

    identity_row=ROW.pack(KIND_IDENTITY,EPI_OBSERVED,0,0,0,0,789,0,0)
    identity_ok=independent_row_decision(identity_row)=="DISTINCT"

    # Adversarial check: one unsatisfied bit must block, regardless of unrelated satisfied bits.
    one_bit_witnesses=[]
    for bit in range(7):
        req=1<<bit
        sat=((1<<7)-1) ^ req
        row=ROW.pack(KIND_CLAIM,EPI_OBSERVED,0,0,req,sat,bit,0,0)
        one_bit_witnesses.append(independent_row_decision(row)=="BLOCK")

    return {
        "passed":not mismatches and all(unknown_checks) and identity_ok and all(one_bit_witnesses),
        "mask_pairs_checked":checked,
        "mismatches":mismatches,
        "unknown_unresolved_preserved":all(unknown_checks),
        "identity_relation_preserved":identity_ok,
        "single_missing_requirement_witnesses":sum(one_bit_witnesses),
        "verifier_imports_candidate_compiler":False,
        "claim_ceiling":"finite task-local relation verifier; not independent external replication or global minimality proof"
    }

if __name__=="__main__":
    print(json.dumps(run(),indent=2,sort_keys=True))
