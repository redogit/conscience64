from __future__ import annotations
from library_fold import STAGE2, STAGE3, STAGE4, STAGE5


def run():
    by={e["project"]:e for e in STAGE2["entries"]}
    moon=by["MoonShot"]
    shadow=by["SHADOW"]
    pdr=by["Parameter_Differential_Reflow"]
    runtime=by["RuntimeRelationIndex"]
    negative_ok=(moon["classification"]=="NEW_VERIFIED_NEGATIVE_RESULT" and moon["delta"]["verdict"]=="VERIFIED_NO_FOR_FROZEN_BOUNDED_SYSTEM" and moon["delta"]["universal"]=="UNRESOLVED")
    pdr_ok=pdr["classification"]=="NEW_CANDIDATE_IMPORT" and "usefulness unestablished" in pdr["delta"]
    shadow_ok=(shadow["delta"]["committed_coverage"]=="12288/130825" and shadow["delta"]["S0002"]=="INTEGRITY_STOP_UNCOMMITTED" and shadow["delta"]["S0004"]=="PENDING_AT_EXPORT")
    runtime_ok=runtime["classification"]=="NEW_CANDIDATE_HELPER"
    roots_untouched=all(x["physical_source_movement"]=="NONE" for x in (STAGE2,STAGE3,STAGE4))
    privacy_ok="/Homework" in STAGE4["reserved_namespaces"] and "excluded" in STAGE4["boundary"]
    support_ok=STAGE5["stage_result"]["status"]=="READY_FOR_BOUNDED_LIBRARY_SUPPORT_SEARCH" and "related != supports" in STAGE5["retrieval_contract"]
    no_schema=STAGE5["kernel_schema_additions"]==0
    passed=all([negative_ok,pdr_ok,shadow_ok,runtime_ok,roots_untouched,privacy_ok,support_ok,no_schema])
    return {"passed":passed,"observations":{
      "bounded_negative_imported":negative_ok,
      "pdr_remains_candidate":pdr_ok,
      "shadow_denominator_integrity_preserved":shadow_ok,
      "runtime_relation_index_is_helper_not_authority":runtime_ok,
      "source_roots_not_bulk_moved":roots_untouched,
      "minimum_access_stage_preserved":privacy_ok,
      "support_retrieval_stage_ready":support_ok,
      "kernel_schema_additions_zero":no_schema,
    },"kernel_schema_additions":0,"claim_ceiling":[
      "Stages 2-5 integrate consequential deltas and retrieval routes, not every byte in the Library.",
      "Unopened or unclassified material remains reachable and is not declared irrelevant.",
      "No source project is merged into Orbit merely because a relationship was found."
    ]}

if __name__=="__main__":
    import json; print(json.dumps(run(),indent=2,sort_keys=True))
