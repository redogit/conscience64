# Orbit Lab Alpha 0.17 — Current

Alpha 0.17 extends selective research retrieval into an explicit recovery-map → primary-branch evidence route.

Bounded question:

> Does agreement among multiple models establish that their input is externally true?

Recovered answer for the tested 4D branch: **No.** All three models can receive the same coherently wrong input, agree, and remain wrong in all 4,096 tested cases.

Route:

```text
Operator recovery map
  -> 4D primary-artifact branch packet
  -> original archive identity/hash/Library locator
```

The map alone is not evidence enough to SUPPORT the branch claim.

Validation:
- 171/171 regressions PASS
- primary-evidence-route task profile PASS
- retrieval-neighborhood S4 PASS
- operator-primary-route S4 PASS
- S5 whole integration PASS
- strict path successor of Alpha 0.16
- zero new kernel schema types

Alpha 0.17 also repairs an orchestration omission in Alpha 0.16: retrieval-neighborhood was registered but absent from the monolithic S4 execution list. A regression now protects that path.

Known remainder: the monolithic selector process can still linger under the host wrapper. This remains an orchestration boundary, not a scientific result.
