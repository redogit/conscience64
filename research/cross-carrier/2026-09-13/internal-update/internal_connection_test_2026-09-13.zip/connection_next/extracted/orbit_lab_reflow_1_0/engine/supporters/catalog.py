
from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Iterable
import itertools
import json

@dataclass(frozen=True)
class HelperSpec:
    name: str
    capabilities: frozenset[str]
    cost: int
    mechanism: str
    lineage: str
    note: str

HELPERS = [
    HelperSpec("Orbital Adversary",frozenset({"adversarial","composition","mutation"}),3,"generative-adversarial","shared-alpha-runtime","structured adversarial history generation"),
    HelperSpec("Bounded Explorer",frozenset({"bounded","exact","scope","state-space"}),2,"exhaustive-enumeration","shared-alpha-runtime","small exact oracle track"),
    HelperSpec("Metamorphic Tester",frozenset({"metamorphic","representation","invariance"}),1,"metamorphic-testing","shared-alpha-runtime","checks transformations that should preserve consequence"),
    HelperSpec("Replay Custodian",frozenset({"replay","recovery","transport","persistence"}),2,"differential-replay","shared-alpha-runtime","restart/export/import differential"),
    HelperSpec("Mutation Sentinel",frozenset({"mutation","audit","history","integrity"}),2,"mutation-testing","shared-alpha-runtime","injects corruption and measures audit sensitivity"),
    HelperSpec("Observer Ensemble",frozenset({"observer","frame","representation","measurement"}),2,"multi-view-observation","shared-alpha-runtime","tests dependence on observation frame"),
    HelperSpec("Exposure Custodian",frozenset({"exposure","holdout","privacy","authority"}),2,"access-history","shared-alpha-runtime","truth-access and temporal contamination"),
    HelperSpec("Counterfactual Referee",frozenset({"counterfactual","causal","experiment","reset"}),2,"matched-counterfactual","shared-alpha-runtime","matched intervention validity"),
    HelperSpec("Baseline Champion",frozenset({"baseline","comparison","claim-ceiling"}),1,"matched-baseline","shared-alpha-runtime","prevents local benefit from becoming superiority"),
    HelperSpec("Resource Accountant",frozenset({"resource","cost","pareto","minimality"}),1,"multiobjective-accounting","shared-alpha-runtime","keeps incomparable resource tradeoffs visible"),
    HelperSpec("Grounding Oracle",frozenset({"grounding","truth","external-reference"}),2,"external-reference","shared-alpha-runtime","separates internal agreement from external truth"),
    HelperSpec("Regime Scout",frozenset({"regime","threshold","time","nonstationarity"}),2,"boundary-search","shared-alpha-runtime","looks for phase/regime boundaries"),
    HelperSpec("Residual Scout",frozenset({"residual","unknown","anomaly"}),1,"residual-search","shared-alpha-runtime","preserves unexplained remainder"),
    HelperSpec("Counterexample Shrinker",frozenset({"shrink","debug","minimal-witness"}),1,"delta-debugging","shared-alpha-runtime","minimizes reproduced counterexamples"),
    HelperSpec("Wrapper Decomposer",frozenset({"pipeline","component","wrapper","attribution"}),1,"component-differential","shared-alpha-runtime","separates component behavior from wrapper outcome"),
    HelperSpec("Justification Auditor",frozenset({"dependency","theorem-application","provenance","claim-ceiling"}),1,"justification-dag","shared-alpha-runtime","checks declared prerequisite claims before terminal support"),
    HelperSpec("Surface Guard",frozenset({"epistemic-surface","language-warning"}),1,"surface-language-guard","shared-alpha-runtime","warns when human-facing wording may cross observation/comparison/inference boundaries"),
    HelperSpec("Independence Auditor",frozenset({"independence","correlation","role-separation"}),1,"correlation-audit","shared-alpha-runtime","refuses to call correlated reviewers independent"),
]

PROFILES = {
    "faithful_transport": {
        "required":{"transport","grounding","observer","metamorphic","replay","resource"},
        "reason":"transport can preserve output while losing grounding, intervention validity, or cost advantage"
    },
    "adaptive_architecture": {
        "required":{"counterfactual","baseline","resource","replay","regime","residual"},
        "reason":"adaptive mechanisms need matched ablation, baseline comparison, cost, stability and residual tracking"
    },
    "schema_change": {
        "required":{"mutation","bounded","metamorphic","replay","independence"},
        "reason":"language changes need exact small models, corruption pressure, invariance, recovery and correlation disclosure"
    },
    "holdout_experiment": {
        "required":{"exposure","authority","counterfactual","observer","replay","independence"},
        "reason":"clean evaluation depends on custody, history, matched execution and role separation"
    },
    "language_or_representation": {
        "required":{"observer","representation","metamorphic","residual","baseline","minimality"},
        "reason":"representation claims need view changes, weaker recodings, unresolved cases and lifecycle cost"
    },
    "pipeline_or_wrapper": {
        "required":{"pipeline","component","baseline","grounding","replay"},
        "reason":"final success can mask component failure or deterministic shortcutting"
    },
    "theorem_dependent_inference": {
        "required":{"dependency","theorem-application","provenance","claim-ceiling","external-reference"},
        "reason":"theorem-backed conclusions require both a justified theorem dependency and a checked application; finite witnesses alone do not close the claim"
    },
}

def route(required: set[str]) -> dict:
    """Exact minimum-cost supporter cover for the current bounded catalog.

    Tie-breakers prefer fewer helpers, then more distinct mechanisms, then
    deterministic helper-name order. With 16 helpers the complete subset
    space is small enough that a heuristic is unnecessary.
    """
    required=set(required)
    best=None
    for r in range(len(HELPERS)+1):
        for combo in itertools.combinations(HELPERS,r):
            covered=set().union(*(h.capabilities for h in combo)) if combo else set()
            if not required <= covered:
                continue
            cost=sum(h.cost for h in combo)
            mechanisms=len({h.mechanism for h in combo})
            key=(cost,len(combo),-mechanisms,tuple(h.name for h in combo))
            if best is None or key < best[0]:
                best=(key,combo,covered)
        if best is not None and best[0][0] <= r:
            # Every helper costs at least 1, so no larger combination can beat this cost.
            break
    if best is None:
        selected=()
        covered=set()
    else:
        _,selected,covered=best
    uncovered=required-covered
    return {
        "selected":[asdict(x) | {"capabilities":sorted(x.capabilities)} for x in selected],
        "covered":sorted(required-uncovered),
        "uncovered":sorted(uncovered),
        "total_cost":sum(x.cost for x in selected),
        "mechanisms":sorted({x.mechanism for x in selected}),
        "lineages":sorted({x.lineage for x in selected}),
        "selection_method":"exact_minimum_cost_cover",
        "independent":False,
        "independence_note":"All built-in supporters share the alpha runtime lineage; mechanism diversity is not independent replication."
    }

def route_profile(name: str) -> dict:
    p=PROFILES[name]
    result=route(set(p["required"]))
    result["profile"]=name
    result["reason"]=p["reason"]
    return result

def main():
    print(json.dumps({name:route_profile(name) for name in PROFILES},indent=2,sort_keys=True))

if __name__=="__main__":
    main()
