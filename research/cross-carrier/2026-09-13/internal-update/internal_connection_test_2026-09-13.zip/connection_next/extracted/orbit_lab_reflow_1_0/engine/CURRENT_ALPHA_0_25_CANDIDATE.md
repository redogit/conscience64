# Orbit Lab Alpha 0.25 Candidate

Library Fold Stage 1: resolve pre-existing Incoming; preserve source custody; add two bounded candidate imports.
