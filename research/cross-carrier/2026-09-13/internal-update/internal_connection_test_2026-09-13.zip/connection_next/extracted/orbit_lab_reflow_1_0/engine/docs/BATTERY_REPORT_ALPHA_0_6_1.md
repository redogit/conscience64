# Alpha 0.6.1 Battery Report

## Scope
Broad whole-and-parts test of the Alpha 0.6 connected-research candidate.

## Findings reproduced and repaired
1. `seed_research.py` succeeded on a fresh database but failed on a completed repeated invocation. Repair: completed seed is reused idempotently; partial seed remains a hard explicit stop.
2. `supporters/adversary.py` and `supporters/ecology.py` worked through import/selector paths but failed as direct scripts because the project root was absent from `sys.path`. Repair: dual direct/module entry boundary and non-eager package initializer.
3. `connections.py --seed` failed on a completed repeated invocation. Repair: same completed-seed reuse / partial-state hard-stop rule.

No kernel schema type was added.

## Post-repair bounded results
- 117 regression/invariant tests: PASS.
- Selector: 11/11 components PASS; zero unresolved obligations.
- Additional Orbital adversarial pressure: 1,600 trials across seeds 1, 42, 1701, and 90210; zero novel findings; zero harness errors.
- Supporter ecology: two repeated passes, each 16 signals / 11 PASS / 5 retained PRESSURE / 0 FINDING.
- All six supporter profiles: fully covered by exact minimum-cost routing.
- Connected-research state export/import: identical state digest, pre/post audit PASS.
- Tampered state: rejected.
- Human CLI cycle: question, need, limit, try, two observations, derived comparison, interpretation, and unresolved remainder all executed successfully.

## Non-claims
This battery does not establish completeness, independent replication, universal security, universal usability, or absence of undiscovered composition failures. Repeated built-in supporters share runtime lineage.
