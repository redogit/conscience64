# Orbit Lab Alpha 0.9 — Obligation-Preserving Bridge Candidate

## Earned failure

Alpha 0.8 could record a `TRANSFER` as `PRESERVED` even when an Obligation
declared a required evidence kind that the cited evidence did not provide.

Example:

- Obligation requires `SAME_CONTENT_IDENTITY`.
- Evidence provides only `SEMANTIC_SIMILARITY`.
- Alpha 0.8 accepted `PRESERVED` and `alpha_audit()` passed.

## Smallest repair

No `Bridge` object and no new Episode type were added.

Existing structure is sufficient:

```text
Source Context
    ↓
TRANSFER / CUSTODY_TRANSFER
    ↓
Destination Context
with:
    Obligation
    Evidence
    Result
```

An `Obligation` may declare `required_evidence_tags`. A `PRESERVED` result is
allowed only when the transfer evidence satisfies those declared qualifications.

Insufficient evidence can remain `UNRESOLVED`; it is not forced into failure.

The audit rechecks historical `PRESERVED` transfers and detects qualification drift
or persistence corruption.

## Boundary retained

`PRESERVED transfer != destination authorization`.

Transfer also does not automatically establish current applicability. Applicability
assessment remains a separate relation.

## Source pressure

Recovered Society / Recovery / Bridge material proposes:

> Bridge = obligation-preserving conversion between arrangements.

Alpha 0.9 adopts only the experimentally forced part: transfer preservation must be
checked against the obligation's own evidence requirements. It does not promote
`Bridge` to a universal primitive.
