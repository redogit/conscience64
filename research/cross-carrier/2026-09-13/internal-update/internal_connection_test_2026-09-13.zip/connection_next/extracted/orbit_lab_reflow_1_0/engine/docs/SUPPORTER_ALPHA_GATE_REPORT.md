# Orbit Lab internal alpha 0.3 supporter gate

```text
{
  "checks": {
    "alpha_state_gate": true,
    "full_regression_suite": true,
    "orbital_harness_errors": 0,
    "orbital_novel_findings": 0,
    "orbital_trials": 1000,
    "router_profiles": 6,
    "router_profiles_fully_covered": true,
    "supporter_findings": 0,
    "supporter_passes": 11,
    "supporter_pressures_retained": 5,
    "supporter_signals": 16
  },
  "gate": "Orbit Lab internal alpha 0.3-supporter-ecology",
  "known_boundaries": [
    "Built-in supporters are role-separated mechanisms, not independent replication.",
    "Actor authentication remains an embedding-runtime trust boundary.",
    "Supporter pressures are not automatically promoted into kernel structure.",
    "No finite GAN/supporter/test run establishes completeness."
  ],
  "passed": true,
  "retained_pressures": [
    {
      "consequence": "Keep a Pareto set until an explicit minimality order or obligation prices the tradeoff.",
      "detail": "Multiple resource allocations remain Pareto-incomparable; a single scalar 'efficient' score would invent a preference.",
      "mode": "Pareto accounting",
      "signature": "RESOURCE:NO_UNIVERSAL_MINIMUM",
      "source_case": "Musilanguage microchecks found channel-count \u2194 precision/noise \u2194 decoder-computation tradeoffs.",
      "status": "PRESSURE",
      "supporter": "Resource Accountant"
    },
    {
      "consequence": "Never promote wrapper success into a claim about the learned component; preserve component-local outcomes.",
      "detail": "Final wrapper accuracy is perfect while the learned component is imperfect because a deterministic path covers the current task surface.",
      "mode": "component differential",
      "signature": "PIPELINE:WRAPPER_SUCCESS_MASKS_COMPONENT_ERROR",
      "source_case": "Recovered AI-math/spaCy hybrid: 38/39 test classifier vs 39/39 hybrid exact answers.",
      "status": "PRESSURE",
      "supporter": "Wrapper Decomposer"
    },
    {
      "consequence": "Preserve both claims: component benefit is real; architecture superiority is not earned.",
      "detail": "The intervention helps relative to its own ablation but remains worse than the stronger matched baseline.",
      "mode": "matched comparator",
      "signature": "BASELINE:LOCAL_BENEFIT_NOT_OVERALL_WIN",
      "source_case": "Compact associative hybrid: memory helped its 30-wide hybrid, yet the 36-wide GRU remained better.",
      "status": "PRESSURE",
      "supporter": "Baseline Champion"
    },
    {
      "consequence": "Consensus/redundancy must not be promoted into grounding; trusted input evidence is a separate obligation.",
      "detail": "Perfect internal agreement can reproduce a coherently wrong externally supplied state.",
      "mode": "external-reference separation",
      "signature": "GROUNDING:CONSENSUS_CANNOT_CERTIFY_INPUT_TRUTH",
      "source_case": "4D identity experiment: all 4096 coherent wrong-input cases were internally accepted.",
      "status": "PRESSURE",
      "supporter": "Grounding Oracle"
    },
    {
      "consequence": "Prefer regime/boundary maps over assigning one global success status to the organization.",
      "detail": "The same organization moves from near-total success to near-total failure as observation delay crosses a regime boundary.",
      "mode": "boundary search",
      "signature": "REGIME:GLOBAL_STATUS_HIDES_THRESHOLD",
      "source_case": "Existence-space observation refresh experiment: short-refresh pair succeeds; ~1000 ms pair collapses.",
      "status": "PRESSURE",
      "supporter": "Regime Scout"
    }
  ]
}

```
