
from __future__ import annotations
from dataclasses import dataclass, asdict
from pathlib import Path
import subprocess, sys, json, tempfile, time

from supporter_router import route_profile
from supporter_ecology import SupporterEcology
from orbital_gans import OrbitalGAN

BASE = Path(__file__).resolve().parent

# Frozen selector preorder recovered from prior research:
# S0 no active choice
# S1 fixed cycle
# S2 random
# S3 one-step ambiguity
# S4 bounded distinguishing search
# S5 stronger planning / soak
SELECTOR_PREORDER = ("S0","S1","S2","S3","S4","S5")

@dataclass(frozen=True)
class Component:
    name: str
    kind: str
    obligations: frozenset[str]
    profile: str | None = None
    active: bool = True
    note: str = ""

COMPONENTS = [
    Component("orbit_lab.py","kernel",frozenset({
        "importable","regression","state","authority","schema","history","scope",
        "transport","lineage","epistemic","current"
    }),"schema_change"),
    Component("orbital_gans.py","adversarial-supporter",frozenset({
        "importable","deterministic-seed","composition","novelty-archive","no-harness-errors"
    }),None),
    Component("supporter_ecology.py","supporter-ecology",frozenset({
        "importable","mechanism-diversity","no-findings","retain-pressures"
    }),None),
    Component("supporter_router.py","selector-router",frozenset({
        "importable","coverage","cost-aware","mechanism-diversity","no-false-independence"
    }),None),
    Component("seed_research.py","active-loader",frozenset({
        "importable","loads","preserves-historical-status"
    }),None),
    Component("alpha_gate.py","gate",frozenset({
        "state-roundtrip","tamper-reject","audit"
    }),None),
    Component("supporter_alpha_gate.py","whole-gate",frozenset({
        "whole","parts","orbital","supporters","router"
    }),None),
    Component("historical_stress_audit.py","historical-auditor",frozenset({
        "history","classifies-stale","no-unexplained-failure"
    }),None),
]

MANDATORY_TESTS = {
    "orbit_lab.py":[
        "test_orbit_lab.py","test_episode.py",
        "test_v04.py","test_v05.py","test_v06.py","test_v07.py","test_v08.py","test_v09.py",
        "test_v10.py","test_v11.py","test_v12.py","test_v13.py","test_v14.py","test_v15.py",
        "test_v16.py","test_v17.py","test_v18.py","test_v19.py","test_v20.py","test_v21.py",
        "test_v22.py","test_v23.py","test_v24.py","test_v25.py","test_v26.py","test_v27.py",
        "test_v28.py","test_v29.py","test_v30.py","test_alpha_0_1.py",
        "test_counterfactual_execution.py","test_supporter_findings.py",
        "test_orbital_findings.py","test_orbital_generation2.py","test_orbital_generation3.py",
    ],
    "orbital_gans.py":["test_orbital_gans.py"],
    "supporter_ecology.py":["test_supporter_ecology.py","test_supporter_findings.py"],
    "supporter_router.py":["test_supporter_router.py"],
}

def run_cmd(args, timeout=60):
    started=time.time()
    p=subprocess.run(args,cwd=BASE,text=True,capture_output=True,timeout=timeout)
    return {
        "cmd":" ".join(args),
        "rc":p.returncode,
        "seconds":round(time.time()-started,3),
        "stdout_tail":p.stdout[-2500:],
        "stderr_tail":p.stderr[-1800:],
    }

def test_files(files):
    if not files:
        return {"rc":0,"files":[],"detail":"no dedicated test files"}
    mods=[Path(f).stem for f in files]
    result=run_cmd([sys.executable,"-m","unittest","-v",*mods],timeout=120)
    result["files"]=files
    return result

def s0(component: Component):
    """No active choice: compile/import plus dedicated regressions."""
    compile_result=run_cmd([sys.executable,"-m","py_compile",component.name],timeout=20)
    tests=test_files(MANDATORY_TESTS.get(component.name,[]))
    passed=compile_result["rc"]==0 and tests["rc"]==0
    return {
        "selector":"S0",
        "passed":passed,
        "resolved":set(["importable"] if compile_result["rc"]==0 else []) |
                   (set(component.obligations) if tests["rc"]==0 and component.name=="orbit_lab.py" else set()),
        "compile":compile_result,
        "tests":tests,
    }

def s1(component: Component):
    """Fixed cycle: component's own normal executable path."""
    mapping={
        "seed_research.py":[sys.executable,"seed_research.py"],
        "alpha_gate.py":[sys.executable,"alpha_gate.py"],
        "supporter_alpha_gate.py":[sys.executable,"supporter_alpha_gate.py"],
        "historical_stress_audit.py":[sys.executable,"historical_stress_audit.py"],
        "supporter_router.py":[sys.executable,"supporter_router.py"],
        "supporter_ecology.py":[sys.executable,"supporter_ecology.py"],
    }
    if component.name not in mapping:
        return {"selector":"S1","passed":True,"resolved":set(),"skipped":True,
                "reason":"no distinct fixed-cycle executable beyond S0"}
    r=run_cmd(mapping[component.name],timeout=180)
    return {"selector":"S1","passed":r["rc"]==0,"resolved":set(component.obligations) if r["rc"]==0 else set(),"run":r}

def s2(component: Component):
    """Random selector: bounded seeded adversarial sampling only where applicable."""
    if component.name not in {"orbit_lab.py","orbital_gans.py","supporter_alpha_gate.py"}:
        return {"selector":"S2","passed":True,"resolved":set(),"skipped":True,
                "reason":"randomized adversarial sampling not applicable"}
    report=OrbitalGAN(seed=1701).run(rounds=96)
    passed=report["novel_findings"]==0 and not report["harness_errors"]
    return {
        "selector":"S2","passed":passed,
        "resolved":{"composition","no-harness-errors","deterministic-seed"} if passed else set(),
        "report":{
            "trials":report["trials"],
            "novel_findings":report["novel_findings"],
            "harness_errors":len(report["harness_errors"]),
            "signatures":[x["signature"] for x in report["findings"]],
        }
    }

def s3(component: Component, unresolved: set[str]):
    """One-step ambiguity: invoke diverse helpers only for unresolved/relevant obligations."""
    if not unresolved and component.name not in {"supporter_ecology.py","supporter_router.py"}:
        return {"selector":"S3","passed":True,"resolved":set(),"skipped":True,
                "reason":"no unresolved ambiguity after weaker selectors"}
    ecology=SupporterEcology().run()
    profile=None
    if component.profile:
        profile=route_profile(component.profile)
    passed=ecology["findings"]==0 and (profile is None or not profile["uncovered"])
    resolved=set()
    if passed:
        resolved |= {"mechanism-diversity","no-findings","retain-pressures","coverage","cost-aware","no-false-independence"}
        if profile:
            resolved |= set(profile["covered"])
    return {
        "selector":"S3","passed":passed,"resolved":resolved,
        "ecology":{
            "signals":len(ecology["signals"]),
            "findings":ecology["findings"],
            "pressures":ecology["pressures"],
            "finding_signatures":[x["signature"] for x in ecology["signals"] if x["status"]=="FINDING"],
        },
        "profile":None if profile is None else {
            "name":profile["profile"],"uncovered":profile["uncovered"],
            "mechanisms":profile["mechanisms"],"total_cost":profile["total_cost"],
            "independent":profile["independent"],
        }
    }

def s4(component: Component, unresolved: set[str]):
    """Bounded distinguishing search: exact small-state supporter when ambiguity remains."""
    relevant = component.name in {"orbit_lab.py","supporter_ecology.py","supporter_alpha_gate.py"} or bool(
        unresolved & {"scope","authority","state","schema","composition"}
    )
    if not relevant:
        return {"selector":"S4","passed":True,"resolved":set(),"skipped":True,
                "reason":"bounded exact search not relevant to unresolved obligations"}
    eco=SupporterEcology()
    signal=eco.bounded_scope_explorer()
    meta=eco.metamorphic_navigation_supporter()
    passed=signal.status!="FINDING" and meta.status!="FINDING"
    resolved={"scope","bounded","metamorphic"} if passed else set()
    return {
        "selector":"S4","passed":passed,"resolved":resolved,
        "signals":[asdict_safe(signal),asdict_safe(meta)],
    }

def asdict_safe(x):
    return {
        "supporter":x.supporter,"mode":x.mode,"status":x.status,
        "signature":x.signature,"detail":x.detail,"consequence":x.consequence
    }

def s5(component: Component, unresolved: set[str]):
    """Stronger planning/soak only when weaker levels leave a release/whole obligation unresolved."""
    must_soak = component.name=="supporter_alpha_gate.py" or bool(unresolved & {
        "whole","parts","composition","state","authority","schema","history"
    })
    if not must_soak:
        return {"selector":"S5","passed":True,"resolved":set(),"skipped":True,
                "reason":"weaker selectors satisfied preregistered obligations"}
    if component.name=="supporter_alpha_gate.py":
        r=run_cmd([sys.executable,"supporter_alpha_gate.py"],timeout=240)
        return {"selector":"S5","passed":r["rc"]==0,
                "resolved":set(component.obligations) if r["rc"]==0 else set(),
                "run":r}
    report=OrbitalGAN(seed=20260904).run(rounds=500)
    passed=report["novel_findings"]==0 and not report["harness_errors"]
    return {
        "selector":"S5","passed":passed,
        "resolved":{"composition","authority","schema","state","history"} if passed else set(),
        "report":{
            "trials":report["trials"],"novel_findings":report["novel_findings"],
            "harness_errors":len(report["harness_errors"])
        }
    }

def evaluate_component(component: Component):
    required=set(component.obligations)
    resolved=set()
    trace=[]
    escalations=[]

    r0=s0(component); trace.append(normalize(r0)); resolved|=r0["resolved"]
    if not r0["passed"]:
        return finish(component,required,resolved,trace,escalations)

    unresolved=required-resolved
    r1=s1(component); trace.append(normalize(r1)); resolved|=r1["resolved"]
    unresolved=required-resolved

    # S2 is used only if stochastic/composition obligations remain or component is the adversary.
    if unresolved & {"composition","deterministic-seed","no-harness-errors"} or component.name=="orbital_gans.py":
        escalations.append({"from":"S1","to":"S2","because":sorted(unresolved)})
        r2=s2(component); trace.append(normalize(r2)); resolved|=r2["resolved"]
    else:
        trace.append(normalize({"selector":"S2","passed":True,"resolved":set(),"skipped":True,
                                "reason":"no stochastic/composition obligation unresolved"}))
    unresolved=required-resolved

    if unresolved:
        escalations.append({"from":"S2","to":"S3","because":sorted(unresolved)})
        r3=s3(component,unresolved); trace.append(normalize(r3)); resolved|=r3["resolved"]
    else:
        trace.append(normalize({"selector":"S3","passed":True,"resolved":set(),"skipped":True,
                                "reason":"weaker selectors resolved obligations"}))
    unresolved=required-resolved

    if unresolved & {"scope","authority","state","schema","composition","bounded","metamorphic"}:
        escalations.append({"from":"S3","to":"S4","because":sorted(unresolved)})
        r4=s4(component,unresolved); trace.append(normalize(r4)); resolved|=r4["resolved"]
    else:
        trace.append(normalize({"selector":"S4","passed":True,"resolved":set(),"skipped":True,
                                "reason":"no bounded-distinguishing obligation unresolved"}))
    unresolved=required-resolved

    if unresolved or component.name=="supporter_alpha_gate.py":
        escalations.append({"from":"S4","to":"S5","because":sorted(unresolved) or ["whole-release-gate"]})
        r5=s5(component,unresolved); trace.append(normalize(r5)); resolved|=r5["resolved"]
    else:
        trace.append(normalize({"selector":"S5","passed":True,"resolved":set(),"skipped":True,
                                "reason":"weaker selectors resolved obligations"}))

    return finish(component,required,resolved,trace,escalations)

def normalize(x):
    y=dict(x)
    y["resolved"]=sorted(y.get("resolved",set()))
    return y

def finish(component,required,resolved,trace,escalations):
    unresolved=required-resolved
    passed=not unresolved and all(x.get("passed",False) for x in trace if not x.get("skipped"))
    return {
        "component":asdict(component) | {"obligations":sorted(component.obligations)},
        "passed":passed,
        "resolved":sorted(resolved & required),
        "unresolved":sorted(unresolved),
        "selector_trace":trace,
        "escalations":escalations,
    }

def main():
    results=[evaluate_component(c) for c in COMPONENTS if c.active]
    out={
        "selector_preorder":SELECTOR_PREORDER,
        "policy":"Use the weakest applicable selector; escalate only when a preregistered obligation remains unresolved.",
        "components":len(results),
        "passed_components":sum(r["passed"] for r in results),
        "failed_components":[r["component"]["name"] for r in results if not r["passed"]],
        "results":results,
    }
    print(json.dumps(out,indent=2,sort_keys=True))
    if out["failed_components"]:
        raise SystemExit(1)

if __name__=="__main__":
    main()
