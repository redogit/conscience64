
from __future__ import annotations
from pathlib import Path
import hashlib, json, re, tempfile, sys
ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0,str(ROOT))
from orbit_lab import OrbitLab

DATA=ROOT/"data"/"operator_primary_route"
MANIFEST=json.loads((DATA/"ROUTE_MANIFEST.json").read_text())

def _read_checked(entry):
    p=DATA/entry["file"]
    raw=p.read_bytes()
    got=hashlib.sha256(raw).hexdigest()
    if got!=entry["sha256"]:
        raise ValueError(f"source digest mismatch: {p.name}")
    return raw.decode("utf-8")

def run():
    mapping=_read_checked(MANIFEST["operator_recovery_map"])
    packet=_read_checked(MANIFEST["four_d_branch_packet"])

    # Hop 1: recovery map must identify the correct branch and its evidence status.
    mapping_lower=mapping.lower()
    map_points_to_4d=all([
        "4d codec / inversion / observer" in mapping_lower,
        "v1.0" in mapping_lower,
        "primary-artifact level" in mapping_lower,
        "agreement among models/observers is not external truth" in mapping_lower,
    ])

    # Hop 2: branch packet must carry the actual bounded witness and primary-artifact status.
    packet_primary=all([
        "PRIMARY + rerun comparison" in packet,
        "all models given the same wrong input can agree and be wrong" in packet,
        "PRIMARY_ARTIFACT_BRANCH_RECOVERED_WITH_MIXED_RERUN_COVERAGE" in packet,
    ])
    wrong_4096=bool(re.search(
        r"All three could agree on a coherently wrong input and remain wrong in all 4,096 tested cases",
        packet, re.I
    ))
    archive_identity=(
        MANIFEST["primary_archive_locator"]["declared_sha256"] in packet
        and "141,477,592 bytes" in packet
    )

    # Check role separation using Orbit Lab's existing evidence qualification.
    with tempfile.TemporaryDirectory() as td:
        lab=OrbitLab(Path(td)/"operator-route.db")
        try:
            frame=lab.add(
                "ObservationFrame","Operator Moonshot two-hop retrieval",
                data={
                    "observer":"operator-primary-route-probe",
                    "apparatus":"recovery-map -> branch-packet traversal",
                    "accessible_variables":["source_role","source_hash","bounded_result"],
                    "resolution":"one recovered branch claim",
                    "intervention":"withhold primary branch packet, then restore it",
                    "boundary":"recovered finite software evidence; not universal ensemble theory",
                },
                provenance_class="TEST",provenance="operator-route",identity_key="frame"
            )
            locator=lab.add(
                "Artifact","Operator recovery map locator",
                data={
                    "evidence_tags":["RECOVERY_MAP_LOCATOR"],
                    "sha256":MANIFEST["operator_recovery_map"]["sha256"],
                },
                provenance_class="TEST",provenance="operator-route",identity_key="locator"
            )
            primary=lab.add(
                "Evidence","4D consensus failure branch packet",
                data={
                    "evidence_tags":["PRIMARY_BRANCH_EVIDENCE"],
                    "sha256":MANIFEST["four_d_branch_packet"]["sha256"],
                    "archive_sha256":MANIFEST["primary_archive_locator"]["declared_sha256"],
                },
                epistemic="OBSERVED",
                provenance_class="TEST",provenance="operator-route",identity_key="primary"
            )
            claim=lab.add(
                "Claim","Model agreement does not establish external input truth in the bounded wrong-input test",
                data={"required_evidence_tags":["PRIMARY_BRANCH_EVIDENCE"]},
                provenance_class="TEST",provenance="operator-route",identity_key="claim"
            )
            locator_only_blocked=False
            try:
                lab.assess_claim(
                    claim,frame_id=frame,evidence_ids=[locator],verdict="SUPPORTED",
                    scope="bounded recovered 4D wrong-input test",
                    provenance_class="TEST",provenance="operator-route"
                )
            except ValueError:
                locator_only_blocked=True

            assessment=lab.assess_claim(
                claim,frame_id=frame,evidence_ids=[primary],verdict="SUPPORTED",
                scope="three recovered model runs; common wrong input; 4,096 tested cases",
                provenance_class="TEST",provenance="operator-route"
            )
            supported_verdict=lab.episode(assessment)["data"]["verdict"]
            audit=lab.alpha_audit()
        finally:
            lab.close()

    # Byte-equal independent copies mean Incoming copies are not sole custody.
    independent_copies=(
        MANIFEST["operator_recovery_map"]["independent_copy_identical"]
        and MANIFEST["four_d_branch_packet"]["independent_copy_identical"]
    )

    return {
        "passed":(
            map_points_to_4d and packet_primary and wrong_4096 and archive_identity
            and locator_only_blocked and independent_copies
            and supported_verdict=="SUPPORTED"
            and audit["passed"]
        ),
        "question":MANIFEST["question"],
        "map_points_to_primary_branch":map_points_to_4d,
        "primary_branch_status_recovered":packet_primary,
        "wrong_input_consensus_4096_witness":wrong_4096,
        "primary_archive_identity_recoverable":archive_identity,
        "recovery_map_alone_cannot_certify_primary_claim":locator_only_blocked,
        "independent_library_copies_byte_identical":independent_copies,
        "route_bytes_loaded":(
            MANIFEST["operator_recovery_map"]["size_bytes"]
            + MANIFEST["four_d_branch_packet"]["size_bytes"]
        ),
        "operator_incoming_broad_bytes":74264,
        "bounded_answer":MANIFEST["bounded_answer"],
        "claim_ceiling":MANIFEST["claim_ceiling"],
        "kernel_schema_additions":0,
        "audit_passed":audit["passed"],
    }

if __name__=="__main__":
    print(json.dumps(run(),indent=2,sort_keys=True))
