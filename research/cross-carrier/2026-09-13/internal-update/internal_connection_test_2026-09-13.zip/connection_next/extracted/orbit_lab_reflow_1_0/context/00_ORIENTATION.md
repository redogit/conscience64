# Orbit Lab Reflow 1.0 — Orientation

## Purpose

Orbit Lab is a small human-facing research/work loop backed by a larger recoverable verifier and Library.
It exists to help a person investigate, build, troubleshoot, compare, and decide without silently turning
retrieval, resemblance, history, or model confidence into evidence.

## Primary orientation

**Ethics is primary as an action constraint.** It must be able to change or reject a plan, not merely decorate it.
Ethics does not replace empirical evidence, mathematical proof, or local authority.

Working Compass:

> All matter. Protect most where the ability to self-protect is least. Remain correctable.

The Compass orients action. It is not scientific evidence and does not self-authorize a claim.

## What survived the entire conversation

1. Preserve what actually happened before explaining it.
2. Observation, derived comparison, interpretation, and decision remain distinct.
3. Classify the tested relation, not the whole thing globally.
4. A source being available does not make it active, relevant, authorized, or evidence.
5. Retrieval finds candidates. Verification determines what they can support.
6. Current should be small. History/evidence should remain recoverable.
7. Unknown, unresolved, timeout, missing, and not-found are not silently converted into failure or nonexistence.
8. Architecture grows only when absence causes a consequential failure that a smaller repair resolves.
9. Costs, privacy, risk, reversibility, affected parties, and what is being protected are part of the work boundary.
10. Successful verification does not self-authorize promotion; propose/search, verify, and admit remain separate.

## Reflow decision

The Alpha 0.x sequence is now **history and verified implementation lineage**, not the active conceptual interface.
The active model is reduced to three layers:

```text
WORK
  What are we trying to understand or accomplish?

VERIFY
  What actually supports the result, under what scope and authority?

LIBRARY
  What evidence, history, candidates, contradictions, helpers, and unresolved material remain recoverable?
```
