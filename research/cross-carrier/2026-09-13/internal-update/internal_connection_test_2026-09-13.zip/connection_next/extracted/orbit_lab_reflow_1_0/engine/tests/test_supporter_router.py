
import unittest
from supporters.catalog import route_profile, PROFILES

class SupporterRouterTests(unittest.TestCase):
    def test_profiles_cover_required_capabilities(self):
        for name,p in PROFILES.items():
            r=route_profile(name)
            self.assertEqual(r["uncovered"],[],name)
            self.assertFalse(r["independent"])

    def test_schema_route_is_not_only_adversarial(self):
        r=route_profile("schema_change")
        self.assertGreaterEqual(len(r["mechanisms"]),3)

if __name__=="__main__": unittest.main()
