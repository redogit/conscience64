# Orbit Lab Alpha 0.14 — Current

Alpha 0.14 consolidates the integrated research kernel with a TBCL-inspired task-local
active relation carrier.

Current bounded result:

```text
Preserved evidence/history
        ↓ references
510-byte active relation carrier
        ↓
same tested actions / provenance reconstruction
```

The comparison surface was 4,991 bytes, giving ~9.79x smaller active serialized state
on the 14-case finite corpus. Source/cold records remain preserved and recoverable.

Validation:
- 153/153 regressions PASS
- TBCL active-carrier probe PASS
- orthogonal 16,384-pair counterprobe PASS
- direct S5 whole integration PASS
- strict path successor of Alpha 0.13
- zero new kernel schema types

Do not infer global minimality or general TBCL equivalence from this finite result.
