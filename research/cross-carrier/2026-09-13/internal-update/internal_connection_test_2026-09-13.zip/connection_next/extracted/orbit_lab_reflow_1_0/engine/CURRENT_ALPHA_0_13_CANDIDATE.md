# Orbit Lab Alpha 0.13 candidate

Adds exact evidence-set contracts for campaign/evidence-custody claims, forced by SHADOW.
