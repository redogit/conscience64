
import unittest
from checks.tbcl_active_carrier_counterprobe import run

class TBCLActiveCarrierCounterprobeTests(unittest.TestCase):
    def test_exhaustive_task_local_relation(self):
        r=run()
        self.assertTrue(r["passed"])
        self.assertEqual(r["mask_pairs_checked"],16384)
        self.assertEqual(r["mismatches"],[])
        self.assertEqual(r["single_missing_requirement_witnesses"],7)
        self.assertFalse(r["verifier_imports_candidate_compiler"])

if __name__=="__main__":
    unittest.main()
