
import tempfile
from pathlib import Path
from orbit_lab import OrbitLab

with tempfile.TemporaryDirectory() as td:
    lab=OrbitLab(Path(td)/"stress.db")
    passes=[]; breaks=[]
    try:
        frame=lab.add("ObservationFrame","same lab frame",data={"observer":"same-team","apparatus":"same-code","accessible_variables":["score"],"resolution":"1","intervention":"none","boundary":"same dataset"},provenance_class="TEST",provenance="stress",identity_key="f")
        params=lab.add("Parameters","params",data={"seed":7},provenance_class="TEST",provenance="stress",identity_key="params")
        reset=lab.add("Artifact","reset",provenance_class="TEST",provenance="stress",identity_key="reset")
        p=lab.add("Probe","probe",provenance_class="TEST",provenance="stress",identity_key="p")

        # Run 1
        r1=lab.add("RunIdentity","run one",data={"machine":"same","code":"same","data":"same","seed":7},
                   provenance_class="PRIMARY_ARTIFACT",provenance="run:1",identity_key="run:1")
        o1=lab.add("Observation","score .7",data={"score":0.7},provenance_class="PRIMARY_ARTIFACT",provenance="run:1",identity_key="o1",epistemic="OBSERVED")
        e1=lab.record_execution(run_id=r1,probe_id=p,frame_id=frame,parameters_id=params,reset_id=reset,observation_ids=[o1],status="COMPLETED",provenance_class="PRIMARY_ARTIFACT",provenance="run:1")

        try:
            lab.record_execution(run_id=r1,probe_id=p,frame_id=frame,parameters_id=params,reset_id=reset,observation_ids=[o1],status="COMPLETED",provenance_class="PRIMARY_ARTIFACT",provenance="run:1")
            breaks.append("same run identity reused")
        except ValueError:
            passes.append("A RunIdentity can be consumed by only one Execution.")

        # Run 2 is a genuine new execution identity, but same code/data/team/environment/seed lineage.
        r2=lab.add("RunIdentity","run two",data={"machine":"same","code":"same","data":"same","seed":7},
                   provenance_class="PRIMARY_ARTIFACT",provenance="run:2",identity_key="run:2")
        o2=lab.add("Observation","score .7 replay",data={"score":0.7},provenance_class="PRIMARY_ARTIFACT",provenance="run:2",identity_key="o2",epistemic="OBSERVED")
        e2=lab.record_execution(run_id=r2,probe_id=p,frame_id=frame,parameters_id=params,reset_id=reset,observation_ids=[o2],status="COMPLETED",provenance_class="PRIMARY_ARTIFACT",provenance="run:2")

        breaks.append(
            "Distinct RunIdentity proves two executions occurred, but the kernel has no relation that says "
            "whether e2 is replay/repeatability/partial replication/independent replication. "
            "Different runs are not automatically independent evidence."
        )

        print("V0.11 RUN / REPLICATION STRESS")
        print("------------------------------")
        print("PASS:")
        for x in passes: print("-",x)
        print("\nNEXT BREAK:")
        for i,x in enumerate(breaks,1): print(f"{i}. {x}")
    finally:
        lab.close()
