from __future__ import annotations
import json, sys
from pathlib import Path
BASE=Path(__file__).resolve().parents[1]
if str(BASE) not in sys.path: sys.path.insert(0,str(BASE))
from connections import ConnectionMap

JOINTS={
    'observation-before-interpretation':{
        'branches':{'one-level-up','r3-method','csol'},
        'meaning':'raw observations and scope must survive before interpretation or interface compression'
    },
    'agreement-is-not-grounding':{
        'branches':{'four-d-observer','r3-method'},
        'meaning':'agreement/reviewer consensus is not independent external truth'
    },
    'local-validity-not-whole-sufficiency':{
        'branches':{'pulsenet-gp','musilanguage','computer-mind'},
        'meaning':'local legality or component success cannot substitute for the whole declared obligation set'
    },
    'small-active-large-recoverable':{
        'branches':{'one-level-up','r3-method','operator-moonshot','moonshot-root','tbcl'},
        'meaning':'Current may stay small while deeper evidence remains recoverable and separately authoritative'
    }
}

def run():
    m=ConnectionMap(); ids={b['id'] for b in m.branches}
    missing={name:sorted(spec['branches']-ids) for name,spec in JOINTS.items() if spec['branches']-ids}
    check=m.check()
    return {
        'passed':not missing and check['passed'],
        'joint_count':len(JOINTS),
        'missing':missing,
        'joints':{name:{'branches':sorted(spec['branches']),'meaning':spec['meaning'],
                        'independent_replication_claimed':False,'merge_performed':False}
                  for name,spec in JOINTS.items()},
        'kernel_schema_changes':0,
        'connection_check':check,
        'claim':'These are convergent pressures/counterexamples with separate provenance; no cross-branch equivalence or independent replication is inferred.'
    }

if __name__=='__main__':
    r=run(); print(json.dumps(r,indent=2,sort_keys=True)); raise SystemExit(0 if r['passed'] else 1)
