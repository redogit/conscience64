
from __future__ import annotations
from pathlib import Path
import tempfile, json, hashlib, sys
ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0,str(ROOT))
from orbit_lab import OrbitLab

def _digest(values):
    canonical=[
        json.dumps(v,sort_keys=True,separators=(",",":"),ensure_ascii=False)
        for v in values
    ]
    return hashlib.sha256(("\n".join(sorted(canonical))+"\n").encode()).hexdigest()

def run():
    scheduled=list(range(8))
    with tempfile.TemporaryDirectory() as td:
        lab=OrbitLab(Path(td)/"shadow.db")
        try:
            frame=lab.add(
                "ObservationFrame","SHADOW evidence-custody reconstruction",
                data={
                    "observer":"shadow-integrity-probe",
                    "apparatus":"bounded exact collection reconstruction",
                    "accessible_variables":["scheduled_id","raw_status","final_decision"],
                    "resolution":"one scheduled identity",
                    "intervention":"remove/replace evidence records",
                    "boundary":"synthetic eight-record analogue of SHADOW shard custody"
                },
                provenance_class="TEST",provenance="shadow-integrity",identity_key="frame"
            )
            col=lab.add(
                "Collection","Parent-campaign shard S0004",
                provenance_class="TEST",provenance="shadow-integrity",identity_key="collection"
            )
            raw_ids=[]
            for i in scheduled:
                epistemic="UNKNOWN" if i==3 else "OBSERVED"
                ev=lab.add(
                    "Evidence",f"raw record {i}",
                    data={
                        "scheduled_id":i,
                        "raw_status":"TIMEOUT" if i==3 else "OBSERVED",
                        "final_decision":"RETAIN" if i==3 else "REJECT",
                        "evidence_tags":["RAW_CLASSIFICATION_RECORD"]
                    },
                    epistemic=epistemic,
                    provenance_class="TEST",provenance="shadow-integrity",
                    identity_key=f"raw-{i}"
                )
                raw_ids.append(ev); lab.add_to_collection(col,ev)

            summary=lab.add(
                "Evidence","Exact reconstruction audit",
                data={"evidence_tags":["CAMPAIGN_RECONSTRUCTION_AUDIT"]},
                epistemic="OBSERVED",
                provenance_class="TEST",provenance="shadow-integrity",identity_key="summary"
            )
            contract={
                "collection_id":col,
                "expected_count":8,
                "identity_field":"scheduled_id",
                "expected_identities":scheduled,
                "expected_identity_sha256":_digest(scheduled),
                "required_member_evidence_tags":["RAW_CLASSIFICATION_RECORD"]
            }
            claim=lab.add(
                "Claim","Shard reconstructs exactly 8 scheduled identities",
                data={
                    "required_evidence_tags":["CAMPAIGN_RECONSTRUCTION_AUDIT"],
                    "evidence_set_contract":contract
                },
                provenance_class="TEST",provenance="shadow-integrity",identity_key="claim"
            )
            supported=lab.assess_claim(
                claim,frame_id=frame,evidence_ids=[summary],verdict="SUPPORTED",
                scope="bounded eight-record SHADOW analogue",
                provenance_class="TEST",provenance="shadow-integrity"
            )

            # UNKNOWN raw observation remains UNKNOWN even though a later final
            # decision can resolve the classifier branch.
            unknown_preserved=lab.get(raw_ids[3]).epistemic=="UNKNOWN"

            # Same visible label, distinct scientific identities.
            a=lab.add("RunIdentity","S0004",provenance_class="TEST",provenance="shadow-integrity",identity_key="parent:S0004")
            b=lab.add("RunIdentity","S0004",provenance_class="TEST",provenance="shadow-integrity",identity_key="successor:S0004")
            same_label_distinct_identity=(a!=b and lab.get(a).title==lab.get(b).title)

            # Remove one linked raw record after support; audit must invalidate the
            # complete-coverage claim rather than silently retaining denominator 8.
            lab.remove_from_collection(col,raw_ids[-1],reason="simulate lost evidence link")
            drift_audit=lab.alpha_audit()
            drift_detected=(
                not drift_audit["passed"]
                and any(f["check"]=="claim_evidence_sets" for f in drift_audit["failures"])
            )

            # Restore it, then substitute the wrong scheduled identity.
            lab.add_to_collection(col,raw_ids[-1],note="restore")
            wrong=lab.add(
                "Evidence","wrong identity",
                data={"scheduled_id":99,"evidence_tags":["RAW_CLASSIFICATION_RECORD"]},
                epistemic="OBSERVED",provenance_class="TEST",provenance="shadow-integrity",
                identity_key="wrong-99"
            )
            lab.remove_from_collection(col,raw_ids[-1],reason="identity corruption")
            lab.add_to_collection(col,wrong)
            identity_status=lab.claim_evidence_set_status(claim)
            wrong_identity_detected=not identity_status["satisfied"]

            return {
                "passed":(
                    unknown_preserved and same_label_distinct_identity
                    and drift_detected and wrong_identity_detected
                    and lab.episode(supported)["data"]["verdict"]=="SUPPORTED"
                ),
                "complete_set_initially_supported":lab.episode(supported)["data"]["verdict"]=="SUPPORTED",
                "timeout_observation_remains_unknown":unknown_preserved,
                "same_label_distinct_run_identity":same_label_distinct_identity,
                "post_support_link_loss_detected":drift_detected,
                "wrong_scheduled_identity_detected":wrong_identity_detected,
                "wrong_identity_status":identity_status,
                "kernel_schema_additions":0,
                "representation":"existing Claim + Collection + Evidence + RunIdentity; one evidence-set contract helper"
            }
        finally:
            lab.close()

if __name__=="__main__":
    print(json.dumps(run(),indent=2,sort_keys=True))
