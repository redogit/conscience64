# Alpha Lineage — Preserved as History

The Alpha sequence is retained to explain **why** the present boundaries exist. It is not the interface a person must carry.

| Checkpoint | Main surviving contribution |
|---|---|
| 0.1 | State-complete export/import, digest, FK/audit/immutability baseline. |
| 0.2 | Adversarial authority/scope/revocation/schema/legacy-path repairs; bounded Orbital GAN stress. |
| 0.3 | Supporter ecology and retained pressures: resource tradeoffs, wrapper masking, local-vs-global benefit, consensus-vs-grounding, regime hiding. |
| 0.4 | Selector core: use weakest applicable selector; escalate only while obligation unresolved; cache/share probe results. |
| 0.5 | Human Research Card; separate observation, thought, decision; hide kernel plumbing by default. |
| 0.6 | Connected research without authority transfer; `compare` added when paired observations exposed a missing human distinction. |
| 0.6.1 | Battery hardening, idempotent seeding, direct-run fixes, persistence/tamper checks. |
| 0.7 | Hodge prerequisite chain and non-blocking language Surface Guard. |
| 0.8 | Evidence-kind/tag qualification forced by BGZF carrier-vs-learned-state distinction. |
| 0.9 | Obligation-preserving transfer/bridge qualification. |
| 0.10 | Floating decoder failure vs scaled-integer finite-radix roundtrip; designed inverse != generic inverse. |
| 0.11 | Source/execution lineage: source code cannot certify runtime behavior; repaired variants remain distinct identities. |
| 0.12 | Recoverable recursive address != identified generator family/state. |
| 0.13 | SHADOW evidence-set/denominator/identity integrity; UNKNOWN timeout != miss. |
| 0.14 | Active relation carrier compressed task-local state ~9.79x while source evidence remained recoverable. |
| 0.15 | Task-specific verification activation; full regression reserved for release. |
| 0.16 | Selective research retrieval; small source neighborhood can preserve a bounded answer when project/source identity is respected. |
| 0.17 | Recovery map -> primary branch -> exact source route; locator != primary evidence. |
| 0.18 | Philosophy/source-role separation; philosophy may motivate but not certify empirical claims. |
| 0.19 | Weaker recoding showed earlier surface field names were not globally necessary. |
| 0.20 | Bounded GR/QM tidal-phase structural bridge with explicit weak-field/sign-convention scope and empirical calibration source. |
| 0.21 | Method-authority boundary; predecessor method can remain relevant without certifying a current-method claim. |
| 0.22 | Closed unresolved Research Card loop; `not found in bounded search != never existed`. |
| 0.23 | $20 low-attention penny stress replay produced a negative result; original sizing failed the existing drawdown brake. |
| 0.24 | GDSN work helper; non-persistent triage and standard-vs-local implementation separation. |
| 0.25 | Library Fold Stage 1; old Incoming resolved to recoverable History with delta-only imports. |
| 0.26 | Library Fold stages 2–5 + support retrieval; `related != supports`; private namespaces minimum-access. |

## Reflow conclusion

Most Alpha changes were not new ontology. They were repeated repairs to four recurring failure classes:

1. **identity loss** — same name/representation mistaken for same thing;
2. **epistemic upgrade** — related/retrieved/reported material mistaken for evidence;
3. **scope/authority drift** — a valid result used outside the method/context/permission that earned it;
4. **active-state bloat** — preserving history confused with carrying all history at once.

Reflow 1.0 makes those four protections explicit and removes the need to reconstruct them from 26 incremental checkpoints.
