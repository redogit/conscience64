
import tempfile
from pathlib import Path
import unittest
from orbit_lab import OrbitLab
class V16Tests(unittest.TestCase):
    def setUp(self): self.tmp=tempfile.TemporaryDirectory(); self.lab=OrbitLab(Path(self.tmp.name)/"t.db")
    def tearDown(self): self.lab.close(); self.tmp.cleanup()
    def add(self,t,title,key,**kw): return self.lab.add(t,title,provenance_class="TEST",provenance="test",identity_key=key,**kw)
    def root(self,c,s,actor,ops): return self.lab.establish_authority_root(context_id=c,scope_id=s,operations=ops,holder_actor_id=actor,provenance_class="USER",provenance="user")
    def test_authorization_is_operation_scoped(self):
        c=self.add("Context","C","c"); a=self.add("Actor","user","a"); x=self.add("Candidate","X","x"); s=self.add("Scope","S","s"); e=self.add("Evidence","e","e",epistemic="OBSERVED")
        root=self.root(c,s,a,["INSPECT"])
        self.lab.grant_authorization(context_id=c,entity_id=x,operation="INSPECT",scope_id=s,issuer_authority_id=root,issuer_actor_id=a,principal_id=a,basis_entity_ids=[e],reason="inspect",provenance_class="TEST",provenance="test")
        self.assertTrue(self.lab.check_authorized(context_id=c,actor_id=a,entity_id=x,operation="INSPECT",scope_id=s)["authorized"])
        self.assertFalse(self.lab.check_authorized(context_id=c,actor_id=a,entity_id=x,operation="ACTIVATE",scope_id=s)["authorized"])
    def test_authorization_is_context_local(self):
        a_ctx=self.add("Context","A","ca"); b_ctx=self.add("Context","B","cb"); actor=self.add("Actor","user","actor"); x=self.add("Candidate","X","x"); s=self.add("Scope","S","s"); e=self.add("Evidence","e","e",epistemic="OBSERVED")
        root=self.root(a_ctx,s,actor,["ACTIVATE"])
        self.lab.grant_authorization(context_id=a_ctx,entity_id=x,operation="ACTIVATE",scope_id=s,issuer_authority_id=root,issuer_actor_id=actor,principal_id=actor,basis_entity_ids=[e],reason="A",provenance_class="TEST",provenance="test")
        self.assertTrue(self.lab.check_authorized(context_id=a_ctx,actor_id=actor,entity_id=x,operation="ACTIVATE",scope_id=s)["authorized"])
        self.assertFalse(self.lab.check_authorized(context_id=b_ctx,actor_id=actor,entity_id=x,operation="ACTIVATE",scope_id=s)["authorized"])
    def test_access_history_can_revoke_eligibility(self):
        c=self.add("Context","Evaluator","c"); actor=self.add("Actor","checker","actor"); s=self.add("Scope","cycle","s"); truth=self.add("Artifact","truth","truth"); model=self.add("Candidate","model","model"); e=self.add("Evidence","e","e",epistemic="OBSERVED")
        root=self.root(c,s,actor,["CLEAN_EVALUATE","INSPECT"])
        self.lab.grant_authorization(context_id=c,entity_id=model,operation="CLEAN_EVALUATE",scope_id=s,issuer_authority_id=root,issuer_actor_id=actor,principal_id=actor,basis_entity_ids=[e],reason="clean",prerequisites={"forbid_exposure_tags":["CONFIRMATION_TRUTH"]},provenance_class="TEST",provenance="test")
        self.lab.grant_authorization(context_id=c,entity_id=truth,operation="INSPECT",scope_id=s,issuer_authority_id=root,issuer_actor_id=actor,principal_id=actor,basis_entity_ids=[e],reason="truth",provenance_class="TEST",provenance="test")
        self.lab.record_access(context_id=c,actor_id=actor,entity_id=truth,operation="INSPECT",scope_id=s,exposure_tags=["CONFIRMATION_TRUTH"],provenance_class="TEST",provenance="test")
        self.assertFalse(self.lab.check_authorized(context_id=c,actor_id=actor,entity_id=model,operation="CLEAN_EVALUATE",scope_id=s)["authorized"])
    def test_transfer_does_not_grant_destination_use(self):
        a=self.add("Context","A","a"); b=self.add("Context","B","b"); actor=self.add("Actor","user","actor"); x=self.add("Candidate","X","x"); s=self.add("Scope","S","s"); o=self.add("Obligation","o","o"); e=self.add("Evidence","e","e",epistemic="OBSERVED")
        self.lab.transfer(source_context_id=a,destination_context_id=b,entity_id=x,obligation_ids=[o],evidence_entity_ids=[e],requested_operations=["USE_AS_EVIDENCE"],result="PRESERVED",reason="preserved",provenance_class="TEST",provenance="test")
        self.assertFalse(self.lab.check_authorized(context_id=b,actor_id=actor,entity_id=x,operation="USE_AS_EVIDENCE",scope_id=s)["authorized"])
if __name__=="__main__": unittest.main()
