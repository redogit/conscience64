from __future__ import annotations
from pathlib import Path
import json

BASE=Path(__file__).resolve().parent

def _load(stage:int, name:str):
    return json.loads((BASE/"data"/f"library_fold_stage{stage}"/name).read_text())

MANIFEST=_load(1,"STAGE1_MANIFEST.json")
IMPORTS=_load(1,"NEW_CANDIDATE_IMPORTS.json")
STAGE2=_load(2,"STAGE2_MANIFEST.json")
STAGE3=_load(3,"STAGE3_MANIFEST.json")
STAGE4=_load(4,"STAGE4_MANIFEST.json")
STAGE5=_load(5,"STAGE5_MANIFEST.json")

def stage1_status(): return MANIFEST["stage_result"]
def stage_status(stage:int):
    return {1:MANIFEST,2:STAGE2,3:STAGE3,4:STAGE4,5:STAGE5}[stage]["stage_result"]

def all_stage_status():
    return {str(i):stage_status(i) for i in range(1,6)}

def lookup_stage1(query:str):
    q=(query or "").lower().strip(); hits=[]
    for e in MANIFEST["entries"]:
        if q and q in json.dumps(e,sort_keys=True).lower(): hits.append(e)
    return hits

def lookup_stage2(query:str):
    q=(query or "").lower().strip(); hits=[]
    for e in STAGE2["entries"]:
        if q and q in json.dumps(e,sort_keys=True).lower(): hits.append(e)
    return hits

def candidate_import(name:str): return IMPORTS.get(name)
