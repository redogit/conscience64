# Orbit Lab Alpha 0.17 — Operator Moonshot Primary-Evidence Route

## Question

Does agreement among multiple models establish that their input is externally true?

## Selective retrieval route

1. Operator Moonshot current recovery map — locator/control source.
2. 4D Codec / Inversion / Observer recovery packet — primary-artifact branch recovery.
3. Original 141 MB archive identity — recoverable by exact hash and Library locator.

The recovery map alone is not allowed to certify the claim.

The 4D branch packet records a finite direct counterexample:
all three tested models can receive the same coherently wrong input, agree, and remain
wrong in all 4,096 tested cases.

Therefore, within the tested branch:

`model agreement != external truth`.

This is a bounded software counterexample, not a universal theorem about ensembles.

## Orchestration repair

Alpha 0.16's retrieval-neighborhood obligations were registered in selector policy and
task verification, but the monolithic selector S4 execution list omitted the retrieval
probe. Alpha 0.17 adds it and preserves a regression for the full-selector path.

## Cleanup boundary

Independent Library copies of both the Operator recovery map and the 4D branch packet
are byte-identical to the Incoming copies. The original 141 MB source archive also has
an exact Library locator. Therefore those two duplicate Incoming files no longer have
sole-custody value after Alpha 0.17 is admitted.
