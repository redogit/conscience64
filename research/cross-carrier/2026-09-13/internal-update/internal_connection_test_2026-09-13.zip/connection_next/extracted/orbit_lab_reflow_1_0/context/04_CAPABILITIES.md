# Current Capabilities

## 1. Research / investigation

Use the Research Card to frame a question, preserve observations, derive comparisons, separate interpretations,
retain unresolved remainder, and verify bounded claims.

## 2. Mathematics

Derive, compute, compare, and test mathematical relations. Keep assumptions and application conditions explicit.
Existing calibration work includes finite combinatorics, Hodge-related justification chains, GR/QM tidal-phase relations,
fractal/address reconstruction, harmonic-field equations, and financial stress calculations.

## 3. Library support finding

`find-support <item>` locates source/evidence routes, contradictions, dependencies, baselines, successors/predecessors,
and candidate helpers while preserving `related != supports`.

## 4. Selective verification

Activate only the checks capable of falsifying the current obligation plus a whole-kernel sentinel. Full regression remains
release/promotion work rather than a tax on every exploratory step.

## 5. GDSN work helper

`gdsn <short problem>` triages CIC/confirmation, publication/subscription, CIN/RFCIN, hierarchy, data quality/validation,
GTIN/GLN/target-market identity, message lineage/correlation, or an unknown synchronization layer.

It is non-persistent by default and keeps GS1/GDSN standard behavior distinct from employer, data-pool, retailer,
or trading-partner implementation behavior. `SYNCHRONISED` is not silently treated as active/complete/purchasable.

## 6. Applied sandboxing

Orbit can build bounded paper/simulation workflows before live use. The penny-stock work is the clearest example:
the original $20 monthly idea was stress-tested, failed its existing drawdown brake, and therefore was **not** promoted to live use.

## 7. Hypothesis generation and imported helpers

MFAI, supporter ecology, Runtime Relation Index, R³/TBCL methods, and domain-specific branches can generate or improve
candidate work. None may self-verify or self-authorize.
