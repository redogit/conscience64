# Orbit Lab Alpha 0.20 — GR/QM Tidal Bridge

This integrates the Distinction Physics / GR–Quantum Seam branch at one bounded
relation rather than at theory level.

## Registered structural relation

For
`Phi(z)=Phi0 + g0*z + (q/2) z^2`:

- centered second difference annihilates the affine part;
- the surviving term is `q h^2`;
- acceleration gradient is `Tzz=-q`.

For a light-pulse Mach-Zehnder atom interferometer, using the registered weak-gradient
phase dependence `K v Tzz T^3` and half-recoil midpoint shift
`v_r/2 = hbar K/(2m)` gives exactly:

`phi_tidal = hbar K^2 Tzz T^3 /(2m)`.

This matches the tidal term reported by Asenbaum et al. (PRL 118, 183602, 2017).

## One-degree ablations

- constant potential offset: no tidal change;
- uniform linear potential term: no tidal change in the recoil-difference observable;
- `Tzz -> 0`: tidal phase vanishes.

## Local relativistic transport

Under the explicitly registered convention

- `g00=-(1+2 Phi/c^2)`;
- local free fall removes constant/linear potential terms at the reference worldline;
- `g00=-1-R_0z0z z^2+...`;

we obtain `R_0z0z=q/c^2`, `Tzz=-c^2 R_0z0z`, hence

`phi_tidal = -(hbar K^2 c^2 /(2m)) R_0z0z T^3`.

The sign is convention-bound; this candidate records the convention rather than
claiming convention-free sign identity.

## Witness separation

The structural derivation cannot certify the empirical bridge alone.
The external measurement cannot certify the structural reconstruction alone.
The combined bounded claim requires both evidence kinds.

The same evidence cannot satisfy a claim requiring a nonclassical-gravity witness.

## Provenance defect preserved

The recovered finite-difference Python source executes and reproduces all mathematical
expressions, but its current stdout is not byte-identical to the archived output:
one line label says `through h^4` in source output versus `series` in the archived text.
This is a source/output lineage defect, not a physics contradiction.

No new kernel object or Episode type was added.
