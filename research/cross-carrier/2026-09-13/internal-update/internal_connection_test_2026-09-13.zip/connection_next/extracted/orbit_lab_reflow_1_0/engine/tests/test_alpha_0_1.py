
import tempfile
from pathlib import Path
import unittest
from orbit_lab import OrbitLab

class Alpha01Tests(unittest.TestCase):
    def build_learned_state(self, db):
        lab=OrbitLab(db)
        ctx=lab.add("Context","Schema context",provenance_class="TEST",provenance="test",identity_key="ctx")
        actor=lab.add("Actor","owner",provenance_class="TEST",provenance="test",identity_key="actor")
        scope=lab.add("Scope","Schema",provenance_class="TEST",provenance="test",identity_key="scope")
        frame=lab.add("ValidityFrame","frame",data={"conditions":{"kernel":"alpha"}},
                      provenance_class="TEST",provenance="test",identity_key="frame")
        witness=lab.add("Evidence","witness",epistemic="OBSERVED",
                        provenance_class="TEST",provenance="test",identity_key="w")
        gap=lab.record_schema_gap(gap_kind="LANGUAGE_COLLISION",current_term="Obligation",
            missing_distinction="pre-obligation pressure",provenance_class="TEST",provenance="test")
        proposal=lab.propose_schema_object_type(gap_id=gap,type_name="Pressure",
            definition="Observed tension before obligation is earned.",
            provenance_class="TEST",provenance="test",identity_key="proposal")
        promotion=lab.record_promotion(context_id=ctx,entity_id=proposal,scope_id=scope,
            validity_frame_id=frame,witness_entity_id=witness,basis_entity_ids=[witness],
            change_claim="Pressure required",revalidation_rule="rerun collision",
            provenance_class="TEST",provenance="test")
        root=lab.establish_authority_root(context_id=ctx,scope_id=scope,
            operations=["SCHEMA_CHANGE"],holder_actor_id=actor,
            provenance_class="USER",provenance="user",identity_key="root")
        lab.grant_authorization(context_id=ctx,entity_id=proposal,operation="SCHEMA_CHANGE",
            scope_id=scope,issuer_authority_id=root,issuer_actor_id=actor,principal_id=actor,
            basis_entity_ids=[witness,promotion],reason="earned repair",
            provenance_class="TEST",provenance="test")
        lab.apply_schema_object_type(proposal_id=proposal,promotion_episode_id=promotion,
            context_id=ctx,actor_id=actor,scope_id=scope,reason="apply",
            provenance_class="TEST",provenance="test")
        pressure=lab.add("Pressure","pressure instance",provenance_class="TEST",
                         provenance="test",identity_key="pressure")
        return lab,pressure

    def test_state_roundtrip_preserves_digest_and_learned_schema(self):
        with tempfile.TemporaryDirectory() as td:
            td=Path(td)
            lab,pressure=self.build_learned_state(td/"source.db")
            exported=lab.export_state(td/"state.json")
            source_digest=exported["sha256"]
            lab.close()

            restored=OrbitLab(td/"restored.db")
            imported=restored.import_state(td/"state.json")
            self.assertEqual(imported["sha256"],source_digest)
            self.assertEqual(restored.schema_term("Pressure")["status"],"ACTIVE")
            self.assertEqual(restored.get(pressure).type,"Pressure")
            self.assertEqual(restored.state_snapshot()["sha256"],source_digest)
            restored.close()

    def test_tampered_snapshot_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            td=Path(td)
            lab,_=self.build_learned_state(td/"source.db")
            lab.export_state(td/"state.json"); lab.close()
            text=(td/"state.json").read_text()
            (td/"state.json").write_text(text.replace("pressure instance","tampered instance",1))
            restored=OrbitLab(td/"restored.db")
            with self.assertRaises(ValueError):
                restored.import_state(td/"state.json")
            restored.close()

    def test_alpha_audit_passes_on_governed_state(self):
        with tempfile.TemporaryDirectory() as td:
            lab,_=self.build_learned_state(Path(td)/"source.db")
            audit=lab.alpha_audit()
            self.assertTrue(audit["passed"],audit["failures"])
            self.assertEqual(audit["stage"],"ALPHA_CANDIDATE")
            self.assertEqual(audit["warnings"][0]["boundary"],"runtime_authentication")
            lab.close()

if __name__=="__main__":
    unittest.main()
