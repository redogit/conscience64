from __future__ import annotations
from pathlib import Path
import json, tempfile, sys
ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path: sys.path.insert(0,str(ROOT))
from orbit_lab import OrbitLab

FIXTURE=json.loads((ROOT/'data'/'bgzf_carrier_fixture.json').read_text())

def add(lab,t,title,key,**kw):
    return lab.add(t,title,provenance_class='TEST',provenance='bgzf-carrier-probe',identity_key=key,**kw)

def run():
    with tempfile.TemporaryDirectory() as td:
        lab=OrbitLab(Path(td)/'bgzf.db')
        try:
            frame=add(lab,'ObservationFrame','BGZF rebuild frame','frame',data={
                'observer':'independent rebuild','apparatus':'gcc+selftest','accessible_variables':['source_sha256','executable_bytes','selftest'],
                'resolution':'exact bytes / exact selftest output','intervention':'rebuild and execute selftest','boundary':'bounded synthetic selftest'})
            exact=add(lab,'Artifact','Exact deterministic BGZF summary evidence','exact',epistemic='TESTED',data={
                'evidence_tags':[FIXTURE['exact_carrier_tag']],
                'source_sha256':FIXTURE['source_sha256'],
                'split_embedding_max_error':FIXTURE['independent_rebuild']['selftest']['split_embedding_max_error']})
            learned=add(lab,'Artifact','Learned local hierarchy state','learned',epistemic='TESTED',data={
                'evidence_tags':[FIXTURE['learned_state_tag']],
                'supervision':'file-level binary label'})
            weak=add(lab,'Artifact','File-level training label','weak',epistemic='OBSERVED',data={
                'evidence_tags':[FIXTURE['weak_file_label_tag']]})
            exact_claim=add(lab,'Claim','Ordered BGZF summary composition is exact in the bounded selftest','claim-exact',data={
                'required_evidence_tags':[FIXTURE['exact_carrier_tag']]})
            block_claim=add(lab,'Claim','A positive file label establishes this block is positive','claim-block',data={
                'required_evidence_tags':[FIXTURE['block_truth_tag']]})

            learned_blocked=False
            try:
                lab.assess_claim(exact_claim,frame_id=frame,evidence_ids=[learned],verdict='SUPPORTED',scope='bounded BGZF exactness',provenance_class='TEST',provenance='probe')
            except ValueError:
                learned_blocked=True
            exact_assessment=lab.assess_claim(exact_claim,frame_id=frame,evidence_ids=[exact],verdict='SUPPORTED',scope='bounded BGZF exactness',provenance_class='TEST',provenance='probe')
            weak_blocked=False
            try:
                lab.assess_claim(block_claim,frame_id=frame,evidence_ids=[weak],verdict='SUPPORTED',scope='block truth',provenance_class='TEST',provenance='probe')
            except ValueError:
                weak_blocked=True

            # Resource boundary: artifact budget is supported, total deployment remains dependency-gated.
            budget_evidence=add(lab,'Evidence','Documented executable+model byte arithmetic','budget-ev',epistemic='OBSERVED',data={
                'evidence_tags':['ARTIFACT_SIZE_ACCOUNTING'],
                'executable_bytes':FIXTURE['independent_rebuild']['executable_bytes'],
                'model_bytes':FIXTURE['documented_model_bytes'],
                'total_bytes':FIXTURE['documented_artifact_total_bytes'],
                'budget_bytes':FIXTURE['storage_budget_bytes']})
            artifact_budget=add(lab,'Claim','Documented executable plus model fits the declared artifact budget','artifact-budget',data={
                'required_evidence_tags':['ARTIFACT_SIZE_ACCOUNTING']})
            runtime_accounting=add(lab,'Claim','Dynamic runtime dependencies are fully accounted in the deployment footprint','runtime-accounting')
            total_deployment=add(lab,'Claim','Full deployment footprint fits the declared 1.44 MiB budget','total-deployment')
            lab.relate(total_deployment,'REQUIRES',artifact_budget,provenance_class='TEST',provenance='probe')
            lab.relate(total_deployment,'REQUIRES',runtime_accounting,provenance_class='TEST',provenance='probe')
            lab.assess_claim(artifact_budget,frame_id=frame,evidence_ids=[budget_evidence],verdict='SUPPORTED',scope='documented artifact bytes only',provenance_class='TEST',provenance='probe')
            deployment_blocked=False
            try:
                lab.assess_claim(total_deployment,frame_id=frame,evidence_ids=[budget_evidence],verdict='SUPPORTED',scope='full deployment footprint',provenance_class='TEST',provenance='probe')
            except ValueError:
                deployment_blocked=True
            audit=lab.alpha_audit()
            return {
                'passed':all([learned_blocked,weak_blocked,deployment_blocked,audit['passed']]),
                'source_sha256':FIXTURE['source_sha256'],
                'selftest':FIXTURE['independent_rebuild']['selftest'],
                'artifact_budget':{'total_bytes':FIXTURE['documented_artifact_total_bytes'],'budget_bytes':FIXTURE['storage_budget_bytes'],'fits':FIXTURE['documented_artifact_total_bytes']<=FIXTURE['storage_budget_bytes']},
                'learned_state_cannot_satisfy_exact_carrier_claim':learned_blocked,
                'exact_carrier_evidence_supports_exact_claim':lab.episode(exact_assessment)['data']['verdict']=='SUPPORTED',
                'weak_file_label_cannot_satisfy_block_truth_claim':weak_blocked,
                'full_deployment_claim_waits_for_runtime_accounting':deployment_blocked,
                'audit_passed':audit['passed'],
                'kernel_schema_additions':0,
            }
        finally:
            lab.close()

if __name__=='__main__':
    print(json.dumps(run(),indent=2,sort_keys=True))
