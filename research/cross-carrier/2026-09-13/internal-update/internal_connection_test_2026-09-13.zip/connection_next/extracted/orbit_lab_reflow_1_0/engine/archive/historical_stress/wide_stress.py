
from pathlib import Path
import tempfile
from orbit_lab import OrbitLab, EPISTEMIC

wide_sources = [
    ("wide:control-surface","Minimal Library control surface","library:file_000000001f8481f58e69704307505f60","control",
     "RESOLVE → PROVE → ADMIT → EXECUTE is a minimal control-surface proposal; caches are disposable and dependency closure matters to size claims."),
    ("wide:obstruction-carrier","Obstruction / Carrier research framework","library:file_00000000bc0881f79f1ea239f5dde3f1","research-framework",
     "Failure residuals, explicit falsifiers, claim boundaries, matched budgets, negative knowledge, and obstruction-guided representation invention are active research structures; several higher-level ideas remain hypotheses."),
    ("wide:csol-uncertainty","CSOL uncertainty-loop experiment v1","library:file_00000000495881f5890d127eefc122b9","experiment",
     "Adaptive probing beat uniform strongly on some localized peaks, tied on flat/hinge, and lost on oscillatory cases at modest budgets; narrow needles remain difficult at low budgets."),
    ("wide:necessity-first","Necessity-first architecture research line","library:file_00000000005c81fa9b676b2e0dc9f39a","research-program",
     "Add capability only after witnessed failure, identifiable missing distinction, weaker repair failure, restoration, and ablation recurrence."),
    ("wide:byte-slm","Tokenizer-free byte / patch SLM","library:file_00000000f4e0822fbb5b069fd37b787e","experiment",
     "Five parameter-near variants were trained across three seeds; patch models improved NLL/latency but failed the first-byte long-range binding criterion on the bounded synthetic workload."),
    ("wide:geometry-observer","Operational geometry observer","library:file_00000000a54081f58a3c840f19d935e4","experiment",
     "Exact synthetic coordinate-invariance/confound tests and redundant-audit necessity checks were run; redundant evidence was needed to reject a corrupted fitted metric."),
    ("wide:compressed-domain","Compressed-domain text computation","library:file_00000000548481f6a33445a41dbb2990","engineering-experiment",
     "Grammar-compressed text supports phrase search and selected classification without full plaintext materialization; real-world accuracy/generalization remains unestablished."),
    ("wide:language-functions","Language as Functions","library:file_000000002be481f59402a5af9d0e2a59","research-prototype",
     "Language use can be operationalized as hybrid functional systems under uncertainty; runnable code is proof-of-structure, not proof of complete language reducibility."),
    ("wide:communicative-function","Language communicative-function experiment 002","library:file_00000000ba5881f5b6dacd4ec157d7ac","experiment",
     "Eight bounded communicative-form cases passed, including an unresolved silence case; not universal language understanding."),
    ("wide:creativity","Multifactorial creativity / MFAI","library:file_000000003b5881f582423510bd5cdf22","prototype+proposed-experiment",
     "A multifactorial method can turn a creative prompt into a testable hypothesis; superiority over other ideation methods remains untested."),
    ("wide:fractal-roadmap","Fractal core recurrent-model roadmap","library:file_000000004e5481f7b26dcda7f999759b","planned-experiments",
     "Planned controlled comparisons separate trajectory weighting, depth readouts, topology sensitivity, and recurrent phase adapters with explicit acceptance/rejection conditions."),
    ("wide:airlock-aperture","Controlled current-context aperture","library:file_00000000d32481f5b3310e7b1f70f5e9","control",
     "Current question → small candidate set → inspect original region → admit necessary material; historical instructions remain inert."),
]

with tempfile.TemporaryDirectory() as td:
    lab = OrbitLab(Path(td)/"wide.db")
    breaks, passes = [], []
    try:
        root = lab.add("Subject","Wider research stress test",
                       provenance_class="CURRENT_CONVERSATION",
                       provenance="conversation:2026-09-04",
                       identity_key="wide:root", lifecycle="ACTIVE")
        lab.pin("subject", root)

        loaded = {}
        for key,title,source,kind,summary in wide_sources:
            s = lab.add("Subject", title,
                        data={"kind":kind,"summary":summary},
                        provenance_class="LIBRARY_ARTIFACT",
                        provenance=source,
                        identity_key=key,
                        lifecycle="QUARANTINED")
            loaded[key] = s
            lab.relate(s,"RELEVANT_TO",root,data={"kind":kind},
                       provenance_class="DERIVED",provenance="wide-stress")
        passes.append(f"Loaded {len(loaded)} wider research/control subjects without activating them.")

        try:
            lab.add("Experiment","CSOL uncertainty loop",
                    provenance_class="PRIMARY_ARTIFACT",
                    provenance="library:file_00000000495881f5890d127eefc122b9")
            breaks.append("Experiment unexpectedly accepted.")
        except Exception as e:
            breaks.append(f"No first-class Experiment object: {type(e).__name__}: {e}")

        needed={"PLANNED","RUNNING","PASSED","FAILED","NULL","CONFOUNDED","TOOL_FAILED"}
        missing=sorted(needed-set(EPISTEMIC))
        if missing:
            breaks.append("Experiment outcome/status vocabulary missing: " + ", ".join(missing))

        csol=loaded["wide:csol-uncertainty"]
        lab.set_epistemic(csol,"SUPPORTED",reason="localized-peak results")
        breaks.append("One epistemic status on Subject collapses mixed CSOL outcomes across families/budgets.")

        lab.add("Claim","Adaptive probing is better",
                provenance_class="DERIVED",provenance="wide-stress",
                identity_key="wide:bad-claim",epistemic="SUPPORTED")
        breaks.append("SUPPORTED Claim still needs no mandatory scope, comparator, evidence edge, or falsifier.")

        e1=lab.add("Artifact","same run A",provenance_class="PRIMARY_ARTIFACT",provenance="run:42")
        e2=lab.add("Artifact","same run B",provenance_class="PRIMARY_ARTIFACT",provenance="run:42")
        breaks.append(f"Execution identity is optional; same run locator admitted twice ({e1}, {e2}).")

        q=loaded["wide:airlock-aperture"]
        try:
            lab.launch(q,reason="direct legacy activation")
            breaks.append("QUARANTINED legacy object launches directly; no UNDER_REVIEW/ADMIT transition.")
        except PermissionError:
            passes.append("Quarantine activation is enforced.")

        a=loaded["wide:byte-slm"]; b=loaded["wide:compressed-domain"]
        lab.relate(a,"BASELINE",b,provenance_class="TEST",provenance="nonsense-test")
        breaks.append("Relation-schema validation absent; unrelated branches can be declared BASELINE.")

        if all(lab.get(x).type=="Subject" for x in loaded.values()):
            breaks.append("Subject is overloaded: project/branch/container and examined subject use the same type.")

        print("WIDER STRESS PASS")
        print("-----------------")
        for p in passes: print("PASS:",p)
        print("\nNEW PRESSURES/BREAKS:")
        for i,b in enumerate(breaks,1): print(f"{i}. {b}")
    finally:
        lab.close()
