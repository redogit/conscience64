
import unittest
from checks.x_ls_002_weaker_recode_probe import run

class XLS002WeakerRecodeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.r=run()

    def test_xls001_primary_result_recovered(self):
        self.assertTrue(self.r["x_ls_001_archived_result_recovered"])

    def test_weaker_recode_preserves_frozen_partition_and_routes(self):
        self.assertTrue(self.r["nine_field_partition_equals_generic"])
        self.assertEqual(self.r["generic_router_exact_matches"],54)
        self.assertEqual(self.r["generic_router_mismatches"],[])

    def test_cross_probe_composition_has_no_new_alias(self):
        self.assertEqual(self.r["cross_probe_pairwise_compositions"],171)
        self.assertEqual(self.r["cross_probe_composition_aliases"],0)

    def test_weaker_recode_reduces_schema_surface(self):
        self.assertEqual(self.r["named_state_fields"],{"prior":9,"weaker":1})
        self.assertGreater(self.r["serialized_byte_reduction_ratio"],8.0)

    def test_claim_ceiling_and_no_schema_growth(self):
        self.assertTrue(self.r["bounded_reduction_claim_supported"])
        self.assertEqual(self.r["kernel_schema_additions"],0)
        self.assertTrue(self.r["audit_passed"])

if __name__=="__main__":
    unittest.main()
