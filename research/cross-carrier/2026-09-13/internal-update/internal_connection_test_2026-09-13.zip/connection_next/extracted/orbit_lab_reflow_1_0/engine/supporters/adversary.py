
from __future__ import annotations
from dataclasses import dataclass, asdict
from pathlib import Path
import sys

# Support both `python -m supporters.adversary` and direct file execution.
if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from typing import Callable, Optional
import tempfile, random, json, traceback
from orbit_lab import OrbitLab

@dataclass
class Finding:
    orbit: str
    invariant: str
    signature: str
    detail: str
    genome: dict
    accepted_by_api: bool
    audit_passed: Optional[bool]

class NoveltyArchive:
    def __init__(self):
        self.by_signature: dict[str, Finding] = {}

    def add(self, finding: Finding) -> bool:
        if finding.signature in self.by_signature:
            return False
        self.by_signature[finding.signature] = finding
        return True

    def list(self):
        return list(self.by_signature.values())

class OrbitalGAN:
    """Adversarial co-evolution harness for Orbit Lab.

    Not a neural GAN. Generator populations mutate research histories.
    Discriminators encode higher-level invariants. A generator "wins"
    only when the public API accepts a history that violates an invariant,
    or when alpha_audit misses a persistence-layer corruption.
    """

    def __init__(self, seed: int = 90210):
        self.rng = random.Random(seed)
        self.seed = seed
        self.archive = NoveltyArchive()
        self.trials = 0
        self.controls_passed = 0

    @staticmethod
    def add(lab, t, title, key, **kw):
        return lab.add(
            t, title,
            provenance_class=kw.pop("provenance_class", "TEST"),
            provenance=kw.pop("provenance", "orbital-gan"),
            identity_key=key,
            **kw
        )

    def _authority_world(self, lab: OrbitLab, depth: int = 2):
        ctx=self.add(lab,"Context","Authority world","ctx")
        owner=self.add(lab,"Actor","root owner","owner")
        scope=self.add(lab,"Scope","root scope","scope")
        target=self.add(lab,"Candidate","target","target")
        basis=self.add(lab,"Evidence","basis","basis",epistemic="OBSERVED")
        root=lab.establish_authority_root(
            context_id=ctx,scope_id=scope,
            operations=["INSPECT","ACTIVATE","SCHEMA_CHANGE","AUTHORIZE"],
            holder_actor_id=owner,max_delegation_depth=max(1,depth),
            provenance_class="USER",provenance="orbital-user",
            identity_key="root"
        )
        chain=[(root,owner)]
        parent=root
        for i in range(depth):
            actor=self.add(lab,"Actor",f"delegate {i}",f"actor:{i}")
            remaining=max(0, depth-i-1)
            child=lab.delegate_authority(
                parent_authority_id=parent,grantee_id=actor,scope_id=scope,
                operations=["INSPECT","ACTIVATE"],
                max_delegation_depth=remaining,
                reason=f"delegate level {i}",
                provenance_class="TEST",provenance="orbital-gan",
                identity_key=f"authority:{i}"
            )
            chain.append((child,actor))
            parent=child
        return ctx,scope,target,basis,chain

    def authority_revocation_trial(self, genome: dict):
        with tempfile.TemporaryDirectory() as td:
            lab=OrbitLab(Path(td)/"t.db")
            try:
                depth=genome["depth"]
                ctx,scope,target,basis,chain=self._authority_world(lab,depth)
                leaf_auth,leaf_actor=chain[-1]
                lab.grant_authorization(
                    context_id=ctx,entity_id=target,operation="INSPECT",scope_id=scope,
                    issuer_authority_id=leaf_auth,issuer_actor_id=leaf_actor,
                    principal_id=leaf_actor,basis_entity_ids=[basis],
                    reason="pre-revocation grant",
                    provenance_class="TEST",provenance="orbital-gan"
                )
                revoke_index=genome["revoke_index"]
                revoked_auth,_=chain[revoke_index]
                lab.revoke_authority(
                    revoked_auth,reason="orbital ancestor revocation",
                    provenance_class="TEST",provenance="orbital-gan"
                )
                accepted=lab.check_authorized(
                    context_id=ctx,actor_id=leaf_actor,entity_id=target,
                    operation="INSPECT",scope_id=scope
                )["authorized"]
                audit=lab.alpha_audit()
                if accepted:
                    return Finding(
                        orbit="authority",
                        invariant="ancestor revocation cuts descendant authority",
                        signature="AUTH:ANCESTOR_REVOCATION_NOT_TRANSITIVE",
                        detail=f"revoked chain[{revoke_index}] but leaf authorization remained usable",
                        genome=genome,accepted_by_api=True,audit_passed=audit["passed"]
                    )
                self.controls_passed += 1
                return None
            finally:
                lab.close()

    def authority_expiry_trial(self, genome: dict):
        import datetime as dt
        with tempfile.TemporaryDirectory() as td:
            lab=OrbitLab(Path(td)/"t.db")
            try:
                ctx=self.add(lab,"Context","expiry world","ctx")
                owner=self.add(lab,"Actor","owner","owner")
                child_actor=self.add(lab,"Actor","child","child")
                scope=self.add(lab,"Scope","scope","scope")
                root=lab.establish_authority_root(
                    context_id=ctx,scope_id=scope,operations=["INSPECT"],
                    holder_actor_id=owner,max_delegation_depth=1,
                    expires_at=(dt.datetime.now(dt.timezone.utc)+dt.timedelta(days=1)).isoformat(),
                    provenance_class="USER",provenance="orbital-user"
                )
                child=lab.delegate_authority(
                    parent_authority_id=root,grantee_id=child_actor,scope_id=scope,
                    operations=["INSPECT"],max_delegation_depth=0,expires_at=None,
                    reason="child without expiry",
                    provenance_class="TEST",provenance="orbital-gan"
                )
                info=lab.authority_info(child)
                audit=lab.alpha_audit()
                if info["expires_at"] is None:
                    return Finding(
                        orbit="authority",
                        invariant="delegation cannot outlive parent",
                        signature="AUTH:FINITE_PARENT_UNBOUNDED_CHILD",
                        detail="finite parent delegated child with expires_at=None",
                        genome=genome,accepted_by_api=True,audit_passed=audit["passed"]
                    )
                self.controls_passed += 1
                return None
            except PermissionError:
                self.controls_passed += 1
                return None
            finally:
                lab.close()

    def revoked_issuer_grant_trial(self, genome: dict):
        with tempfile.TemporaryDirectory() as td:
            lab=OrbitLab(Path(td)/"t.db")
            try:
                ctx=self.add(lab,"Context","grant world","ctx")
                owner=self.add(lab,"Actor","owner","owner")
                principal=self.add(lab,"Actor","principal","principal")
                scope=self.add(lab,"Scope","scope","scope")
                target=self.add(lab,"Candidate","target","target")
                basis=self.add(lab,"Evidence","basis","basis",epistemic="OBSERVED")
                root=lab.establish_authority_root(
                    context_id=ctx,scope_id=scope,operations=["INSPECT"],
                    holder_actor_id=owner,provenance_class="USER",
                    provenance="orbital-user"
                )
                lab.grant_authorization(
                    context_id=ctx,entity_id=target,operation="INSPECT",scope_id=scope,
                    issuer_authority_id=root,issuer_actor_id=owner,principal_id=principal,
                    basis_entity_ids=[basis],reason="grant before revoke",
                    provenance_class="TEST",provenance="orbital-gan"
                )
                lab.revoke_authority(root,reason="revoke issuer",
                    provenance_class="TEST",provenance="orbital-gan")
                accepted=lab.check_authorized(
                    context_id=ctx,actor_id=principal,entity_id=target,
                    operation="INSPECT",scope_id=scope
                )["authorized"]
                audit=lab.alpha_audit()
                if accepted:
                    return Finding(
                        orbit="authority",
                        invariant="grant cannot remain live after issuer authority is revoked",
                        signature="AUTH:REVOKED_ISSUER_GRANT_STILL_LIVE",
                        detail="authorization issued by revoked root remained usable",
                        genome=genome,accepted_by_api=True,audit_passed=audit["passed"]
                    )
                self.controls_passed += 1
                return None
            finally:
                lab.close()

    def schema_audit_trial(self, genome: dict):
        with tempfile.TemporaryDirectory() as td:
            lab=OrbitLab(Path(td)/"t.db")
            try:
                ctx=self.add(lab,"Context","schema ctx","ctx")
                actor=self.add(lab,"Actor","owner","actor")
                scope=self.add(lab,"Scope","schema","scope")
                frame=self.add(lab,"ValidityFrame","frame","frame",data={"conditions":{"k":"v"}})
                witness=self.add(lab,"Evidence","witness","w",epistemic="OBSERVED")
                gap=lab.record_schema_gap(
                    gap_kind="LANGUAGE_COLLISION",current_term="Candidate",
                    missing_distinction="earned type",
                    provenance_class="TEST",provenance="orbital-gan"
                )
                proposal=lab.propose_schema_object_type(
                    gap_id=gap,type_name="OrbitalEarned",
                    definition="earned test type",
                    provenance_class="TEST",provenance="orbital-gan"
                )
                promotion=lab.record_promotion(
                    context_id=ctx,entity_id=proposal,scope_id=scope,
                    validity_frame_id=frame,witness_entity_id=witness,
                    basis_entity_ids=[witness],change_claim="earned",
                    revalidation_rule="rerun",
                    provenance_class="TEST",provenance="orbital-gan"
                )
                root=lab.establish_authority_root(
                    context_id=ctx,scope_id=scope,operations=["SCHEMA_CHANGE"],
                    holder_actor_id=actor,provenance_class="USER",provenance="orbital-user"
                )
                lab.grant_authorization(
                    context_id=ctx,entity_id=proposal,operation="SCHEMA_CHANGE",
                    scope_id=scope,issuer_authority_id=root,issuer_actor_id=actor,
                    principal_id=actor,basis_entity_ids=[witness,promotion],
                    reason="governed",provenance_class="TEST",provenance="orbital-gan"
                )
                lab.apply_schema_object_type(
                    proposal_id=proposal,promotion_episode_id=promotion,
                    context_id=ctx,actor_id=actor,scope_id=scope,reason="apply",
                    provenance_class="TEST",provenance="orbital-gan"
                )
                gap2=lab.record_schema_gap(
                    gap_kind="ONTOLOGY_LEAKAGE",current_term="Artifact",
                    missing_distinction="unrelated gap",
                    provenance_class="TEST",provenance="orbital-gan"
                )
                lab.conn.execute(
                    "UPDATE schema_changes SET gap_id=? WHERE term_name='OrbitalEarned'",
                    (gap2,)
                )
                lab.conn.commit()
                audit=lab.alpha_audit()
                if audit["passed"]:
                    return Finding(
                        orbit="schema",
                        invariant="audit binds admitted schema term to the gap/proposal that earned it",
                        signature="SCHEMA:AUDIT_MISSES_GAP_RELINK",
                        detail="schema_changes.gap_id relinked to unrelated open gap; alpha_audit still passed",
                        genome=genome,accepted_by_api=False,audit_passed=True
                    )
                self.controls_passed += 1
                return None
            finally:
                lab.close()

    def association_control_trial(self, genome: dict):
        with tempfile.TemporaryDirectory() as td:
            lab=OrbitLab(Path(td)/"t.db")
            try:
                scope=self.add(lab,"Scope","scope","scope")
                a=self.add(lab,"Artifact","packet","a")
                b=self.add(lab,"Artifact","source","b")
                assoc=lab.record_association(
                    source_entity_id=a,target_entity_id=b,scope_id=scope,
                    relation="DECLARED_SOURCE",resolution_status="LIBRARY_ID_EXACT",
                    provenance_class="TEST",provenance="orbital-gan"
                )
                ctx=self.add(lab,"Context","ctx","ctx")
                method=self.add(lab,"Method","method","method")
                packet=self.add(lab,"Artifact","packet2","packet2")
                try:
                    lab.assess_method_compliance(
                        context_id=ctx,entity_id=packet,method_id=method,
                        scope_id=scope,verdict="CURRENT",basis_entity_ids=[assoc],
                        reason="try smuggle association",
                        provenance_class="TEST",provenance="orbital-gan"
                    )
                    return Finding(
                        orbit="association",
                        invariant="association never upgrades to evidence",
                        signature="ASSOC:EVIDENCE_SMUGGLE",
                        detail="ASSOCIATION satisfied an evidence/basis role",
                        genome=genome,accepted_by_api=True,audit_passed=lab.alpha_audit()["passed"]
                    )
                except TypeError:
                    self.controls_passed += 1
                    return None
            finally:
                lab.close()

    def lineage_control_trial(self, genome: dict):
        with tempfile.TemporaryDirectory() as td:
            lab=OrbitLab(Path(td)/"t.db")
            try:
                ctx=self.add(lab,"Context","ctx","ctx")
                m=self.add(lab,"Method","m","m")
                def occ(key,digest):
                    content=lab.register_content(algorithm="sha256",digest=digest,
                        provenance_class="TEST",provenance="orbital-gan")
                    inst=lab.create_artifact_instance(content_id=content,
                        provenance_class="TEST",provenance="orbital-gan",identity_key="i:"+key)
                    return lab.record_instance_occurrence(instance_id=inst,context_id=ctx,
                        locator="/"+key,mode="REGISTER",
                        provenance_class="TEST",provenance="orbital-gan",identity_key="o:"+key)
                a=occ("a","aa"); b=occ("b","bb")
                lab.record_derivation(input_occurrence_ids=[a],method_id=m,output_occurrence_id=b,
                    transformation="a->b",reconstructibility="DIRECT",
                    provenance_class="TEST",provenance="orbital-gan")
                try:
                    lab.record_derivation(input_occurrence_ids=[b],method_id=m,output_occurrence_id=a,
                        transformation="b->a",reconstructibility="DIRECT",
                        provenance_class="TEST",provenance="orbital-gan")
                    return Finding(
                        orbit="lineage",
                        invariant="derivation provenance remains acyclic",
                        signature="LINEAGE:DERIVATION_CYCLE",
                        detail="API accepted derivation cycle",
                        genome=genome,accepted_by_api=True,audit_passed=lab.alpha_audit()["passed"]
                    )
                except ValueError:
                    self.controls_passed += 1
                    return None
            finally:
                lab.close()


    def authorize_wildcard_trial(self, genome: dict):
        """A meta-authorize capability should not mint operations it does not contain."""
        with tempfile.TemporaryDirectory() as td:
            lab=OrbitLab(Path(td)/"t.db")
            try:
                ctx=self.add(lab,"Context","authorize world","ctx")
                owner=self.add(lab,"Actor","owner","owner")
                principal=self.add(lab,"Actor","principal","principal")
                scope=self.add(lab,"Scope","scope","scope")
                target=self.add(lab,"Candidate","target","target")
                basis=self.add(lab,"Evidence","basis","basis",epistemic="OBSERVED")
                root=lab.establish_authority_root(
                    context_id=ctx,scope_id=scope,operations=["AUTHORIZE"],
                    holder_actor_id=owner,provenance_class="USER",provenance="orbital-user"
                )
                accepted=False
                try:
                    lab.grant_authorization(
                        context_id=ctx,entity_id=target,operation="ACTIVATE",scope_id=scope,
                        issuer_authority_id=root,issuer_actor_id=owner,principal_id=principal,
                        basis_entity_ids=[basis],reason="mint undeclared operation",
                        provenance_class="TEST",provenance="orbital-gan"
                    )
                    accepted=True
                except PermissionError:
                    pass
                audit=lab.alpha_audit()
                if accepted:
                    return Finding(
                        orbit="authority",
                        invariant="issuer cannot mint an operation absent from its own authority",
                        signature="AUTH:AUTHORIZE_WILDCARD_ESCALATION",
                        detail="Authority with only AUTHORIZE minted ACTIVATE",
                        genome=genome,accepted_by_api=True,audit_passed=audit["passed"]
                    )
                self.controls_passed += 1
                return None
            finally:
                lab.close()

    def revoked_denial_trial(self, genome: dict):
        """Revoked issuer should not keep exercising a negative authorization either."""
        with tempfile.TemporaryDirectory() as td:
            lab=OrbitLab(Path(td)/"t.db")
            try:
                ctx=self.add(lab,"Context","denial world","ctx")
                owner=self.add(lab,"Actor","owner","owner")
                denier=self.add(lab,"Actor","denier","denier")
                principal=self.add(lab,"Actor","principal","principal")
                scope=self.add(lab,"Scope","scope","scope")
                target=self.add(lab,"Candidate","target","target")
                basis=self.add(lab,"Evidence","basis","basis",epistemic="OBSERVED")
                root=lab.establish_authority_root(
                    context_id=ctx,scope_id=scope,operations=["INSPECT"],
                    holder_actor_id=owner,max_delegation_depth=1,
                    provenance_class="USER",provenance="orbital-user"
                )
                # Valid root grant.
                lab.grant_authorization(
                    context_id=ctx,entity_id=target,operation="INSPECT",scope_id=scope,
                    issuer_authority_id=root,issuer_actor_id=owner,principal_id=principal,
                    basis_entity_ids=[basis],reason="allow",
                    provenance_class="TEST",provenance="orbital-gan"
                )
                delegated=lab.delegate_authority(
                    parent_authority_id=root,grantee_id=denier,scope_id=scope,
                    operations=["INSPECT"],max_delegation_depth=0,reason="bounded denier",
                    provenance_class="TEST",provenance="orbital-gan"
                )
                lab.grant_authorization(
                    context_id=ctx,entity_id=target,operation="INSPECT",scope_id=scope,
                    issuer_authority_id=delegated,issuer_actor_id=denier,principal_id=principal,
                    basis_entity_ids=[basis],result="DENIED",reason="temporary deny",
                    provenance_class="TEST",provenance="orbital-gan"
                )
                lab.revoke_authority(
                    delegated,reason="denier authority revoked",
                    provenance_class="TEST",provenance="orbital-gan"
                )
                auth=lab.check_authorized(
                    context_id=ctx,actor_id=principal,entity_id=target,
                    operation="INSPECT",scope_id=scope
                )
                # With denier gone, the older still-live root grant should be visible.
                if not auth["authorized"] and auth["reason"]=="explicit denial":
                    return Finding(
                        orbit="authority",
                        invariant="revoked issuer's denial is no longer exercisable",
                        signature="AUTH:REVOKED_DENIAL_STILL_BLOCKS",
                        detail="revoked delegated denier continued to override live root grant",
                        genome=genome,accepted_by_api=True,audit_passed=lab.alpha_audit()["passed"]
                    )
                self.controls_passed += 1
                return None
            finally:
                lab.close()

    def schema_definition_drift_trial(self, genome: dict):
        with tempfile.TemporaryDirectory() as td:
            lab=OrbitLab(Path(td)/"t.db")
            try:
                ctx=self.add(lab,"Context","schema ctx","ctx")
                actor=self.add(lab,"Actor","owner","actor")
                scope=self.add(lab,"Scope","schema","scope")
                frame=self.add(lab,"ValidityFrame","frame","frame",data={"conditions":{"k":"v"}})
                witness=self.add(lab,"Evidence","witness","w",epistemic="OBSERVED")
                gap=lab.record_schema_gap(gap_kind="LANGUAGE_COLLISION",current_term="Candidate",
                    missing_distinction="definition drift target",
                    provenance_class="TEST",provenance="orbital-gan")
                proposal=lab.propose_schema_object_type(gap_id=gap,type_name="DefinitionBound",
                    definition="original earned definition",
                    provenance_class="TEST",provenance="orbital-gan")
                promotion=lab.record_promotion(context_id=ctx,entity_id=proposal,scope_id=scope,
                    validity_frame_id=frame,witness_entity_id=witness,basis_entity_ids=[witness],
                    change_claim="earned",revalidation_rule="rerun",
                    provenance_class="TEST",provenance="orbital-gan")
                root=lab.establish_authority_root(context_id=ctx,scope_id=scope,
                    operations=["SCHEMA_CHANGE"],holder_actor_id=actor,
                    provenance_class="USER",provenance="orbital-user")
                lab.grant_authorization(context_id=ctx,entity_id=proposal,operation="SCHEMA_CHANGE",
                    scope_id=scope,issuer_authority_id=root,issuer_actor_id=actor,
                    principal_id=actor,basis_entity_ids=[witness,promotion],reason="governed",
                    provenance_class="TEST",provenance="orbital-gan")
                lab.apply_schema_object_type(proposal_id=proposal,promotion_episode_id=promotion,
                    context_id=ctx,actor_id=actor,scope_id=scope,reason="apply",
                    provenance_class="TEST",provenance="orbital-gan")
                lab.conn.execute(
                    "UPDATE schema_terms SET definition='silently mutated definition' WHERE name='DefinitionBound'"
                )
                lab.conn.commit()
                audit=lab.alpha_audit()
                if audit["passed"]:
                    return Finding(
                        orbit="schema",
                        invariant="runtime schema definition remains bound to promoted proposal",
                        signature="SCHEMA:AUDIT_MISSES_DEFINITION_DRIFT",
                        detail="schema_terms.definition changed after promotion; alpha_audit still passed",
                        genome=genome,accepted_by_api=False,audit_passed=True
                    )
                self.controls_passed += 1
                return None
            finally:
                lab.close()

    def scope_topology_corruption_trial(self, genome: dict):
        with tempfile.TemporaryDirectory() as td:
            lab=OrbitLab(Path(td)/"t.db")
            try:
                a=self.add(lab,"Scope","A","a")
                b=self.add(lab,"Scope","B","b")
                lab.link_scope(a,b)
                # Storage adversary bypasses link_scope cycle check.
                lab.conn.execute(
                    "INSERT INTO scope_edges(parent_scope_id,child_scope_id,created_at) VALUES(?,?,datetime('now'))",
                    (b,a)
                )
                lab.conn.commit()
                audit=lab.alpha_audit()
                if audit["passed"]:
                    return Finding(
                        orbit="scope",
                        invariant="scope containment graph remains acyclic",
                        signature="SCOPE:AUDIT_MISSES_CYCLE",
                        detail="direct persistence corruption introduced A<->B containment cycle; audit passed",
                        genome=genome,accepted_by_api=False,audit_passed=True
                    )
                self.controls_passed += 1
                return None
            finally:
                lab.close()


    def weak_promotion_witness_trial(self, genome: dict):
        with tempfile.TemporaryDirectory() as td:
            lab=OrbitLab(Path(td)/"t.db")
            try:
                ctx=self.add(lab,"Context","promotion world","ctx")
                scope=self.add(lab,"Scope","scope","scope")
                candidate=self.add(lab,"Candidate","candidate","candidate")
                frame=self.add(lab,"ValidityFrame","frame","frame",data={"conditions":{"domain":"D"}})
                weak=self.add(lab,"Evidence","unobserved evidence placeholder","weak",epistemic="UNKNOWN")
                accepted=False
                try:
                    lab.record_promotion(
                        context_id=ctx,entity_id=candidate,scope_id=scope,
                        validity_frame_id=frame,witness_entity_id=weak,basis_entity_ids=[weak],
                        change_claim="persistent change",revalidation_rule="retest",
                        provenance_class="TEST",provenance="orbital-gan"
                    )
                    accepted=True
                except (TypeError,ValueError,PermissionError):
                    pass
                if accepted:
                    return Finding(
                        orbit="epistemic",
                        invariant="persistent promotion requires an epistemically adequate witness",
                        signature="EPISTEMIC:UNKNOWN_EVIDENCE_PROMOTES",
                        detail="Evidence with epistemic=UNKNOWN was accepted as promotion witness",
                        genome=genome,accepted_by_api=True,audit_passed=lab.alpha_audit()["passed"]
                    )
                self.controls_passed+=1
                return None
            finally:
                lab.close()

    def failed_execution_promotion_trial(self, genome: dict):
        with tempfile.TemporaryDirectory() as td:
            lab=OrbitLab(Path(td)/"t.db")
            try:
                ctx=self.add(lab,"Context","execution promotion world","ctx")
                scope=self.add(lab,"Scope","scope","scope")
                candidate=self.add(lab,"Candidate","candidate","candidate")
                frame=self.add(lab,"ValidityFrame","validity","vf",data={"conditions":{"domain":"D"}})

                run=self.add(lab,"RunIdentity","run","run")
                probe=self.add(lab,"Probe","probe","probe")
                obs_frame=self.add(lab,"ObservationFrame","obs frame","of",data={
                    "observer":"gan","apparatus":"sim","accessible_variables":["y"],
                    "resolution":"1","intervention":"none","boundary":"test"})
                params=self.add(lab,"Parameters","params","params",data={})
                reset=self.add(lab,"Artifact","reset","reset")
                obs=self.add(lab,"Observation","tool failed","obs",epistemic="OBSERVED")
                execution=lab.record_execution(
                    run_id=run,probe_id=probe,frame_id=obs_frame,parameters_id=params,
                    reset_id=reset,observation_ids=[obs],status="TOOL_FAILED",
                    provenance_class="TEST",provenance="orbital-gan"
                )
                accepted=False
                try:
                    lab.record_promotion(
                        context_id=ctx,entity_id=candidate,scope_id=scope,
                        validity_frame_id=frame,witness_entity_id=execution,basis_entity_ids=[obs],
                        change_claim="persistent change from failed run",revalidation_rule="retest",
                        provenance_class="TEST",provenance="orbital-gan"
                    )
                    accepted=True
                except (TypeError,ValueError,PermissionError):
                    pass
                if accepted:
                    return Finding(
                        orbit="epistemic",
                        invariant="failed/confounded execution cannot certify persistent promotion",
                        signature="EPISTEMIC:FAILED_EXECUTION_PROMOTES",
                        detail="TOOL_FAILED EXECUTION was accepted as promotion witness",
                        genome=genome,accepted_by_api=True,audit_passed=lab.alpha_audit()["passed"]
                    )
                self.controls_passed+=1
                return None
            finally:
                lab.close()

    def legacy_launch_trial(self, genome: dict):
        with tempfile.TemporaryDirectory() as td:
            lab=OrbitLab(Path(td)/"t.db")
            try:
                x=self.add(lab,"Candidate","native candidate","x")
                accepted=False
                try:
                    lab.launch(x,reason="legacy direct activation")
                    accepted=(lab.get(x).lifecycle=="ACTIVE")
                except PermissionError:
                    pass
                if accepted:
                    return Finding(
                        orbit="compatibility",
                        invariant="work activation passes through the current authority model",
                        signature="COMPAT:LEGACY_LAUNCH_BYPASSES_AUTHORITY",
                        detail="legacy launch() activated a Candidate with no Context/Actor/Scope authorization",
                        genome=genome,accepted_by_api=True,audit_passed=lab.alpha_audit()["passed"]
                    )
                self.controls_passed+=1
                return None
            finally:
                lab.close()

    def current_slot_corruption_trial(self, genome: dict):
        with tempfile.TemporaryDirectory() as td:
            lab=OrbitLab(Path(td)/"t.db")
            try:
                wrong=self.add(lab,"Candidate","not a Subject","wrong")
                # Direct persistence corruption: bypass pin() type check.
                lab.conn.execute("INSERT INTO current_slots(slot,object_id) VALUES('subject',?)",(wrong,))
                lab.conn.commit()
                audit=lab.alpha_audit()
                if audit["passed"]:
                    return Finding(
                        orbit="state",
                        invariant="alpha audit validates Current slot type/limits",
                        signature="STATE:AUDIT_MISSES_CURRENT_SLOT_TYPE",
                        detail="Candidate inserted into subject slot by persistence corruption; audit passed",
                        genome=genome,accepted_by_api=False,audit_passed=True
                    )
                self.controls_passed+=1
                return None
            finally:
                lab.close()

    def run(self, rounds: int = 120) -> dict:
        generators: list[tuple[str, Callable[[dict], Optional[Finding]]]] = [
            ("authority_revocation", self.authority_revocation_trial),
            ("authority_expiry", self.authority_expiry_trial),
            ("revoked_issuer_grant", self.revoked_issuer_grant_trial),
            ("schema_audit", self.schema_audit_trial),
            ("authorize_wildcard", self.authorize_wildcard_trial),
            ("revoked_denial", self.revoked_denial_trial),
            ("schema_definition_drift", self.schema_definition_drift_trial),
            ("scope_topology_corruption", self.scope_topology_corruption_trial),
            ("weak_promotion_witness", self.weak_promotion_witness_trial),
            ("failed_execution_promotion", self.failed_execution_promotion_trial),
            ("legacy_launch", self.legacy_launch_trial),
            ("current_slot_corruption", self.current_slot_corruption_trial),
            ("association_control", self.association_control_trial),
            ("lineage_control", self.lineage_control_trial),
        ]
        wins={name:0 for name,_ in generators}
        for i in range(rounds):
            name,fn=self.rng.choice(generators)
            genome={
                "generation":i,
                "depth":self.rng.choice([1,2,3]),
                "revoke_index":0,
                "mutation":self.rng.randrange(1_000_000),
            }
            if genome["depth"] >= 1:
                genome["revoke_index"]=self.rng.randrange(0, genome["depth"])
            self.trials += 1
            try:
                finding=fn(genome)
                if finding and self.archive.add(finding):
                    wins[name]+=1
            except Exception as e:
                sig=f"HARNESS:{name}:{type(e).__name__}:{str(e)[:80]}"
                self.archive.add(Finding(
                    orbit="harness",invariant="harness executes valid scenario",
                    signature=sig,detail=traceback.format_exc(limit=3),
                    genome=genome,accepted_by_api=False,audit_passed=None
                ))

        findings=[asdict(x) for x in self.archive.list()]
        scientific=[f for f in findings if f["orbit"]!="harness"]
        return {
            "name":"Orbital GANs alpha pressure run",
            "seed":self.seed,
            "trials":self.trials,
            "controls_passed":self.controls_passed,
            "novel_findings":len(scientific),
            "generator_wins":wins,
            "findings":scientific,
            "harness_errors":[f for f in findings if f["orbit"]=="harness"],
        }

def main():
    gan=OrbitalGAN()
    print(json.dumps(gan.run(rounds=340),indent=2,sort_keys=True))

if __name__=="__main__":
    main()
