from __future__ import annotations
import argparse, json, tempfile
from pathlib import Path
from collections import defaultdict
from orbit_lab import OrbitLab

BASE=Path(__file__).resolve().parent
DATA=BASE/'data'/'research_connections.json'
ALLOWED_STATUS={'QUARANTINED'}
ALLOWED_KINDS={'PRESSURES','SUPPORTS_TEST_DESIGN','PROVIDES_COUNTEREXAMPLE','PROVIDES_RECOVERY_PATTERN','PROVIDES_GENERATOR','HISTORY_ONLY'}

class ConnectionMap:
    def __init__(self,path: str|Path=DATA):
        self.path=Path(path)
        self.data=json.loads(self.path.read_text(encoding='utf-8'))
        self.validate()

    @property
    def branches(self): return self.data['branches']

    def validate(self):
        ids=set()
        components=set(self.data['components'])
        for b in self.data['branches']:
            if b['id'] in ids: raise ValueError(f"duplicate branch id: {b['id']}")
            ids.add(b['id'])
            if b['status'] not in ALLOWED_STATUS: raise ValueError(f"branch must remain quarantined: {b['id']}")
            if not b['source'].startswith('/Orbit Lab/Incoming/'):
                raise ValueError(f"source must point to controlled Incoming copy: {b['id']}")
            if not b.get('connections'): raise ValueError(f"branch has no connection/history route: {b['id']}")
            for c in b['connections']:
                if c['component'] not in components: raise ValueError(f"unknown component: {c['component']}")
                if c['kind'] not in ALLOWED_KINDS: raise ValueError(f"unknown connection kind: {c['kind']}")
                if not c.get('why','').strip(): raise ValueError(f"connection needs why: {b['id']}")
        return True

    def by_component(self):
        out=defaultdict(list)
        for b in self.branches:
            for c in b['connections']:
                out[c['component']].append((b,c))
        return out

    def summary(self):
        groups=self.by_component()
        lines=['CONNECTED RESEARCH','==================',
               f"{len(self.branches)} recovered branches are mapped as quarantined review input.",
               'Connections are navigation/test pressure only; they do not transfer evidence or authority.','']
        for component in self.data['components']:
            items=groups.get(component,[])
            if not items: continue
            names=', '.join(b['name'] for b,_ in items)
            lines.append(f"{component}: {names}")
        return '\n'.join(lines)

    def why(self,component: str):
        component=component.strip().lower().replace('_','-')
        groups=self.by_component()
        if component not in groups:
            choices=', '.join(sorted(groups))
            raise ValueError(f"unknown connected area; choose one of: {choices}")
        lines=[f"WHY: {component}",'='*(5+len(component))]
        for b,c in groups[component]:
            lines.append(f"• {b['name']} [{c['kind']}]")
            lines.append(f"  {c['why']}")
            if b.get('does_not_establish'):
                lines.append('  Does not establish: '+ '; '.join(b['does_not_establish']))
        lines += ['', 'These are candidate connections with separate provenance, not merged claims.']
        return '\n'.join(lines)

    def _existing_complete_seed(self, lab):
        expected={
            'connections:subject','connections:obligation','connections:boundary','connections:scope',
            *{f'connections:component:{c}' for c in self.data['components']},
            *{f"connections:collection:{b['id']}" for b in self.branches},
            *{f"connections:source:{b['id']}" for b in self.branches},
            *{f"connections:{b['id']}:{i}" for b in self.branches for i,_ in enumerate(b['connections'])},
        }
        object_rows=lab.conn.execute(
            "SELECT id, identity_key FROM objects WHERE identity_key IS NOT NULL"
        ).fetchall()
        episode_rows=lab.conn.execute(
            "SELECT id, identity_key FROM episodes WHERE identity_key IS NOT NULL"
        ).fetchall()
        by_key={r['identity_key']:r['id'] for r in [*object_rows,*episode_rows]}
        present=expected & set(by_key)
        if not present:
            return None
        if present != expected:
            missing=sorted(expected-present)
            raise RuntimeError(
                'partial connected-research seed detected; preserve/recover rather than silently reseed; '
                f'missing identity keys: {missing}'
            )
        sources={b['id']:by_key[f"connections:source:{b['id']}"] for b in self.branches}
        associations=[by_key[f"connections:{b['id']}:{i}"] for b in self.branches for i,_ in enumerate(b['connections'])]
        return {
            'subject':by_key['connections:subject'],
            'sources':sources,
            'associations':associations,
            'stats':lab.stats(),
            'audit':lab.alpha_audit(),
        }

    def seed(self,db_path: str|Path):
        lab=OrbitLab(db_path)
        try:
            existing=self._existing_complete_seed(lab)
            if existing is not None:
                return existing
            subject=lab.add('Subject','Review connected recovered research without inherited authority',
                            provenance_class='CURRENT_CONVERSATION',provenance='connections.py',identity_key='connections:subject',lifecycle='ACTIVE')
            obligation=lab.add('Obligation','Keep source boundaries and admit only action-relevant verified imports',
                               provenance_class='CURRENT_CONVERSATION',provenance='connections.py',identity_key='connections:obligation',lifecycle='ACTIVE')
            boundary=lab.add('Boundary','Connection or copying does not transfer evidence authority applicability or activation',
                             provenance_class='CURRENT_CONVERSATION',provenance='connections.py',identity_key='connections:boundary',lifecycle='ACTIVE')
            lab.pin('subject',subject); lab.pin('obligation',obligation); lab.pin('boundary',boundary)
            scope=lab.add('Scope','Incoming research review',provenance_class='CURRENT_CONVERSATION',provenance='connections.py',identity_key='connections:scope')
            targets={}
            for component in self.data['components']:
                targets[component]=lab.add('Artifact',f'Orbit Lab component: {component}',
                    data={'component':component,'current_component_reference':True},
                    provenance_class='CURRENT_CONVERSATION',provenance='connections.py',identity_key=f'connections:component:{component}')
            source_ids={}
            association_ids=[]
            for b in self.branches:
                collection=lab.add('Collection',b['name'],data={'branch_id':b['id'],'source':b['source']},
                    provenance_class='RECOVERY_PACKET',provenance=b['source'],identity_key=f"connections:collection:{b['id']}")
                source=lab.add('Artifact',b['name'],data={
                        'branch_id':b['id'],'source':b['source'],'roles':b['roles'],
                        'contributes':b['contributes'],'does_not_establish':b['does_not_establish'],
                        'connection_status':'CANDIDATE_ONLY'},
                    provenance_class='RECOVERY_PACKET',provenance=b['source'],identity_key=f"connections:source:{b['id']}",lifecycle='QUARANTINED')
                lab.add_to_collection(collection,source,note='controlled Incoming source; quarantined')
                source_ids[b['id']]=source
                for i,c in enumerate(b['connections']):
                    ep=lab.record_association(source_entity_id=source,target_entity_id=targets[c['component']],scope_id=scope,
                        relation=c['kind'],resolution_status='LOGICAL_ARTIFACT_ID',provenance_class='DERIVED',provenance='connections.py',
                        identity_key=f"connections:{b['id']}:{i}",note=c['why'])
                    association_ids.append(ep)
            return {'subject':subject,'sources':source_ids,'associations':association_ids,'stats':lab.stats(),'audit':lab.alpha_audit()}
        finally:
            lab.close()

    def check(self):
        with tempfile.TemporaryDirectory() as td:
            result=self.seed(Path(td)/'connections.db')
            lab=OrbitLab(Path(td)/'connections.db')
            try:
                source_status={bid:lab.admission_status(oid)['status'] for bid,oid in result['sources'].items()}
                assoc=[]
                for eid in result['associations']:
                    ep=lab.episode(eid)
                    assoc.append(ep['data'])
                return {
                    'passed':result['audit']['passed'] and all(v=='QUARANTINED' for v in source_status.values())
                             and all(x.get('evidence_effect')=='NONE' and x.get('authority_effect')=='NONE'
                                     and x.get('applicability_effect')=='NONE' for x in assoc),
                    'branches':len(result['sources']),
                    'associations':len(result['associations']),
                    'all_quarantined':all(v=='QUARANTINED' for v in source_status.values()),
                    'all_non_evidentiary':all(x.get('evidence_effect')=='NONE' for x in assoc),
                    'audit_passed':result['audit']['passed']
                }
            finally: lab.close()

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--why')
    p.add_argument('--check',action='store_true')
    p.add_argument('--seed')
    args=p.parse_args()
    m=ConnectionMap()
    if args.check: print(json.dumps(m.check(),indent=2,sort_keys=True)); return
    if args.seed: print(json.dumps(m.seed(args.seed),indent=2,sort_keys=True,default=str)); return
    if args.why: print(m.why(args.why)); return
    print(m.summary())

if __name__=='__main__': main()
