
import tempfile
from pathlib import Path
import unittest
from orbit_lab import OrbitLab

class V21Tests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.lab=OrbitLab(Path(self.tmp.name)/"t.db")
    def tearDown(self):
        self.lab.close(); self.tmp.cleanup()
    def add(self,t,title,key,**kw):
        return self.lab.add(t,title,provenance_class="TEST",provenance="test",identity_key=key,**kw)

    def test_structural_validity_and_method_compliance_coexist(self):
        c=self.add("Context","Recovery context","c")
        s=self.add("Scope","Recovery","s")
        old=self.add("Method","CFV1","old")
        packet=self.add("Artifact","schema-valid packet","packet",data={"schema_valid":True})
        basis=self.add("Evidence","method status record","e",epistemic="OBSERVED")
        ep=self.lab.assess_method_compliance(
            context_id=c,entity_id=packet,method_id=old,scope_id=s,
            verdict="WRONG_METHOD",basis_entity_ids=[basis],
            reason="schema-valid but non-current method",
            provenance_class="TEST",provenance="test")
        self.assertTrue(self.lab.get(packet).data["schema_valid"])
        self.assertEqual(self.lab.episode(ep)["data"]["verdict"],"WRONG_METHOD")

    def test_replacement_is_scope_local(self):
        recovery=self.add("Scope","Recovery","recovery")
        science=self.add("Scope","Science","science")
        old=self.add("Method","Old recovery method","old")
        new=self.add("Method","New recovery method","new")
        basis=self.add("Evidence","replacement status","e",epistemic="OBSERVED")
        ep=self.lab.record_replacement(
            predecessor_entity_id=old,successor_entity_id=new,scope_id=recovery,
            relation="AUTHORITY_REPLACEMENT",basis_entity_ids=[basis],
            reason="new method governs recovery only",
            provenance_class="TEST",provenance="test")
        scopes=self.lab.episode_role_ids(ep,"scope")
        self.assertEqual(scopes,[recovery])
        self.assertEqual(self.lab.get(old).lifecycle,"DORMANT")
        self.assertFalse(self.lab.scope_contains(recovery, science))

if __name__=="__main__":
    unittest.main()
