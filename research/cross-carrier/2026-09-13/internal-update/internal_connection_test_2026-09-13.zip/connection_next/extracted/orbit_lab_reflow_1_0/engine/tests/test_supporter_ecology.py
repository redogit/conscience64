
import unittest
from supporters.ecology import SupporterEcology

class SupporterEcologyTests(unittest.TestCase):
    def test_ecology_runs(self):
        r=SupporterEcology().run()
        self.assertEqual(len(r["signals"]),16)

    def test_pareto_keeps_incomparable_plans(self):
        plans=[
            {"name":"a","physical":2,"compute":1,"latency":3,"human":1},
            {"name":"b","physical":1,"compute":3,"latency":1,"human":1},
        ]
        self.assertEqual(len(SupporterEcology.pareto_front(plans)),2)

if __name__=="__main__":
    unittest.main()
