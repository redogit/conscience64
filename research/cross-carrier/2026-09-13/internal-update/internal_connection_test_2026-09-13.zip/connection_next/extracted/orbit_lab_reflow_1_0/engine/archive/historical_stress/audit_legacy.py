from __future__ import annotations
from pathlib import Path
import json, subprocess, sys, tempfile

BASE=Path(__file__).resolve().parent
MANIFEST=json.loads((BASE/'historical_stress_manifest.json').read_text())
EXPECTED=MANIFEST['expected_stale']
SCRIPTS=sorted(set(p.name for p in BASE.glob('*_stress.py')) | {'stress_research.py'})

def run_one(name: str):
    with tempfile.TemporaryDirectory() as td:
        p=subprocess.run([sys.executable,str(BASE/name)],cwd=td,text=True,capture_output=True,timeout=30)
    combined=p.stdout+'\n'+p.stderr
    if p.returncode==0:
        return {'file':name,'status':'PASS','rc':0}
    expected=EXPECTED.get(name)
    if expected and expected in combined:
        return {'file':name,'status':'EXPECTED_STALE','rc':p.returncode,'reason':expected}
    return {'file':name,'status':'UNEXPECTED_FAILURE','rc':p.returncode,'tail':combined[-1800:]}

def main():
    results=[run_one(x) for x in SCRIPTS]
    active=[]
    for name in MANIFEST.get('active_loader',[]):
        with tempfile.TemporaryDirectory() as td:
            p=subprocess.run([sys.executable,str(BASE/name)],cwd=td,text=True,capture_output=True,timeout=30)
        active.append({'file':name,'status':'PASS' if p.returncode==0 else 'FAIL','rc':p.returncode,'tail':(p.stdout+'\n'+p.stderr)[-1200:]})
    out={
        'historical_total':len(results),
        'historical_pass':sum(x['status']=='PASS' for x in results),
        'historical_expected_stale':sum(x['status']=='EXPECTED_STALE' for x in results),
        'historical_unexpected_failures':[x for x in results if x['status']=='UNEXPECTED_FAILURE'],
        'active_loaders':active,
        'passed':not any(x['status']=='UNEXPECTED_FAILURE' for x in results) and all(x['status']=='PASS' for x in active),
        'results':results,
    }
    print(json.dumps(out,indent=2,sort_keys=True))
    if not out['passed']:
        raise SystemExit(1)

if __name__=='__main__':
    main()
