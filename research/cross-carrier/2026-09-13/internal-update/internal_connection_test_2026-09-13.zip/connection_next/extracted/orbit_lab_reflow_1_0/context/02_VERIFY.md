# Verify — Evidence, Authority, and Claim Boundaries

Verification answers one question:

> What is this result actually allowed to support?

## Qualification order

```text
identity
→ provenance
→ source role
→ evidence kind
→ method/context/scope
→ obligation/dependency coverage
→ claim boundary
→ audit / regression when promotion matters
```

## Hard distinctions

```text
observation != interpretation != decision
source != execution
specification != measured behavior
simulation != physical measurement
association != evidence
related != supports
lookup != evidence
retrieval != proof
transfer != authorization
historical relevance != current authority
same label != same run identity
not found in bounded search != never existed
agreement/consensus != grounding
finite success != universal guarantee
```

## Promotion

A candidate may be generated aggressively. It becomes Current only when the relevant verifier path passes and
promotion is actually authorized. A later change in method status, source role, dependency state, or evidence custody
may invalidate a previously supported claim; audit must be able to expose that drift.

## Release verification

The contained Alpha 0.26 engine was re-run during this reflow:

- 209/209 unit/regression tests PASS in the current environment;
- the previous promotion record reports 33 components / 133 declared obligations with no unresolved selector obligation;
- the known post-output host-wrapper linger remains an orchestration boundary, not a scientific result.

Reflow 1.0 changes active context organization, not those underlying scientific results.
