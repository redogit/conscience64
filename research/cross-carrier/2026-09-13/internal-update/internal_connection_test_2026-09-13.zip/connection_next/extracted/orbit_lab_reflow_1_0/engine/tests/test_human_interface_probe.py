import tempfile
from pathlib import Path
import unittest

from checks.human_interface_probe import raw_path, human_path

class HumanInterfaceProbeTests(unittest.TestCase):
    def test_three_action_surface_preserves_semantics_and_hides_ids(self):
        with tempfile.TemporaryDirectory() as td:
            td=Path(td)
            raw=raw_path(td/'raw.db')
            human=human_path(td/'human.db')
            self.assertEqual(raw,{k:human[k] for k in ('subject','observation','inference')})
            self.assertNotIn(human['subject_id'],human['card'])

if __name__=='__main__': unittest.main()
