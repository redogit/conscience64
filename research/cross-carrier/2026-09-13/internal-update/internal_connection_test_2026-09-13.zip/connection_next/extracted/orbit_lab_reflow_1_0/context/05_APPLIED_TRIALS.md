# Applied Trials from This Conversation

These are not one scientific theory. They are examples of the same work/verify/library discipline applied to different needs.

## Mathematics check

The conversation explicitly asked whether Orbit can do math. The surviving answer is operational: yes—mathematical derivation,
calculation, finite checking, and model comparison are helpers inside the Research Card/verifier loop. Mathematical correctness
is kept separate from empirical grounding and application authority.

## Ethics-first use

The user made ethics primary. Orbit therefore treats ethics as a plan/work/result constraint capable of changing or rejecting
an action. It does not turn moral orientation into empirical evidence.

## Small free web game

The conversation used a simple public/free web-game request as a low-stakes practical trial. It did not force a new kernel concept,
so it remains an application example rather than architecture.

## Low-attention $20 penny-stock research

Goal: reduce how much attention money requires, not maximize activity.

Historical development replay:

- starting cash: $20;
- monthly review;
- 3-month positive momentum selection;
- one-month holding period;
- modeled 0.5% one-way friction;
- missing next exchange-listed price written to zero in the stress model;
- collect 50% of cash above $20 after monthly liquidation;
- existing sleeve drawdown brake: -20%.

Result for the original two-slot $10/$10 version:

- ending active account: $15.61;
- collected cash: $21.91;
- account + collected: $37.52;
- maximum drawdown: -53.3%;
- verdict: FAIL against the pre-existing -20% brake.

One-slot $10 and $5 variants still breached the brake. A post-hoc $4 exposure landed near the boundary under one modeled cost
and failed when friction increased, so it remained a candidate rather than a rule. No live-trading promotion was supported.

Earned distinction:

```text
monthly withdrawal != principal protection
```

## GDSN work helper

GDSN was added because the user encounters it at work. The helper is deliberately task-local and privacy-preserving.
It can organize troubleshooting without automatically storing production details in research history.

## Library fold and support finder

The conversation then shifted from importing more material to making the Library useful without bulk-loading it.
This produced the staged fold and support-finding capability now central to Reflow 1.0.
