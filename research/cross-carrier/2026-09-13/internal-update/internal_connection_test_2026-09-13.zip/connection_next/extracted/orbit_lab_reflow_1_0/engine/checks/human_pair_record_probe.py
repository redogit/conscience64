from __future__ import annotations
import json, tempfile, sys
from pathlib import Path
BASE=Path(__file__).resolve().parents[1]
if str(BASE) not in sys.path: sys.path.insert(0,str(BASE))
from human_lab import HumanLab, dispatch

def run():
    with tempfile.TemporaryDirectory() as td:
        h=HumanLab(Path(td)/'pair.db')
        try:
            dispatch(h,['start','Does the changed condition alter the measured outcome?'])
            dispatch(h,['need','Preserve both raw condition outcomes before deriving comparison or interpretation.'])
            dispatch(h,['limit','Scope S = this bounded paired-condition trial; no causal claim beyond the comparison.'])
            dispatch(h,['try','Compare C0 = baseline with C1 = changed condition using measure M = score.'])
            dispatch(h,['saw','Y0 under C0 = 10.'])
            dispatch(h,['saw','Y1 under C1 = 13.'])
            cmp_id=h.compare('D = Y1 - Y0 = +3.')
            thought_id=h.think('The changed condition may improve the score in this bounded setup.')
            scan=h.lab.scan(); cmp=h.lab.get(cmp_id); thought=h.lab.get(thought_id)
            graph=h.lab.graph(cmp_id)
            derived=[r for r in graph['outgoing'] if r['kind']=='DERIVED_FROM']
            card=h.card(); reasoning=h.recent_thoughts(limit=10)
            passed=(len(scan['observation'])==2 and all(x['epistemic']=='OBSERVED' for x in scan['observation'])
                    and cmp.type=='Inference' and cmp.data.get('human_surface')=='Comparison'
                    and thought.data.get('human_surface')=='Thought' and len(derived)==2
                    and 'Comparison:' in reasoning and 'Thought:' in reasoning
                    and cmp_id not in card and thought_id not in card)
            return {
                'passed':passed,
                'observations':[(x['title'],x['epistemic']) for x in scan['observation']],
                'comparison_type':cmp.type,
                'comparison_surface':cmp.data.get('human_surface'),
                'comparison_sources':len(derived),
                'thought_surface':thought.data.get('human_surface'),
                'raw_ids_visible_on_card':cmp_id in card or thought_id in card,
                'reasoning_view':reasoning,
                'claim':'The human surface can preserve raw paired observations, a derived comparison, and an interpretation as three distinct steps without adding a kernel schema type.'
            }
        finally: h.close()

if __name__=='__main__':
    r=run(); print(json.dumps(r,indent=2,sort_keys=True)); raise SystemExit(0 if r['passed'] else 1)
