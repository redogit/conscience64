
import tempfile
from pathlib import Path
import unittest
from orbit_lab import OrbitLab
class V17Tests(unittest.TestCase):
    def setUp(self): self.tmp=tempfile.TemporaryDirectory(); self.lab=OrbitLab(Path(self.tmp.name)/"t.db")
    def tearDown(self): self.lab.close(); self.tmp.cleanup()
    def add(self,t,title,key,**kw): return self.lab.add(t,title,provenance_class="TEST",provenance="test",identity_key=key,**kw)
    def test_scope_behavior(self):
        c=self.add("Context","C","c"); actor=self.add("Actor","A","actor"); x=self.add("Candidate","X","x"); p=self.add("Scope","P","p"); ch=self.add("Scope","C","ch"); other=self.add("Scope","O","o"); self.lab.link_scope(p,ch); e=self.add("Evidence","e","e",epistemic="OBSERVED")
        root=self.lab.establish_authority_root(context_id=c,scope_id=p,operations=["INSPECT"],holder_actor_id=actor,provenance_class="USER",provenance="user")
        self.lab.grant_authorization(context_id=c,entity_id=x,operation="INSPECT",scope_id=p,issuer_authority_id=root,issuer_actor_id=actor,principal_id=actor,basis_entity_ids=[e],reason="parent",provenance_class="TEST",provenance="test")
        self.assertTrue(self.lab.check_authorized(context_id=c,actor_id=actor,entity_id=x,operation="INSPECT",scope_id=ch)["authorized"])
        self.assertFalse(self.lab.check_authorized(context_id=c,actor_id=actor,entity_id=x,operation="INSPECT",scope_id=other)["authorized"])
    def test_scope_cycle_rejected(self):
        a=self.add("Scope","A","a"); b=self.add("Scope","B","b"); self.lab.link_scope(a,b)
        with self.assertRaises(ValueError): self.lab.link_scope(b,a)
if __name__=="__main__": unittest.main()
