from __future__ import annotations
from pathlib import Path
import json, os, subprocess, sys, tempfile

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
MANIFEST=json.loads((HERE/'manifest.json').read_text())
EXPECTED=MANIFEST['expected_stale']
SCRIPTS=sorted(p.name for p in HERE.glob('*_stress.py'))
if (HERE/'stress_research.py').exists():
    SCRIPTS.append('stress_research.py')

def env():
    e=os.environ.copy()
    old=e.get('PYTHONPATH','')
    e['PYTHONPATH']=str(ROOT)+(os.pathsep+old if old else '')
    return e

def run_one(name: str):
    with tempfile.TemporaryDirectory() as td:
        p=subprocess.run([sys.executable,str(HERE/name)],cwd=td,text=True,capture_output=True,
                         timeout=30,env=env())
    combined=p.stdout+'\n'+p.stderr
    if p.returncode==0:
        return {'file':name,'status':'PASS','rc':0}
    expected=EXPECTED.get(name)
    if expected and expected in combined:
        return {'file':name,'status':'EXPECTED_STALE','rc':p.returncode,'reason':expected}
    return {'file':name,'status':'UNEXPECTED_FAILURE','rc':p.returncode,'tail':combined[-1800:]}

def run_active_loader(name: str):
    with tempfile.TemporaryDirectory() as td:
        p=subprocess.run([sys.executable,str(ROOT/name)],cwd=td,text=True,capture_output=True,
                         timeout=30,env=env())
    return {'file':name,'status':'PASS' if p.returncode==0 else 'FAIL','rc':p.returncode,
            'tail':(p.stdout+'\n'+p.stderr)[-1200:]}

def run_audit():
    results=[run_one(x) for x in SCRIPTS]
    active=[run_active_loader(x) for x in MANIFEST.get('active_loader',[])]
    return {
        'historical_total':len(results),
        'historical_pass':sum(x['status']=='PASS' for x in results),
        'historical_expected_stale':sum(x['status']=='EXPECTED_STALE' for x in results),
        'historical_unexpected_failures':[x for x in results if x['status']=='UNEXPECTED_FAILURE'],
        'active_loaders':active,
        'passed':not any(x['status']=='UNEXPECTED_FAILURE' for x in results)
                 and all(x['status']=='PASS' for x in active),
        'results':results,
    }

def main():
    out=run_audit()
    print(json.dumps(out,indent=2,sort_keys=True))
    if not out['passed']:
        raise SystemExit(1)

if __name__=='__main__':
    main()
