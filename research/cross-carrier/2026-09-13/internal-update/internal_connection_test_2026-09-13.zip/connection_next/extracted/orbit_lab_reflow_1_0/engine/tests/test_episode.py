
import tempfile, sqlite3
from pathlib import Path
import unittest
from orbit_lab import OrbitLab

class EpisodeTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.lab=OrbitLab(Path(self.tmp.name)/"t.db")
    def tearDown(self):
        self.lab.close(); self.tmp.cleanup()
    def add(self,t,title,key,**kw):
        return self.lab.add(t,title,provenance_class="TEST",provenance="test",identity_key=key,**kw)
    def frame(self,key):
        return self.add("ObservationFrame","frame",key,data={
            "observer":"test","apparatus":"sim","accessible_variables":["y"],
            "resolution":"fixed","intervention":"none","boundary":"test"
        })
    def execution(self,key,params=None,reset=None):
        p=self.add("Probe",key+" probe",key+"p")
        f=self.frame(key+"f")
        params=params or self.add("Parameters","shared params",key+"params",data={"lr":0.1})
        reset=reset or self.add("Artifact","reset",key+"reset")
        o=self.add("Observation",key+" obs",key+"o",epistemic="OBSERVED")
        run=self.add("RunIdentity",key+" run",key+"run"); return self.lab.record_execution(run_id=run,probe_id=p,frame_id=f,parameters_id=params,reset_id=reset,
                                         observation_ids=[o],status="COMPLETED",
                                         provenance_class="TEST",provenance="test",identity_key=key+"e")
    def test_participant_integrity(self):
        a=self.add("Artifact","a","a"); b=self.add("Artifact","b","b")
        o=self.add("Obligation","o","o"); e=self.add("Evidence","e","e")
        ep=self.lab.add_episode("FAITHFUL_TRANSPORT","transport",
            participants=[
                {"role":"source","object_id":a},{"role":"target","object_id":b},
                {"role":"obligation","object_id":o},{"role":"evidence","object_id":e}],
            provenance_class="TEST",provenance="test")
        with self.assertRaises(sqlite3.IntegrityError):
            self.lab.conn.execute("DELETE FROM objects WHERE id=?",(o,))
        self.lab.conn.rollback()
        self.assertEqual(len(self.lab.episode(ep)["participants"]),4)
    def test_counterfactual_pair_integrity(self):
        c=self.add("Candidate","link","c"); reset=self.add("Artifact","reset","reset")
        params=self.add("Parameters","params","params",data={"lr":0.1})
        frame=self.frame("sharedf")
        poff=self.add("Probe","off probe","offp"); ooff=self.add("Observation","off obs","offo",epistemic="OBSERVED")
        pon=self.add("Probe","on probe","onp"); oon=self.add("Observation","on obs","ono",epistemic="OBSERVED")
        runoff=self.add("RunIdentity","off run","runoff"); off=self.lab.record_execution(run_id=runoff,probe_id=poff,frame_id=frame,parameters_id=params,reset_id=reset,observation_ids=[ooff],status="COMPLETED",provenance_class="TEST",provenance="test")
        runon=self.add("RunIdentity","on run","runon"); on=self.lab.record_execution(run_id=runon,probe_id=pon,frame_id=frame,parameters_id=params,reset_id=reset,observation_ids=[oon],status="COMPLETED",provenance_class="TEST",provenance="test")
        result=self.add("Observation","result","result",epistemic="OBSERVED")
        ep=self.lab.add_episode("MATCHED_COUNTERFACTUAL","matched",
            participants=[
                {"role":"candidate","object_id":c},{"role":"reset","object_id":reset},
                {"role":"control","episode_id":off},{"role":"treatment","episode_id":on},
                {"role":"result","object_id":result}],
            provenance_class="TEST",provenance="test")
        with self.assertRaises(sqlite3.IntegrityError):
            self.lab.conn.execute("DELETE FROM episodes WHERE id=?",(off,))
        self.lab.conn.rollback()
        self.assertEqual(self.lab.episode(ep)["kind"],"MATCHED_COUNTERFACTUAL")
if __name__=="__main__": unittest.main()
