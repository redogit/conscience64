"""Task-local work helpers. These are not kernel ontology or scientific evidence."""
