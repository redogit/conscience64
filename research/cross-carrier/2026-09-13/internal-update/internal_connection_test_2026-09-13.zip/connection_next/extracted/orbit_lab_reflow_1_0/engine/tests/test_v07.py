
import tempfile
from pathlib import Path
import unittest
from orbit_lab import OrbitLab

class V07Tests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.lab=OrbitLab(Path(self.tmp.name)/"t.db")
    def tearDown(self):
        self.lab.close(); self.tmp.cleanup()
    def add(self,t,title,key,**kw):
        return self.lab.add(t,title,provenance_class="TEST",provenance="test",identity_key=key,**kw)

    def frame(self,key="f"):
        return self.add("ObservationFrame","frame",key,data={
            "observer":"tester",
            "apparatus":"simulator",
            "accessible_variables":["output"],
            "resolution":"1 step",
            "intervention":"none",
            "boundary":"finite panel"
        })

    def test_frame_contract(self):
        with self.assertRaises(ValueError):
            self.add("ObservationFrame","bad","bad",data={"observer":"x"})
        self.assertEqual(self.lab.get(self.frame()).type,"ObservationFrame")

    def test_claim_requires_frame_type(self):
        c=self.add("Claim","C","c")
        e=self.add("Evidence","E","e",epistemic="OBSERVED")
        a=self.add("Artifact","not frame","a")
        with self.assertRaises(TypeError):
            self.lab.assess_claim(c,frame_id=a,evidence_ids=[e],verdict="SUPPORTED",
                                  scope="x",provenance_class="TEST",provenance="test")

    def test_collection_is_not_subject(self):
        col=self.add("Collection","Micro-Ouro branch","col")
        s=self.add("Subject","Does recurrence help recall?","s")
        self.lab.add_to_collection(col,s)
        self.assertEqual(self.lab.collection_members(col)[0]["entity_id"],s)
        with self.assertRaises(TypeError):
            self.lab.pin("subject",col)

    def test_collection_can_hold_episode(self):
        c=self.add("Claim","C","c")
        f=self.frame()
        e=self.add("Evidence","E","e",epistemic="OBSERVED")
        ep=self.lab.assess_claim(c,frame_id=f,evidence_ids=[e],verdict="SUPPORTED",
                                 scope="x",provenance_class="TEST",provenance="test")
        col=self.add("Collection","Research branch","col")
        self.lab.add_to_collection(col,ep)
        self.assertEqual(self.lab.collection_members(col)[0]["entity_kind"],"EPISODE")

if __name__=="__main__":
    unittest.main()
