
import tempfile
from pathlib import Path
from orbit_lab import OrbitLab

with tempfile.TemporaryDirectory() as td:
    lab=OrbitLab(Path(td)/"stress.db")
    passes=[]; breaks=[]
    try:
        # Demonstrate replication grade can be carried separately from execution identity.
        frame=lab.add("ObservationFrame","frame",data={"observer":"team","apparatus":"same implementation","accessible_variables":["nll","latency","state"],"resolution":"run","intervention":"architecture","boundary":"byte LM test"},provenance_class="TEST",provenance="stress",identity_key="f")
        params=lab.add("Parameters","params",data={"training_positions":921600,"seeds":3},provenance_class="TEST",provenance="stress",identity_key="p")
        reset=lab.add("Artifact","initial checkpoint protocol",provenance_class="TEST",provenance="stress",identity_key="r")
        probe=lab.add("Probe","evaluate compact associative memory",provenance_class="TEST",provenance="stress",identity_key="probe")

        def run(key,nll,latency,state):
            rid=lab.add("RunIdentity",key,data={"lineage":"same-code-data"},provenance_class="PRIMARY_ARTIFACT",provenance=key,identity_key=key)
            obs=lab.add("Observation",key+" metrics",data={"nll":nll,"latency":latency,"active_state":state},provenance_class="PRIMARY_ARTIFACT",provenance=key,identity_key=key+":obs",epistemic="OBSERVED")
            return lab.record_execution(run_id=rid,probe_id=probe,frame_id=frame,parameters_id=params,reset_id=reset,observation_ids=[obs],status="COMPLETED",provenance_class="PRIMARY_ARTIFACT",provenance=key)

        e1=run("run:1",2.34,1.0,0.4)
        e2=run("run:2",2.33,1.0,0.4)
        basis=lab.add("Evidence","same implementation/data lineage; repeatability only",provenance_class="DERIVED",provenance="stress",identity_key="basis",epistemic="OBSERVED")
        lab.assess_replication(original_execution_id=e1,candidate_execution_id=e2,grade="REPEATABILITY",basis_ids=[basis],reason="new run but same lineage",provenance_class="DERIVED",provenance="stress")
        passes.append("Execution identity and replication grade are separate.")

        # Economic/minimality attack.
        obligation=lab.add("Obligation","Reduce active state without unacceptable quality or latency loss",provenance_class="TEST",provenance="stress",identity_key="ob")
        compact=lab.add("Candidate","compact associative memory",data={"active_state":0.4,"nll":2.34,"latency":1.2},provenance_class="TEST",provenance="stress",identity_key="compact")
        gru=lab.add("Candidate","GRU recurrent state",data={"active_state":1.0,"nll":2.27,"latency":0.8},provenance_class="TEST",provenance="stress",identity_key="gru")
        decision=lab.add("Decision","Choose compact because it uses less state",data={"chosen":compact},provenance_class="TEST",provenance="stress",identity_key="decision")
        breaks.append(
            "The kernel can record a Decision that calls one candidate 'better/minimal' without any declared "
            "objective vector, feasibility thresholds, ordering, or Pareto rule. Compact uses less state but "
            "loses quality and latency; 'minimal' is undefined until the comparison order is explicit."
        )

        print("V0.12 REPLICATION / ECONOMIC STRESS")
        print("----------------------------------")
        print("PASS:")
        for x in passes: print("-",x)
        print("\nNEXT BREAK:")
        for i,x in enumerate(breaks,1): print(f"{i}. {x}")
    finally:
        lab.close()
