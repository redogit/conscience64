import unittest
from checks.task_compile_probe import run as compile_run
from checks.human_interface_core_probe import run as human_run
from checks.self_verification_probe import run as self_run

class TaskVerificationSurfaceTests(unittest.TestCase):
    def test_compile_and_human_core_sentinels(self):
        self.assertTrue(compile_run()['passed'])
        self.assertTrue(human_run()['passed'])

    def test_self_verification_carrier(self):
        r=self_run()
        self.assertTrue(r['passed'])
        self.assertEqual(r['release_only_obligations'],['regression'])
        self.assertTrue(r['deleted_required_edge_refuses_pass'])

if __name__=='__main__': unittest.main()
