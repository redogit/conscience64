
from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import hashlib, json, random, struct, tempfile, zlib, sys

ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0,str(ROOT))

# Task-local requirement bits. These are not promoted to kernel ontology.
REQ_DEPENDENCIES   = 1 << 0
REQ_EVIDENCE_KIND  = 1 << 1
REQ_EVIDENCE_SET   = 1 << 2
REQ_TRANSFER_OBL   = 1 << 3
REQ_GENERATOR_ID   = 1 << 4
REQ_PHYSICAL_MEAS = 1 << 5
REQ_AUTHORITY      = 1 << 6

EPI_OBSERVED   = 1
EPI_UNKNOWN    = 2
EPI_UNRESOLVED = 3

KIND_CLAIM     = 1
KIND_TRANSFER  = 2
KIND_IDENTITY  = 3
KIND_OBSERVE   = 4

ACTION_ALLOW      = 1
ACTION_BLOCK      = 2
ACTION_KEEP_OPEN  = 3
ACTION_DISTINCT   = 4

ROW = struct.Struct("<BBBBIIIHH")
# kind, epistemic, action, flags, required_mask, satisfied_mask,
# stable_identity_hash32, provenance_ref, scope_ref

@dataclass(frozen=True)
class FullCase:
    case_id:str
    kind:str
    epistemic:str
    required:list[str]
    satisfied:list[str]
    stable_identity:str
    display_label:str
    provenance:str
    scope:str
    expected_action:str
    note:str

REQ = {
    "DEPENDENCIES":REQ_DEPENDENCIES,
    "EVIDENCE_KIND":REQ_EVIDENCE_KIND,
    "EVIDENCE_SET":REQ_EVIDENCE_SET,
    "TRANSFER_OBLIGATION":REQ_TRANSFER_OBL,
    "GENERATOR_IDENTIFICATION":REQ_GENERATOR_ID,
    "PHYSICAL_MEASUREMENT":REQ_PHYSICAL_MEAS,
    "AUTHORITY":REQ_AUTHORITY,
}
KINDS={"CLAIM":KIND_CLAIM,"TRANSFER":KIND_TRANSFER,"IDENTITY":KIND_IDENTITY,"OBSERVATION":KIND_OBSERVE}
EPIS={"OBSERVED":EPI_OBSERVED,"UNKNOWN":EPI_UNKNOWN,"UNRESOLVED":EPI_UNRESOLVED}
ACTIONS={"ALLOW":ACTION_ALLOW,"BLOCK":ACTION_BLOCK,"KEEP_OPEN":ACTION_KEEP_OPEN,"DISTINCT":ACTION_DISTINCT}
REV_ACTION={v:k for k,v in ACTIONS.items()}

def _h32(text):
    return int.from_bytes(hashlib.sha256(text.encode()).digest()[:4],"little")

def corpus():
    # Repeated provenance/scope strings are deliberate; the compiled image should
    # avoid carrying these verbosely in every active row.
    p="Orbit Lab integrated evidence lineage"
    return [
        FullCase("hodge-ok","CLAIM","OBSERVED",["DEPENDENCIES","EVIDENCE_KIND"],["DEPENDENCIES","EVIDENCE_KIND"],
                 "claim:hodge:bounded-witness","Hodge block","TBCL Hodge + Orbit Lab", "bounded theorem-backed claim","ALLOW",
                 "dependencies and evidence kind satisfied"),
        FullCase("hodge-block","CLAIM","UNRESOLVED",["DEPENDENCIES","EVIDENCE_KIND"],["EVIDENCE_KIND"],
                 "claim:hodge:algebraic","Hodge block","TBCL Hodge + Orbit Lab","terminal algebraicity","BLOCK",
                 "theorem dependency unresolved"),
        FullCase("bgzf-exact","CLAIM","OBSERVED",["EVIDENCE_KIND"],["EVIDENCE_KIND"],
                 "claim:bgzf:exact","BGZF exact carrier",p,"bounded exact carrier","ALLOW",
                 "exact evidence satisfies exact-carrier obligation"),
        FullCase("bgzf-learned","CLAIM","OBSERVED",["EVIDENCE_KIND"],[],
                 "claim:bgzf:learned-substitute","BGZF exact carrier",p,"bounded exact carrier","BLOCK",
                 "learned state cannot certify exact carrier"),
        FullCase("bridge-ok","TRANSFER","OBSERVED",["TRANSFER_OBLIGATION"],["TRANSFER_OBLIGATION"],
                 "transfer:identity-preserved","Bridge transfer",p,"destination transfer","ALLOW",
                 "declared preservation obligation satisfied"),
        FullCase("bridge-weak","TRANSFER","OBSERVED",["TRANSFER_OBLIGATION"],[],
                 "transfer:semantic-similarity-only","Bridge transfer",p,"destination transfer","BLOCK",
                 "semantic similarity is not exact identity"),
        FullCase("shadow-complete","CLAIM","OBSERVED",["EVIDENCE_SET"],["EVIDENCE_SET"],
                 "campaign:parent:S0003","S0003", "SHADOW parent campaign","bounded campaign shard","ALLOW",
                 "declared raw evidence set reconstructs"),
        FullCase("shadow-gap","CLAIM","OBSERVED",["EVIDENCE_SET"],[],
                 "campaign:parent:S0002","S0002","SHADOW parent campaign","bounded campaign shard","BLOCK",
                 "raw evidence gap prevents denominator admission"),
        FullCase("shadow-timeout","OBSERVATION","UNKNOWN",[],[],
                 "observation:timeout:11","timeout","SHADOW parent campaign","single native observation","KEEP_OPEN",
                 "timeout remains unknown rather than miss"),
        FullCase("identity-parent","IDENTITY","OBSERVED",[],[],
                 "campaign:parent:S0004","S0004","SHADOW parent campaign","campaign identity","DISTINCT",
                 "same label does not merge parent and successor identity"),
        FullCase("identity-successor","IDENTITY","OBSERVED",[],[],
                 "campaign:successor:S0004","S0004","SHADOW successor environment","development identity","DISTINCT",
                 "same label does not merge parent and successor identity"),
        FullCase("fractal-address","CLAIM","OBSERVED",["GENERATOR_IDENTIFICATION"],[],
                 "claim:fractal:generator-from-address","recursive address","Fractal Unroll + Tree/Orbit","generator identity","BLOCK",
                 "address recovery lacks generator-specific state"),
        FullCase("physical-timing","CLAIM","OBSERVED",["PHYSICAL_MEASUREMENT"],[],
                 "claim:fractal:1ns-hardware","1 ns","Fractal mirror simulation","physical timing","BLOCK",
                 "simulation timestep is not physical measurement"),
        FullCase("authority-after-transfer","TRANSFER","OBSERVED",["TRANSFER_OBLIGATION","AUTHORITY"],["TRANSFER_OBLIGATION"],
                 "transfer:no-destination-authority","Bridge transfer",p,"destination activation","BLOCK",
                 "preserved transfer does not grant destination authority"),
    ]

def evaluate_full(cases):
    out={}
    labels={}
    for c in cases:
        required=0
        satisfied=0
        for x in c.required: required |= REQ[x]
        for x in c.satisfied: satisfied |= REQ[x]
        if c.kind=="OBSERVATION" and c.epistemic in ("UNKNOWN","UNRESOLVED"):
            action="KEEP_OPEN"
        elif c.kind=="IDENTITY":
            labels.setdefault(c.display_label,[]).append(c.stable_identity)
            action="DISTINCT"
        else:
            action="ALLOW" if (required & ~satisfied)==0 else "BLOCK"
        out[c.case_id]={
            "action":action,
            "stable_identity":c.stable_identity,
            "display_label":c.display_label,
            "provenance":c.provenance,
            "scope":c.scope,
            "epistemic":c.epistemic,
        }
    return out

def compile_carrier(cases):
    # Cold dictionaries are recoverable/available but not carried in the active rows.
    prov=[]
    scope=[]
    prov_index={}
    scope_index={}
    rows=[]
    cold={}
    for c in cases:
        if c.provenance not in prov_index:
            prov_index[c.provenance]=len(prov); prov.append(c.provenance)
        if c.scope not in scope_index:
            scope_index[c.scope]=len(scope); scope.append(c.scope)
        req=sum(REQ[x] for x in c.required)
        sat=sum(REQ[x] for x in c.satisfied)
        flags=0
        rows.append(ROW.pack(
            KINDS[c.kind],
            EPIS[c.epistemic],
            ACTIONS[c.expected_action],
            flags,
            req,
            sat,
            _h32(c.stable_identity),
            prov_index[c.provenance],
            scope_index[c.scope],
        ))
        cold[c.case_id]={
            "stable_identity":c.stable_identity,
            "display_label":c.display_label,
            "provenance_ref":prov_index[c.provenance],
            "scope_ref":scope_index[c.scope],
            "note":c.note,
        }
    image=b"".join(rows)
    return {
        "image":image,
        "provenance_table":prov,
        "scope_table":scope,
        "cold_records":cold,
        "case_order":[c.case_id for c in cases],
    }

def evaluate_compact(compiled):
    image=compiled["image"]
    out={}
    for i,cid in enumerate(compiled["case_order"]):
        off=i*ROW.size
        kind,epi,expected,_flags,required,satisfied,ident_hash,pref,sref=ROW.unpack(image[off:off+ROW.size])
        if kind==KIND_OBSERVE and epi in (EPI_UNKNOWN,EPI_UNRESOLVED):
            action="KEEP_OPEN"
        elif kind==KIND_IDENTITY:
            action="DISTINCT"
        else:
            action="ALLOW" if (required & ~satisfied)==0 else "BLOCK"
        cold=compiled["cold_records"][cid]
        out[cid]={
            "action":action,
            "stable_identity":cold["stable_identity"],
            "display_label":cold["display_label"],
            "provenance":compiled["provenance_table"][pref],
            "scope":compiled["scope_table"][sref],
            "epistemic":{1:"OBSERVED",2:"UNKNOWN",3:"UNRESOLVED"}[epi],
        }
    return out

def semantic_digest(results):
    payload=json.dumps(results,sort_keys=True,separators=(",",":")).encode()
    return hashlib.sha256(payload).hexdigest()

def active_footprints(cases, compiled):
    verbose=json.dumps([c.__dict__ for c in cases],sort_keys=True,separators=(",",":")).encode()
    # Active carrier = fixed rows + tiny ordering vector. The human-readable source
    # records and provenance tables remain preserved/recoverable cold.
    active=compiled["image"] + json.dumps(compiled["case_order"],separators=(",",":")).encode()
    cold=json.dumps({
        "provenance_table":compiled["provenance_table"],
        "scope_table":compiled["scope_table"],
        "cold_records":compiled["cold_records"],
    },sort_keys=True,separators=(",",":")).encode()
    return {
        "verbose_active_bytes":len(verbose),
        "compact_active_bytes":len(active),
        "compact_cold_recoverable_bytes":len(cold),
        "compact_total_preserved_bytes":len(active)+len(cold),
        "active_reduction_ratio":len(verbose)/len(active),
    }

def recode_order(cases,seed):
    shuffled=list(cases)
    random.Random(seed).shuffle(shuffled)
    comp=compile_carrier(shuffled)
    return semantic_digest(evaluate_compact(comp))

def attacks(cases):
    baseline=evaluate_full(cases)
    baseline_digest=semantic_digest(baseline)
    results={}

    # A1: timeout-as-miss erases UNKNOWN.
    x=[FullCase(**c.__dict__) for c in cases]
    x=[FullCase(**({**c.__dict__,"epistemic":"OBSERVED","expected_action":"ALLOW"} if c.case_id=="shadow-timeout" else c.__dict__)) for c in x]
    results["timeout_as_observed"]=semantic_digest(evaluate_full(x))!=baseline_digest

    # A2: label-based identity aliases the two S0004 identities.
    parent=next(c for c in cases if c.case_id=="identity-parent")
    succ=next(c for c in cases if c.case_id=="identity-successor")
    results["label_as_identity"]=parent.display_label==succ.display_label and parent.stable_identity!=succ.stable_identity

    # A3: drop evidence-set requirement from the known-gap campaign.
    x=[]
    for c in cases:
        d=dict(c.__dict__)
        if c.case_id=="shadow-gap":
            d["required"]=[]
            d["expected_action"]="ALLOW"
        x.append(FullCase(**d))
    results["drop_evidence_set_requirement"]=semantic_digest(evaluate_full(x))!=baseline_digest

    # A4: drop authority distinction after transfer.
    x=[]
    for c in cases:
        d=dict(c.__dict__)
        if c.case_id=="authority-after-transfer":
            d["required"]=["TRANSFER_OBLIGATION"]
            d["satisfied"]=["TRANSFER_OBLIGATION"]
            d["expected_action"]="ALLOW"
        x.append(FullCase(**d))
    results["merge_transfer_with_authority"]=semantic_digest(evaluate_full(x))!=baseline_digest

    # A5: drop generator-identification requirement.
    x=[]
    for c in cases:
        d=dict(c.__dict__)
        if c.case_id=="fractal-address":
            d["required"]=[]
            d["expected_action"]="ALLOW"
        x.append(FullCase(**d))
    results["address_equals_generator"]=semantic_digest(evaluate_full(x))!=baseline_digest

    # A6: remove provenance pointers. Action survives, but reconstruction obligation fails.
    comp=compile_carrier(cases)
    prov_recoverable=all(
        0 <= ROW.unpack(comp["image"][i*ROW.size:(i+1)*ROW.size])[7] < len(comp["provenance_table"])
        for i in range(len(cases))
    )
    results["drop_provenance_refs_breaks_reconstruction"]=prov_recoverable
    return results

def run():
    cases=corpus()
    full=evaluate_full(cases)
    compiled=compile_carrier(cases)
    compact=evaluate_compact(compiled)

    exact=full==compact
    baseline_digest=semantic_digest(full)
    reorder_digests=[recode_order(cases,s) for s in range(10)]
    # Order-insensitive result digest because evaluate returns a case-id keyed map.
    reorder_invariant=all(d==baseline_digest for d in reorder_digests)

    raw_image=compiled["image"]
    z_image=zlib.compress(raw_image,9)
    # Re-encoding image with zlib must be bit-exact after decompression.
    encoding_invariant=zlib.decompress(z_image)==raw_image

    a=attacks(cases)
    footprint=active_footprints(cases,compiled)

    return {
        "passed":(
            exact and reorder_invariant and encoding_invariant
            and all(a.values())
            and footprint["compact_active_bytes"] < footprint["verbose_active_bytes"]
        ),
        "cases":len(cases),
        "semantic_digest":baseline_digest,
        "full_vs_compact_exact":exact,
        "harmless_reorder_trials":10,
        "harmless_reorder_invariant":reorder_invariant,
        "raw_vs_zlib_encoding_invariant":encoding_invariant,
        "active_footprint":footprint,
        "attacks":a,
        "active_carrier_row_bytes":ROW.size,
        "preserved_source_retained":True,
        "global_minimality_claimed":False,
        "kernel_schema_additions":0,
        "interpretation":"task-local compiled relation image + recoverable cold records",
    }

if __name__=="__main__":
    print(json.dumps(run(),indent=2,sort_keys=True))
