from __future__ import annotations
from dataclasses import dataclass, asdict
import re

@dataclass(frozen=True)
class SurfaceSignal:
    kind: str
    evidence: tuple[str,...]
    message: str

# Narrow transfer from the Language Structure Workbench. This is deliberately
# not a general NLP classifier; it only warns when wording may conflict with
# the Human Lab epistemic slot selected by the person.
CONCLUSION_MARKERS={"therefore","thus","hence","consequently"}
POSSIBILITY_MARKERS={"may","might","could","probably","likely","possibly"}
COMPARISON_MARKERS={"better","worse","more","less","than","improved","decreased","increased"}
INTERPRETATION_PHRASES=("i think","i believe","suggests that","implies that","we infer","i infer")


def _tokens(text: str) -> list[str]:
    return re.findall(r"[a-z]+(?:'[a-z]+)?",text.lower())


def inspect_surface(text: str, *, intended_role: str) -> dict:
    toks=_tokens(text); token_set=set(toks); low=text.lower()
    signals=[]
    conclusion=sorted(token_set & CONCLUSION_MARKERS)
    possibility=sorted(token_set & POSSIBILITY_MARKERS)
    comparison=sorted(token_set & COMPARISON_MARKERS)
    interp=[p for p in INTERPRETATION_PHRASES if p in low]
    if conclusion:
        signals.append(SurfaceSignal("INFERENCE_LIKE",tuple(conclusion),"contains conclusion/inference language"))
    if interp:
        signals.append(SurfaceSignal("INTERPRETATION_LIKE",tuple(interp),"contains explicit interpretation language"))
    if possibility:
        signals.append(SurfaceSignal("MODAL_UNCERTAINTY",tuple(possibility),"contains possibility/uncertainty language"))
    if comparison:
        signals.append(SurfaceSignal("COMPARISON_LIKE",tuple(comparison),"contains comparison/change language"))
    warnings=[]
    if intended_role.upper()=="OBSERVATION":
        for s in signals:
            if s.kind in {"INFERENCE_LIKE","INTERPRETATION_LIKE","MODAL_UNCERTAINTY","COMPARISON_LIKE"}:
                warnings.append(
                    f"Saw is for what was observed; this wording looks {s.kind.lower().replace('_',' ')} ({', '.join(s.evidence)}). "
                    "Keep it if it is literally what was observed, or use compare/think if it is derived."
                )
    return {
        "intended_role":intended_role,
        "signals":[asdict(s) for s in signals],
        "warnings":warnings,
        "blocked":False,
        "claim_limit":"Heuristic surface warning only; wording does not determine epistemic status."
    }
