
from __future__ import annotations
from pathlib import Path
import json, tempfile, sys, numpy as np, hashlib
ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path: sys.path.insert(0,str(ROOT))
from orbit_lab import OrbitLab

FIXTURE=ROOT/"data"/"branching_geometry_lineage_fixture.json"

def _load(src):
    ns={}
    exec(compile(src,"<branching-geometry-lineage>","exec"),ns,ns)
    return ns["f"]

def _failure(src,D=2):
    try:
        _load(src)(D=D)
        return None
    except Exception as e:
        return {"type":type(e).__name__,"message":str(e)}

def run():
    fx=json.loads(FIXTURE.read_text())
    original=fx["original_source"]; r1=fx["repair_1_source"]; r2=fx["repair_2_source"]
    f=_load(r2)
    runs=[]
    for D in [1,2,3,4,6,8,10]:
        a=f(D=D); b=f(D=D)
        lin=a[["depth","p_id","id"]].to_numpy()
        runs.append({
            "D":D,"rows":len(a),
            "deterministic_same_seed":bool(a.equals(b)),
            "lineage_values_integral":bool(np.all(lin==np.floor(lin))),
        })
    raw=f()
    typed=raw.copy()
    typed[["depth","p_id","id"]]=typed[["depth","p_id","id"]].astype(int)

    with tempfile.TemporaryDirectory() as td:
        lab=OrbitLab(Path(td)/"source.db")
        try:
            frame=lab.add(
                "ObservationFrame","Current Python execution",
                data={
                    "observer":"lineage-probe","apparatus":"python+numpy+pandas",
                    "accessible_variables":["exception","dataframe","dtypes"],
                    "resolution":"runtime execution",
                    "intervention":"execute exact recovered source then one-degree repairs",
                    "boundary":"current runtime; not historical execution"
                },
                provenance_class="TEST",provenance="source-lineage",identity_key="frame"
            )
            static_ev=lab.add(
                "Artifact","Exact historical source",
                data={"evidence_tags":["STATIC_SOURCE_TEXT"],"sha256":fx["original_source_sha256"]},
                provenance_class="TEST",provenance="source-lineage",identity_key="static"
            )
            execution_ev=lab.add(
                "Evidence","Repair-2 current runtime execution",
                data={"evidence_tags":["EXECUTED_RUNTIME_BEHAVIOR"]},
                epistemic="OBSERVED",provenance_class="TEST",provenance="source-lineage",identity_key="exec"
            )
            runtime_claim=lab.add(
                "Claim","Repair-2 executes through D=10 in current runtime",
                data={"required_evidence_tags":["EXECUTED_RUNTIME_BEHAVIOR"]},
                provenance_class="TEST",provenance="source-lineage",identity_key="runtime-claim"
            )
            static_blocked=False
            try:
                lab.assess_claim(
                    runtime_claim,frame_id=frame,evidence_ids=[static_ev],
                    verdict="SUPPORTED",scope="current runtime",
                    provenance_class="TEST",provenance="source-lineage"
                )
            except ValueError:
                static_blocked=True
            lab.assess_claim(
                runtime_claim,frame_id=frame,evidence_ids=[execution_ev],
                verdict="SUPPORTED",scope="D in {1,2,3,4,6,8,10}; current runtime",
                provenance_class="TEST",provenance="source-lineage"
            )

            # Preserve three code identities and explicit derivation without merging them.
            ids=[]
            for name,src in [("original",original),("repair1",r1),("repair2",r2)]:
                cid=lab.register_content(
                    algorithm="sha256",digest=hashlib.sha256(src.encode()).hexdigest(),
                    title=name,provenance_class="TEST",provenance="source-lineage"
                )
                ids.append(cid)
            lab.relate(ids[1],"DERIVED_FROM",ids[0],data={"reason":"one-degree row packing repair"},provenance_class="TEST",provenance="source-lineage")
            lab.relate(ids[2],"DERIVED_FROM",ids[1],data={"reason":"one-degree child-length shape repair"},provenance_class="TEST",provenance="source-lineage")
            distinct=len(set(ids))==3
            audit=lab.alpha_audit()
        finally:
            lab.close()

    original_failure=_failure(original)
    r1_failure=_failure(r1)
    r2_failure=_failure(r2)
    return {
        "passed":(
            original_failure is not None and r1_failure is not None and r2_failure is None
            and all(x["deterministic_same_seed"] and x["lineage_values_integral"] for x in runs)
            and static_blocked
            and raw[["depth","p_id","id"]].dtypes.astype(str).eq("float64").all()
            and typed[["depth","p_id","id"]].dtypes.astype(str).eq("int64").all()
            and np.array_equal(raw[["depth","p_id","id"]].to_numpy(),typed[["depth","p_id","id"]].to_numpy())
            and raw.drop(columns=["depth","p_id","id"]).equals(typed.drop(columns=["depth","p_id","id"]))
            and distinct and audit["passed"]
        ),
        "historical_execution_status":fx["historical_execution_status"],
        "original_runtime_failure_now":original_failure,
        "repair_1_runtime_failure":r1_failure,
        "repair_2_runtime_failure":r2_failure,
        "runs":runs,
        "default_rows":len(raw),
        "static_source_cannot_certify_runtime_behavior":static_blocked,
        "three_content_identities_remain_distinct":distinct,
        "typed_return":{
            "raw_lineage_dtypes":{c:str(raw[c].dtype) for c in ["depth","p_id","id"]},
            "candidate_lineage_dtypes":{c:str(typed[c].dtype) for c in ["depth","p_id","id"]},
            "preserves_numeric_values":bool(np.array_equal(
                raw[["depth","p_id","id"]].to_numpy(),typed[["depth","p_id","id"]].to_numpy())),
            "preserves_other_columns":bool(
                raw.drop(columns=["depth","p_id","id"]).equals(typed.drop(columns=["depth","p_id","id"]))
            ),
        },
        "kernel_schema_additions":0,
        "audit_passed":audit["passed"],
    }

if __name__=="__main__":
    print(json.dumps(run(),indent=2,sort_keys=True))
