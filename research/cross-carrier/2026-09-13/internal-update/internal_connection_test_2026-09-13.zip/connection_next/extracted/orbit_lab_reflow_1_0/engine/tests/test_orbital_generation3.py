
import tempfile
from pathlib import Path
import unittest
from orbit_lab import OrbitLab

class OrbitalThirdGenerationRegressions(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.lab=OrbitLab(Path(self.tmp.name)/"t.db")
    def tearDown(self): self.lab.close(); self.tmp.cleanup()
    def add(self,t,title,key,**kw):
        return self.lab.add(t,title,provenance_class="TEST",provenance="test",identity_key=key,**kw)

    def test_unknown_evidence_cannot_promote(self):
        c=self.add("Context","C","c"); s=self.add("Scope","S","s")
        x=self.add("Candidate","X","x"); f=self.add("ValidityFrame","F","f",data={"conditions":{"d":"D"}})
        weak=self.add("Evidence","weak","weak",epistemic="UNKNOWN")
        with self.assertRaises(ValueError):
            self.lab.record_promotion(context_id=c,entity_id=x,scope_id=s,validity_frame_id=f,
                witness_entity_id=weak,basis_entity_ids=[weak],change_claim="promote",
                revalidation_rule="retest",provenance_class="TEST",provenance="test")

    def test_failed_execution_cannot_promote(self):
        c=self.add("Context","C","c"); s=self.add("Scope","S","s")
        x=self.add("Candidate","X","x"); vf=self.add("ValidityFrame","F","vf",data={"conditions":{"d":"D"}})
        run=self.add("RunIdentity","run","run"); probe=self.add("Probe","p","p")
        of=self.add("ObservationFrame","of","of",data={"observer":"t","apparatus":"s","accessible_variables":["y"],"resolution":"1","intervention":"none","boundary":"b"})
        params=self.add("Parameters","params","params",data={}); reset=self.add("Artifact","reset","r")
        obs=self.add("Observation","failed","obs",epistemic="OBSERVED")
        ex=self.lab.record_execution(run_id=run,probe_id=probe,frame_id=of,parameters_id=params,
            reset_id=reset,observation_ids=[obs],status="TOOL_FAILED",
            provenance_class="TEST",provenance="test")
        with self.assertRaises(ValueError):
            self.lab.record_promotion(context_id=c,entity_id=x,scope_id=s,validity_frame_id=vf,
                witness_entity_id=ex,basis_entity_ids=[obs],change_claim="promote",
                revalidation_rule="retest",provenance_class="TEST",provenance="test")

    def test_direct_launch_retired(self):
        x=self.add("Candidate","X","x")
        with self.assertRaises(PermissionError): self.lab.launch(x)

    def test_audit_detects_wrong_current_slot_type(self):
        x=self.add("Candidate","X","x")
        self.lab.conn.execute("INSERT INTO current_slots(slot,object_id) VALUES('subject',?)",(x,))
        self.lab.conn.commit()
        audit=self.lab.alpha_audit()
        self.assertFalse(audit["passed"])
        self.assertTrue(any(f["check"]=="current_slot_types" for f in audit["failures"]))

if __name__=="__main__": unittest.main()
