from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

from seed_research import load

ROOT=Path(__file__).resolve().parents[1]

class EntrypointBoundaryTests(unittest.TestCase):
    def test_seed_loader_is_idempotent_after_complete_seed(self):
        with tempfile.TemporaryDirectory() as td:
            db=Path(td)/"seed.db"
            a=load(db)
            b=load(db)
            self.assertEqual(a[0], b[0])
            self.assertEqual(a[1], b[1])
            self.assertEqual(a[2]["objects"], b[2]["objects"])
            self.assertEqual(a[2]["relations"], b[2]["relations"])

    def test_adversary_direct_entrypoint(self):
        p=subprocess.run([sys.executable,"supporters/adversary.py"],cwd=ROOT,
                         text=True,capture_output=True,timeout=30)
        self.assertEqual(p.returncode,0,p.stderr)
        self.assertIn('"novel_findings": 0',p.stdout)

    def test_ecology_direct_entrypoint(self):
        p=subprocess.run([sys.executable,"supporters/ecology.py"],cwd=ROOT,
                         text=True,capture_output=True,timeout=30)
        self.assertEqual(p.returncode,0,p.stderr)
        self.assertIn('"findings": 0',p.stdout)

if __name__=="__main__": unittest.main()
