
import tempfile
from pathlib import Path
from orbit_lab import OrbitLab

with tempfile.TemporaryDirectory() as td:
    lab=OrbitLab(Path(td)/"stress.db")
    passes=[]; breaks=[]
    try:
        source=lab.add("Context","Source",provenance_class="TEST",provenance="stress",identity_key="source")
        dest=lab.add("Context","Destination",provenance_class="TEST",provenance="stress",identity_key="dest")
        item=lab.add("Candidate","Transferred method",provenance_class="RECOVERY_PACKET",
                     provenance="source",identity_key="item",lifecycle="QUARANTINED")
        obligation=lab.add("Obligation","Preserve provenance and failure history",
                           provenance_class="TEST",provenance="stress",identity_key="ob")
        transfer_ev=lab.add("Evidence","transport verified",
                            provenance_class="TEST",provenance="stress",identity_key="tev",epistemic="OBSERVED")
        transfer=lab.transfer(
            source_context_id=source,destination_context_id=dest,entity_id=item,
            obligation_ids=[obligation],evidence_entity_ids=[transfer_ev],
            requested_operations=["INSPECT","USE_AS_EVIDENCE","ACTIVATE"],
            result="PRESERVED",reason="carrier preserved transfer obligations",
            provenance_class="TEST",provenance="stress"
        )
        if not lab.check_authorized(context_id=dest,entity_id=item,operation="ACTIVATE",scope="task")["authorized"]:
            passes.append("Successful transfer does not manufacture destination activation authority.")

        destination_basis=lab.add("Evidence","destination review supports evidence use only",
                                  provenance_class="TEST",provenance="stress",
                                  identity_key="dbasis",epistemic="OBSERVED")
        lab.grant_authorization(
            context_id=dest,entity_id=item,operation="USE_AS_EVIDENCE",scope="task",
            basis_entity_ids=[destination_basis,transfer],
            reason="destination accepts historical evidence but not the method",
            provenance_class="TEST",provenance="stress"
        )
        if lab.check_authorized(context_id=dest,entity_id=item,operation="USE_AS_EVIDENCE",scope="task")["authorized"] \
           and not lab.check_authorized(context_id=dest,entity_id=item,operation="ACTIVATE",scope="task")["authorized"]:
            passes.append("Evidence use and activation are independently authorized.")

        # Holdout/history attack.
        evaluator=lab.add("Context","Clean evaluator",provenance_class="TEST",provenance="stress",identity_key="eval")
        truth=lab.add("Artifact","holdout truth",provenance_class="TEST",provenance="stress",identity_key="truth")
        model=lab.add("Candidate","model",provenance_class="TEST",provenance="stress",identity_key="model")
        basis=lab.add("Evidence","protocol authority",provenance_class="TEST",provenance="stress",identity_key="basis",epistemic="OBSERVED")
        lab.grant_authorization(
            context_id=evaluator,entity_id=model,operation="CLEAN_EVALUATE",scope="cycle-1",
            basis_entity_ids=[basis],reason="clean role",
            prerequisites={"forbid_exposure_tags":["CONFIRMATION_TRUTH"]},
            provenance_class="TEST",provenance="stress"
        )
        lab.grant_authorization(
            context_id=evaluator,entity_id=truth,operation="INSPECT",scope="cycle-1",
            basis_entity_ids=[basis],reason="later checker access",
            provenance_class="TEST",provenance="stress"
        )
        lab.record_access(
            context_id=evaluator,entity_id=truth,operation="INSPECT",scope="cycle-1",
            exposure_tags=["CONFIRMATION_TRUTH"],
            provenance_class="TEST",provenance="stress"
        )
        if not lab.check_authorized(context_id=evaluator,entity_id=model,operation="CLEAN_EVALUATE",scope="cycle-1")["authorized"]:
            passes.append("Eligibility changes from access history rather than a mutable contamination flag.")

        # Next break: scope is an opaque exact string.
        x=lab.add("Candidate","Scope-sensitive object",provenance_class="TEST",provenance="stress",identity_key="scope-x")
        lab.grant_authorization(
            context_id=dest,entity_id=x,operation="INSPECT",scope="project:moonshot/hodge",
            basis_entity_ids=[destination_basis],reason="bounded subtree",
            provenance_class="TEST",provenance="stress"
        )
        # A narrower scope should plausibly be covered by a parent grant, but v0.16 exact string semantics deny it.
        narrower=lab.check_authorized(
            context_id=dest,entity_id=x,operation="INSPECT",scope="project:moonshot/hodge/m45"
        )
        if not narrower["authorized"]:
            breaks.append(
                "Authority is now operation/context/history scoped, but Scope itself is opaque exact text. "
                "The kernel cannot distinguish narrower-within-authorized-scope from unrelated scope, "
                "nor prove containment/disjointness."
            )

        print("V0.16 AUTHORITY/HISTORY STRESS")
        print("------------------------------")
        print("PASS:")
        for x in passes: print("-",x)
        print("\nNEXT BREAK:")
        for i,x in enumerate(breaks,1): print(f"{i}. {x}")
    finally:
        lab.close()
