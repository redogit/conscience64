
import tempfile
from pathlib import Path
from orbit_lab import OrbitLab

with tempfile.TemporaryDirectory() as td:
    lab=OrbitLab(Path(td)/"stress.db"); passes=[]; breaks=[]
    try:
        ctx=lab.add("Context","Recovery context",provenance_class="TEST",provenance="stress",identity_key="ctx")
        c1=lab.register_content(algorithm="sha256",digest="11",provenance_class="TEST",provenance="stress")
        c2=lab.register_content(algorithm="sha256",digest="22",provenance_class="TEST",provenance="stress")
        i1=lab.create_artifact_instance(content_id=c1,provenance_class="TEST",provenance="stress",identity_key="i1")
        i2=lab.create_artifact_instance(content_id=c2,provenance_class="TEST",provenance="stress",identity_key="i2")
        o1=lab.record_instance_occurrence(instance_id=i1,context_id=ctx,locator="/input/a",
            mode="REGISTER",provenance_class="TEST",provenance="stress",identity_key="o1")
        o2=lab.record_instance_occurrence(instance_id=i2,context_id=ctx,locator="/input/b",
            mode="REGISTER",provenance_class="TEST",provenance="stress",identity_key="o2")
        cout=lab.register_content(algorithm="sha256",digest="33",provenance_class="TEST",provenance="stress")
        iout=lab.create_artifact_instance(content_id=cout,provenance_class="TEST",provenance="stress",identity_key="io")
        out=lab.record_instance_occurrence(instance_id=iout,context_id=ctx,locator="/output/report",
            mode="REGISTER",provenance_class="TEST",provenance="stress",identity_key="out")
        method=lab.add("Method","recovery synthesis",provenance_class="TEST",provenance="stress",identity_key="m")
        d=lab.record_derivation(input_occurrence_ids=[o1,o2],method_id=method,output_occurrence_id=out,
            transformation="synthesize report from two source occurrences",reconstructibility="PARTIAL",
            provenance_class="TEST",provenance="stress")
        if len(lab.episode_role_ids(d,"input"))==2:
            passes.append("Multi-parent derivation is distinct from custody and preserves reconstructibility status.")

        # Association pressure: a recovery packet mentions or resolves a Library artifact without
        # producing it, copying it, or earning evidence authority from that link.
        target=lab.add("Artifact","Library artifact target",provenance_class="LIBRARY_ARTIFACT",
                       provenance="library",identity_key="target")
        recovery=lab.add("Artifact","Recovery packet",provenance_class="RECOVERY_PACKET",
                         provenance="recovery",identity_key="recovery")
        lab.relate(recovery,"ASSOCIATED_WITH",target,
                   data={"resolution_status":"LIBRARY_ID_EXACT","evidence_upgrade":False},
                   provenance_class="DERIVED",provenance="stress")
        breaks.append(
            "Association still lives in the generic binary relation table with free-form metadata. "
            "The kernel cannot enforce that association is navigation-only, cannot type resolution status, "
            "and cannot prevent an association relation from being mistaken for evidence elsewhere."
        )

        print("V0.25 DERIVATION / ASSOCIATION STRESS")
        print("------------------------------------")
        print("PASS:"); [print("-",x) for x in passes]
        print("\nNEXT BREAK:"); [print(f"{i}. {x}") for i,x in enumerate(breaks,1)]
    finally: lab.close()
