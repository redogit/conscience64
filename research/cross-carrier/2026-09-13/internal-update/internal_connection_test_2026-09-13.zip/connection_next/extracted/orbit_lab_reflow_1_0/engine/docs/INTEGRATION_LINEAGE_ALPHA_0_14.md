# Orbit Lab Alpha 0.14 — Integration Lineage

Alpha 0.14 adds TBCL proper as a **compression pressure**, not as a replacement ontology.

## Earned result

On 14 already-integrated Orbit Lab decision cases:

- verbose active serialized representation: 4,991 bytes
- compact active relation carrier: 510 bytes
- active reduction: ~9.79x
- exact action/reconstruction equivalence: PASS
- 10 harmless reorderings: invariant
- raw vs zlib carrier recoding: invariant
- orthogonal finite verifier: 16,384/16,384 requirement/satisfaction combinations
- consequential ablations: detected
- provenance/source records remain recoverable cold
- global minimality: not claimed

## Why this is TBCL-relevant

Confirmed TBCL 0.2 RELVM established a bounded pattern: a compiled relation can earn a role
because it removes repeated execution/search effort while source semantics remain retained
for attack and regeneration. Orbit Lab applies that pattern only to its current task-local
decision surface.

## Preserved boundaries

- PRESERVED != ACTIVE
- compact active carrier != deletion of source evidence
- file integrity != semantic truth
- same action != same provenance
- UNKNOWN/UNRESOLVED != miss
- transfer != authority
- address recovery != generator identity
- compression != global minimality

The independent TBCL project remains authoritative for TBCL itself. Orbit Lab only imports
the demonstrated relation pattern relevant to its own obligation.
