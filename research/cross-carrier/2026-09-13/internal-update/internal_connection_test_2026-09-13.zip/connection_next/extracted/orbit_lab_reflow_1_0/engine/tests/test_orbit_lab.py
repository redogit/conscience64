
import tempfile
from pathlib import Path
import unittest
from orbit_lab import OrbitLab

class OrbitLabV02Tests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.lab=OrbitLab(Path(self.tmp.name)/"t.db")
    def tearDown(self):
        self.lab.close(); self.tmp.cleanup()

    def add(self,t,title,key=None,lifecycle="DORMANT"):
        return self.lab.add(t,title,provenance_class="TEST",provenance="test",identity_key=key,lifecycle=lifecycle)

    def test_quarantine(self):
        x=self.add("Subject","legacy","q",lifecycle="QUARANTINED")
        self.assertEqual(self.lab.get(x).lifecycle,"QUARANTINED")

    def test_claim(self):
        x=self.add("Claim","bounded claim","c")
        self.assertEqual(self.lab.get(x).type,"Claim")

    def test_relation_payload(self):
        a=self.add("Subject","a","a"); b=self.add("Subject","b","b")
        self.lab.relate(a,"RELEVANT_TO",b,data={"scope":"local"},provenance_class="TEST",provenance="test")
        self.assertEqual(self.lab.graph(a)["outgoing"][0]["data"]["scope"],"local")

    def test_subject_scoped_orbit(self):
        s1=self.add("Subject","s1","s1"); s2=self.add("Subject","s2","s2"); x=self.add("Candidate","x","x")
        self.lab.orbit(x,s1); self.assertEqual(len(self.lab.orbit_list(s1)),1); self.assertEqual(len(self.lab.orbit_list(s2)),0)

    def test_identity_dedupe(self):
        self.add("Subject","x","same")
        with self.assertRaises(ValueError): self.add("Subject","x again","same")

    def test_current_probe_limit_and_expansion(self):
        for i in range(3):
            p=self.add("Probe",f"p{i}",f"p{i}"); self.lab.pin("probe",p)
        p=self.add("Probe","p3","p3")
        with self.assertRaises(RuntimeError): self.lab.pin("probe",p)
        self.lab.expand_current("probe",4,reason="fourth probe needed to preserve distinction")
        self.lab.pin("probe",p)
        self.assertEqual(len(self.lab.scan()["probe"]),4)

    def test_supersedes_cycle_rejected(self):
        a=self.add("Claim","a","ca"); b=self.add("Claim","b","cb")
        self.lab.relate(a,"SUPERSEDES",b,provenance_class="TEST",provenance="test")
        with self.assertRaises(ValueError):
            self.lab.relate(b,"SUPERSEDES",a,provenance_class="TEST",provenance="test")

    def test_provenance_class_required(self):
        with self.assertRaises(ValueError):
            self.lab.add("Evidence","x",provenance_class="BOGUS",provenance="somewhere")

if __name__=="__main__":
    unittest.main()
