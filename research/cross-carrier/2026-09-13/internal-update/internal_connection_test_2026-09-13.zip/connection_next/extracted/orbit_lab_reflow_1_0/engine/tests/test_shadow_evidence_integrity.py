
import hashlib, json, tempfile, unittest
from pathlib import Path
from orbit_lab import OrbitLab
from checks.shadow_evidence_integrity_probe import run

class ShadowEvidenceIntegrityTests(unittest.TestCase):
    def test_end_to_end_shadow_probe(self):
        r=run()
        self.assertTrue(r["passed"])
        self.assertTrue(r["timeout_observation_remains_unknown"])
        self.assertTrue(r["same_label_distinct_run_identity"])
        self.assertTrue(r["post_support_link_loss_detected"])
        self.assertTrue(r["wrong_scheduled_identity_detected"])

    def test_incomplete_collection_blocks_support(self):
        with tempfile.TemporaryDirectory() as td:
            lab=OrbitLab(Path(td)/"t.db")
            try:
                frame=lab.add("ObservationFrame","f",data={
                    "observer":"t","apparatus":"t","accessible_variables":["id"],
                    "resolution":"record","intervention":"none","boundary":"test"
                },provenance_class="TEST",provenance="t",identity_key="f")
                col=lab.add("Collection","c",provenance_class="TEST",provenance="t",identity_key="c")
                for i in range(3):
                    ev=lab.add("Evidence",str(i),data={"scheduled_id":i,"evidence_tags":["RAW"]},
                        epistemic="OBSERVED",provenance_class="TEST",provenance="t",identity_key=f"e{i}")
                    lab.add_to_collection(col,ev)
                summary=lab.add("Evidence","summary",data={"evidence_tags":["AUDIT"]},
                    epistemic="OBSERVED",provenance_class="TEST",provenance="t",identity_key="summary")
                claim=lab.add("Claim","4/4 complete",data={
                    "required_evidence_tags":["AUDIT"],
                    "evidence_set_contract":{
                        "collection_id":col,"expected_count":4,
                        "identity_field":"scheduled_id","expected_identities":[0,1,2,3],
                        "required_member_evidence_tags":["RAW"]
                    }
                },provenance_class="TEST",provenance="t",identity_key="claim")
                with self.assertRaises(ValueError):
                    lab.assess_claim(claim,frame_id=frame,evidence_ids=[summary],verdict="SUPPORTED",
                        scope="test",provenance_class="TEST",provenance="t")
            finally:
                lab.close()

if __name__=="__main__":
    unittest.main()
