
from __future__ import annotations
import json, subprocess, sys
from orbital_gans import OrbitalGAN

def main():
    tests=subprocess.run(
        [sys.executable,"-m","unittest","discover","-v"],
        text=True,capture_output=True
    )
    alpha=subprocess.run(
        [sys.executable,"alpha_gate.py"],
        text=True,capture_output=True
    )
    orbital=OrbitalGAN(seed=20260904).run(rounds=1000)

    result={
        "gate":"Orbit Lab internal alpha 0.2-orbital",
        "passed": bool(
            tests.returncode==0
            and alpha.returncode==0
            and not orbital["findings"]
            and not orbital["harness_errors"]
        ),
        "checks":{
            "full_regression_suite":tests.returncode==0,
            "alpha_state_gate":alpha.returncode==0,
            "orbital_trials":orbital["trials"],
            "orbital_novel_findings":orbital["novel_findings"],
            "orbital_harness_errors":len(orbital["harness_errors"]),
            "orbital_controls_passed":orbital["controls_passed"],
        },
        "known_boundary":[
            "Actor identity remains an embedding-runtime authentication boundary.",
            "Orbital GANs are structured adversarial co-evolution, not learned neural generators.",
            "No finite adversarial run establishes completeness."
        ],
    }
    print(json.dumps(result,indent=2,sort_keys=True))
    if not result["passed"]:
        if tests.returncode:
            print(tests.stdout); print(tests.stderr,file=sys.stderr)
        if alpha.returncode:
            print(alpha.stdout); print(alpha.stderr,file=sys.stderr)
        raise SystemExit(1)

if __name__=="__main__":
    main()
