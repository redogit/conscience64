
from __future__ import annotations
from pathlib import Path
import hashlib, json, tempfile, sys
ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0,str(ROOT))
from orbit_lab import OrbitLab
from human_lab import HumanLab

DATA=ROOT/"data"/"research_card_negative_retrieval"
FIXTURE=json.loads((DATA/"NEGATIVE_RETRIEVAL_SEARCH_FIXTURE.json").read_text())
RECOVERY=json.loads((DATA/"composable_knowledge_recovery.json").read_text())
ASSOC=json.loads((DATA/"composable_knowledge_associations.json").read_text())

def _record(rid):
    return next(r for r in RECOVERY["records"] if r.get("id")==rid)

def _assoc(rid):
    for item in ASSOC.get("associations", ASSOC if isinstance(ASSOC,list) else []):
        if isinstance(item,dict) and item.get("record_id")==rid:
            return item
    if isinstance(ASSOC,dict):
        stack=list(ASSOC.values())
        while stack:
            x=stack.pop()
            if isinstance(x,dict):
                if x.get("record_id")==rid: return x
                stack.extend(x.values())
            elif isinstance(x,list):
                stack.extend(x)
    return None

def run():
    r62,r63,r64,r68=(_record(x) for x in ("R062","R063","R064","R068"))
    a62,a63=_assoc("R062"),_assoc("R063")

    recovery_boundary=(
        r62["execution_status"]=="UNKNOWN"
        and r63["execution_status"]=="UNKNOWN"
        and r64["status"]=="OPEN_QUESTION"
        and r68["status"]=="PROVENANCE_GAP"
        and "Absence here does not prove" in r68["claim_boundary"]
    )
    association_boundary=all([
        a62 is not None and a62.get("resolution_status")=="CONVERSATION_ONLY_SOURCE",
        a63 is not None and a63.get("resolution_status")=="CONVERSATION_ONLY_SOURCE",
        a62.get("library_file_id") is None,
        a63.get("library_file_id") is None,
    ])

    with tempfile.TemporaryDirectory() as td:
        # Human surface.
        h=HumanLab(Path(td)/"human.db")
        try:
            card=FIXTURE["research_card"]
            h.start(card["Question"])
            h.add("need",card["Need"])
            h.add("limit",card["Limit"])
            h.add("try",card["Try"])
            h.add("saw",card["Saw"])
            h.add("left",card["Left"])
            h.think("The current evidence closes the provenance search only within the searched Library routes; it does not close the historical execution question.")
            rendered=h.card()
            scan=h.lab.scan()
            remainder=scan["remainder"][-1]
            human_remainder_preserved=(
                remainder["title"]==card["Left"]
                and remainder["epistemic"]=="UNEXPLAINED"
                and "Left" in rendered
            )
        finally:
            h.close()

        # Claim-boundary surface.
        lab=OrbitLab(Path(td)/"claim.db")
        try:
            frame=lab.add(
                "ObservationFrame","Bounded Library provenance search",
                data={
                    "observer":"research-card-negative-retrieval",
                    "apparatus":"Library semantic/title search + recovery association map",
                    "accessible_variables":["recovery_status","execution_status","resolution_status","library_file_id"],
                    "resolution":"indexed Library records available on 2026-09-04",
                    "intervention":"search exact metrics/phrases, then widen by behavior/source role",
                    "boundary":"failure to locate in this search is not universal nonexistence"
                },
                provenance_class="TEST",provenance="card-negative-retrieval",identity_key="frame"
            )
            search_ev=lab.add(
                "Evidence","No primary mutation/staleness execution artifact located in bounded Library search",
                data={
                    "source_role":"BOUNDED_SEARCH_RESULT",
                    "evidence_tags":["BOUNDED_SEARCH_RESULT"],
                    "primary_artifact_candidates_found":FIXTURE["primary_artifact_candidates_found"],
                },
                epistemic="OBSERVED",
                provenance_class="TEST",provenance="card-negative-retrieval",identity_key="search"
            )
            bounded=lab.add(
                "Claim","No primary execution artifact was located in the searched Library routes",
                data={
                    "required_evidence_tags":["BOUNDED_SEARCH_RESULT"],
                    "evidence_source_role_contract":{
                        "allowed":["BOUNDED_SEARCH_RESULT"],
                        "require_declared_role":True
                    }
                },
                provenance_class="TEST",provenance="card-negative-retrieval",identity_key="bounded"
            )
            ep=lab.assess_claim(
                bounded,frame_id=frame,evidence_ids=[search_ev],verdict="SUPPORTED",
                scope=FIXTURE["search_scope"],
                provenance_class="TEST",provenance="card-negative-retrieval"
            )
            bounded_supported=lab.episode(ep)["data"]["verdict"]=="SUPPORTED"

            strong=lab.add(
                "Claim","The mutation/staleness experiment was never executed anywhere",
                data={
                    "required_evidence_tags":["UNIVERSAL_NONEXISTENCE_WITNESS"],
                    "evidence_source_role_contract":{
                        "allowed":["PRIMARY_HISTORICAL_EVIDENCE","UNIVERSAL_SEARCH_PROOF"],
                        "require_declared_role":True
                    }
                },
                provenance_class="TEST",provenance="card-negative-retrieval",identity_key="strong"
            )
            strong_blocked=False
            try:
                lab.assess_claim(
                    strong,frame_id=frame,evidence_ids=[search_ev],verdict="SUPPORTED",
                    scope="all possible historical locations",
                    provenance_class="TEST",provenance="card-negative-retrieval"
                )
            except ValueError:
                strong_blocked=True

            unresolved=lab.add(
                "Remainder","Whether the mutation attack was executed, and what its result was, remains unresolved.",
                epistemic="UNEXPLAINED",
                provenance_class="TEST",provenance="card-negative-retrieval",identity_key="remainder"
            )
            audit=lab.alpha_audit()
        finally:
            lab.close()

    return {
        "passed":all([
            recovery_boundary, association_boundary,
            human_remainder_preserved, bounded_supported, strong_blocked,
            audit["passed"],
            FIXTURE["incoming_composable_packet_has_independent_byte_identical_copy"],
        ]),
        "research_card_rendered":rendered,
        "recovery_records_preserve_open_execution_question":recovery_boundary,
        "association_map_has_no_primary_library_locator":association_boundary,
        "bounded_not_found_claim_supported":bounded_supported,
        "not_found_does_not_support_never_existed":strong_blocked,
        "left_remainder_preserved":human_remainder_preserved,
        "incoming_composable_packet_duplicate_verified":FIXTURE["incoming_composable_packet_has_independent_byte_identical_copy"],
        "kernel_schema_additions":0,
        "audit_passed":audit["passed"],
        "claim_ceiling":[
            "The negative result is limited to the searched Library routes available on 2026-09-04.",
            "No claim is made that the artifact never existed or that the experiment was never executed.",
            "The historical reported benchmark metrics remain UNVERIFIED_REPORTED_RESULT.",
            "The mutation/staleness question remains OPEN until primary execution evidence is recovered or a new experiment is run."
        ]
    }

if __name__=="__main__":
    print(json.dumps(run(),indent=2,sort_keys=True))
