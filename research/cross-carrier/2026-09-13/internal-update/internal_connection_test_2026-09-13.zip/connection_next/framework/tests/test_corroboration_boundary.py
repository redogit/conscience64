from pathlib import Path
from ecs_world import ECSFrameworkWorld
from ecs_world.components import Budget

def test_internal_fingerprint_does_not_establish_corroboration():
    engine = ECSFrameworkWorld(Path(__file__).resolve().parents[1]/'world')
    result = engine.router.dispatch(engine.world, 'INTERNAL-PROBE',
        {'method':'restart-contract'}, Budget(),
        {'boundary':['Internal software test'], 'acceptance':[]})
    assert result['ok'] is True
    assert result['verification']['ok'] is True
    assert result['second_carrier_check_passed'] is True
    assert result['corroborated'] is False
    assert result['corroboration_status'] == 'NOT_ESTABLISHED'
