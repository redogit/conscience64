from ecs_world.carriers import LocalFileCarrierAdapter

def test_partial_recovery_keeps_each_missing_source(tmp_path):
    (tmp_path/'present.txt').write_text('source')
    result = LocalFileCarrierAdapter([tmp_path]).execute({
        'sources':['present.txt','missing.txt'], 'acceptance':[]})
    assert len(result['artifact']['matches']) == 1
    assert result['unresolved'] == ['Unresolved source: missing.txt']
