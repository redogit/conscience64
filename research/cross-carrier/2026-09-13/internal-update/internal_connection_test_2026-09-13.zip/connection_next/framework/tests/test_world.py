from pathlib import Path
from ecs_world.runner import ECSFrameworkWorld
from ecs_world.components import (
    Identity, Problem, Assignment, EvidenceLedger, Freshness, Blackboard, Remainder, PassHistory
)

CONFIG = Path(__file__).parents[1] / "world"


def test_all_active_problems_receive_agents():
    engine = ECSFrameworkWorld(CONFIG)
    engine.step()
    for eid, ident, problem, assignment in engine.world.query(Identity, Problem, Assignment):
        assert problem.status == "open"
        assert assignment.agent_ids, ident.key


def test_every_problem_produces_evidence_and_remainder():
    engine = ECSFrameworkWorld(CONFIG)
    engine.step()
    for eid, ident, problem, evidence, remainder in engine.world.query(
        Identity, Problem, EvidenceLedger, Remainder
    ):
        assert evidence.claims, ident.key
        assert evidence.claims[-1]["status"] == "evidence-qualified"
        assert remainder.unresolved
        assert "do not overwrite" in remainder.next_state


def test_cooperation_blackboard_preserves_problem_provenance():
    engine = ECSFrameworkWorld(CONFIG)
    engine.step()
    rows = list(engine.world.query(Blackboard))
    assert len(rows) == 1
    _, board = rows[0]
    problems = {x["problem"] for x in board.entries}
    assert {"P-CROSS-CARRIER", "P-ORBIT-RECOVERY", "P-INTEGRATION", "P-POOL"} <= problems
    assert all("authors" in x and "sources" in x for x in board.entries)


def test_knowledge_decay_reopens_only_freshness_sensitive_criteria():
    from ecs_world.components import AcceptanceLedger, CriterionGraph
    from ecs_world.systems import KnowledgeDecaySystem

    engine = ECSFrameworkWorld(CONFIG)
    engine.step()
    world = engine.world
    target = None
    for eid, ident, problem, fresh, evidence, ledger, graph, history in world.query(
        Identity, Problem, Freshness, EvidenceLedger, AcceptanceLedger, CriterionGraph, PassHistory
    ):
        if ident.key == "P-CROSS-CARRIER":
            target = (fresh, evidence, ledger, graph, history)
            break
    assert target is not None
    fresh, evidence, ledger, graph, history = target
    criterion = "Knowledge freshness classified"
    ledger.criteria[criterion] = {
        "status": "supported", "support": ["source:v1"], "cycle": 1, "problem_pass": 1
    }
    evidence.claims.append({"criterion": criterion, "status": "evidence-qualified", "cycle": 1})
    fresh.max_age_cycles = 1
    # Freshness age is local to this problem's own passes, not unrelated world cycles.
    history.passes = [{"cycle": 1}, {"cycle": 2}, {"cycle": 3}]
    world.cycle = 99
    KnowledgeDecaySystem().run(world)
    assert ledger.criteria[criterion]["status"] == "stale"
    assert graph.nodes[criterion]["runtime_status"] == "STALE"
    assert fresh.stale is True
    assert evidence.claims[-1]["status"] == "stale-reverify"
    assert ledger.criteria["At least one explicit carrier-transform-receiver test"]["status"] == "supported"


def test_unrelated_world_cycles_do_not_age_freshness_sensitive_criterion():
    from ecs_world.components import AcceptanceLedger, CriterionGraph
    from ecs_world.systems import KnowledgeDecaySystem

    engine = ECSFrameworkWorld(CONFIG)
    engine.step()
    for _, ident, problem, fresh, evidence, ledger, graph, history in engine.world.query(
        Identity, Problem, Freshness, EvidenceLedger, AcceptanceLedger, CriterionGraph, PassHistory
    ):
        if ident.key != "P-CROSS-CARRIER":
            continue
        criterion = "Knowledge freshness classified"
        ledger.criteria[criterion] = {
            "status": "supported", "support": ["source:v1"], "cycle": 1,
            "problem_pass": len(history.passes)
        }
        graph.nodes[criterion]["runtime_status"] = "SUPPORTED"
        evidence.claims.append({"criterion": criterion, "status": "evidence-qualified", "cycle": 1})
        fresh.max_age_cycles = 1
        engine.world.cycle += 1000
        KnowledgeDecaySystem().run(engine.world)
        assert ledger.criteria[criterion]["status"] == "supported"
        assert graph.nodes[criterion]["runtime_status"] == "SUPPORTED"
        assert fresh.stale is False
        return
    raise AssertionError("P-CROSS-CARRIER not found")

def test_forward_pass_keeps_evidence_when_ephemeral_state_resets():
    engine = ECSFrameworkWorld(CONFIG)
    engine.step(reset=True)
    counts_before = {eid: len(ev.claims) for eid, ev in engine.world.query(EvidenceLedger)}
    engine.step(reset=True)
    counts_after = {eid: len(ev.claims) for eid, ev in engine.world.query(EvidenceLedger)}
    for eid in counts_before:
        assert counts_after[eid] > counts_before[eid]


def test_each_team_contributes_before_selection():
    from ecs_world.components import ContributionLedger, Selection
    engine = ECSFrameworkWorld(CONFIG)
    engine.step()
    for _, ident, problem, assignment, contributions, selection in engine.world.query(
        Identity, Problem, Assignment, ContributionLedger, Selection
    ):
        assert len(contributions.entries) == len(assignment.agent_ids) >= 1, ident.key
        assert set(selection.option["contributors"]) == {x["agent_key"] for x in contributions.entries}


def test_router_uses_problem_appropriate_primary_carriers_and_independent_verifier():
    from ecs_world.components import ActionState, DispatchLog
    engine = ECSFrameworkWorld(CONFIG)
    engine.step()
    expected = {
        "P-CROSS-CARRIER": "computation",
        "P-ORBIT-RECOVERY": "local-files",
        "P-INTEGRATION": "computation",
        "P-POOL": "computation",
    }
    for _, ident, problem, action, dispatch in engine.world.query(Identity, Problem, ActionState, DispatchLog):
        assert action.carrier == expected[ident.key]
        executes = [x for x in dispatch.attempts if x["mode"] == "execute"]
        verifies = [x for x in dispatch.attempts if x["mode"] == "verify"]
        assert executes and executes[0]["ok"] is True
        assert verifies and verifies[0]["executor_key"] != executes[0]["executor_key"]
        assert verifies[0]["ok"] is True


def test_pass_history_survives_reset_and_grows_forward_only():
    from ecs_world.components import PassHistory
    engine = ECSFrameworkWorld(CONFIG)
    engine.step(reset=True)
    before = {eid: len(h.passes) for eid, h in engine.world.query(PassHistory)}
    engine.step(reset=True)
    after = {eid: len(h.passes) for eid, h in engine.world.query(PassHistory)}
    assert all(after[eid] == before[eid] + 1 for eid in before)
    for _, h in engine.world.query(PassHistory):
        assert [x["cycle"] for x in h.passes] == sorted(x["cycle"] for x in h.passes)


def test_orbit_retrieval_does_not_invent_missing_sources():
    from ecs_world.components import ObservationLog
    engine = ECSFrameworkWorld(CONFIG)
    engine.step()
    for _, ident, problem, obs in engine.world.query(Identity, Problem, ObservationLog):
        if ident.key == "P-ORBIT-RECOVERY":
            result = obs.items[-1]
            assert result["carrier"] == "local-files"
            assert "remains unresolved" in result["result"]
            assert result["substantive"] is False
            assert all(not x.startswith("file:sha256:") for x in result["evidence"])


def test_restart_computation_carrier_round_trip_is_real_not_fallback():
    from ecs_world.components import ObservationLog
    engine = ECSFrameworkWorld(CONFIG)
    engine.step()
    for _, ident, problem, obs in engine.world.query(Identity, Problem, ObservationLog):
        if ident.key == "P-INTEGRATION":
            result = obs.items[-1]
            assert result["carrier"] == "computation"
            assert result["artifact"]["round_trip_equal"] is True
            assert len(result["artifact"]["canonical_sha256"]) == 64


def test_scheduler_stops_repeating_when_admissible_evidence_carrier_is_unavailable():
    from ecs_world.components import PassHistory, CriterionGraph, SchedulerState

    engine = ECSFrameworkWorld(CONFIG)
    for _ in range(6):
        engine.step(reset=True)

    for _, ident, problem, history, graph, scheduler in engine.world.query(
        Identity, Problem, PassHistory, CriterionGraph, SchedulerState
    ):
        if ident.key == "P-CROSS-CARRIER":
            # Only the two locally admissible criteria run; external evidence gaps are blocked.
            assert len(history.passes) == 2
            assert graph.nodes["Counter-probe recorded"]["runtime_status"] == "BLOCKED_EVIDENCE"
            assert graph.nodes["Knowledge freshness classified"]["runtime_status"] == "BLOCKED_EVIDENCE"
            assert scheduler.status == "BLOCKED"
        if ident.key == "P-INTEGRATION":
            assert problem.status == "complete"
            assert len(history.passes) == 4

def test_carrier_failure_is_isolated_and_falls_back_without_erasing_attempt():
    from ecs_world.carriers import RuleCarrierAdapter, LocalFileCarrierAdapter
    from ecs_world.router import CarrierRouter
    from ecs_world.runner import ECSFrameworkWorld
    from ecs_world.components import ActionState, DispatchLog

    class ExplodingCarrier:
        def execute(self, request):
            raise RuntimeError("simulated carrier fault")

    class ReferenceCarrier:
        def execute(self, request):
            return {
                "ok": True,
                "result": "bounded fallback observation",
                "evidence": ["fallback:test"],
                "evidence_kind": "execution-trace",
                "scope_kind": "internal",
                "substantive": False,
            }

    router = CarrierRouter({
        "computation": ExplodingCarrier(),
        "local-files": LocalFileCarrierAdapter([CONFIG]),
        "rule": RuleCarrierAdapter(),
        "reference": ReferenceCarrier(),
    })
    engine = ECSFrameworkWorld(CONFIG, router=router)
    engine.step()
    for _, ident, problem, action, dispatch in engine.world.query(Identity, Problem, ActionState, DispatchLog):
        if ident.key == "P-CROSS-CARRIER":
            assert action.carrier == "reference"
            assert dispatch.attempts[0]["executor_key"] == "computation"
            assert dispatch.attempts[0]["ok"] is False
            assert dispatch.attempts[1]["executor_key"] == "reference"
            assert dispatch.attempts[1]["ok"] is True


def test_unbound_external_carrier_can_be_explicitly_bound_without_engine_changes():
    from ecs_world.live import CallableCarrierAdapter, bind_carrier
    from ecs_world.components import Carrier, Identity

    engine = ECSFrameworkWorld(CONFIG)
    seen = {}

    def fake_model(request):
        seen["problem"] = request["problem_key"]
        return {"ok": True, "result": "model candidate only", "evidence": [], "substantive": False}

    eid = bind_carrier(engine.world, engine.router, "model", CallableCarrierAdapter(fake_model))
    ident = engine.world.get(eid, Identity)
    carrier = engine.world.get(eid, Carrier)
    assert ident.key == "C-MODEL"
    assert carrier.enabled is True
    assert "model" in engine.router.adapters


def test_criterion_team_dispatches_only_declared_criterion_methods():
    from ecs_world.components import ContributionLedger, Selection, CriterionGraph

    engine = ECSFrameworkWorld(CONFIG)
    engine.step()
    for _, ident, problem, graph, contributions, selection in engine.world.query(
        Identity, Problem, CriterionGraph, ContributionLedger, Selection
    ):
        criterion = graph.active_criterion
        assert criterion is not None, ident.key
        assert contributions.entries
        allowed = set(graph.nodes[criterion]["methods"])
        assert selection.option["method"] in allowed
        assert selection.option["target_criterion"] == criterion
        # Supporting reviewers may use other methods, but they cannot become the dispatched action.
        selected_name = selection.option["name"]
        selected = [e for e in contributions.entries if selected_name.startswith(e["agent_key"] + ":")]
        if selected:
            assert selected[0]["eligible_action_method"] is True

def test_jsonl_host_bridge_has_stable_retry_identity_and_emits_once(tmp_path):
    from ecs_world.bridge import JsonlHostBridgeAdapter, pending_host_requests

    outbox = tmp_path / "outbox.jsonl"
    inbox = tmp_path / "inbox.jsonl"
    adapter = JsonlHostBridgeAdapter("research", outbox, inbox)
    request = {
        "cycle": 1,
        "dispatch_id": "ignored-a",
        "problem_key": "P-X",
        "mode": "execute",
        "action": {"name": "DECAY:freshness-gate", "method": "freshness-gate", "uses": ["freshness"]},
        "boundary": ["bounded"],
        "acceptance": ["current evidence"],
        "target_output": "freshness result",
        "sources": ["source-a"],
    }
    first = adapter.execute(request)
    request2 = dict(request, cycle=99, dispatch_id="ignored-b")
    second = adapter.execute(request2)
    assert first["pending"] is True and second["pending"] is True
    assert first["request_id"] == second["request_id"]
    assert len(outbox.read_text().splitlines()) == 1
    assert len(pending_host_requests(outbox, inbox)) == 1


def test_jsonl_host_bridge_ingests_evidence_without_world_mutation(tmp_path):
    from ecs_world.bridge import JsonlHostBridgeAdapter, append_host_response, pending_host_requests

    outbox = tmp_path / "outbox.jsonl"
    inbox = tmp_path / "inbox.jsonl"
    adapter = JsonlHostBridgeAdapter("library", outbox, inbox)
    request = {
        "problem_key": "P-ORBIT-RECOVERY",
        "mode": "execute",
        "action": {"name": "LIBRARIAN:recovery-map", "method": "recovery-map"},
        "boundary": ["exact source only"],
        "acceptance": ["source resolved or unresolved"],
        "target_output": "recovery path",
        "sources": ["exact.md"],
    }
    pending = adapter.execute(request)
    append_host_response(inbox, {
        "request_id": pending["request_id"],
        "ok": True,
        "result": "Resolved exact library source.",
        "evidence": ["library:file:123@v4"],
        "evidence_kind": "file-reference",
        "scope_kind": "external-file",
        "substantive": True,
        "confidence": 0.99,
    })
    resolved = adapter.execute(request)
    assert resolved["ok"] is True
    assert resolved["pending"] is False
    assert resolved["substantive"] is True
    assert resolved["evidence"] == ["library:file:123@v4"]
    assert pending_host_requests(outbox, inbox) == []


def test_host_bridge_downgrades_unsupported_substantive_claim(tmp_path):
    from ecs_world.bridge import JsonlHostBridgeAdapter, append_host_response

    outbox = tmp_path / "outbox.jsonl"
    inbox = tmp_path / "inbox.jsonl"
    adapter = JsonlHostBridgeAdapter("model", outbox, inbox)
    request = {
        "problem_key": "P-X",
        "mode": "execute",
        "action": {"name": "SYNTH:bounded-synthesis", "method": "bounded-synthesis"},
        "boundary": ["no unsupported facts"],
    }
    pending = adapter.execute(request)
    append_host_response(inbox, {
        "request_id": pending["request_id"],
        "ok": True,
        "result": "Unsupported factual claim",
        "evidence": [],
        "substantive": True,
    })
    resolved = adapter.execute(request)
    assert resolved["substantive"] is False
    assert any("downgraded" in x for x in resolved["unresolved"])


def test_pending_host_dispatch_preserves_exact_action_for_retry(tmp_path):
    from ecs_world.bridge import bind_jsonl_host_bridges
    from ecs_world.components import ActionState, ObservationLog, ConsequenceLog, Selection
    from ecs_world.systems import ResetForNextPassSystem

    engine = ECSFrameworkWorld(CONFIG)
    bind_jsonl_host_bridges(engine.world, engine.router, tmp_path)

    # Force one problem to a host-bound synthesis action to test the reset contract directly.
    target = None
    for pid, ident, problem, selection, action, obs, cons in engine.world.query(
        Identity, Problem, Selection, ActionState, ObservationLog, ConsequenceLog
    ):
        if ident.key == "P-CROSS-CARRIER":
            target = (pid, selection, action, obs, cons)
            break
    assert target is not None
    pid, selection, action, obs, cons = target
    selection.option = {"name": "SYNTH:bounded-synthesis", "method": "bounded-synthesis", "uses": ["relations"], "cost": 0.1}
    action.action = dict(selection.option)
    action.carrier = "model"
    obs.items.append({"pending": True, "request_id": "host:model:abc"})
    cons.items.append({"accepted": False})
    before = dict(action.action)
    ResetForNextPassSystem().run(engine.world)
    assert action.action == before
    assert selection.option == before
    assert obs.items == [] and cons.items == []


def test_bound_host_research_carrier_can_complete_router_dispatch(tmp_path):
    from ecs_world.bridge import bind_jsonl_host_bridges, append_host_response
    from ecs_world.components import Budget

    engine = ECSFrameworkWorld(CONFIG)
    bind_jsonl_host_bridges(engine.world, engine.router, tmp_path)
    budget = Budget(attention=1.0, compute=1.0, money=1.0)
    action = {"name": "DECAY:freshness-gate", "method": "freshness-gate", "uses": ["freshness"], "cost": 0.1}
    context = {
        "cycle": 1,
        "boundary": ["current evidence only"],
        "acceptance": ["freshness classified"],
        "target_output": "freshness classification",
        "sources": [],
    }
    first = engine.router.dispatch(engine.world, "P-X", action, budget, context)
    assert first["pending"] is True
    assert first["carrier"] == "research"
    request_id = first["request_id"]
    append_host_response(tmp_path / "inbox.jsonl", {
        "request_id": request_id,
        "ok": True,
        "result": "Current source checked.",
        "evidence": ["source:https://example.test/current#v1"],
        "evidence_kind": "external-source",
        "scope_kind": "external",
        "substantive": True,
        "confidence": 0.9,
    })
    second = engine.router.dispatch(engine.world, "P-X", action, budget, dict(context, cycle=2))
    assert second["ok"] is True
    assert second["carrier"] == "research"
    assert second["substantive"] is True
    assert second["request_id"] == request_id


def test_world_snapshot_restores_cycle_history_evidence_and_sets(tmp_path):
    from ecs_world.components import Agent, PassHistory, EvidenceLedger

    engine = ECSFrameworkWorld(CONFIG)
    engine.step(reset=True)
    engine.step(reset=True)
    snap = tmp_path / "world.json"
    engine.save_snapshot(snap)

    restored = ECSFrameworkWorld(CONFIG, snapshot=snap)
    assert restored.world.cycle == 2
    original_hist = {eid: len(x.passes) for eid, x in engine.world.query(PassHistory)}
    restored_hist = {eid: len(x.passes) for eid, x in restored.world.query(PassHistory)}
    assert restored_hist == original_hist
    original_ev = {eid: len(x.claims) for eid, x in engine.world.query(EvidenceLedger)}
    restored_ev = {eid: len(x.claims) for eid, x in restored.world.query(EvidenceLedger)}
    assert restored_ev == original_ev
    assert all(isinstance(agent.skills, set) and isinstance(agent.active_assignments, set) for _, agent in restored.world.query(Agent))


def test_snapshot_restore_rejects_identity_drift(tmp_path):
    import json

    engine = ECSFrameworkWorld(CONFIG)
    engine.step()
    snap = tmp_path / "bad.json"
    engine.save_snapshot(snap)
    data = json.loads(snap.read_text())
    first_identity = next(iter(data["components"]["Identity"].values()))
    first_identity["key"] = "DRIFTED"
    snap.write_text(json.dumps(data))
    try:
        ECSFrameworkWorld(CONFIG, snapshot=snap)
    except ValueError as exc:
        assert "identity mismatch" in str(exc)
    else:
        raise AssertionError("identity drift should be rejected")


def test_pending_host_action_survives_process_snapshot_and_can_resume(tmp_path):
    from ecs_world.bridge import append_host_response
    from ecs_world.components import Identity, Problem, ActionState, PassHistory

    bridge = tmp_path / "bridge"
    engine = ECSFrameworkWorld(CONFIG, bridge_dir=bridge)
    # Two cycles reach the cross-carrier host-bound cross-carrier-check; reset preserves that pending action.
    engine.step(reset=True)
    engine.step(reset=True)
    pending_action = None
    pending_request = None
    for _, ident, problem, action, history in engine.world.query(Identity, Problem, ActionState, PassHistory):
        if ident.key == "P-CROSS-CARRIER":
            pending_action = dict(action.action or {})
            pending_request = history.passes[-1]["observation"].get("request_id")
            assert history.passes[-1]["claim"]["status"] == "pending-carrier"
    assert pending_action and pending_request

    snap = tmp_path / "pending-world.json"
    engine.save_snapshot(snap)
    append_host_response(bridge / "inbox.jsonl", {
        "request_id": pending_request,
        "ok": True,
        "result": "Independent host counter-check completed.",
        "evidence": ["compute:artifact:test-resume"],
        "evidence_kind": "external-computation",
        "scope_kind": "external-computation",
        "substantive": True,
        "confidence": 0.9,
        "satisfies": ["Counter-probe recorded"],
    })

    resumed = ECSFrameworkWorld(CONFIG, bridge_dir=bridge, snapshot=snap)
    resumed.step(reset=False)
    for _, ident, problem, action, history in resumed.world.query(Identity, Problem, ActionState, PassHistory):
        if ident.key == "P-CROSS-CARRIER":
            assert history.passes[-1]["cycle"] == 3
            assert history.passes[-1]["claim"]["status"] == "evidence-qualified"
            assert history.passes[-1]["selection"]["name"] == pending_action["name"]
            assert history.passes[-1]["observation"]["request_id"] == pending_request


def test_global_task_board_exposes_complete_pending_and_blocked_frontier():
    from ecs_world.components import TaskBoard

    engine = ECSFrameworkWorld(CONFIG)
    for _ in range(6):
        engine.step(reset=True)
    rows = list(engine.world.query(TaskBoard))
    assert len(rows) == 1
    _, board = rows[0]
    assert len(board.tasks) == 17
    assert len(board.completed) == 11
    assert len(board.pending) == 1
    assert len(board.blocked) == 5
    assert board.frontier == []
    assert any("Cleaning consequence measured" in x for x in board.pending)


def test_local_human_queue_is_retry_stable_and_emits_once(tmp_path):
    from ecs_world.carriers import HumanQueueCarrierAdapter

    queue = tmp_path / "human.jsonl"
    adapter = HumanQueueCarrierAdapter(queue)
    request = {
        "problem_key": "P-POOL",
        "criterion": "Cleaning consequence measured",
        "acceptance": ["Cleaning consequence measured"],
        "boundary": ["bounded"],
        "action": {"method": "physical-measurement", "target_criterion": "Cleaning consequence measured"},
    }
    first = adapter.execute(request)
    second = adapter.execute(dict(request, cycle=999, dispatch_id="different"))
    assert first["request_id"] == second["request_id"]
    assert len(queue.read_text().splitlines()) == 1


def test_binding_host_carriers_reopens_evidence_blocked_criterion(tmp_path):
    from ecs_world.bridge import bind_jsonl_host_bridges
    from ecs_world.components import CriterionGraph, PassHistory

    engine = ECSFrameworkWorld(CONFIG)
    engine.step(reset=True)
    engine.step(reset=True)
    cross = next((row for row in engine.world.query(Identity, Problem, CriterionGraph) if row[1].key == "P-CROSS-CARRIER"), None)
    assert cross is not None
    assert cross[3].nodes["Counter-probe recorded"]["runtime_status"] == "BLOCKED_EVIDENCE"

    bind_jsonl_host_bridges(engine.world, engine.router, tmp_path)
    engine.step(reset=True)
    row = next(row for row in engine.world.query(Identity, Problem, CriterionGraph, PassHistory) if row[1].key == "P-CROSS-CARRIER")
    graph, history = row[3], row[4]
    assert graph.nodes["Counter-probe recorded"]["runtime_status"] == "PENDING"
    assert history.passes[-1]["criterion"] == "Counter-probe recorded"
    assert history.passes[-1]["carrier"] == "scientific-compute"
    assert history.passes[-1]["claim"]["status"] == "pending-carrier"


def test_host_external_evidence_closes_exact_target_criterion_after_retry(tmp_path):
    from ecs_world.bridge import append_host_response
    from ecs_world.components import AcceptanceLedger, PassHistory

    engine = ECSFrameworkWorld(CONFIG, bridge_dir=tmp_path)
    engine.step(reset=True)
    engine.step(reset=True)
    row = next(row for row in engine.world.query(Identity, Problem, PassHistory) if row[1].key == "P-CROSS-CARRIER")
    request_id = row[3].passes[-1]["observation"]["request_id"]
    append_host_response(tmp_path / "inbox.jsonl", {
        "request_id": request_id,
        "ok": True,
        "result": "Independent scientific counter-probe completed.",
        "evidence": ["external-computation:artifact:v1"],
        "evidence_kind": "external-computation",
        "scope_kind": "external-computation",
        "substantive": True,
        "confidence": 0.95,
    })
    engine.step(reset=True)
    row = next(row for row in engine.world.query(Identity, Problem, AcceptanceLedger, PassHistory) if row[1].key == "P-CROSS-CARRIER")
    ledger, history = row[3], row[4]
    assert ledger.criteria["Counter-probe recorded"]["status"] == "supported"
    assert history.passes[-1]["criterion"] == "Counter-probe recorded"
    assert history.passes[-1]["observation"]["request_id"] == request_id
    assert history.passes[-1]["claim"]["status"] == "evidence-qualified"


def test_dependency_block_prevents_downstream_orbit_human_review():
    from ecs_world.components import CriterionGraph

    engine = ECSFrameworkWorld(CONFIG)
    for _ in range(4):
        engine.step(reset=True)
    row = next(row for row in engine.world.query(Identity, Problem, CriterionGraph) if row[1].key == "P-ORBIT-RECOVERY")
    graph = row[3]
    assert graph.nodes["Primary evidence path recorded"]["runtime_status"] == "BLOCKED_EVIDENCE"
    assert graph.nodes["Accessible recovery interface retained"]["runtime_status"] == "BLOCKED"


def test_snapshot_restores_criterion_scheduler_and_task_board(tmp_path):
    from ecs_world.components import CriterionGraph, SchedulerState, TaskBoard

    engine = ECSFrameworkWorld(CONFIG)
    for _ in range(4):
        engine.step(reset=True)
    snap = tmp_path / "criterion-world.json"
    engine.save_snapshot(snap)
    restored = ECSFrameworkWorld(CONFIG, snapshot=snap)

    original_graphs = {eid: (g.active_criterion, {k: v["runtime_status"] for k, v in g.nodes.items()}) for eid, g in engine.world.query(CriterionGraph)}
    restored_graphs = {eid: (g.active_criterion, {k: v["runtime_status"] for k, v in g.nodes.items()}) for eid, g in restored.world.query(CriterionGraph)}
    assert restored_graphs == original_graphs
    original_scheduler = {eid: (s.status, s.reason) for eid, s in engine.world.query(SchedulerState)}
    restored_scheduler = {eid: (s.status, s.reason) for eid, s in restored.world.query(SchedulerState)}
    assert restored_scheduler == original_scheduler
    original_board = next(engine.world.query(TaskBoard))[1]
    restored_board = next(restored.world.query(TaskBoard))[1]
    assert restored_board.tasks == original_board.tasks
    assert restored_board.blocked == original_board.blocked


def test_counter_probe_request_carries_exact_dependency_artifact(tmp_path):
    import json

    engine = ECSFrameworkWorld(CONFIG, bridge_dir=tmp_path)
    engine.step(reset=True)
    engine.step(reset=True)
    rows = [json.loads(x) for x in (tmp_path / "outbox.jsonl").read_text().splitlines() if x.strip()]
    req = next(x for x in rows if x["carrier"] == "scientific-compute")
    ctx = req["semantic_request"]["action"]["dependency_context"]
    dep = ctx["At least one explicit carrier-transform-receiver test"]
    assert dep["artifact"]["boundary_count"] == 4
    assert dep["artifact"]["receiver"] == "P-CROSS-CARRIER"
    assert dep["carrier"] == "computation"


def test_pool_human_measurement_request_inherits_experiment_and_safety_artifacts(tmp_path):
    import json

    engine = ECSFrameworkWorld(CONFIG, bridge_dir=tmp_path)
    for _ in range(4):
        engine.step(reset=True)
    rows = [json.loads(x) for x in (tmp_path / "outbox.jsonl").read_text().splitlines() if x.strip()]
    req = next(x for x in rows if x["carrier"] == "human-queue")
    action = req["semantic_request"]["action"]
    dep = action["dependency_context"]
    experiment = dep["One independently varied degree"]["artifact"]
    assert experiment["change_one"] == "auxiliary cleaner state"
    assert experiment["levels"] == ["OFF", "ON"]
    assert experiment["off_control"] is True
    assert dep["Safety boundary preserved"]["result"]
    payload = action["task_payload"]
    assert "captured debris mass" in " ".join(payload["record_fields"]).lower()


def test_unchanged_pending_request_does_not_spam_pass_history(tmp_path):
    from ecs_world.components import PassHistory

    engine = ECSFrameworkWorld(CONFIG, bridge_dir=tmp_path)
    for _ in range(8):
        engine.step(reset=True)
    pool = next(row for row in engine.world.query(Identity, Problem, PassHistory) if row[1].key == "P-POOL")
    history = pool[3]
    pending = [p for p in history.passes if p.get("claim", {}).get("status") == "pending-human"]
    assert len(pending) == 1
    assert pending[0]["observation"]["request_id"].startswith("host:human-queue:")


def test_final_criterion_closes_problem_in_same_recorded_pass():
    engine = ECSFrameworkWorld(CONFIG)
    for _ in range(4):
        engine.step(reset=True)
    for _, ident, problem, history in engine.world.query(Identity, Problem, PassHistory):
        if ident.key == "P-INTEGRATION":
            assert problem.status == "complete"
            assert len(history.passes) == 4
            assert history.passes[-1]["criterion"] == "Representative integration task passes or fails explicitly"
            return
    raise AssertionError("P-INTEGRATION not found")
