from __future__ import annotations
import json
from pathlib import Path

import pytest

from ecs_world.components import BranchPortfolio, CrossProjectGraph, IntakeQueue, Identity, Problem
from ecs_world.intake import admit_request, decompose_request, load_branch_catalog, stable_problem_key
from ecs_world.loader import load_world
from ecs_world.systems import PortfolioSystem

ROOT = Path(__file__).resolve().parents[1]
CONFIG = ROOT / "world"


def _request(**overrides):
    row = {
        "subject": "Test bounded task",
        "motivator": "Need a deterministic intake contract.",
        "request": "Create a bounded executable problem specification.",
        "obligation": "Preserve evidence and unresolved remainder.",
        "branch": "hodge",
    }
    row.update(overrides)
    return row


def test_branch_portfolio_represents_all_context_paths():
    world = load_world(CONFIG)
    rows = list(world.query(BranchPortfolio))
    assert len(rows) == 1
    portfolio = rows[0][1]
    assert len(portfolio.branches) >= 39
    for key in ["hodge", "p-vs-np", "physics-extra-dim", "pool-water", "accessibility", "tbcl", "shadow", "redogit-conscience64"]:
        assert key in portfolio.branches


def test_cross_project_links_never_transfer_authority():
    world = load_world(CONFIG)
    graph = list(world.query(CrossProjectGraph))[0][1]
    assert graph.links
    assert all(link.get("authority_transfer") is False for link in graph.links)


def test_portfolio_system_exposes_separate_frontiers():
    world = load_world(CONFIG)
    PortfolioSystem().run(world)
    portfolio = list(world.query(BranchPortfolio))[0][1]
    assert "hodge" in portfolio.open_research_frontier
    assert "p-vs-np" in portfolio.open_research_frontier
    assert "pool-water" in portfolio.human_frontier
    assert "accessibility" in portfolio.human_frontier
    assert "redogit-conscience64" in portfolio.external_frontier


def test_open_problem_ceiling_is_not_promoted_by_portfolio():
    world = load_world(CONFIG)
    PortfolioSystem().run(world)
    portfolio = list(world.query(BranchPortfolio))[0][1]
    assert portfolio.branches["hodge"]["coverage"] == "OPEN_NOT_ESTABLISHED"
    assert "no proof" in portfolio.branches["hodge"]["claim_ceiling"]
    assert portfolio.branches["p-vs-np"]["coverage"] == "OPEN_NOT_ESTABLISHED"


def test_stable_problem_key_is_deterministic_and_request_sensitive():
    a = _request()
    b = dict(a)
    assert stable_problem_key(a) == stable_problem_key(b)
    b["obligation"] = "Different obligation"
    assert stable_problem_key(a) != stable_problem_key(b)


def test_intake_requires_standard_interface_fields():
    catalog = load_branch_catalog(CONFIG)
    req = _request()
    del req["obligation"]
    with pytest.raises(ValueError, match="obligation"):
        decompose_request(req, catalog)


def test_research_intake_builds_dependency_and_evidence_graph():
    spec = decompose_request(_request(), load_branch_catalog(CONFIG))
    assert spec["intake"]["problem_class"] == "research"
    assert len(spec["criteria"]) == 4
    assert spec["criteria"][1]["depends_on"] == [spec["criteria"][0]["criterion"]]
    assert "external-source" in spec["criteria"][1]["evidence_kinds"]
    assert spec["criteria"][2]["requires_corroboration"] is True
    assert any("Branch claim ceiling" in x for x in spec["boundary"])


def test_physical_intake_requires_real_human_observation():
    spec = decompose_request(_request(branch="pool-water"), load_branch_catalog(CONFIG))
    measurement = next(x for x in spec["criteria"] if x["criterion"] == "Physical consequence measured")
    assert measurement["requires_human"] is True
    assert measurement["evidence_kinds"] == ["human-observation"]


def test_application_intake_does_not_convert_tooling_into_research_evidence():
    spec = decompose_request(_request(branch="excel-jaws"), load_branch_catalog(CONFIG))
    assert spec["intake"]["problem_class"] == "application"
    assert any("application behavior" in x.lower() for x in spec["boundary"] if "Branch claim ceiling" in x)


def test_generated_problem_admission_is_idempotent_in_isolated_config(tmp_path):
    # Copy only the configuration files needed by intake/load; do not mutate the packaged config.
    import shutil
    config = tmp_path / "world"
    shutil.copytree(CONFIG, config)
    (config / "generated_problems.json").write_text("[]\n")
    (config / "intake_queue.json").write_text(json.dumps({"pending": [], "admitted": [], "rejected": []}, indent=2))
    req = _request(branch="redogit-conscience64")
    first = admit_request(config, req)
    second = admit_request(config, req)
    assert first["key"] == second["key"]
    generated = json.loads((config / "generated_problems.json").read_text())
    assert len(generated) == 1
    state = json.loads((config / "intake_queue.json").read_text())
    assert len(state["admitted"]) == 1
    world = load_world(config)
    problem_keys = {ident.key for _, ident, _ in world.query(Identity, Problem)}
    assert first["key"] in problem_keys


def test_intake_queue_component_is_durable_world_data():
    world = load_world(CONFIG)
    queue = list(world.query(IntakeQueue))[0][1]
    assert isinstance(queue.pending, list)
    assert isinstance(queue.admitted, list)
    assert isinstance(queue.rejected, list)


def test_branch_context_sources_are_explicit_and_small():
    branches = json.loads((CONFIG / "branches.json").read_text())
    assert all(b.get("context_source_ids") for b in branches)
    sources = {x["id"] for x in json.loads((CONFIG / "context_sources.json").read_text())}
    assert all(set(b["context_source_ids"]) <= sources for b in branches)
