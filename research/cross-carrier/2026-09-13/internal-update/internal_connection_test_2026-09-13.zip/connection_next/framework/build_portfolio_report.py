from __future__ import annotations
import json
from collections import defaultdict
from pathlib import Path

from ecs_world.loader import load_world
from ecs_world.components import BranchPortfolio, CrossProjectGraph
from ecs_world.systems import PortfolioSystem

ROOT=Path(__file__).resolve().parent
CONFIG=ROOT/'world'
world=load_world(CONFIG)
PortfolioSystem().run(world)
portfolio=list(world.query(BranchPortfolio))[0][1]
graph=list(world.query(CrossProjectGraph))[0][1]

state={
    'framework_version':'0.5.0',
    'date':'2026-09-12',
    'branch_count':len(portfolio.branches),
    'runtime_summary':portfolio.runtime_summary,
    'machine_frontier':portfolio.machine_frontier,
    'human_frontier':portfolio.human_frontier,
    'external_frontier':portfolio.external_frontier,
    'open_research_frontier':portfolio.open_research_frontier,
    'cross_project_link_count':len(graph.links),
    'all_links_authority_transfer_false':all(x.get('authority_transfer') is False for x in graph.links),
    'branches':portfolio.branches,
    'links':graph.links,
}
(ROOT/'ALL_PATHS_STATE.json').write_text(json.dumps(state,indent=2)+'\n')

groups=defaultdict(list)
for key,b in sorted(portfolio.branches.items()):
    groups[b.get('group','other')].append((key,b))
lines=[
    '# All Context Paths — v0.5.0', '',
    '**Date:** 2026-09-12',
    '**Boundary:** this is a bounded portfolio over currently surfaced context, not an account-wide completeness claim.', '',
    'Projects remain separate objects. Cross-project links may pressure, test, locate, generate, or supply recovery patterns; they do not automatically transfer evidence, authority, identity, or applicability.', '',
    f'**Branches represented:** {len(portfolio.branches)}',
    f'**Typed cross-project links:** {len(graph.links)} (authority transfer allowed: no)', '',
    '## Frontiers', '',
    f'- Machine/intake frontier: {", ".join(portfolio.machine_frontier) if portfolio.machine_frontier else "none"}',
    f'- Human/physical frontier: {", ".join(portfolio.human_frontier) if portfolio.human_frontier else "none"}',
    f'- External-configuration frontier: {", ".join(portfolio.external_frontier) if portfolio.external_frontier else "none"}',
    f'- Open-research frontier: {", ".join(portfolio.open_research_frontier) if portfolio.open_research_frontier else "none"}', '',
    '## Runtime state counts', ''
]
for k,v in sorted(portfolio.runtime_summary.items()): lines.append(f'- `{k}`: {v}')
for group,rows in sorted(groups.items()):
    lines += ['', f'## {group}', '', '| Path | Runtime | Coverage | Next bounded obligation | Claim ceiling |', '|---|---|---|---|---|']
    for key,b in rows:
        def esc(x): return str(x).replace('|','\\|').replace('\n',' ')
        lines.append(f'| `{key}` | `{esc(b.get("runtime_status"))}` | `{esc(b.get("coverage"))}` | {esc(b.get("next_obligation"))} | {esc(b.get("claim_ceiling"))} |')
lines += ['', '## Cross-project relation rule', '', 'Every link in `world/cross_project_links.json` has `authority_transfer: false`. Receiving branches must independently admit any evidence or method through their own obligation/evidence gates.', '']
(ROOT/'ALL_PATHS_STATE.md').write_text('\n'.join(lines))
print(json.dumps({k:state[k] for k in ['branch_count','runtime_summary','machine_frontier','human_frontier','external_frontier','open_research_frontier','cross_project_link_count']},indent=2))
