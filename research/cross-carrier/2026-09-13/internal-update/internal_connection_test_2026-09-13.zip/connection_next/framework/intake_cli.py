#!/usr/bin/env python3
from __future__ import annotations
import argparse, json
from pathlib import Path
from ecs_world.intake import admit_request, decompose_request, load_branch_catalog


def main():
    ap=argparse.ArgumentParser(description="Deterministic bounded problem intake for ECS World")
    ap.add_argument("request", help="JSON request file")
    ap.add_argument("--config", default=str(Path(__file__).parent / "world"))
    ap.add_argument("--admit", action="store_true", help="append to generated_problems.json")
    ap.add_argument("--output", default="-")
    args=ap.parse_args()
    req=json.loads(Path(args.request).read_text())
    result=admit_request(args.config, req) if args.admit else decompose_request(req, load_branch_catalog(args.config))
    text=json.dumps(result, indent=2)
    if args.output == "-": print(text)
    else: Path(args.output).write_text(text+"\n")
if __name__ == "__main__": main()
