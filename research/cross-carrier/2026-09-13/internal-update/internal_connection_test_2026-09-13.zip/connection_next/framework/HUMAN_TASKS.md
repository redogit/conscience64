# Current Human Evidence Tasks

These tasks are intentionally unresolved. The ECS has reached evidence classes that the configured machine carriers are not permitted to substitute for.

## 1. Pool cleaning consequence measurement

**Problem:** `P-POOL`  
**Criterion:** `Cleaning consequence measured`

Run the already-supported OFF/ON comparison while holding the chosen geometry and normal pool-system operation fixed between conditions.

Record, at minimum:

- condition (`OFF` or `ON`);
- start/end time;
- measured or estimated flow / water processed when feasible;
- captured debris mass when it can be measured safely;
- visible debris count/type;
- normal pool-equipment state;
- weather or other major disturbances;
- anomalies or departures from the fixed setup.

Do not claim a cleaning consequence if condition, geometry, or normal pool-system state changed in a confounding way. The current experiment treats turbidity alone, TDS change, or elapsed time alone when flow differs as insufficient primary measures.

When this criterion receives admissible human observation, `Attention/maintenance cost recorded` becomes dependency-ready. That follow-on task records setup, observation, cleanup/service time, interventions, and unexpected maintenance.

## 2. Orbit accessible recovery-interface observation

**Problem:** `P-ORBIT-RECOVERY`  
**Criterion:** `Accessible recovery interface retained`

Review the task-local recovery path in an actual human/assistive-technology use setting appropriate to the claim. Check:

- linear screen-reader reading order;
- clear distinction among **not found**, **unresolved**, and **absent**;
- no color-only distinctions;
- concise task-local route before expanded historical material.

The dependency path is already evidence-supported: `ORBIT_CHRONOLOGY_2026-09-06.md` is the primary Orbit checkpoint/lineage source, while `Cross_Carrier_Field_Transform_Wave_01.md` is activated only when cross-carrier experiment/design evidence is consequential to the task.

Code-only or model-only inspection does not close this human-observation criterion.
