# Next Actions Across All Context Paths — v0.5.0

**Rule:** continue every consequential path, but do not manufacture work for dormant capabilities or evidence for blocked paths.

## ACTIVE

- **Cross Carrier Wave** (`cross-carrier-wave`): Reuse only when a receiving problem declares a consequential carrier/transform obligation. **Ceiling:** finite bounded implementations; not a universal physical field
- **Data-driven ECS** (`data-driven-ecs`): Accept new bounded problems through deterministic intake and preserve restart-safe criterion graphs. **Ceiling:** bounded framework behavior only
- **Historical knowledge recovery / Knowledge Decay** (`knowledge-decay`): Reverify recovered knowledge only when a present obligation depends on it. **Ceiling:** source-bound recovery, not global completeness
- **Orbit Lab** (`orbit`): Preserve selective primary-evidence routing; investigate host-wrapper linger only when it blocks a real task; accessibility remains human-evidence bounded. **Ceiling:** retrieval/verification behavior within recorded scope

## READY_FOR_INTAKE

- **Excel/report automation + JAWS** (`excel-jaws`): Accept a concrete report/workbook task and optimize for screen-reader-safe reading/filling without reusing unrelated spreadsheets. **Ceiling:** application behavior, not research evidence
- **Member Success / Jira** (`member-success-jira`): Accept concrete team/member-success workflow input; preserve people as people rather than categories. **Ceiling:** application workflow
- **RIVIR** (`rivir`): Accept concrete API/data-pool task through I/R/P/O boundary; keep implementation separate from claims about people or outcomes. **Ceiling:** application/API behavior

## OPEN_RESEARCH

- **Hodge conjecture** (`hodge`): Work only on explicitly bounded mathematical subclaims with proof/counterexample gates; no proof claim without complete primary mathematical evidence. **Ceiling:** open problem; no proof established
- **P vs NP** (`p-vs-np`): Separate finite SAT/decomposition behavior from complexity-class claims; attack only bounded lemmas or counterexamples. **Ceiling:** open problem; no resolution established
- **Physics / quantum / extra-dimension observer** (`physics-extra-dim`): Keep synthetic geometry/rank evidence separate from physical observation; seek discriminating observable or no-go constraint before physical claims. **Ceiling:** synthetic/model evidence only

## BLOCKED_HUMAN

- **Accessibility / CPACC / Section 508 / JAWS / document accessibility** (`accessibility`): Collect real assistive-technology/user evidence for accessibility claims; keep tooling assistance distinct from human outcome evidence. **Ceiling:** design/tooling without human outcome claim
- **Water / pool engineering** (`pool-water`): Run the already-defined physical OFF/ON cleaning measurement, then record attention/maintenance cost. **Ceiling:** design until physical measurement exists

## BLOCKED_EXTERNAL_CONFIGURATION

- **redogit / conscience64 GitHub deployment** (`redogit-conscience64`): Enable/confirm branch-static GitHub Pages source as main/root through repository Pages configuration, then verify the public deployment separately from CI. **Ceiling:** Latest local verification workflow passes at 44da96f; external Pages deployment remains unverified/configuration-required.

## ACTIVE_ON_DEMAND

- **One_Level_Up / AIRLOCK** (`one-level-up`): Apply admission/provenance discipline to cross-project transfers; unresolved remains unresolved. **Ceiling:** custody/admission method, not domain truth

## CAPABILITY

- **4D codec / observer** (`codec4d`): Reuse finite classification/nullspace/inversion counterevidence; recover incomplete source lineage if a current task requires implementation-level authority. **Ceiling:** finite codec/observer evidence
- **Computer Mind** (`computer-mind`): Reuse component-confirmation/utility-boundary experiment patterns, not a mind ontology. **Ceiling:** bounded component/utility evidence
- **CSOL** (`csol`): Pressure human-facing interfaces toward clarity/economy without converting interface quality into truth authority. **Ceiling:** method/interface pressure
- **Float64 algorithmic builder** (`float64-builder`): Use deterministic float64-safe IDs/integrity coordinates only for identity/indexing; never semantic weight or evidence score. **Ceiling:** identity/integrity implementation only
- **Graph decomposition / Independent Set** (`graph-decomposition`): Use exact composition/held-out recursion only for matched combinatorial obligations. **Ceiling:** bounded graph evidence
- **Language Structure Workbench** (`language-workbench`): Use selfchecked interface behavior as software capability, not linguistic truth authority. **Ceiling:** software behavior
- **Multifactorial Creativity** (`multifactorial-creativity`): Generate candidates only; downstream evidence gates decide admission. **Ceiling:** idea generation only
- **Musilanguage / necessity-first** (`musilanguage`): Apply necessity-first compression only where it preserves consequential distinctions; recover Observer lineage before stronger claims. **Ceiling:** bounded observer/method evidence
- **Polynomial/Chebyshev echoes** (`polynomial-echoes`): Reuse basis-aligned positive and negative search results only for matched smooth-response questions. **Ceiling:** bounded polynomial evidence
- **R³ Scientific Method** (`r3`): Provide bounded experimental design and one-factor tests when selected by a current problem. **Ceiling:** method support only outside its tested domains
- **RuntimeRelationIndex** (`runtime-relation-index`): Use as retrieval helper only; never treat retrieval adjacency as evidence. **Ceiling:** tooling only
- **TaskWorld / Operator-Mind O1.1** (`taskworld`): Reuse causal ablation and independent-verification pattern when an executable actor/obligation interface needs it. **Ceiling:** bounded causal behavior
- **TBCL — Context Language Lab** (`tbcl`): Use relation/evaluation machinery only behind an explicit task interface; preserve source-language semantics. **Ceiling:** tested finite language/runtime behavior

## CAPABILITY_WITH_RECOVERY_GAP

- **SHADOW** (`shadow`): Use bounded structured-memory/control evidence; cleanly recover no-hook/control source window before stronger continuation. **Ceiling:** partial bounded control/memory evidence

## DORMANT_ON_DEMAND

- **3D + time harmonic field generator** (`harmonic-field`): Use as explicit mathematical test material only when a receiving experiment declares it. **Ceiling:** domain test input
- **MNCL / MNCL2** (`mncl`): Reuse only for matched factorization/causal questions with original boundaries preserved. **Ceiling:** bounded grid/factorization evidence
- **Parameter Differential Reflow** (`pdr`): Require matched fixed-parameter baseline before any promotion or integration. **Ceiling:** experimental mechanism
- **PulseNet original** (`pulsenet`): Resolve lineage/rewrite regression before treating prior XOR/spiral runs as current implementation evidence. **Ceiling:** mixed/partial lineage
- **PulseNet GP** (`pulsenet-gp`): Use short curvature/structural-deletion evidence only as bounded model evidence; require new benchmark before broader claims. **Ceiling:** bounded prototype evidence
- **SPDM** (`spdm`): Preserve repaired benchmark and failed reasoning-core result; require stronger baseline for any renewed mechanism claim. **Ceiling:** mixed bounded benchmark evidence
- **Tiny Babel** (`tiny-babel`): Recover clean source window before relying on historical recovery authority. **Ceiling:** locator/recovery boundary

## QUARANTINED_ON_DEMAND

- **Operator Moonshot** (`operator-moonshot`): Use as primary-evidence locator/method source only when a current question earns retrieval; never inherit predecessor authority. **Ceiling:** predecessor evidence/methods only

## ALWAYS_CONSTRAINT

- **Web / ethics / economics** (`web-ethics-economics`): Continue as continuous planning/action/result constraints, never empirical scientific proof. **Ceiling:** normative/decision layer

## HUMAN_DIRECTION

- **Pursuit of Happiness** (`pursuit-happiness`): Use as a human aim/constraint when explicitly selected; do not convert it into a universal optimization target. **Ceiling:** human direction, not empirical proof
- **Shared Well / hopes and values** (`shared-well`): Carry values relationally without treating them as independent empirical replication. **Ceiling:** orientation/context
