from pathlib import Path
import argparse
import json
import sys

ROOT = Path(__file__).parent
SRC = ROOT / "src"
sys.path.insert(0, str(SRC))

from ecs_world import ECSFrameworkWorld, pending_host_requests
from ecs_world.components import Identity, Problem, PassHistory, EvidenceLedger, Remainder


def main() -> None:
    parser = argparse.ArgumentParser(description="Run bounded cooperative ECS research passes.")
    parser.add_argument("--cycles", type=int, default=1, help="Number of forward-only passes to run")
    parser.add_argument("--no-reset", action="store_true", help="Do not clear ephemeral pass state between cycles")
    parser.add_argument("--snapshot", default="world_snapshot.json", help="Snapshot output path relative to project root")
    parser.add_argument("--resume", default=None, help="Resume exact ECS state from a prior world snapshot")
    parser.add_argument(
        "--bridge-dir",
        default=None,
        help="Enable durable host-bound model/research/library/scientific-compute carriers using this JSONL bridge directory",
    )
    args = parser.parse_args()

    if args.cycles < 1:
        raise SystemExit("--cycles must be >= 1")

    bridge_dir = Path(args.bridge_dir) if args.bridge_dir else None
    resume = Path(args.resume) if args.resume else None
    engine = ECSFrameworkWorld(ROOT / "world", bridge_dir=bridge_dir, snapshot=resume)
    for i in range(args.cycles):
        # Persist continuation-ready state by default. Pending host work preserves its exact selected
        # action across reset; completed work clears only ephemeral pass state. --no-reset is the
        # explicit inspection/debug mode.
        engine.step(reset=not args.no_reset)

    out = ROOT / args.snapshot
    out.write_text(json.dumps(engine.world.snapshot(), indent=2))
    print(f"cycle={engine.world.cycle} snapshot={out}")
    if resume is not None:
        print(f"resumed_from={resume}")
    if engine.bound_host_carriers:
        print("host_carriers=" + ",".join(sorted(engine.bound_host_carriers)))
    for _, ident, problem, history, evidence, remainder in engine.world.query(
        Identity, Problem, PassHistory, EvidenceLedger, Remainder
    ):
        last = history.passes[-1] if history.passes else {}
        claim = evidence.claims[-1] if evidence.claims else {}
        print(
            f"{ident.key}: passes={len(history.passes)} "
            f"last={last.get('selection', {}).get('name')} "
            f"carrier={last.get('carrier')} status={claim.get('status')} "
            f"remainder={len(remainder.unresolved)}"
        )

    if bridge_dir is not None:
        pending = pending_host_requests(bridge_dir / "outbox.jsonl", bridge_dir / "inbox.jsonl")
        print(f"pending_host_requests={len(pending)}")
        for row in pending:
            print(f"  {row.get('request_id')} carrier={row.get('carrier')} problem={row.get('problem_key')} mode={row.get('mode')}")


if __name__ == "__main__":
    main()
