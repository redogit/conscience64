# ECS World State — v0.5.0

## Engine status

- Criterion-driven orchestration: operational.
- Cross-context portfolio: operational.
- Deterministic dynamic intake: operational.
- Test suite: **45/45 passing**.
- Agents: **20**, selected by criterion skill/method fit and capacity.
- Surfaced context paths: **39**.
- Typed cross-project links: **16**; every link forbids automatic authority transfer.
- Stable dynamic problem IDs: SHA-256-derived from the explicit intake interface.
- Snapshot/restart, evidence gating, dependency transport, knowledge decay, and durable host bridge remain preserved from v0.4.

## Portfolio frontier

Current runtime-state counts:

- `ACTIVE`: 4
- `ACTIVE_ON_DEMAND`: 1
- `ALWAYS_CONSTRAINT`: 1
- `BLOCKED_EXTERNAL_CONFIGURATION`: 1
- `BLOCKED_HUMAN`: 2
- `CAPABILITY`: 13
- `CAPABILITY_WITH_RECOVERY_GAP`: 1
- `DORMANT_ON_DEMAND`: 7
- `HUMAN_DIRECTION`: 2
- `OPEN_RESEARCH`: 3
- `QUARANTINED_ON_DEMAND`: 1
- `READY_FOR_INTAKE`: 3

### Human / physical frontier

- `accessibility` — real assistive-technology/user observation remains required for accessibility outcome claims.
- `pool-water` — physical OFF/ON cleaning consequence measurement remains required before attention/maintenance cost can close.

### External configuration frontier

- `redogit-conscience64` — latest `REDOGIT local verification` run **34719913887** succeeded at commit `44da96f4f86b43b1c8867b30fe64afeb0338f726`. Repository `BUILD_AUDIT.json` remains `PASS_WITH_DEPLOYMENT_CONFIGURATION_REQUIRED`; branch-static Pages requires `main` / repository root. Local CI success is not treated as external deployment verification.

### Open research frontier

- `hodge` — `OPEN_NOT_ESTABLISHED`; no proof claim is admitted.
- `p-vs-np` — `OPEN_NOT_ESTABLISHED`; finite SAT/decomposition evidence is not a complexity-class resolution.
- `physics-extra-dim` — `SYNTHETIC_EVIDENCE_ONLY`; no physical observation has been established.

Candidate bounded intake requests for these fronts live under `examples/intake/`; they are **not auto-admitted** merely because the paths are open.

### Intake-ready application frontier

- `excel-jaws` — needs a concrete workbook/report task.
- `member-success-jira` — needs a concrete workflow/task surface.
- `rivir` — needs a concrete API/data-pool task.

## Preserved v0.4 task frontier

The v0.4 host-bound trace remains evidence custody under `examples/live_v4/`. Its final state had 14 supported criteria, two pending human observations, one downstream pool criterion blocked by physical measurement, and no remaining machine-actionable criterion. v0.5 does not overwrite that history.

## Governing boundary

Projects remain separate objects. Cross-project links may inform, pressure, test, generate, or locate. They do not automatically transfer evidence, authority, identity, or applicability. `unknown != false`, `associated != evidence`, `indexed != admitted`, and `reconstruction != source` remain active distinctions.

See `ALL_PATHS_STATE.md`, `NEXT_ACTIONS.md`, `INTAKE.md`, and `HUMAN_TASKS.md`.
