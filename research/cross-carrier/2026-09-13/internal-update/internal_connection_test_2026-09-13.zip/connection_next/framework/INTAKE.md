# Dynamic Problem Intake — v0.5.0

A problem enters the world only through an explicit interface. The minimum request is:

```json
{
  "subject": "What is being worked on?",
  "motivator": "Why does this matter?",
  "request": "What is requested from the interaction?",
  "obligation": "What must the output faithfully satisfy?"
}
```

Optional fields include `branch`, `problem_class`, `target_output`, `constraints`, `tags`, `priority`, `budget`, and source handles.

The intake engine does **not** declare the request solved. It deterministically creates a stable problem key, boundary, acceptance criteria, dependency graph, admissible evidence classes, and provenance fingerprint. `--admit` appends the resulting specification to `world/generated_problems.json`, after which normal ECS loading/snapshot rules apply. Repeating the same request is idempotent.

Problem classes currently supported: `research`, `software`, `application`, `physical`, `human`, and `recovery`. The class changes the evidence graph; it does not change the underlying rule that claim strength cannot exceed evidence.

Cross-project branch matches contribute only their declared claim ceiling and source handles. A branch match never imports its conclusions or authority.

Example:

```bash
PYTHONPATH=src python intake_cli.py examples/intake/redogit_build.json
PYTHONPATH=src python intake_cli.py examples/intake/redogit_build.json --admit
```
