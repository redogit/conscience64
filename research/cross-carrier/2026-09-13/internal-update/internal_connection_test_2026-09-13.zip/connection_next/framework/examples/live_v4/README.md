# Live v0.4 Host-Bound Trace

This directory records the criterion-driven live trace used for the packaged v0.4 frontier.

- `cycle_01.json` ... `cycle_06.json` — world state after each forward pass.
- `outbox.jsonl` — six host requests emitted exactly once.
- `inbox.jsonl` — four non-human responses supported by evidence actually obtained during construction.
- `FINAL_HUMAN_FRONTIER.json` — final machine state with no machine-actionable criterion left.
- `service_round_*.json` — compact markers showing when non-human pending work was serviced.

The final two unanswered outbox requests are deliberate:

1. Pool physical cleaning measurement.
2. Orbit accessible-interface human/assistive-technology observation.

No synthetic human response is included.
