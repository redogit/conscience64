# All Context Paths — v0.5.0

**Date:** 2026-09-12
**Boundary:** this is a bounded portfolio over currently surfaced context, not an account-wide completeness claim.

Projects remain separate objects. Cross-project links may pressure, test, locate, generate, or supply recovery patterns; they do not automatically transfer evidence, authority, identity, or applicability.

**Branches represented:** 39
**Typed cross-project links:** 16 (authority transfer allowed: no)

## Frontiers

- Machine/intake frontier: cross-carrier-wave, data-driven-ecs, excel-jaws, knowledge-decay, member-success-jira, orbit, rivir
- Human/physical frontier: accessibility, pool-water
- External-configuration frontier: redogit-conscience64
- Open-research frontier: hodge, p-vs-np, physics-extra-dim

## Runtime state counts

- `ACTIVE`: 4
- `ACTIVE_ON_DEMAND`: 1
- `ALWAYS_CONSTRAINT`: 1
- `BLOCKED_EXTERNAL_CONFIGURATION`: 1
- `BLOCKED_HUMAN`: 2
- `CAPABILITY`: 13
- `CAPABILITY_WITH_RECOVERY_GAP`: 1
- `DORMANT_ON_DEMAND`: 7
- `HUMAN_DIRECTION`: 2
- `OPEN_RESEARCH`: 3
- `QUARANTINED_ON_DEMAND`: 1
- `READY_FOR_INTAKE`: 3

## active-core

| Path | Runtime | Coverage | Next bounded obligation | Claim ceiling |
|---|---|---|---|---|
| `cross-carrier-wave` | `ACTIVE` | `EVIDENCE_LINKED` | Reuse only when a receiving problem declares a consequential carrier/transform obligation. | finite bounded implementations; not a universal physical field |
| `data-driven-ecs` | `ACTIVE` | `EVIDENCE_LINKED` | Accept new bounded problems through deterministic intake and preserve restart-safe criterion graphs. | bounded framework behavior only |
| `knowledge-decay` | `ACTIVE` | `EVIDENCE_LINKED` | Reverify recovered knowledge only when a present obligation depends on it. | source-bound recovery, not global completeness |
| `orbit` | `ACTIVE` | `EVIDENCE_LINKED` | Preserve selective primary-evidence routing; investigate host-wrapper linger only when it blocks a real task; accessibility remains human-evidence bounded. | retrieval/verification behavior within recorded scope |

## application-tooling

| Path | Runtime | Coverage | Next bounded obligation | Claim ceiling |
|---|---|---|---|---|
| `excel-jaws` | `READY_FOR_INTAKE` | `APPLICATION_TOOLING` | Accept a concrete report/workbook task and optimize for screen-reader-safe reading/filling without reusing unrelated spreadsheets. | application behavior, not research evidence |
| `language-workbench` | `CAPABILITY` | `SOFTWARE_EVIDENCE` | Use selfchecked interface behavior as software capability, not linguistic truth authority. | software behavior |
| `member-success-jira` | `READY_FOR_INTAKE` | `APPLICATION_TOOLING` | Accept concrete team/member-success workflow input; preserve people as people rather than categories. | application workflow |
| `redogit-conscience64` | `BLOCKED_EXTERNAL_CONFIGURATION` | `LIVE_LOCAL_VERIFICATION_PASS_DEPLOYMENT_CONFIG_REQUIRED` | Enable/confirm branch-static GitHub Pages source as main/root through repository Pages configuration, then verify the public deployment separately from CI. | Latest local verification workflow passes at 44da96f; external Pages deployment remains unverified/configuration-required. |
| `rivir` | `READY_FOR_INTAKE` | `APPLICATION_TOOLING` | Accept concrete API/data-pool task through I/R/P/O boundary; keep implementation separate from claims about people or outcomes. | application/API behavior |

## experimental

| Path | Runtime | Coverage | Next bounded obligation | Claim ceiling |
|---|---|---|---|---|
| `computer-mind` | `CAPABILITY` | `EVIDENCE_LINKED` | Reuse component-confirmation/utility-boundary experiment patterns, not a mind ontology. | bounded component/utility evidence |
| `mncl` | `DORMANT_ON_DEMAND` | `EVIDENCE_LINKED` | Reuse only for matched factorization/causal questions with original boundaries preserved. | bounded grid/factorization evidence |
| `pdr` | `DORMANT_ON_DEMAND` | `EXPERIMENTAL_MECHANISM_NOT_PROMOTED` | Require matched fixed-parameter baseline before any promotion or integration. | experimental mechanism |
| `pulsenet` | `DORMANT_ON_DEMAND` | `EVIDENCE_LINKED_PARTIAL_LINEAGE` | Resolve lineage/rewrite regression before treating prior XOR/spiral runs as current implementation evidence. | mixed/partial lineage |
| `pulsenet-gp` | `DORMANT_ON_DEMAND` | `EVIDENCE_LINKED` | Use short curvature/structural-deletion evidence only as bounded model evidence; require new benchmark before broader claims. | bounded prototype evidence |
| `spdm` | `DORMANT_ON_DEMAND` | `EVIDENCE_LINKED_MIXED` | Preserve repaired benchmark and failed reasoning-core result; require stronger baseline for any renewed mechanism claim. | mixed bounded benchmark evidence |

## generator

| Path | Runtime | Coverage | Next bounded obligation | Claim ceiling |
|---|---|---|---|---|
| `multifactorial-creativity` | `CAPABILITY` | `GENERATOR_METHOD_NO_TRUTH_AUTHORITY` | Generate candidates only; downstream evidence gates decide admission. | idea generation only |

## governance-method

| Path | Runtime | Coverage | Next bounded obligation | Claim ceiling |
|---|---|---|---|---|
| `one-level-up` | `ACTIVE_ON_DEMAND` | `EVIDENCE_DISCIPLINE_PLUS_FINITE_QUOTIENT` | Apply admission/provenance discipline to cross-project transfers; unresolved remains unresolved. | custody/admission method, not domain truth |

## human-application

| Path | Runtime | Coverage | Next bounded obligation | Claim ceiling |
|---|---|---|---|---|
| `accessibility` | `BLOCKED_HUMAN` | `DESIGNED_NOT_RUN` | Collect real assistive-technology/user evidence for accessibility claims; keep tooling assistance distinct from human outcome evidence. | design/tooling without human outcome claim |

## human-direction

| Path | Runtime | Coverage | Next bounded obligation | Claim ceiling |
|---|---|---|---|---|
| `pursuit-happiness` | `HUMAN_DIRECTION` | `HUMAN_DIRECTION` | Use as a human aim/constraint when explicitly selected; do not convert it into a universal optimization target. | human direction, not empirical proof |
| `shared-well` | `HUMAN_DIRECTION` | `HUMAN_DIRECTION_NON_EVIDENTIARY` | Carry values relationally without treating them as independent empirical replication. | orientation/context |
| `web-ethics-economics` | `ALWAYS_CONSTRAINT` | `NORMATIVE_ORIENTATION` | Continue as continuous planning/action/result constraints, never empirical scientific proof. | normative/decision layer |

## infrastructure

| Path | Runtime | Coverage | Next bounded obligation | Claim ceiling |
|---|---|---|---|---|
| `float64-builder` | `CAPABILITY` | `IMPLEMENTATION_EVIDENCE` | Use deterministic float64-safe IDs/integrity coordinates only for identity/indexing; never semantic weight or evidence score. | identity/integrity implementation only |

## interface-method

| Path | Runtime | Coverage | Next bounded obligation | Claim ceiling |
|---|---|---|---|---|
| `csol` | `CAPABILITY` | `METHOD_OR_INTERFACE_PRESSURE` | Pressure human-facing interfaces toward clarity/economy without converting interface quality into truth authority. | method/interface pressure |

## open-research

| Path | Runtime | Coverage | Next bounded obligation | Claim ceiling |
|---|---|---|---|---|
| `hodge` | `OPEN_RESEARCH` | `OPEN_NOT_ESTABLISHED` | Work only on explicitly bounded mathematical subclaims with proof/counterexample gates; no proof claim without complete primary mathematical evidence. | open problem; no proof established |
| `p-vs-np` | `OPEN_RESEARCH` | `OPEN_NOT_ESTABLISHED` | Separate finite SAT/decomposition behavior from complexity-class claims; attack only bounded lemmas or counterexamples. | open problem; no resolution established |
| `physics-extra-dim` | `OPEN_RESEARCH` | `SYNTHETIC_EVIDENCE_ONLY` | Keep synthetic geometry/rank evidence separate from physical observation; seek discriminating observable or no-go constraint before physical claims. | synthetic/model evidence only |

## physical

| Path | Runtime | Coverage | Next bounded obligation | Claim ceiling |
|---|---|---|---|---|
| `pool-water` | `BLOCKED_HUMAN` | `DESIGN_ONLY` | Run the already-defined physical OFF/ON cleaning measurement, then record attention/maintenance cost. | design until physical measurement exists |

## predecessor

| Path | Runtime | Coverage | Next bounded obligation | Claim ceiling |
|---|---|---|---|---|
| `operator-moonshot` | `QUARANTINED_ON_DEMAND` | `HISTORY_RECOVERY_AUTHORITY` | Use as primary-evidence locator/method source only when a current question earns retrieval; never inherit predecessor authority. | predecessor evidence/methods only |

## reusable-method

| Path | Runtime | Coverage | Next bounded obligation | Claim ceiling |
|---|---|---|---|---|
| `codec4d` | `CAPABILITY` | `EVIDENCE_LINKED_WITH_RECOVERY_GAP` | Reuse finite classification/nullspace/inversion counterevidence; recover incomplete source lineage if a current task requires implementation-level authority. | finite codec/observer evidence |
| `graph-decomposition` | `CAPABILITY` | `EVIDENCE_LINKED` | Use exact composition/held-out recursion only for matched combinatorial obligations. | bounded graph evidence |
| `musilanguage` | `CAPABILITY` | `EVIDENCE_LINKED_WITH_RECOVERY_GAP` | Apply necessity-first compression only where it preserves consequential distinctions; recover Observer lineage before stronger claims. | bounded observer/method evidence |
| `polynomial-echoes` | `CAPABILITY` | `EVIDENCE_LINKED` | Reuse basis-aligned positive and negative search results only for matched smooth-response questions. | bounded polynomial evidence |
| `r3` | `CAPABILITY` | `EVIDENCE_LINKED` | Provide bounded experimental design and one-factor tests when selected by a current problem. | method support only outside its tested domains |
| `shadow` | `CAPABILITY_WITH_RECOVERY_GAP` | `EVIDENCE_LINKED` | Use bounded structured-memory/control evidence; cleanly recover no-hook/control source window before stronger continuation. | partial bounded control/memory evidence |
| `taskworld` | `CAPABILITY` | `EVIDENCE_LINKED` | Reuse causal ablation and independent-verification pattern when an executable actor/obligation interface needs it. | bounded causal behavior |
| `tbcl` | `CAPABILITY` | `EVIDENCE_LINKED` | Use relation/evaluation machinery only behind an explicit task interface; preserve source-language semantics. | tested finite language/runtime behavior |
| `tiny-babel` | `DORMANT_ON_DEMAND` | `RECOVERY_ADJACENT` | Recover clean source window before relying on historical recovery authority. | locator/recovery boundary |

## test-input

| Path | Runtime | Coverage | Next bounded obligation | Claim ceiling |
|---|---|---|---|---|
| `harmonic-field` | `DORMANT_ON_DEMAND` | `DOMAIN_TEST_INPUT` | Use as explicit mathematical test material only when a receiving experiment declares it. | domain test input |

## tooling

| Path | Runtime | Coverage | Next bounded obligation | Claim ceiling |
|---|---|---|---|---|
| `runtime-relation-index` | `CAPABILITY` | `TOOLING_NOT_EVIDENCE_AUTHORITY` | Use as retrieval helper only; never treat retrieval adjacency as evidence. | tooling only |

## Cross-project relation rule

Every link in `world/cross_project_links.json` has `authority_transfer: false`. Receiving branches must independently admit any evidence or method through their own obligation/evidence gates.
