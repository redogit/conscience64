# Criterion-Driven Orchestration — v0.4.0

The unit of work is no longer “run another pass on this problem.” It is an unresolved acceptance criterion whose declared dependencies and evidence requirements are currently satisfiable.

## Criterion node

Each criterion is data in `world/problems.json` and may declare:

- `depends_on` — prerequisite criteria that must already be supported;
- `skills` — capabilities useful for team formation;
- `methods` — action methods admissible for the criterion;
- `evidence_kinds` — evidence classes allowed to close it;
- `scope_kinds` — admissible evidence scopes;
- `requires_substantive` — whether structural/internal evidence is insufficient;
- `requires_human` — whether a human observation is mandatory;
- `requires_corroboration` — whether an independent verifier is mandatory;
- `freshness_sensitive` — whether the supporting evidence may later require re-verification;
- `priority` and `max_attempts` — bounded scheduling controls;
- `task_payload` — criterion-specific instructions and fields that downstream carriers receive.

## Runtime states

A criterion can be:

- `READY` — dependencies are supported and an enabled carrier can emit an admissible evidence class;
- `ACTIVE` — selected for the current bounded pass;
- `PENDING` — exact action/request is awaiting an external or human response;
- `SUPPORTED` — admitted evidence explicitly satisfied the criterion;
- `BLOCKED` — one or more prerequisite criteria remain unsupported;
- `BLOCKED_EVIDENCE` — no enabled carrier can currently produce an admissible evidence class;
- `BLOCKED_ATTEMPTS` — bounded non-closing attempts have been exhausted;
- `STALE` — a freshness-sensitive criterion needs re-verification.

Unselected criteria are not false. A blocked criterion is not failed. A pending criterion is not evidence.

## Scheduling

For each problem:

1. Recompute criterion states from persistent acceptance evidence and dependencies.
2. Preserve a pending action exactly; do not silently select another action for that criterion.
3. Exclude criteria whose required evidence class has no enabled carrier.
4. Among remaining ready criteria, prefer higher declared priority while slightly reducing priority after non-closing attempts so independent ready work can proceed.
5. Form a team around the selected criterion.
6. Collect all team contributions, but dispatch only a method declared admissible by that criterion.
7. Route the action to a carrier capable of the required method/evidence contract.
8. Gate the returned evidence against evidence kind, scope, human/substantive/corroboration requirements, and explicit `satisfies` declaration.
9. Append the complete pass to history before final completion status is applied.
10. Recompute the world task board.

## Dependency transport

A dependency is more than a green flag. For every supported prerequisite, the downstream action receives a `dependency_context` carrying:

- the supporting result;
- evidence identifiers;
- carrier and evidence metadata;
- cycle/pass information;
- the produced artifact when present.

This lets a counter-probe attack the actual prior transform artifact and lets a physical measurement request inherit the actual supported experiment specification and safety result.

## Three clocks

v0.4.0 separates:

1. **world cycle** — global engine progress;
2. **problem pass** — evidentiary work performed on one problem;
3. **source freshness** — whether a particular evidence source remains appropriate for a freshness-sensitive claim.

Unrelated work elsewhere in the world no longer makes a completed criterion stale. Only additional passes on the same problem age a freshness-sensitive criterion under the current bounded policy.

## Stop semantics

The engine stops creating machine work when no machine-actionable criterion remains. It does not manufacture progress to keep agents busy.

The current live frontier demonstrates this:

- 14 criteria are supported;
- 2 criteria are pending explicit human observation;
- 1 criterion is blocked behind one of those human measurements;
- the machine-actionable frontier is empty.

That is a valid stopping state, not an orchestration failure.
