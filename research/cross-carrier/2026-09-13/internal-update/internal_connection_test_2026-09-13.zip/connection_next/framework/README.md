# Data-Driven Cooperative ECS World — v0.5.0

A runnable Entity-Component-System world for coordinating many agents around bounded human problems while keeping goals, dependencies, evidence, provenance, cost, failures, restarts, and unresolved remainder explicit.

v0.5.0 keeps the v0.4 criterion-driven engine and adds a **cross-context portfolio plus deterministic problem intake**. The world now represents every currently surfaced project/domain path as a separate branch object, exposes the appropriate machine/human/external/open-research frontier, and can admit a new problem without hard-coding a new engine system.

## Governing pass

`Human Need/Aim -> Boundary -> bounded Possibility Space -> Selection -> Distinction -> Relation -> Transform -> Carrier/Action -> Observation -> Consequence -> Evidence-qualified Output -> Unresolved Remainder -> next bounded state`

Selection is local, not globally optimal. Unselected possibilities remain unresolved rather than becoming false. Evidence, provenance, failures, history, and remainder survive later passes.

## v0.5 portfolio and intake

The new portfolio layer contains **39 surfaced paths** and **16 typed cross-project links**. Every link has `authority_transfer: false`. A branch may provide a counterexample, test-design pressure, generator, recovery pattern, or history locator without its conclusions becoming evidence in the receiving project.

Portfolio runtime states include:

`ACTIVE | ACTIVE_ON_DEMAND | CAPABILITY | CAPABILITY_WITH_RECOVERY_GAP | READY_FOR_INTAKE | OPEN_RESEARCH | BLOCKED_HUMAN | BLOCKED_EXTERNAL_CONFIGURATION | DORMANT_ON_DEMAND | QUARANTINED_ON_DEMAND | ALWAYS_CONSTRAINT | HUMAN_DIRECTION`

Current bounded frontiers are:

- human/physical: accessibility evidence and pool measurement;
- external configuration: `redogit/conscience64` GitHub Pages configuration/verification;
- open research: Hodge, P vs NP, and physics extra-dimension grounding;
- intake-ready applications: Excel/JAWS, Member Success/Jira, and RIVIR;
- reusable capabilities: TBCL, R³, SHADOW, 4D codec, Musilanguage, Computer Mind, CSOL, RuntimeRelationIndex, Float64 builder, and related bounded methods.

`intake_cli.py` accepts Subject, Motivator, Request, and Obligation, derives a deterministic problem key plus criterion/evidence graph, and optionally admits it to `world/generated_problems.json`. See `INTAKE.md`.

`ALL_PATHS_STATE.md` is the complete human-readable portfolio; `NEXT_ACTIONS.md` gives one bounded continuation obligation per path.

## Current problem worlds

1. **Cross-Carrier Field/Transform Verification** — carrier/transform/receiver behavior, independent counter-probe, freshness classification, bounded remainder.
2. **Orbit Exact Recovery & Evidence Routing** — exact source recovery, primary-evidence routing, cold-history restraint, accessible recovery interface.
3. **Version, Restart & Shared-Resource Integration** — restart identity, snapshot/resume, conflict detection, explicit integration replay.
4. **Low-Attention Pool Cleaning** — one-degree OFF/ON experiment, safety, physical cleaning measurement, attention/maintenance cost.

Backlog material remains candidate input, not automatically inherited truth.

## Criterion graph

Every acceptance criterion is data in `world/problems.json`. A node may declare:

- prerequisites (`depends_on`);
- relevant skills and admissible methods;
- evidence kinds and evidence scopes;
- whether substantive, human, or independently corroborated evidence is mandatory;
- priority and bounded attempt limits;
- freshness sensitivity;
- criterion-specific task payload.

Runtime criterion states are:

`READY | ACTIVE | PENDING | SUPPORTED | BLOCKED | BLOCKED_EVIDENCE | BLOCKED_ATTEMPTS | STALE`

See `CRITERION_ORCHESTRATION.md`.

## Cooperation is operational

The world defines 20 cooperating agents. Teams form around the current criterion rather than a static problem role.

- every assigned agent contributes before selection;
- the selected action carries the whole team contribution set and authorship identifiers;
- only a method admissible for the criterion can become the dispatched action;
- supporting agents may still contribute constraints/review without silently changing the criterion method;
- method use rotates within each agent's repertoire;
- downstream actions receive the exact supporting evidence/artifacts of prerequisite criteria.

## Carrier router

Agents propose bounded work; carriers execute it.

Local carriers:

- `computation` — executable transforms, snapshot tests, conflict probes, integration replays, experiment specifications;
- `local-files` — exact local source lookup plus SHA-256 provenance;
- `rule` — bounded structural reasoning and independent checks;
- `human-queue` — explicit human-evidence boundary;
- `reference` — deterministic compatibility/fallback path.

Host-bound carriers:

- `library` — exact Library retrieval and file/version identity;
- `research` — external/current source verification;
- `scientific-compute` — independent symbolic/numerical computation;
- `model` — bounded synthesis/planning/relation work;
- `human-queue` — durable human observation request when the bridge is enabled.

Host-bound carriers are disabled unless explicitly bound. The standalone engine never pretends that an external carrier was called.

## Evidence availability is a scheduling constraint

A criterion requiring an evidence class that no enabled carrier can produce becomes `BLOCKED_EVIDENCE`; the engine works on other ready criteria instead of repeatedly generating non-closing attempts.

When an admissible carrier is later bound, the criterion automatically becomes schedulable again.

A returned result closes a criterion only when it passes all declared gates: evidence kind, scope, substantive/human/corroboration requirements, and explicit target criterion.

## Dependency transport

Supported prerequisites carry forward their actual:

- result;
- evidence identifiers;
- carrier and evidence metadata;
- pass/cycle identity;
- produced artifact.

This fixed an earlier weakness where downstream work knew only that a dependency was green. The current counter-probe receives the exact prior transform artifact; the current pool measurement request receives the exact supported OFF/ON specification and safety evidence.

## Durable host boundary and restart

```text
ECS world -> outbox.jsonl -> host carrier/human -> inbox.jsonl -> ECS evidence gate
```

Request IDs are semantic and retry-stable. Pending actions survive reset and process restart. Duplicate polling does not produce duplicate outbox requests or duplicate pending history rows.

```bash
python run_world.py --cycles 2 --bridge-dir .runtime/bridge --snapshot state.json
python run_world.py --cycles 1 --bridge-dir .runtime/bridge --resume state.json --snapshot state2.json
```

See `HOST_BRIDGE.md`.

## Three clocks

Freshness no longer follows global world time alone.

- **world cycle** — global orchestration progress;
- **problem pass** — evidentiary work performed on one problem;
- **source freshness** — claim-relative evidence currency.

Unrelated work in another problem cannot make a completed freshness-sensitive criterion stale. Current bounded decay advances with additional passes on the same problem.

## Live v0.4 frontier

`examples/live_v4/` contains a rebuilt host-bound trace using evidence actually obtained during construction.

Machine-side work reached a stable stopping frontier:

- **14 acceptance criteria supported**;
- **2 human-observation criteria pending**;
- **1 downstream criterion blocked** behind the pool measurement;
- **0 machine-actionable criteria ready**.

Completed problems:

- `P-CROSS-CARRIER` — complete;
- `P-INTEGRATION` — complete.

Open only at human evidence boundaries:

- `P-ORBIT-RECOVERY` — pending `Accessible recovery interface retained`;
- `P-POOL` — pending `Cleaning consequence measured`; `Attention/maintenance cost recorded` remains blocked until measurement exists.

See `HUMAN_TASKS.md` and `WORLD_STATE.md`.

## Live external evidence used

The live trace includes:

- exact Library file/version identities for `ORBIT_CHRONOLOGY_2026-09-06.md` and `Cross_Carrier_Field_Transform_Wave_01.md`;
- an independent WolframAlpha field-sensitivity counter-probe (baseline 143, perturbed 153, delta 10) whose claim is deliberately limited to the encoded one-field perturbation;
- current W3C status evidence used only to classify the PROV reference as stable/reference, not to validate project-specific theory.

## Run

Offline/local carriers only:

```bash
python run_world.py --cycles 8
```

Enable the durable host boundary:

```bash
python run_world.py --cycles 8 --bridge-dir .runtime/bridge
```

Inspect pending host work:

```bash
python bridge_cli.py --bridge-dir .runtime/bridge pending
```

Append a host response:

```bash
python bridge_cli.py --bridge-dir .runtime/bridge respond REQUEST_ID response.json
```

## Tests

```bash
python -m pytest -q
```

Current result: **45 passed**.

Coverage includes team assignment/contribution, method eligibility/rotation, criterion dependencies, evidence availability blocking/unblocking, evidence admission, dependency-artifact transport, retry-stable host/human requests, pending deduplication, restart/hydration, identity-drift rejection, task-board state, selective knowledge decay, global-cycle freshness isolation, exact same-pass completion, shared-resource conflict detection, and forward-only evidence/history.

## Important files

- `src/ecs_world/components.py` — ECS data components.
- `src/ecs_world/systems.py` — criterion scheduler, teams, selection, evidence gating, decay, history, completion, task board, reset.
- `src/ecs_world/router.py` — capability/budget routing and verifier dispatch.
- `src/ecs_world/carriers.py` — local carrier implementations.
- `src/ecs_world/bridge.py` — durable host request/response boundary.
- `src/ecs_world/loader.py` — configuration load and snapshot restoration.
- `src/ecs_world/intake.py` — deterministic problem decomposition/admission.
- `world/branches.json` — cross-context branch portfolio with claim ceilings and next obligations.
- `world/cross_project_links.json` — typed non-authority-transferring branch relations.
- `world/context_sources.json` — minimal provenance handles for the portfolio.
- `world/live_external_evidence.json` — bounded current public external observations.
- `ALL_PATHS_STATE.md` — all surfaced paths and frontiers.
- `NEXT_ACTIONS.md` — one bounded continuation per path.
- `INTAKE.md` — intake contract and CLI.
- `world/problems.json` — problems plus executable criterion graph data.
- `world/agents.json` — agent population and method repertoires.
- `world/carriers.json` — carrier registry/evidence capabilities.
- `world/routing.json` — method-to-carrier contracts.
- `CRITERION_ORCHESTRATION.md` — scheduler/evidence semantics.
- `HOST_BRIDGE.md` — host and restart contract.
- `HUMAN_TASKS.md` — exact current human evidence frontier.
- `WORLD_STATE.md` — current verified world state.
- `examples/live_v4/` — host-bound v0.4 evidence trace.

## Current boundary

The world is intentionally stopped at the first evidence dependencies it cannot legitimately satisfy itself. That is the desired behavior: cooperation continues while justified work exists and stops rather than manufacturing evidence when the next consequential observation belongs to a human or the physical world.
