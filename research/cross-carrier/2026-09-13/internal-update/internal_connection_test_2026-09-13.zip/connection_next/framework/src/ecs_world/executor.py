from __future__ import annotations
from typing import Protocol, Any

class ActionExecutor(Protocol):
    def execute(self, problem: str, action: dict[str, Any], context: dict[str, Any]) -> dict[str, Any]: ...

class DeterministicExecutor:
    """Offline executor used for tests/demo. Replace with a model/tool adapter for live agents."""
    def execute(self, problem: str, action: dict[str, Any], context: dict[str, Any]) -> dict[str, Any]:
        return {
            "ok": True,
            "problem": problem,
            "action": action.get("name", "unknown"),
            "result": action.get("expected_observation", "bounded observation produced"),
            "evidence": action.get("evidence", ["executor:deterministic"]),
            "cost": action.get("cost", 0.1),
        }
