from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any

@dataclass
class Identity:
    key: str
    name: str
    kind: str

@dataclass
class Agent:
    skills: set[str]
    methods: set[str]
    capacity: int = 1
    active_assignments: set[int] = field(default_factory=set)

@dataclass
class Problem:
    need: str
    boundary: list[str]
    tags: set[str]
    priority: float
    target_output: str
    acceptance: list[str]
    status: str = "open"

@dataclass
class Governance:
    requirements: set[str]

@dataclass
class Budget:
    attention: float = 1.0
    compute: float = 1.0
    money: float = 1.0

@dataclass
class CostProfile:
    attention: float = 0.0
    compute: float = 0.0
    money: float = 0.0

@dataclass
class Carrier:
    executor_key: str
    capabilities: set[str]
    evidence_types: set[str]
    reliability: float = 1.0
    enabled: bool = True
    requires_human: bool = False

@dataclass
class DispatchPolicy:
    max_attempts: int = 3
    min_capability_coverage: float = 0.5
    verify_with_second_carrier: bool = True
    allow_human_queue: bool = True

@dataclass
class RoutingTable:
    methods: dict[str, dict[str, Any]] = field(default_factory=dict)

@dataclass
class Assignment:
    problem_id: int
    agent_ids: list[int] = field(default_factory=list)
    criterion: str | None = None

@dataclass
class ContributionLedger:
    entries: list[dict[str, Any]] = field(default_factory=list)

@dataclass
class PossibilitySpace:
    options: list[dict[str, Any]] = field(default_factory=list)

@dataclass
class Selection:
    option: dict[str, Any] | None = None
    rationale: str = ""

@dataclass
class DistinctionLog:
    items: list[str] = field(default_factory=list)

@dataclass
class RelationLog:
    items: list[str] = field(default_factory=list)

@dataclass
class ActionState:
    action: dict[str, Any] | None = None
    carrier: str | None = None
    dispatch_id: str | None = None

@dataclass
class DispatchLog:
    attempts: list[dict[str, Any]] = field(default_factory=list)

@dataclass
class ObservationLog:
    items: list[dict[str, Any]] = field(default_factory=list)

@dataclass
class ConsequenceLog:
    items: list[dict[str, Any]] = field(default_factory=list)

@dataclass
class EvidenceLedger:
    claims: list[dict[str, Any]] = field(default_factory=list)

@dataclass
class AcceptanceLedger:
    criteria: dict[str, dict[str, Any]] = field(default_factory=dict)

@dataclass
class CriterionGraph:
    """Executable acceptance graph for one problem.

    nodes are data, not code. Each criterion may declare dependencies, skills, methods,
    admissible evidence/scope classes, priority, and human/substantive/corroboration gates.
    runtime status is recomputed by the scheduler.
    """
    nodes: dict[str, dict[str, Any]] = field(default_factory=dict)
    active_criterion: str | None = None
    active_since_cycle: int | None = None
    decision_log: list[dict[str, Any]] = field(default_factory=list)

@dataclass
class SchedulerState:
    status: str = "IDLE"
    reason: str = ""
    ready: list[str] = field(default_factory=list)
    blocked: dict[str, list[str]] = field(default_factory=dict)

@dataclass
class Remainder:
    unresolved: list[str] = field(default_factory=list)
    next_state: str | None = None

@dataclass
class PassHistory:
    passes: list[dict[str, Any]] = field(default_factory=list)

@dataclass
class Provenance:
    authors: list[str] = field(default_factory=list)
    sources: list[str] = field(default_factory=list)
    transformations: list[str] = field(default_factory=list)

@dataclass
class Freshness:
    cycle_verified: int = 0
    max_age_cycles: int = 3
    stale: bool = False

@dataclass
class Blackboard:
    entries: list[dict[str, Any]] = field(default_factory=list)

@dataclass
class TaskBoard:
    """World-level view of criterion tasks across all problems."""
    tasks: dict[str, dict[str, Any]] = field(default_factory=dict)
    frontier: list[str] = field(default_factory=list)
    pending: list[str] = field(default_factory=list)
    blocked: list[str] = field(default_factory=list)
    completed: list[str] = field(default_factory=list)

@dataclass
class BranchPortfolio:
    """Cross-project portfolio. Branches remain separate identities and do not inherit evidence."""
    branches: dict[str, dict[str, Any]] = field(default_factory=dict)
    runtime_summary: dict[str, int] = field(default_factory=dict)
    machine_frontier: list[str] = field(default_factory=list)
    human_frontier: list[str] = field(default_factory=list)
    open_research_frontier: list[str] = field(default_factory=list)
    external_frontier: list[str] = field(default_factory=list)

@dataclass
class CrossProjectGraph:
    """Non-authority-transferring relations between otherwise separate project/domain branches."""
    links: list[dict[str, Any]] = field(default_factory=list)

@dataclass
class IntakeQueue:
    """Durable metadata for dynamically admitted problem specifications."""
    pending: list[dict[str, Any]] = field(default_factory=list)
    admitted: list[dict[str, Any]] = field(default_factory=list)
    rejected: list[dict[str, Any]] = field(default_factory=list)
