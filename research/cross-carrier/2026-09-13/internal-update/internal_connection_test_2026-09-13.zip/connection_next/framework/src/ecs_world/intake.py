from __future__ import annotations
import hashlib
import json
from pathlib import Path
from typing import Any


REQUIRED_FIELDS = ("subject", "motivator", "request", "obligation")


def _canonical(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def stable_problem_key(request: dict[str, Any]) -> str:
    core = {k: request.get(k) for k in sorted(set(REQUIRED_FIELDS) | {"branch", "problem_class", "target_output"})}
    return "P-INTAKE-" + hashlib.sha256(_canonical(core).encode()).hexdigest()[:12].upper()


def load_branch_catalog(config_dir: str | Path) -> dict[str, dict[str, Any]]:
    p = Path(config_dir) / "branches.json"
    rows = json.loads(p.read_text()) if p.exists() else []
    return {row["key"]: row for row in rows}


def _criterion(criterion: str, *, depends_on=(), skills=(), methods=(), evidence_kinds=("execution-trace",), scope_kinds=("structural",), priority=1.0, requires_substantive=False, requires_corroboration=False, requires_human=False, freshness_sensitive=False, max_attempts=3) -> dict[str, Any]:
    return {
        "criterion": criterion,
        "depends_on": list(depends_on),
        "skills": list(skills),
        "methods": list(methods),
        "evidence_kinds": list(evidence_kinds),
        "scope_kinds": list(scope_kinds),
        "priority": priority,
        "requires_substantive": requires_substantive,
        "requires_corroboration": requires_corroboration,
        "requires_human": requires_human,
        "freshness_sensitive": freshness_sensitive,
        "max_attempts": max_attempts,
    }


def decompose_request(request: dict[str, Any], branch_catalog: dict[str, dict[str, Any]]) -> dict[str, Any]:
    missing = [k for k in REQUIRED_FIELDS if not str(request.get(k, "")).strip()]
    if missing:
        raise ValueError(f"intake missing required fields: {missing}")
    branch_key = request.get("branch")
    branch = branch_catalog.get(branch_key, {}) if branch_key else {}
    problem_class = request.get("problem_class") or branch.get("problem_class") or "application"
    if problem_class not in {"research", "software", "physical", "human", "recovery", "application"}:
        raise ValueError(f"unsupported problem_class: {problem_class}")
    key = stable_problem_key(request)
    target = request.get("target_output") or f"Evidence-qualified bounded output for: {request['subject']}"
    base_boundary = [
        "Human/system authorship remains separate.",
        "Unselected possibilities remain unresolved rather than false.",
        "Cross-project association does not transfer evidence or authority.",
        "Claim strength cannot exceed admitted evidence.",
        "Preserve unresolved remainder and provenance.",
    ]
    base_boundary += list(request.get("constraints", []))
    if branch:
        base_boundary += [f"Branch claim ceiling: {branch.get('claim_ceiling', 'unspecified')}"]

    c0 = "Boundary, obligation, and success condition fixed"
    criteria = [_criterion(c0, skills=("boundedness", "scope", "human-needs"), methods=("boundary-check",), priority=2.0)]
    if problem_class == "research":
        c1 = "Primary premises/evidence loaded with provenance"
        c2 = "Independent countercheck or counterexample attempt recorded"
        c3 = "Claim ceiling and unresolved remainder retained"
        criteria += [
            _criterion(c1, depends_on=(c0,), skills=("evidence","provenance","mathematics"), methods=("primary-evidence-routing","external-research-check"), evidence_kinds=("file-reference","external-source","paper","retrieval-trace"), scope_kinds=("documentary","formal","research"), priority=1.8, requires_substantive=True),
            _criterion(c2, depends_on=(c1,), skills=("verification","counterexample","mathematics"), methods=("counter-probe","independent-verifier"), evidence_kinds=("external-computation","computation-trace","external-source"), scope_kinds=("formal","research"), priority=1.6, requires_substantive=True, requires_corroboration=True),
            _criterion(c3, depends_on=(c2,), skills=("boundedness","evidence","relations"), methods=("unresolved-remainder","bounded-synthesis"), priority=1.0),
        ]
    elif problem_class in {"software", "application"}:
        c1 = "Executable application contract specified"
        c2 = "Representative failure/success path reproduced"
        c3 = "Recovery, accessibility, and provenance boundaries retained"
        criteria += [
            _criterion(c1, depends_on=(c0,), skills=("application","integration","testing"), methods=("application-contract","integration-task"), priority=1.8),
            _criterion(c2, depends_on=(c1,), skills=("testing","integration","failure"), methods=("failure-injection","integration-task"), evidence_kinds=("internal-test","computation-trace","external-source"), scope_kinds=("software","integration"), priority=1.5, requires_substantive=True),
            _criterion(c3, depends_on=(c2,), skills=("accessibility","provenance","recovery","human-needs"), methods=("accessibility-gate","authority-transfer-gate","unresolved-remainder"), priority=1.0),
        ]
    elif problem_class == "physical":
        c1 = "One-degree physical experiment and OFF/control state specified"
        c2 = "Safety boundary preserved before measurement"
        c3 = "Physical consequence measured"
        c4 = "Attention/cost consequence recorded"
        criteria += [
            _criterion(c1, depends_on=(c0,), skills=("measurement","safety","optimization"), methods=("one-degree-experiment",), priority=1.9),
            _criterion(c2, depends_on=(c1,), skills=("safety","ethics"), methods=("continuous-ethics-check",), priority=1.8),
            _criterion(c3, depends_on=(c2,), skills=("measurement",), methods=("physical-measurement",), evidence_kinds=("human-observation",), scope_kinds=("physical",), priority=1.5, requires_substantive=True, requires_human=True),
            _criterion(c4, depends_on=(c3,), skills=("cost","attention","human-needs"), methods=("attention-budget",), evidence_kinds=("human-observation",), scope_kinds=("human","physical"), priority=1.0, requires_human=True),
        ]
    elif problem_class == "human":
        c1 = "Human goal, consent, necessities, and rejectability preserved"
        c2 = "Human/assistive-technology observation collected where outcome is claimed"
        c3 = "Qualitative disagreement and unresolved remainder retained"
        criteria += [
            _criterion(c1, depends_on=(c0,), skills=("human-needs","ethics","privacy","accessibility"), methods=("necessity-gate","continuous-ethics-check"), priority=1.9),
            _criterion(c2, depends_on=(c1,), skills=("accessibility","human-needs"), methods=("accessibility-gate",), evidence_kinds=("human-observation",), scope_kinds=("human",), priority=1.5, requires_substantive=True, requires_human=True),
            _criterion(c3, depends_on=(c2,), skills=("relations","evidence","human-needs"), methods=("unresolved-remainder",), priority=1.0),
        ]
    else:  # recovery
        c1 = "Exact source identity selected or explicitly unresolved"
        c2 = "Source-native chronology and authority role preserved"
        c3 = "Candidate reuse admitted only through current obligation"
        criteria += [
            _criterion(c1, depends_on=(c0,), skills=("retrieval","provenance","recovery"), methods=("primary-evidence-routing","recovery-map"), evidence_kinds=("file-reference","retrieval-trace"), scope_kinds=("documentary","recovery"), priority=1.9, requires_substantive=True),
            _criterion(c2, depends_on=(c1,), skills=("history","authority","provenance"), methods=("authority-transfer-gate",), priority=1.5),
            _criterion(c3, depends_on=(c2,), skills=("boundedness","integration","evidence"), methods=("unresolved-remainder","bounded-synthesis"), priority=1.0),
        ]

    acceptance = [x["criterion"] for x in criteria]
    sources = list(request.get("sources", []))
    if branch:
        sources.append(f"branch:{branch_key}")
    return {
        "key": key,
        "name": request["subject"],
        "need": request["motivator"],
        "boundary": base_boundary,
        "tags": sorted(set(request.get("tags", [])) | {problem_class} | ({branch_key} if branch_key else set())),
        "priority": float(request.get("priority", 1.0)),
        "target_output": target,
        "acceptance": acceptance,
        "criteria": criteria,
        "budget": request.get("budget", {"attention":1.0,"compute":1.0,"money":1.0}),
        "sources": sources,
        "intake": {
            "motivator": request["motivator"],
            "request": request["request"],
            "obligation": request["obligation"],
            "branch": branch_key,
            "problem_class": problem_class,
            "fingerprint": hashlib.sha256(_canonical(request).encode()).hexdigest(),
        },
    }


def admit_request(config_dir: str | Path, request: dict[str, Any]) -> dict[str, Any]:
    config = Path(config_dir)
    catalog = load_branch_catalog(config)
    problem = decompose_request(request, catalog)
    generated_path = config / "generated_problems.json"
    rows = json.loads(generated_path.read_text()) if generated_path.exists() else []
    by_key = {row["key"]: row for row in rows}
    if problem["key"] in by_key:
        if by_key[problem["key"]].get("intake", {}).get("fingerprint") != problem["intake"]["fingerprint"]:
            raise ValueError("stable intake key collision with different request fingerprint")
        return by_key[problem["key"]]
    rows.append(problem)
    generated_path.write_text(json.dumps(rows, indent=2) + "\n")

    qpath = config / "intake_queue.json"
    state = json.loads(qpath.read_text()) if qpath.exists() else {"pending":[],"admitted":[],"rejected":[]}
    state.setdefault("admitted", []).append({"key": problem["key"], "fingerprint": problem["intake"]["fingerprint"], "branch": problem["intake"].get("branch")})
    qpath.write_text(json.dumps(state, indent=2) + "\n")
    return problem
