from __future__ import annotations
import json
from pathlib import Path

from .core import World
from .components import *


def load_world(config_dir: str | Path) -> World:
    p = Path(config_dir)
    agents = json.loads((p / "agents.json").read_text())
    problems = json.loads((p / "problems.json").read_text())
    generated_path = p / "generated_problems.json"
    if generated_path.exists():
        problems += json.loads(generated_path.read_text())
    branches = json.loads((p / "branches.json").read_text()) if (p / "branches.json").exists() else []
    cross_links = json.loads((p / "cross_project_links.json").read_text()) if (p / "cross_project_links.json").exists() else []
    intake_state = json.loads((p / "intake_queue.json").read_text()) if (p / "intake_queue.json").exists() else {"pending": [], "admitted": [], "rejected": []}
    carriers = json.loads((p / "carriers.json").read_text()) if (p / "carriers.json").exists() else []
    routing = json.loads((p / "routing.json").read_text()) if (p / "routing.json").exists() else {"methods": {}}
    global_cfg = json.loads((p / "world.json").read_text())
    dcfg = global_cfg.get("dispatch", {})

    world = World()
    world.create(
        Identity("WORLD", global_cfg["name"], "world"),
        Blackboard(), TaskBoard(),
        BranchPortfolio({row["key"]: dict(row) for row in branches}),
        CrossProjectGraph(list(cross_links)),
        IntakeQueue(list(intake_state.get("pending", [])), list(intake_state.get("admitted", [])), list(intake_state.get("rejected", []))),
        Governance(set(global_cfg["requirements"])),
        DispatchPolicy(**dcfg),
        RoutingTable(routing.get("methods", {})),
    )

    for row in carriers:
        world.create(
            Identity(row["key"], row["name"], "carrier"),
            Carrier(
                executor_key=row["executor_key"],
                capabilities=set(row.get("capabilities", [])),
                evidence_types=set(row.get("evidence_types", [])),
                reliability=float(row.get("reliability", 1.0)),
                enabled=bool(row.get("enabled", True)),
                requires_human=bool(row.get("requires_human", False)),
            ),
            CostProfile(**row.get("cost", {})),
            Provenance(authors=["Framework carrier registry"], sources=row.get("sources", [])),
        )

    for row in agents:
        world.create(
            Identity(row["key"], row["name"], "agent"),
            Agent(set(row["skills"]), set(row["methods"]), row.get("capacity", 1)),
            Governance(set(row.get("requirements", global_cfg["requirements"]))),
            Provenance(authors=[row["name"]], sources=row.get("sources", [])),
        )

    for row in problems:
        world.create(
            Identity(row["key"], row["name"], "problem"),
            Problem(
                need=row["need"],
                boundary=row["boundary"],
                tags=set(row["tags"]),
                priority=float(row.get("priority", 1.0)),
                target_output=row["target_output"],
                acceptance=row["acceptance"],
            ),
            Governance(set(row.get("requirements", global_cfg["requirements"]))),
            Budget(**row.get("budget", {})),
            Assignment(problem_id=0), ContributionLedger(),
            PossibilitySpace(), Selection(), DistinctionLog(), RelationLog(), ActionState(), DispatchLog(),
            ObservationLog(), ConsequenceLog(), EvidenceLedger(),
            AcceptanceLedger({criterion: {"status": "unresolved", "support": [], "cycle": None, "scope_kind": None} for criterion in row["acceptance"]}),
            CriterionGraph({
                item["criterion"]: {
                    **item,
                    "depends_on": list(item.get("depends_on", [])),
                    "skills": list(item.get("skills", [])),
                    "methods": list(item.get("methods", [])),
                    "evidence_kinds": list(item.get("evidence_kinds", [])),
                    "scope_kinds": list(item.get("scope_kinds", [])),
                    "priority": float(item.get("priority", 1.0)),
                    "requires_substantive": bool(item.get("requires_substantive", False)),
                    "requires_corroboration": bool(item.get("requires_corroboration", False)),
                    "requires_human": bool(item.get("requires_human", False)),
                    "freshness_sensitive": bool(item.get("freshness_sensitive", False)),
                    "max_attempts": int(item.get("max_attempts", 3)),
                    "attempts": 0,
                    "last_admission_failed": False,
                    "runtime_status": "UNRESOLVED",
                    "last_cycle": None,
                    "last_reason": "",
                }
                for item in row.get("criteria", [{"criterion": c} for c in row["acceptance"]])
            }),
            SchedulerState(),
            Remainder(), PassHistory(),
            Provenance(authors=["User research"], sources=row.get("sources", [])),
            Freshness(max_age_cycles=row.get("max_age_cycles", 3)),
        )
    for eid, assignment in world.query(Assignment):
        assignment.problem_id = eid
    return world


def restore_world(config_dir: str | Path, snapshot_path: str | Path) -> World:
    """Restore a previously snapshotted world onto the declared configuration schema.

    The configuration is loaded first to establish component types and entity identities. Snapshot
    data then replaces state only when the entity/component already exists and Identity keys match.
    This intentionally rejects schema/identity drift instead of silently mapping a snapshot onto a
    different world definition.
    """
    snapshot = json.loads(Path(snapshot_path).read_text(encoding="utf-8"))
    if not isinstance(snapshot, dict) or "components" not in snapshot:
        raise ValueError("invalid ECS snapshot: missing components")
    world = load_world(config_dir)

    snap_components = snapshot.get("components", {})
    snap_identity = snap_components.get("Identity", {})
    current_identity = world.components.get(Identity, {})
    for eid, ident in current_identity.items():
        row = snap_identity.get(str(eid))
        if row is None:
            raise ValueError(f"snapshot identity missing entity {eid}:{ident.key}")
        if row.get("key") != ident.key or row.get("kind") != ident.kind:
            raise ValueError(
                f"snapshot/config identity mismatch for entity {eid}: "
                f"snapshot={row.get('key')!r}/{row.get('kind')!r} config={ident.key!r}/{ident.kind!r}"
            )

    by_name = {ctype.__name__: ctype for ctype in world.components}
    for component_name, rows in snap_components.items():
        ctype = by_name.get(component_name)
        if ctype is None:
            raise ValueError(f"snapshot contains unknown component type: {component_name}")
        store = world.components[ctype]
        for eid_text, state in rows.items():
            eid = int(eid_text)
            if eid not in store:
                raise ValueError(f"snapshot contains undeclared {component_name} entity {eid}")
            _restore_component(store[eid], state)

    world.cycle = int(snapshot.get("cycle", 0))
    return world


def _restore_component(component: object, state: dict) -> None:
    if not isinstance(state, dict):
        raise ValueError(f"component snapshot for {type(component).__name__} must be an object")
    for key, value in state.items():
        if not hasattr(component, key):
            raise ValueError(f"snapshot field {type(component).__name__}.{key} is not in current schema")
        current = getattr(component, key)
        if isinstance(current, set):
            setattr(component, key, set(value))
        elif isinstance(current, dict):
            setattr(component, key, dict(value))
        elif isinstance(current, list):
            setattr(component, key, list(value))
        else:
            setattr(component, key, value)
