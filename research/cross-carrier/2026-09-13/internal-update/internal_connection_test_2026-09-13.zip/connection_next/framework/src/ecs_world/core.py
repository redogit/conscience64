from __future__ import annotations
from collections import defaultdict
from dataclasses import asdict, is_dataclass
from typing import Any, Iterable, TypeVar

T = TypeVar("T")

class World:
    def __init__(self) -> None:
        self._next_entity = 1
        self.components: dict[type, dict[int, Any]] = defaultdict(dict)
        self.cycle = 0

    def create(self, *components: Any) -> int:
        eid = self._next_entity
        self._next_entity += 1
        for comp in components:
            self.add(eid, comp)
        return eid

    def add(self, eid: int, component: Any) -> None:
        self.components[type(component)][eid] = component

    def get(self, eid: int, component_type: type[T]) -> T:
        return self.components[component_type][eid]

    def maybe(self, eid: int, component_type: type[T]) -> T | None:
        return self.components.get(component_type, {}).get(eid)

    def has(self, eid: int, *component_types: type) -> bool:
        return all(eid in self.components.get(t, {}) for t in component_types)

    def query(self, *component_types: type) -> Iterable[tuple[int, ...]]:
        if not component_types:
            return []
        ids = set(self.components.get(component_types[0], {}))
        for t in component_types[1:]:
            ids &= set(self.components.get(t, {}))
        for eid in sorted(ids):
            yield (eid, *(self.components[t][eid] for t in component_types))

    def snapshot(self) -> dict[str, Any]:
        out: dict[str, Any] = {"cycle": self.cycle, "components": {}}
        for ctype, store in self.components.items():
            rows = {}
            for eid, value in store.items():
                if is_dataclass(value):
                    row = asdict(value)
                else:
                    row = value
                rows[str(eid)] = _jsonable(row)
            out["components"][ctype.__name__] = rows
        return out


def _jsonable(v: Any) -> Any:
    if isinstance(v, set):
        return sorted(v)
    if isinstance(v, dict):
        return {str(k): _jsonable(x) for k, x in v.items()}
    if isinstance(v, (list, tuple)):
        return [_jsonable(x) for x in v]
    return v
