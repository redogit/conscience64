from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any, Iterable

from .components import Carrier, Identity
from .core import World
from .router import CarrierRouter


class HostBridgeContractError(ValueError):
    pass


def _json_fingerprint(value: Any) -> str:
    raw = json.dumps(value, sort_keys=True, separators=(",", ":"), default=str).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def _semantic_request(request: dict[str, Any], carrier_key: str) -> dict[str, Any]:
    """Return the retry-stable portion of a dispatch request.

    Cycle and dispatch UUID are intentionally excluded so an interrupted/pending host request
    can be retried without producing a new identity.
    """
    primary = request.get("primary_result") or {}
    return {
        "carrier": carrier_key,
        "problem_key": request.get("problem_key"),
        "mode": request.get("mode", "execute"),
        "action": request.get("action", {}),
        "boundary": request.get("boundary", []),
        "acceptance": request.get("acceptance", []),
        "criterion": request.get("criterion"),
        "criterion_spec": request.get("criterion_spec", {}),
        "target_output": request.get("target_output"),
        "sources": request.get("sources", []),
        "primary_result": {
            "result": primary.get("result"),
            "evidence": primary.get("evidence", []),
            "scope_kind": primary.get("scope_kind"),
            "substantive": primary.get("substantive", False),
        } if primary else None,
    }


def _read_jsonl(path: Path) -> list[dict[str, Any]]:
    if not path.exists():
        return []
    rows: list[dict[str, Any]] = []
    for lineno, line in enumerate(path.read_text(encoding="utf-8").splitlines(), start=1):
        if not line.strip():
            continue
        try:
            value = json.loads(line)
        except json.JSONDecodeError as exc:
            raise HostBridgeContractError(f"invalid JSONL in {path} line {lineno}: {exc.msg}") from exc
        if not isinstance(value, dict):
            raise HostBridgeContractError(f"JSONL row in {path} line {lineno} must be an object")
        rows.append(value)
    return rows


def append_host_response(inbox_path: str | Path, response: dict[str, Any]) -> None:
    """Append a host response envelope to an inbox.

    Required: request_id, ok, result. Evidence is a list of stable source/artifact identifiers.
    A response claiming substantive evidence without any evidence identifiers is downgraded by
    the adapter instead of being trusted implicitly.
    """
    if not isinstance(response, dict):
        raise HostBridgeContractError("response must be an object")
    missing = [k for k in ("request_id", "ok", "result") if k not in response]
    if missing:
        raise HostBridgeContractError(f"response missing required fields: {', '.join(missing)}")
    path = Path(inbox_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(response, sort_keys=True, default=str) + "\n")


def pending_host_requests(outbox_path: str | Path, inbox_path: str | Path) -> list[dict[str, Any]]:
    outbox = _read_jsonl(Path(outbox_path))
    answered = {row.get("request_id") for row in _read_jsonl(Path(inbox_path)) if row.get("request_id")}
    return [row for row in outbox if row.get("request_id") not in answered]


class JsonlHostBridgeAdapter:
    """Durable host boundary using an append-only JSONL outbox/inbox pair.

    The ECS emits a bounded request and receives either a matching host response or a pending
    result. It never calls a network service itself and never lets a host mutate world state.
    """

    def __init__(self, carrier_key: str, outbox_path: str | Path, inbox_path: str | Path):
        self.carrier_key = carrier_key
        self.outbox_path = Path(outbox_path)
        self.inbox_path = Path(inbox_path)

    def _request_id(self, request: dict[str, Any]) -> str:
        return f"host:{self.carrier_key}:{_json_fingerprint(_semantic_request(request, self.carrier_key))}"

    def _matching_response(self, request_id: str) -> dict[str, Any] | None:
        matches = [row for row in _read_jsonl(self.inbox_path) if row.get("request_id") == request_id]
        return matches[-1] if matches else None

    def _emit_once(self, envelope: dict[str, Any]) -> None:
        existing = {row.get("request_id") for row in _read_jsonl(self.outbox_path)}
        if envelope["request_id"] in existing:
            return
        self.outbox_path.parent.mkdir(parents=True, exist_ok=True)
        with self.outbox_path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(envelope, sort_keys=True, default=str) + "\n")

    @staticmethod
    def _normalize_response(request_id: str, row: dict[str, Any]) -> dict[str, Any]:
        if "ok" not in row or "result" not in row:
            raise HostBridgeContractError("host response requires 'ok' and 'result'")
        evidence = row.get("evidence", [])
        if evidence is None:
            evidence = []
        if not isinstance(evidence, list) or any(not isinstance(x, str) for x in evidence):
            raise HostBridgeContractError("host response evidence must be a list of stable string identifiers")
        substantive = bool(row.get("substantive", False))
        unresolved = list(row.get("unresolved", []))
        if substantive and not evidence:
            substantive = False
            unresolved.append("Host marked result substantive but supplied no evidence identifiers; downgraded to non-substantive.")
        return {
            "ok": bool(row.get("ok")),
            "pending": False,
            "result": str(row.get("result")),
            "evidence": evidence,
            "evidence_kind": row.get("evidence_kind", "external-source"),
            "scope_kind": row.get("scope_kind", "external"),
            "substantive": substantive,
            "confidence": float(row.get("confidence", 0.0)),
            "artifact": row.get("artifact"),
            "unresolved": unresolved,
            "satisfies": list(row.get("satisfies", [])),
            "request_id": request_id,
            "host_carrier": row.get("carrier"),
        }

    def execute(self, request: dict[str, Any]) -> dict[str, Any]:
        request_id = self._request_id(request)
        response = self._matching_response(request_id)
        if response is not None:
            normalized = self._normalize_response(request_id, response)
            if "satisfies" not in response:
                normalized["satisfies"] = list(request.get("acceptance", []))
            return normalized

        envelope = {
            "request_id": request_id,
            "carrier": self.carrier_key,
            "problem_key": request.get("problem_key"),
            "mode": request.get("mode", "execute"),
            "semantic_request": _semantic_request(request, self.carrier_key),
        }
        self._emit_once(envelope)
        return {
            "ok": False,
            "pending": True,
            "result": f"Awaiting host response from '{self.carrier_key}'.",
            "evidence": [],
            "evidence_kind": "carrier-pending",
            "scope_kind": "pending",
            "substantive": False,
            "confidence": 0.0,
            "request_id": request_id,
            "unresolved": [f"Pending host carrier response: {request_id}"],
        }


def bind_jsonl_host_bridges(
    world: World,
    router: CarrierRouter,
    bridge_dir: str | Path,
    executor_keys: Iterable[str] = ("model", "research", "library", "scientific-compute", "human-queue"),
) -> dict[str, int]:
    """Bind declared external carriers to one durable JSONL request/response bus."""
    bridge = Path(bridge_dir)
    outbox = bridge / "outbox.jsonl"
    inbox = bridge / "inbox.jsonl"
    bound: dict[str, int] = {}
    by_key = {carrier.executor_key: (eid, carrier) for eid, carrier in world.query(Carrier)}
    for executor_key in executor_keys:
        match = by_key.get(executor_key)
        if match is None:
            continue
        eid, carrier = match
        router.register(executor_key, JsonlHostBridgeAdapter(executor_key, outbox, inbox))
        carrier.enabled = True
        bound[executor_key] = eid
    return bound
