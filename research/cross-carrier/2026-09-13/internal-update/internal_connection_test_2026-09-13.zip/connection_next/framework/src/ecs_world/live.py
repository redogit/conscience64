from __future__ import annotations

from typing import Any, Callable

from .components import Carrier, Identity
from .core import World
from .router import CarrierRouter


class CarrierContractError(ValueError):
    pass


class CallableCarrierAdapter:
    """Boundary adapter for host-provided model/tool/human callbacks.

    The callback receives one JSON-like request and must return a JSON-like result.
    The ECS never assumes that a callback result is substantive evidence merely because
    a tool or model produced it.
    """

    def __init__(self, fn: Callable[[dict[str, Any]], dict[str, Any]]):
        self.fn = fn

    def execute(self, request: dict[str, Any]) -> dict[str, Any]:
        result = self.fn(request)
        if not isinstance(result, dict):
            raise CarrierContractError("carrier callback must return a dict")
        if "ok" not in result or "result" not in result:
            raise CarrierContractError("carrier result requires 'ok' and 'result'")
        result.setdefault("evidence", [])
        result.setdefault("evidence_kind", "external-observation")
        result.setdefault("scope_kind", "external")
        result.setdefault("substantive", False)
        result.setdefault("confidence", 0.0)
        return result


def bind_carrier(
    world: World,
    router: CarrierRouter,
    executor_key: str,
    adapter: Any,
    *,
    enable: bool = True,
) -> int:
    """Bind a host adapter to a data-declared carrier and optionally enable it."""
    matches = []
    for eid, ident, carrier in world.query(Identity, Carrier):
        if carrier.executor_key == executor_key:
            matches.append((eid, ident, carrier))
    if not matches:
        raise KeyError(f"no carrier entity declares executor_key={executor_key!r}")
    if len(matches) > 1:
        raise CarrierContractError(f"executor_key={executor_key!r} is not unique")
    eid, _, carrier = matches[0]
    router.register(executor_key, adapter)
    if enable:
        carrier.enabled = True
    return eid
