from __future__ import annotations
import json
from pathlib import Path

from .loader import load_world, restore_world
from .executor import ActionExecutor, DeterministicExecutor
from .carriers import (
    ComputationCarrierAdapter, HumanQueueCarrierAdapter, LocalFileCarrierAdapter,
    RuleCarrierAdapter,
)
from .router import CarrierRouter
from .bridge import bind_jsonl_host_bridges
from .systems import (
    CriterionSchedulerSystem, GlobalTaskBoardSystem, PortfolioSystem, AssignmentSystem, TeamContributionSystem, PossibilitySystem, SelectionSystem,
    DistinctionRelationSystem, TransformSystem, RouterExecutionSystem,
    EvidenceConsequenceSystem, KnowledgeDecaySystem, CooperationSystem,
    PassHistorySystem, CompletionStatusSystem, ResetForNextPassSystem,
)


class _LegacyExecutorAdapter:
    def __init__(self, executor: ActionExecutor):
        self.executor = executor

    def execute(self, request: dict):
        return self.executor.execute(request["problem_key"], request["action"], request)


class ECSFrameworkWorld:
    def __init__(
        self,
        config_dir: str | Path,
        executor: ActionExecutor | None = None,
        router: CarrierRouter | None = None,
        bridge_dir: str | Path | None = None,
        snapshot: str | Path | None = None,
    ):
        self.config_dir = Path(config_dir)
        self.snapshot_path = Path(snapshot) if snapshot is not None else None
        self.world = restore_world(self.config_dir, self.snapshot_path) if self.snapshot_path is not None else load_world(self.config_dir)
        if router is None:
            router = CarrierRouter({
                "rule": RuleCarrierAdapter(),
                "computation": ComputationCarrierAdapter(),
                "local-files": LocalFileCarrierAdapter([self.config_dir.parent, self.config_dir]),
                "human-queue": HumanQueueCarrierAdapter(self.config_dir.parent / ".runtime" / "human_queue.jsonl"),
                "reference": _LegacyExecutorAdapter(executor or DeterministicExecutor()),
            })
        self.router = router
        self.bridge_dir = Path(bridge_dir) if bridge_dir is not None else None
        self.bound_host_carriers: dict[str, int] = {}
        if self.bridge_dir is not None:
            self.bound_host_carriers = bind_jsonl_host_bridges(self.world, self.router, self.bridge_dir)
        self.systems = [
            CriterionSchedulerSystem(),
            AssignmentSystem(),
            TeamContributionSystem(),
            PossibilitySystem(),
            SelectionSystem(),
            DistinctionRelationSystem(),
            TransformSystem(),
            RouterExecutionSystem(self.router),
            EvidenceConsequenceSystem(),
            KnowledgeDecaySystem(),
            CooperationSystem(),
            PassHistorySystem(),
            CompletionStatusSystem(),
            GlobalTaskBoardSystem(),
            PortfolioSystem(),
        ]
        self.reset = ResetForNextPassSystem()

    def step(self, reset: bool = False) -> dict:
        self.world.cycle += 1
        for system in self.systems:
            system.run(self.world)
        snapshot = self.world.snapshot()
        if reset:
            self.reset.run(self.world)
        return snapshot

    def save_snapshot(self, path: str | Path) -> None:
        Path(path).write_text(json.dumps(self.world.snapshot(), indent=2))
