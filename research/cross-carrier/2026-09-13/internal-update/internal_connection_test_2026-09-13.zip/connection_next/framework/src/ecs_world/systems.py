from __future__ import annotations
from dataclasses import dataclass
from typing import Any

from .core import World
from .components import (
    Identity, Agent, Problem, Governance, Budget, Assignment, ContributionLedger,
    PossibilitySpace, Selection, DistinctionLog, RelationLog, ActionState, DispatchLog,
    ObservationLog, ConsequenceLog, EvidenceLedger, AcceptanceLedger, CriterionGraph,
    SchedulerState, Remainder, PassHistory, Provenance, Freshness, Blackboard, TaskBoard,
    Carrier, RoutingTable, BranchPortfolio, CrossProjectGraph, IntakeQueue,
)
from .router import CarrierRouter


def _criterion_skill_score(node: dict[str, Any], agent: Agent) -> float:
    skills = set(node.get("skills", []))
    if not skills:
        return 0.0
    return len(skills & agent.skills) / len(skills)


def _criterion_method_match(node: dict[str, Any], agent: Agent) -> int:
    return len(set(node.get("methods", [])) & agent.methods)


def _admissible_carrier_available(world: World, node: dict[str, Any]) -> tuple[bool, str]:
    required_evidence = set(node.get("evidence_kinds", []))
    if not required_evidence:
        return True, "criterion declares no evidence-kind restriction"
    methods = list(node.get("methods", [])) or ["*"]
    routing_rows = list(world.query(RoutingTable))
    routes = routing_rows[0][1].methods if routing_rows else {}
    candidates = []
    for _, ident, carrier in world.query(Identity, Carrier):
        if not carrier.enabled:
            continue
        if not (required_evidence & carrier.evidence_types):
            continue
        if node.get("requires_human") and not carrier.requires_human:
            continue
        method_ok = False
        for method in methods:
            route = routes.get(method, routes.get("*", {}))
            required_caps = set(route.get("required_capabilities", []))
            if not required_caps or required_caps <= carrier.capabilities:
                method_ok = True
                break
        if method_ok:
            candidates.append(ident.key)
    if candidates:
        return True, f"admissible enabled carrier(s): {sorted(candidates)}"
    return False, f"no enabled carrier can emit {sorted(required_evidence)} for declared criterion method(s) {methods}"


@dataclass
class CriterionSchedulerSystem:
    """Turn acceptance criteria into an executable dependency graph.

    The scheduler is deliberately local to each problem. It never treats an unselected criterion as
    false; it merely records whether the criterion is READY, BLOCKED, PENDING, SUPPORTED, or STALE.
    """
    def run(self, world: World) -> None:
        for pid, ident, problem, ledger, graph, scheduler, action in world.query(
            Identity, Problem, AcceptanceLedger, CriterionGraph, SchedulerState, ActionState
        ):
            ready: list[str] = []
            blocked: dict[str, list[str]] = {}

            # Recompute graph states from persistent evidence + declared dependencies.
            for criterion, node in graph.nodes.items():
                state = ledger.criteria.get(criterion, {})
                if state.get("status") == "supported":
                    node["runtime_status"] = "SUPPORTED"
                    continue
                if state.get("status") == "stale":
                    node["runtime_status"] = "STALE"
                deps = list(node.get("depends_on", []))
                missing = [d for d in deps if ledger.criteria.get(d, {}).get("status") != "supported"]
                if missing:
                    node["runtime_status"] = "BLOCKED"
                    blocked[criterion] = [f"dependency:{x}" for x in missing]
                else:
                    available, availability_reason = _admissible_carrier_available(world, node)
                    exhausted = (
                        bool(node.get("last_admission_failed"))
                        and int(node.get("attempts", 0)) >= int(node.get("max_attempts", 3))
                    )
                    if not available:
                        node["runtime_status"] = "BLOCKED_EVIDENCE"
                        blocked[criterion] = [availability_reason]
                    elif exhausted:
                        node["runtime_status"] = "BLOCKED_ATTEMPTS"
                        blocked[criterion] = [
                            f"{node.get('attempts')} non-closing attempts reached max_attempts={node.get('max_attempts')}"
                        ]
                    else:
                        node["runtime_status"] = "READY" if state.get("status") != "stale" else "STALE"
                        ready.append(criterion)

            scheduler.ready = list(ready)
            scheduler.blocked = {k: list(v) for k, v in blocked.items()}

            # Completion is evidence-defined. Stale criteria reopen the problem.
            all_supported = bool(graph.nodes) and all(
                ledger.criteria.get(c, {}).get("status") == "supported" for c in graph.nodes
            )
            if all_supported:
                problem.status = "complete"
                graph.active_criterion = None
                graph.active_since_cycle = None
                scheduler.status = "COMPLETE"
                scheduler.reason = "all acceptance criteria are evidence-supported"
                continue
            problem.status = "open"

            # A pending action owns the criterion until its carrier responds. Do not reschedule it.
            if graph.active_criterion and action.action:
                active = graph.active_criterion
                node = graph.nodes.get(active, {})
                if ledger.criteria.get(active, {}).get("status") != "supported":
                    node["runtime_status"] = "PENDING" if action.carrier not in (None, "unrouted") else "ACTIVE"
                    scheduler.status = node["runtime_status"]
                    scheduler.reason = f"preserve active criterion and exact action: {active}"
                    continue

            # Select the smallest currently executable criterion. Attempts lower priority slightly,
            # allowing independent ready work to proceed instead of hammering one non-closing path.
            candidates = [c for c in ready if ledger.criteria.get(c, {}).get("status") != "supported"]
            if not candidates:
                graph.active_criterion = None
                graph.active_since_cycle = None
                scheduler.status = "BLOCKED"
                scheduler.reason = "no criterion is currently dependency-ready"
                continue

            candidates.sort(
                key=lambda c: (
                    float(graph.nodes[c].get("priority", 1.0)) - 0.10 * int(graph.nodes[c].get("attempts", 0)),
                    -len(graph.nodes[c].get("depends_on", [])),
                    c,
                ),
                reverse=True,
            )
            chosen = candidates[0]
            graph.active_criterion = chosen
            graph.active_since_cycle = world.cycle
            graph.nodes[chosen]["runtime_status"] = "ACTIVE"
            decision = {
                "cycle": world.cycle,
                "criterion": chosen,
                "ready": list(candidates),
                "blocked": {k: list(v) for k, v in blocked.items()},
                "attempts_before": int(graph.nodes[chosen].get("attempts", 0)),
                "reason": "highest bounded criterion priority after dependency and prior-attempt pressure",
            }
            graph.decision_log.append(decision)
            scheduler.status = "ACTIVE"
            scheduler.reason = decision["reason"]



@dataclass
class PortfolioSystem:
    """Publish the state of every known project/domain path without merging their authority.

    A branch can be active, human-blocked, open research, reusable capability, or historical/dormant.
    Linked ECS problem status is reflected, but branch coverage/claim ceilings are never promoted by it.
    """
    def run(self, world: World) -> None:
        rows = list(world.query(BranchPortfolio))
        if not rows:
            return
        _, portfolio = rows[0]
        problem_state = {ident.key: problem.status for _, ident, problem in world.query(Identity, Problem)}
        counts: dict[str, int] = {}
        machine: list[str] = []
        human: list[str] = []
        open_research: list[str] = []
        external: list[str] = []
        for key, branch in portfolio.branches.items():
            linked = list(branch.get("linked_problem_keys", []))
            linked_states = [problem_state[x] for x in linked if x in problem_state]
            activation = str(branch.get("activation", "DORMANT_ON_DEMAND"))
            # Some catalog states encode a stronger current-world boundary than a fresh
            # demonstration problem instance can infer. Preserve those boundaries.
            if activation in {"BLOCKED_HUMAN", "OPEN_RESEARCH", "QUARANTINED_ON_DEMAND", "READY_FOR_INTAKE", "READY_FOR_EXTERNAL_BINDING", "BLOCKED_EXTERNAL_CONFIGURATION"}:
                runtime = activation
            elif linked_states and any(x == "open" for x in linked_states):
                runtime = "ACTIVE"
            elif linked_states and all(x == "complete" for x in linked_states):
                runtime = "BOUNDED_COMPLETE"
            else:
                runtime = activation
            branch["runtime_status"] = runtime
            branch["linked_problem_statuses"] = {p: problem_state.get(p, "NOT_ADMITTED") for p in linked}
            counts[runtime] = counts.get(runtime, 0) + 1
            if runtime in {"ACTIVE", "READY_FOR_INTAKE", "READY_FOR_EXTERNAL_BINDING"}:
                machine.append(key)
            if runtime == "BLOCKED_EXTERNAL_CONFIGURATION":
                external.append(key)
            if runtime == "BLOCKED_HUMAN":
                human.append(key)
            if runtime == "OPEN_RESEARCH":
                open_research.append(key)
        portfolio.runtime_summary = dict(sorted(counts.items()))
        portfolio.machine_frontier = sorted(machine)
        portfolio.human_frontier = sorted(human)
        portfolio.open_research_frontier = sorted(open_research)
        portfolio.external_frontier = sorted(external)


@dataclass
class GlobalTaskBoardSystem:
    """Publish one world-level task frontier so cooperation is visible across problems."""
    def run(self, world: World) -> None:
        boards = list(world.query(TaskBoard))
        if not boards:
            return
        _, board = boards[0]
        tasks: dict[str, dict[str, Any]] = {}
        for pid, ident, problem, graph, ledger in world.query(Identity, Problem, CriterionGraph, AcceptanceLedger):
            for criterion, node in graph.nodes.items():
                task_id = f"{ident.key}::{criterion}"
                tasks[task_id] = {
                    "problem": ident.key,
                    "problem_priority": problem.priority,
                    "criterion": criterion,
                    "status": node.get("runtime_status", "UNRESOLVED"),
                    "priority": float(node.get("priority", 1.0)),
                    "depends_on": list(node.get("depends_on", [])),
                    "methods": list(node.get("methods", [])),
                    "evidence_kinds": list(node.get("evidence_kinds", [])),
                    "attempts": int(node.get("attempts", 0)),
                    "active": graph.active_criterion == criterion,
                    "support_status": ledger.criteria.get(criterion, {}).get("status", "unresolved"),
                }
        board.tasks = tasks
        board.frontier = sorted(k for k, v in tasks.items() if v["status"] in {"READY", "STALE", "ACTIVE"})
        board.pending = sorted(k for k, v in tasks.items() if v["status"] == "PENDING")
        board.blocked = sorted(k for k, v in tasks.items() if str(v["status"]).startswith("BLOCKED"))
        board.completed = sorted(k for k, v in tasks.items() if v["status"] == "SUPPORTED")


@dataclass
class AssignmentSystem:
    team_size: int = 4

    def run(self, world: World) -> None:
        agents = [(eid, ident, agent) for eid, ident, agent in world.query(Identity, Agent)]
        for pid, ident, problem, assignment, graph in world.query(Identity, Problem, Assignment, CriterionGraph):
            criterion = graph.active_criterion
            if problem.status != "open" or not criterion:
                if problem.status == "complete" and assignment.agent_ids:
                    for aid in assignment.agent_ids:
                        world.get(aid, Agent).active_assignments.discard(pid)
                    assignment.agent_ids = []
                    assignment.criterion = None
                continue
            if assignment.criterion == criterion and assignment.agent_ids:
                continue

            # Criterion change = team reformation. Release the prior bounded assignment first.
            for aid in assignment.agent_ids:
                world.get(aid, Agent).active_assignments.discard(pid)
            assignment.agent_ids = []
            assignment.criterion = criterion
            node = graph.nodes[criterion]

            ranked = sorted(
                agents,
                key=lambda row: (
                    _criterion_method_match(node, row[2]),
                    _criterion_skill_score(node, row[2]),
                    -len(row[2].active_assignments),
                    row[2].capacity,
                    row[1].key,
                ),
                reverse=True,
            )
            chosen: list[int] = []
            for aid, _, agent in ranked:
                if len(agent.active_assignments) >= agent.capacity:
                    continue
                if _criterion_method_match(node, agent) <= 0 and _criterion_skill_score(node, agent) <= 0 and chosen:
                    continue
                chosen.append(aid)
                agent.active_assignments.add(pid)
                if len(chosen) >= self.team_size:
                    break
            assignment.agent_ids = chosen


@dataclass
class TeamContributionSystem:
    """Every assigned agent contributes, but only criterion-admissible methods become actions."""
    def run(self, world: World) -> None:
        for pid, ident, problem, assignment, graph, ledger, history in world.query(
            Identity, Problem, Assignment, CriterionGraph, ContributionLedger, PassHistory
        ):
            criterion = graph.active_criterion
            if problem.status != "open" or not criterion or ledger.entries:
                continue
            node = graph.nodes[criterion]
            allowed = set(node.get("methods", []))
            criterion_skills = set(node.get("skills", []))
            for aid in assignment.agent_ids:
                aident = world.get(aid, Identity)
                agent = world.get(aid, Agent)
                overlap = sorted(criterion_skills & agent.skills)
                eligible_methods = sorted(agent.methods & allowed)
                method_pool = eligible_methods or sorted(agent.methods) or ["bounded-pass"]
                method_counts = {m: 0 for m in method_pool}
                for prior in history.passes:
                    for contribution in prior.get("contributions", []):
                        if contribution.get("agent_key") == aident.key and contribution.get("method") in method_counts:
                            method_counts[contribution["method"]] += 1
                method = min(method_pool, key=lambda m: (method_counts[m], m))
                eligible = method in allowed
                ledger.entries.append({
                    "agent_id": aid,
                    "agent_key": aident.key,
                    "agent_name": aident.name,
                    "criterion": criterion,
                    "method": method,
                    "eligible_action_method": eligible,
                    "relevant_skills": overlap,
                    "proposal": (
                        f"Apply {method} to criterion '{criterion}' within {ident.key}."
                        if eligible else
                        f"Contribute {method} as supporting review for criterion '{criterion}'; do not dispatch it as the criterion action."
                    ),
                    "constraint": "Do not exceed the criterion/problem boundary or promote unsupported domain facts.",
                })


@dataclass
class PossibilitySystem:
    max_options: int = 6

    def run(self, world: World) -> None:
        for pid, ident, problem, graph, acceptance, history, ledger, space in world.query(
            Identity, Problem, CriterionGraph, AcceptanceLedger, PassHistory, ContributionLedger, PossibilitySpace
        ):
            criterion = graph.active_criterion
            if problem.status != "open" or not criterion or space.options:
                continue
            node = graph.nodes[criterion]
            dependency_context: dict[str, Any] = {}
            for dep in node.get("depends_on", []):
                dep_state = dict(acceptance.criteria.get(dep, {}))
                dep_pass = next((p for p in reversed(history.passes) if p.get("criterion") == dep and p.get("claim", {}).get("status") in {"evidence-qualified", "stale-reverify"}), None)
                dependency_context[dep] = {
                    "support": dep_state,
                    "result": dep_pass.get("observation", {}).get("result") if dep_pass else None,
                    "artifact": dep_pass.get("observation", {}).get("artifact") if dep_pass else None,
                    "carrier": dep_pass.get("carrier") if dep_pass else dep_state.get("carrier"),
                    "cycle": dep_pass.get("cycle") if dep_pass else dep_state.get("cycle"),
                }
            opts: list[dict[str, Any]] = []
            all_contributors = [x["agent_key"] for x in ledger.entries]
            for entry in ledger.entries:
                if not entry.get("eligible_action_method"):
                    continue
                overlap = list(entry["relevant_skills"])
                method = entry["method"]
                opts.append({
                    "name": f"{entry['agent_key']}:{method}@{criterion}",
                    "agent_id": entry["agent_id"],
                    "method": method,
                    "target_criterion": criterion,
                    "uses": overlap,
                    "contributors": all_contributors,
                    "team_contributions": list(ledger.entries),
                    "cost": max(0.05, 0.2 - 0.02 * len(overlap)),
                    "expected_observation": f"Test {method} specifically against criterion '{criterion}' within {ident.key}",
                    "required_evidence_kinds": list(node.get("evidence_kinds", [])),
                    "required_scope_kinds": list(node.get("scope_kinds", [])),
                    "task_payload": node.get("task_payload", {}),
                    "dependency_context": dependency_context,
                    "evidence": [f"agent:{entry['agent_key']}", f"method:{method}", f"criterion:{criterion}"],
                })
            # Defensive data fallback: a declared criterion method remains addressable even if no
            # current agent advertises it. Authorship remains the team, not an invented specialist.
            if not opts and node.get("methods") and ledger.entries:
                method = node["methods"][0]
                opts.append({
                    "name": f"TEAM:{method}@{criterion}",
                    "agent_id": ledger.entries[0]["agent_id"],
                    "method": method,
                    "target_criterion": criterion,
                    "uses": sorted({s for e in ledger.entries for s in e.get("relevant_skills", [])}),
                    "contributors": all_contributors,
                    "team_contributions": list(ledger.entries),
                    "cost": 0.2,
                    "expected_observation": f"Team-delegated criterion method {method} for '{criterion}'",
                    "required_evidence_kinds": list(node.get("evidence_kinds", [])),
                    "required_scope_kinds": list(node.get("scope_kinds", [])),
                    "task_payload": node.get("task_payload", {}),
                    "dependency_context": dependency_context,
                    "evidence": [f"method:{method}", f"criterion:{criterion}"],
                })
            space.options = opts[: self.max_options]


@dataclass
class SelectionSystem:
    def run(self, world: World) -> None:
        for pid, problem, governance, budget, graph, space, selection, history in world.query(
            Problem, Governance, Budget, CriterionGraph, PossibilitySpace, Selection, PassHistory
        ):
            criterion = graph.active_criterion
            if problem.status != "open" or not criterion or selection.option or not space.options:
                continue
            viable = [o for o in space.options if o.get("cost", 99) <= budget.attention]
            if not viable:
                continue
            prior_counts: dict[str, int] = {}
            for prior in history.passes:
                if prior.get("criterion") != criterion:
                    continue
                name = prior.get("selection", {}).get("name")
                if name:
                    prior_counts[name] = prior_counts.get(name, 0) + 1
            viable.sort(
                key=lambda o: (
                    -prior_counts.get(o.get("name", ""), 0),
                    len(o.get("uses", [])),
                    -o.get("cost", 0),
                    o.get("name", ""),
                ),
                reverse=True,
            )
            selection.option = viable[0]
            used = prior_counts.get(selection.option.get("name", ""), 0)
            selection.rationale = (
                f"criterion='{criterion}'; least-used admissible team method first (prior uses={used}), "
                "then criterion skill overlap and attention cost; local selection only"
            )


@dataclass
class DistinctionRelationSystem:
    def run(self, world: World) -> None:
        for pid, ident, problem, graph, selection, distinctions, relations in world.query(
            Identity, Problem, CriterionGraph, Selection, DistinctionLog, RelationLog
        ):
            if not selection.option or distinctions.items:
                continue
            criterion = graph.active_criterion
            uses = selection.option.get("uses", [])
            distinctions.items.append(
                f"Selected {selection.option['name']} for criterion '{criterion}' from {len(uses)} relevant skill distinctions."
            )
            distinctions.items.append(
                f"Team contributions retained from {len(selection.option.get('contributors', []))} cooperating agents."
            )
            relations.items.append(
                f"{selection.option['method']} -> criterion:{criterion} -> {ident.key}; boundary={'; '.join(problem.boundary)}"
            )


@dataclass
class TransformSystem:
    def run(self, world: World) -> None:
        for pid, graph, selection, action, provenance in world.query(CriterionGraph, Selection, ActionState, Provenance):
            if not selection.option or action.action:
                continue
            action.action = dict(selection.option)
            action.action["target_criterion"] = graph.active_criterion
            action.carrier = "unrouted"
            provenance.transformations.append(
                "criterion graph -> criterion team -> contributions -> admissible possibility -> selection -> relation -> routed action"
            )


@dataclass
class RouterExecutionSystem:
    router: CarrierRouter

    def run(self, world: World) -> None:
        for pid, ident, problem, budget, provenance, graph, action, dispatch, observations in world.query(
            Identity, Problem, Budget, Provenance, CriterionGraph, ActionState, DispatchLog, ObservationLog
        ):
            criterion = graph.active_criterion
            if problem.status != "open" or not criterion or not action.action or observations.items:
                continue
            node = graph.nodes[criterion]
            result = self.router.dispatch(
                world,
                ident.key,
                action.action,
                budget,
                {
                    "cycle": world.cycle,
                    "boundary": problem.boundary,
                    "acceptance": [criterion],
                    "criterion": criterion,
                    "criterion_spec": {
                        k: node.get(k) for k in (
                            "criterion", "depends_on", "skills", "methods", "evidence_kinds", "scope_kinds",
                            "priority", "requires_substantive", "requires_corroboration", "requires_human",
                            "freshness_sensitive", "max_attempts", "task_payload"
                        )
                    },
                    "target_output": problem.target_output,
                    "sources": provenance.sources,
                },
            )
            action.carrier = result.get("carrier")
            action.dispatch_id = result.get("dispatch_id")
            dispatch.attempts.extend(result.get("attempts", []))
            observations.items.append(result)


@dataclass
class EvidenceConsequenceSystem:
    def _admissibility(self, criterion: str, node: dict[str, Any], latest: dict[str, Any]) -> tuple[bool, list[str]]:
        reasons: list[str] = []
        evidence_kind = latest.get("evidence_kind")
        scope_kind = latest.get("scope_kind", "unknown")
        if node.get("evidence_kinds") and evidence_kind not in node.get("evidence_kinds", []):
            reasons.append(f"evidence_kind={evidence_kind!r} not in {node.get('evidence_kinds')}")
        if node.get("scope_kinds") and scope_kind not in node.get("scope_kinds", []):
            reasons.append(f"scope_kind={scope_kind!r} not in {node.get('scope_kinds')}")
        if node.get("requires_substantive") and not bool(latest.get("substantive", False)):
            reasons.append("criterion requires substantive evidence")
        if node.get("requires_corroboration") and not bool(latest.get("corroborated", False)):
            reasons.append("criterion requires an independent corroborating carrier")
        if node.get("requires_human") and evidence_kind != "human-observation":
            reasons.append("criterion requires human observation")
        if criterion not in latest.get("satisfies", []):
            reasons.append("carrier result did not explicitly satisfy the active criterion")
        return (not reasons, reasons)

    def run(self, world: World) -> None:
        for pid, ident, problem, graph, obs, consequences, evidence, acceptance_ledger, remainder, fresh, history in world.query(
            Identity, Problem, CriterionGraph, ObservationLog, ConsequenceLog, EvidenceLedger,
            AcceptanceLedger, Remainder, Freshness, PassHistory
        ):
            criterion = graph.active_criterion
            if not criterion or not obs.items or consequences.items:
                continue
            node = graph.nodes[criterion]
            latest = obs.items[-1]
            ok = bool(latest.get("ok"))
            pending = bool(latest.get("pending"))
            corroborated = bool(latest.get("corroborated"))
            admissible, admission_reasons = self._admissibility(criterion, node, latest) if (ok and not pending) else (False, [])

            node["last_cycle"] = world.cycle
            node["last_result"] = latest.get("result")
            if not pending:
                node["attempts"] = int(node.get("attempts", 0)) + 1

            criterion_supported = ok and not pending and bool(latest.get("evidence")) and admissible
            consequences.items.append({
                "accepted": criterion_supported,
                "criterion": criterion,
                "bounded": True,
                "carrier": latest.get("carrier"),
                "corroborated": corroborated,
                "scope_kind": latest.get("scope_kind", "unknown"),
                "substantive_domain_evidence": bool(latest.get("substantive", False)),
                "admissible_for_criterion": admissible,
                "admission_reasons": list(admission_reasons),
            })

            if pending:
                status = "pending-human" if latest.get("evidence_kind") in {"human-pending", "carrier-pending"} and node.get("requires_human") else "pending-carrier"
                node["runtime_status"] = "PENDING"
            elif criterion_supported:
                status = "evidence-qualified"
                node["runtime_status"] = "SUPPORTED"
            elif ok and latest.get("evidence"):
                status = "evidence-qualified-nonclosing"
                node["runtime_status"] = "READY"
            else:
                status = "failed"
                node["runtime_status"] = "READY"

            evidence.claims.append({
                "claim": latest.get("result"),
                "support": latest.get("evidence", []),
                "scope": ident.key,
                "criterion": criterion,
                "scope_kind": latest.get("scope_kind", "unknown"),
                "evidence_kind": latest.get("evidence_kind"),
                "substantive": bool(latest.get("substantive", False)),
                "carrier": latest.get("carrier"),
                "corroborated": corroborated,
                "admissible_for_criterion": admissible,
                "admission_reasons": list(admission_reasons),
                "cycle": world.cycle,
                "status": status,
            })

            node["last_admission_failed"] = bool(ok and not pending and not criterion_supported)

            if criterion_supported:
                node["last_admission_failed"] = False
                fresh.cycle_verified = world.cycle
                fresh.stale = False
                acceptance_ledger.criteria[criterion] = {
                    "status": "supported",
                    "support": list(latest.get("evidence", [])),
                    "cycle": world.cycle,
                    "problem_pass": len(history.passes) + 1,
                    "scope_kind": latest.get("scope_kind", "unknown"),
                    "evidence_kind": latest.get("evidence_kind"),
                    "carrier": latest.get("carrier"),
                    "substantive": bool(latest.get("substantive", False)),
                    "corroborated": corroborated,
                }

            unresolved = []
            for c, state in acceptance_ledger.criteria.items():
                if state.get("status") == "supported":
                    continue
                deps = graph.nodes.get(c, {}).get("depends_on", [])
                missing = [d for d in deps if acceptance_ledger.criteria.get(d, {}).get("status") != "supported"]
                if state.get("status") == "stale":
                    unresolved.append(f"Acceptance criterion stale: {c}")
                elif missing:
                    unresolved.append(f"Acceptance criterion blocked: {c}; depends on {missing}")
                else:
                    unresolved.append(f"Acceptance criterion unresolved: {c}")
            unresolved.extend(latest.get("unresolved", []))
            unresolved.extend(f"Criterion evidence not admitted: {reason}" for reason in admission_reasons)
            remainder.unresolved = unresolved
            if pending:
                request_id = latest.get("request_id")
                suffix = f" ({request_id})" if request_id else ""
                remainder.next_state = f"retry same criterion/action after carrier response{suffix}; do not advance or overwrite prior pass"
            elif criterion_supported:
                remainder.next_state = "schedule the next dependency-ready acceptance criterion; preserve this support and do not overwrite prior pass"
            else:
                remainder.next_state = "reschedule among dependency-ready criteria; retain this non-closing attempt as evidence and do not overwrite prior pass"


@dataclass
class KnowledgeDecaySystem:
    def run(self, world: World) -> None:
        for pid, problem, fresh, evidence, acceptance, graph, history in world.query(
            Problem, Freshness, EvidenceLedger, AcceptanceLedger, CriterionGraph, PassHistory
        ):
            # Freshness is criterion-local. Stable structural/internal claims are not made stale merely
            # because unrelated time passed; only criteria explicitly marked freshness-sensitive decay.
            fresh.stale = False

            # Criterion-level decay is selective: only criteria declared freshness-sensitive reopen.
            reopened = False
            for criterion, node in graph.nodes.items():
                state = acceptance.criteria.get(criterion, {})
                support_pass = state.get("problem_pass")
                if not node.get("freshness_sensitive") or state.get("status") != "supported" or support_pass is None:
                    continue
                local_age = max(0, len(history.passes) - int(support_pass))
                if local_age > fresh.max_age_cycles:
                    state["status"] = "stale"
                    node["runtime_status"] = "STALE"
                    fresh.stale = True
                    for claim in evidence.claims:
                        if claim.get("criterion") == criterion and claim.get("status") == "evidence-qualified":
                            claim["status"] = "stale-reverify"
                    reopened = True
            if reopened:
                problem.status = "open"


@dataclass
class CooperationSystem:
    def run(self, world: World) -> None:
        boards = list(world.query(Blackboard))
        if not boards:
            return
        _, board = boards[0]
        known = {(e.get("problem"), e.get("claim"), e.get("cycle")) for e in board.entries}
        for pid, ident, evidence, provenance in world.query(Identity, EvidenceLedger, Provenance):
            for claim in evidence.claims:
                key = (ident.key, claim.get("claim"), claim.get("cycle"))
                if key in known:
                    continue
                board.entries.append({
                    "problem": ident.key,
                    "criterion": claim.get("criterion"),
                    "claim": claim.get("claim"),
                    "status": claim.get("status"),
                    "admissible_for_criterion": claim.get("admissible_for_criterion"),
                    "scope_kind": claim.get("scope_kind"),
                    "carrier": claim.get("carrier"),
                    "corroborated": claim.get("corroborated"),
                    "authors": list(provenance.authors),
                    "sources": list(provenance.sources),
                    "cycle": claim.get("cycle", world.cycle),
                })
                known.add(key)


@dataclass
class PassHistorySystem:
    """Append a criterion-scoped, forward-only summary before ephemeral state resets."""
    def run(self, world: World) -> None:
        for pid, ident, graph, scheduler, assignment, contributions, selection, action, dispatch, obs, cons, evidence, acceptance_ledger, remainder, history in world.query(
            Identity, CriterionGraph, SchedulerState, Assignment, ContributionLedger, Selection, ActionState,
            DispatchLog, ObservationLog, ConsequenceLog, EvidenceLedger, AcceptanceLedger, Remainder, PassHistory
        ):
            if not cons.items or any(x.get("cycle") == world.cycle for x in history.passes):
                continue
            current_observation = obs.items[-1]
            current_request_id = current_observation.get("request_id")
            if current_observation.get("pending") and current_request_id and history.passes:
                previous = history.passes[-1]
                if (
                    previous.get("observation", {}).get("request_id") == current_request_id
                    and str(previous.get("claim", {}).get("status", "")).startswith("pending")
                ):
                    # Preserve one transition into pending, not one duplicate history row per poll.
                    continue
            history.passes.append({
                "cycle": world.cycle,
                "problem": ident.key,
                "criterion": graph.active_criterion,
                "scheduler_status": scheduler.status,
                "scheduler_reason": scheduler.reason,
                "team_agent_ids": list(assignment.agent_ids),
                "contributions": list(contributions.entries),
                "selection": dict(selection.option or {}),
                "selection_rationale": selection.rationale,
                "carrier": action.carrier,
                "dispatch_id": action.dispatch_id,
                "dispatch_attempts": list(dispatch.attempts),
                "observation": dict(obs.items[-1]),
                "consequence": dict(cons.items[-1]),
                "claim": dict(evidence.claims[-1]),
                "acceptance": {k: dict(v) for k, v in acceptance_ledger.criteria.items()},
                "criterion_graph": {
                    k: {
                        "runtime_status": v.get("runtime_status"),
                        "attempts": v.get("attempts", 0),
                        "depends_on": list(v.get("depends_on", [])),
                    } for k, v in graph.nodes.items()
                },
                "remainder": list(remainder.unresolved),
                "next_state": remainder.next_state,
            })


@dataclass
class CompletionStatusSystem:
    """Finalize problem status after the current pass has been recorded.

    Scheduling happens at the start of a pass, but evidence may close the final criterion later in
    that same pass. This post-history system prevents a one-cycle lag between the acceptance ledger
    and the problem/task-board status while preserving the final criterion in PassHistory.
    """
    def run(self, world: World) -> None:
        for _, problem, graph, ledger, scheduler in world.query(
            Problem, CriterionGraph, AcceptanceLedger, SchedulerState
        ):
            all_supported = bool(graph.nodes) and all(
                ledger.criteria.get(c, {}).get("status") == "supported" for c in graph.nodes
            )
            if not all_supported:
                continue
            problem.status = "complete"
            graph.active_criterion = None
            graph.active_since_cycle = None
            scheduler.status = "COMPLETE"
            scheduler.reason = "all acceptance criteria are evidence-supported"


@dataclass
class ResetForNextPassSystem:
    def run(self, world: World) -> None:
        for pid, problem, graph, assignment, contributions, space, selection, distinctions, relations, action, dispatch, obs, cons in world.query(
            Problem, CriterionGraph, Assignment, ContributionLedger, PossibilitySpace, Selection,
            DistinctionLog, RelationLog, ActionState, DispatchLog, ObservationLog, ConsequenceLog
        ):
            if not cons.items:
                continue
            pending = bool(obs.items and obs.items[-1].get("pending"))
            if pending and problem.status == "open":
                # Exact pending criterion + action survives retry/restart.
                dispatch.attempts = []
                obs.items = []
                cons.items = []
                continue

            # Completed or non-closing attempts are historical. The next cycle re-runs scheduling.
            graph.active_criterion = None
            graph.active_since_cycle = None
            assignment.criterion = None
            # Release agents so another criterion/problem may recruit them under capacity rules.
            for aid in assignment.agent_ids:
                world.get(aid, Agent).active_assignments.discard(pid)
            assignment.agent_ids = []
            contributions.entries = []
            space.options = []
            selection.option = None
            selection.rationale = ""
            distinctions.items = []
            relations.items = []
            action.action = None
            action.carrier = None
            action.dispatch_id = None
            dispatch.attempts = []
            obs.items = []
            cons.items = []
