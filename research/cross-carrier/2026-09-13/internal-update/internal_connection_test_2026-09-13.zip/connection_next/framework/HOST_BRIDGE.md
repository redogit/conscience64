# Host Carrier Boundary — v0.4.0

The ECS owns world state. External tools and humans return bounded observations; they do not directly mutate that state.

## Transport

`JsonlHostBridgeAdapter` uses two append-only files:

- `outbox.jsonl` — typed criterion-scoped requests emitted by the ECS;
- `inbox.jsonl` — host responses carrying observations and stable evidence identifiers.

Request identity is derived from the semantic request and excludes transient cycle/dispatch UUIDs. Retrying the same pending action therefore retains the same request ID.

The bridge can bind declared carriers for:

- `model`;
- `research`;
- `library`;
- `scientific-compute`;
- `human-queue`.

## Criterion-scoped request contract

The semantic request carries the active criterion and its contract, including:

- exact selected action and team contributions;
- criterion name and `criterion_spec`;
- boundary and target output;
- required acceptance criterion;
- declared sources;
- dependency artifacts/evidence inherited from supported prerequisites;
- verification primary result when dispatch is in verifier mode.

That makes retries reconstructible and lets a host see what evidence class is actually required.

## Authority boundary

A host may return:

- `result` / observation;
- stable evidence identifiers;
- evidence kind and scope;
- confidence;
- an artifact/trace;
- explicit unresolved remainder;
- explicit `satisfies` criteria.

A host may **not** mutate ECS state. The ECS evidence gate decides whether the response can close the active criterion.

`substantive=true` without stable evidence identifiers is automatically downgraded to non-substantive.

A response can therefore be valid information and still be **non-closing** if it has the wrong evidence kind, scope, human status, corroboration status, or explicit criterion target.

## Pending work

When no response exists:

- criterion status becomes `PENDING`;
- the exact action and request ID survive reset/restart;
- the outbox record is emitted once;
- repeated polling does not append duplicate pending history rows;
- no different criterion is silently substituted for that pending action.

## Process restart

```bash
python run_world.py --cycles 2 --bridge-dir .runtime/bridge --snapshot state.json
python run_world.py --cycles 1 --bridge-dir .runtime/bridge --resume state.json --snapshot state2.json
```

Restore recreates the declared configuration schema, verifies entity identity continuity, and then hydrates component state. Identity/schema drift is rejected instead of guessed.

By default each CLI cycle resets only ephemeral pass state after the recorded pass so the resulting snapshot is continuation-ready. `--no-reset` is an explicit inspection/debug mode.

## Inspect and answer requests

```bash
python bridge_cli.py --bridge-dir .runtime/bridge pending
python bridge_cli.py --bridge-dir .runtime/bridge respond REQUEST_ID response.json
```

The response JSON requires `ok` and `result`; `request_id` is supplied by the command. Evidence should use stable source/file/artifact/computation/record identifiers.

See `world/host_carrier_contract.json` for the machine-readable contract and `world/host_profile.chatgpt.json` for an example host mapping.
