from pathlib import Path
import argparse
import json
import sys

ROOT = Path(__file__).parent
SRC = ROOT / "src"
sys.path.insert(0, str(SRC))

from ecs_world import append_host_response, pending_host_requests


def main() -> None:
    parser = argparse.ArgumentParser(description="Inspect or answer ECS host-bridge requests.")
    parser.add_argument("--bridge-dir", default=".runtime/bridge")
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("pending")
    respond = sub.add_parser("respond")
    respond.add_argument("request_id")
    respond.add_argument("response_json", help="Path to JSON object containing at least ok and result")
    args = parser.parse_args()

    bridge = Path(args.bridge_dir)
    outbox = bridge / "outbox.jsonl"
    inbox = bridge / "inbox.jsonl"

    if args.command == "pending":
        rows = pending_host_requests(outbox, inbox)
        print(json.dumps(rows, indent=2))
        return

    response = json.loads(Path(args.response_json).read_text(encoding="utf-8"))
    if not isinstance(response, dict):
        raise SystemExit("response JSON must be an object")
    response["request_id"] = args.request_id
    append_host_response(inbox, response)
    print(f"appended response for {args.request_id} -> {inbox}")


if __name__ == "__main__":
    main()
