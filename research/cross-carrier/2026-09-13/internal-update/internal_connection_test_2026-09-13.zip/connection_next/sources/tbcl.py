#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

MAGIC = "TBCL 0.1 MAXCTX"
SEMANTIC_TAGS = ("meta", "subject", "relation", "contract", "obligation", "claim", "execution")


def canon(obj: Any) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


@dataclass(frozen=True)
class Artifact:
    path: str
    sha256: str
    bytes: int
    payload: bytes


@dataclass
class Program:
    records: list[tuple[str, dict[str, Any]]]
    semantic_root_declared: str
    custody_root_declared: str
    program_root_declared: str
    artifacts: list[Artifact]

    def semantic_records(self) -> list[dict[str, Any]]:
        return [{"tag": tag, "value": value} for tag, value in self.records]

    def semantic_root(self) -> str:
        return sha256_bytes(canon(self.semantic_records()))

    def custody_index(self) -> list[dict[str, Any]]:
        return [
            {"path": a.path, "sha256": a.sha256, "bytes": a.bytes}
            for a in sorted(self.artifacts, key=lambda x: x.path)
        ]

    def custody_root(self) -> str:
        return sha256_bytes(canon(self.custody_index()))

    def program_root(self) -> str:
        return sha256_bytes(canon({"semantic_root": self.semantic_root(), "custody_root": self.custody_root()}))

    def validate(self) -> None:
        if not self.records:
            raise ValueError("program has no semantic records")
        if sum(1 for t, _ in self.records if t == "subject") != 1:
            raise ValueError("program must contain exactly one subject")
        if sum(1 for t, _ in self.records if t == "meta") != 1:
            raise ValueError("program must contain exactly one meta record")
        if sum(1 for t, _ in self.records if t == "execution") != 1:
            raise ValueError("program must contain exactly one execution record")
        paths = [a.path for a in self.artifacts]
        if len(paths) != len(set(paths)):
            raise ValueError("duplicate artifact path")
        for a in self.artifacts:
            if len(a.payload) != a.bytes:
                raise ValueError(f"artifact length mismatch: {a.path}")
            if sha256_bytes(a.payload) != a.sha256:
                raise ValueError(f"artifact checksum mismatch: {a.path}")
        if self.semantic_root() != self.semantic_root_declared:
            raise ValueError("semantic root mismatch")
        if self.custody_root() != self.custody_root_declared:
            raise ValueError("custody root mismatch")
        if self.program_root() != self.program_root_declared:
            raise ValueError("program root mismatch")

    def by_tag(self, tag: str) -> list[dict[str, Any]]:
        return [v for t, v in self.records if t == tag]

    def context_projection(self) -> dict[str, Any]:
        return {
            "meta": self.by_tag("meta")[0],
            "subject": self.by_tag("subject")[0],
            "relations": self.by_tag("relation"),
            "contracts": self.by_tag("contract"),
            "obligations": self.by_tag("obligation"),
            "claims": self.by_tag("claim"),
            "execution": self.by_tag("execution")[0],
            "roots": {
                "semantic": self.semantic_root(),
                "custody": self.custody_root(),
                "program": self.program_root(),
            },
        }


def _read_line(data: bytes, pos: int) -> tuple[bytes, int]:
    j = data.find(b"\n", pos)
    if j < 0:
        return data[pos:], len(data)
    return data[pos:j], j + 1


def parse_bytes(data: bytes) -> Program:
    pos = 0
    line, pos = _read_line(data, pos)
    if line.decode("utf-8") != MAGIC:
        raise ValueError("invalid TBCL header")

    records: list[tuple[str, dict[str, Any]]] = []
    semantic_root = custody_root = program_root = None
    artifacts: list[Artifact] = []

    while pos < len(data):
        line, pos = _read_line(data, pos)
        if not line:
            continue
        if line == b"end":
            if pos != len(data):
                # Permit a final newline only.
                if data[pos:] not in (b"", b"\n"):
                    raise ValueError("trailing bytes after end")
            break
        text = line.decode("utf-8")
        tag, sep, rest = text.partition(" ")
        if not sep:
            raise ValueError(f"malformed statement: {text}")
        if tag in SEMANTIC_TAGS:
            obj = json.loads(rest)
            if not isinstance(obj, dict):
                raise ValueError(f"{tag} must carry an object")
            records.append((tag, obj))
            continue
        if tag in ("semantic_root", "custody_root", "program_root"):
            value = json.loads(rest)
            if not isinstance(value, str) or len(value) != 64:
                raise ValueError(f"invalid {tag}")
            if tag == "semantic_root": semantic_root = value
            elif tag == "custody_root": custody_root = value
            else: program_root = value
            continue
        if tag == "artifact":
            header = json.loads(rest)
            if not isinstance(header, dict):
                raise ValueError("artifact header must be object")
            path = str(header["path"])
            expected_sha = str(header["sha256"])
            expected_len = int(header["bytes"])
            delimiter = str(header["delimiter"]).encode("utf-8")
            marker = b"\n" + delimiter + b"\n"
            end_at = data.find(marker, pos)
            if end_at < 0:
                raise ValueError(f"unterminated artifact: {path}")
            payload = data[pos:end_at]
            pos = end_at + len(marker)
            artifacts.append(Artifact(path, expected_sha, expected_len, payload))
            continue
        raise ValueError(f"unknown statement tag: {tag}")
    else:
        raise ValueError("missing end")

    if semantic_root is None or custody_root is None or program_root is None:
        raise ValueError("missing roots")
    p = Program(records, semantic_root, custody_root, program_root, artifacts)
    p.validate()
    return p


def parse(path: Path) -> Program:
    return parse_bytes(path.read_bytes())


def render(program: Program) -> bytes:
    # Canonical renderer. Artifact payloads are emitted verbatim.
    lines: list[bytes] = [MAGIC.encode("utf-8") + b"\n"]
    for tag, value in program.records:
        lines.append(tag.encode() + b" " + canon(value) + b"\n")
    lines.append(b"semantic_root " + json.dumps(program.semantic_root()).encode() + b"\n")
    lines.append(b"custody_root " + json.dumps(program.custody_root()).encode() + b"\n")
    lines.append(b"program_root " + json.dumps(program.program_root()).encode() + b"\n")
    for a in sorted(program.artifacts, key=lambda x: x.path):
        delimiter = f"@@END_{a.sha256}@@"
        header = {"path": a.path, "sha256": a.sha256, "bytes": a.bytes, "delimiter": delimiter}
        lines.append(b"artifact " + canon(header) + b"\n")
        lines.append(a.payload)
        lines.append(b"\n" + delimiter.encode() + b"\n")
    lines.append(b"end\n")
    return b"".join(lines)


def compile_program(program: Program, dst: Path) -> None:
    program.validate()
    dst.mkdir(parents=True, exist_ok=True)
    for a in program.artifacts:
        out = dst / a.path
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_bytes(a.payload)
    context = program.context_projection()
    (dst / "TBCL_CONTEXT.json").write_text(json.dumps(context, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    launcher = '''#!/usr/bin/env python3\nfrom pathlib import Path\nimport json, sys\nroot = Path(__file__).resolve().parent\nctx = json.loads((root / "TBCL_CONTEXT.json").read_text())\nsys.path.insert(0, str(root / "runtime"))\nfrom tiny_babel_factored import FactoredLibrary\nlib = FactoredLibrary()\nprint(json.dumps({"subject_commitment": lib.subject_commitment(), "semantic_root": ctx["roots"]["semantic"], "custody_root": ctx["roots"]["custody"]}, sort_keys=True))\n'''
    (dst / "run_tbcl.py").write_text(launcher, encoding="utf-8")


def cmd_check(args: argparse.Namespace) -> int:
    p = parse(Path(args.program))
    print(json.dumps({
        "status": "PASS",
        "semantic_root": p.semantic_root(),
        "custody_root": p.custody_root(),
        "program_root": p.program_root(),
        "contracts": len(p.by_tag("contract")),
        "obligations": len(p.by_tag("obligation")),
        "claims": len(p.by_tag("claim")),
        "artifacts": len(p.artifacts),
    }, indent=2))
    return 0


def cmd_inspect(args: argparse.Namespace) -> int:
    p = parse(Path(args.program))
    print(json.dumps(p.context_projection(), indent=2, ensure_ascii=False))
    return 0


def cmd_roundtrip(args: argparse.Namespace) -> int:
    src = Path(args.program).read_bytes()
    p = parse_bytes(src)
    out = render(p)
    same = src == out
    print(json.dumps({"byte_identical": same, "source_bytes": len(src), "rendered_bytes": len(out)}, indent=2))
    return 0 if same else 2


def cmd_compile(args: argparse.Namespace) -> int:
    p = parse(Path(args.program))
    compile_program(p, Path(args.destination))
    print(json.dumps({"compiled": str(Path(args.destination)), "program_root": p.program_root()}, indent=2))
    return 0


def main() -> int:
    ap = argparse.ArgumentParser(description="Tiny Babel Context Language 0.1")
    sub = ap.add_subparsers(dest="cmd", required=True)
    for name in ("check", "inspect", "roundtrip"):
        sp = sub.add_parser(name); sp.add_argument("program")
    sp = sub.add_parser("compile"); sp.add_argument("program"); sp.add_argument("destination")
    args = ap.parse_args()
    return {"check": cmd_check, "inspect": cmd_inspect, "roundtrip": cmd_roundtrip, "compile": cmd_compile}[args.cmd](args)


if __name__ == "__main__":
    raise SystemExit(main())
