# Connected Research Map — Privacy-Safe Corpus

Generated from `MASTER_MANIFEST.json` SHA-256 `d654f1ada18f415ef6f7b79b80ef494b1bc225859277ec655f990d4bb3da7d9e`.

## Governing connection rule

This map connects research by **typed, evidence-bounded relations**. It does not turn all projects into one theory or inherit authority across project boundaries. `DIRECT_ANCESTRY`, `METHOD_TRANSFER`, `LATER_RESEARCH_BRANCH`, `CONCEPTUAL_CONVERGENCE`, and low-confidence parallelism remain different relations.

## The shared spine

`Human Need/Aim → Boundary → bounded Possibility Space → Selection → Distinction → Relation → Transform → Carrier/Action → Observation → Consequence → Evidence-qualified Output → Unresolved Remainder → next bounded state.`

Across the corpus, that spine repeatedly resolves into seven durable operations:

1. **Preserve** source, identity, chronology, and provenance.
2. **Distinguish** only differences consequential to the current obligation.
3. **Transport** across carriers without collapsing or inventing meaning.
4. **Compose** verified operators/capabilities rather than treating every solution as isolated.
5. **Attack / verify** with counterexamples, controls, ablations, frozen evidence, and independent reconstruction.
6. **Select** what becomes active only after correctness, relevance, and cost gates.
7. **Retain the remainder**: unknown, absent-from-view, and disproved are different states.

## Major connected research families

### Privacy-Safe Research Library / Float64 Pack
Canonical privacy-safe corpus, content addressing, redaction/exclusion boundary, and Float64 distribution.

### Pareidolia Guard
False-pattern control, calibration, scoring, provenance, and adversarial pattern interpretation.
Packed artifact connections: **41**.
Connections:
- **FALSE_PATTERN_CONTROL → Historical Knowledge Recovery** (medium): Pareidolia-control machinery provides adversarial pressure against pattern over-reading in recovery work; treated as method reuse, not ancestry

### Integrated Research Stack
Current bounded research framework and whole-stack running-model carrier.
Packed artifact connections: **6**.

### Library of Babel Reconstruction
Cold-source reconstruction, provenance boundaries, UOID identity, semantic scans, and historical compatibility.
Packed artifact connections: **21**.
Connections:
- **CONCEPTUAL_CONVERGENCE → Cross-Carrier Field / Transform Wave** (medium): Both enforce source/carrier/transform/verification separation and unresolved remainder; not asserted as direct ancestry
- **RECOVERY_METHOD_CONVERGENCE → Historical Knowledge Recovery** (medium): Cold-source reconstruction and historical recovery both preserve source/representation/interpretation boundaries

### Physics / GR–Quantum Seam
Space-time-gravity distinctions, relational clocks, curvature probes, Schwarzschild/Rindler controls, and entanglement models.
Packed artifact connections: **12**.
Connections:
- **METHOD_COMPATIBILITY → R³ Scientific Method** (medium): Physics distinction map uses controlled distinctions/counter-probes compatible with R3 transport/falsification discipline; not claimed as original ancestry

### Orbit / Historical Knowledge Recovery
Library organization, retrieval, lineage, source mapping, active/history separation, and recovery.
Packed artifact connections: **2**.
Connections:
- **DIRECT_EXTENSION → Historical Knowledge Recovery** (high): Running model current state uses libraries as machinery for historical carrier/relation recovery

### Cross-Carrier Field / Transform Wave
Relations and transformations across carriers with preserved obligations and unresolved remainder.
Packed artifact connections: **4**.
Connections:
- **CARRIER_IMPLEMENTATION → Float64 / UTF-8 Coordinate Carriers** (high): Float64 coordinate space implements exact reversible carrier/address layer while identity remains separate
- **CURRENT_EXPERIMENTAL_BRANCH → Search / Certify / Recursive Decomposition** (high): Entire Running Models export includes cross-carrier wave, SEARCH/CERTIFY, and recursive decomposition evidence

### Operator Moonshot
Reusable operators, verified composition, search economics, semantic execution, and crystallization.
Packed artifact connections: **2**.
Connections:
- **DIRECT_HANDOFF → One_Level_Up / Airlock** (high): Airlock handoff classifies Operator Moonshot as predecessor and preserves evidence without inherited authority
- **LATER_RESEARCH_BRANCH → Physics / GR–Quantum Seam** (high): Non-private reconstruction and physics recovery package place later GR/QM distinction work after Moonshot methods
- **CANDIDATE_METHOD_TRANSFER → Orbit / Historical Knowledge Recovery** (high): Operator Moonshot source-native reconstruction explicitly limits relation to candidate admission/provenance method

### 4D Codec / Inversion / Ring Topology
Inversion, ring/dual-ring topology, trained identity carriers, and coupled coordinate transforms.
Packed artifact connections: **5**.
Connections:
- **TECHNICAL_PREDECESSOR → Float64 / UTF-8 Coordinate Carriers** (high): 4D/binary64 coordinate work and inversion/identity tests precede later Float64 archival carrier

### Float64 / UTF-8 Coordinate Carriers
Exact identity plus reversible numeric coordinate carriers and archival transport.
Packed artifact connections: **4**.
Connections:
- **APPLICATION → Privacy-Safe Research Library / Float64 Pack** (high): Privacy-safe library is encoded into Float64 carrier objects with SHA-256 identity

### Historical Knowledge Recovery
Multilingual/cross-cultural carrier recovery, variant graphs, chronology, provenance, uncertainty, rights, and accessibility.
Connections:
- **CARRIER_RECOVERY_APPLICATION → Cross-Carrier Field / Transform Wave** (high): Current running state treats historical source/edition/transcription/translation/reconstruction as distinct carriers

### Fractal / Multifractal Geometry
Fractal unrolling, recursive geometry, transforms, topology, and search experiments.
Packed artifact connections: **6**.
Connections:
- **GEOMETRIC_CONVERGENCE → 4D Codec / Inversion / Ring Topology** (medium): Fractal unrolling/rotation/invertibility and 4D inversion/topology share geometric transform machinery without claiming common theory

### R³ Scientific Method
Recursive relational reconstruction; distinguish, ground, transport, attack, repair, select.
Packed artifact connections: **2**.
Connections:
- **METHOD_REINFORCEMENT → Orbit / Historical Knowledge Recovery** (high): R3 source-native reconstruction explicitly classifies relation to Orbit as CURRENT_REINFORCEMENT

### SHADOW
Behavior-preserving control structures over frozen models and minimal executable intervention.
Packed artifact connections: **3**.

### TBCL — Context Language Lab
Portable semantics, context records, bounded native execution, and active/preserved separation.
Packed artifact connections: **1**.
Connections:
- **METHOD_REINFORCEMENT → Orbit / Historical Knowledge Recovery** (high): TBCL source-native reconstruction: active knowledge != preserved experience and bounded admission

### Tiny Babel
Finite compositional subject, carrier replacement, exhaustive resolver verification, and compression.
Packed artifact connections: **3**.
Connections:
- **DIRECT_ANCESTRY → TBCL — Context Language Lab** (high): TBCL source-native reconstruction explicitly names Tiny Babel as genesis/case-study predecessor
- **METHOD_REINFORCEMENT → Orbit / Historical Knowledge Recovery** (high): Source-native Tiny Babel reconstruction: verified subject/obligation != implementation carrier

### One_Level_Up / Airlock
Provenance-preserving transfer, chronology, admission, authority separation, and handoff.
Packed artifact connections: **1**.
Connections:
- **METHOD_PREDECESSOR → Cross-Carrier Field / Transform Wave** (medium): Airlock provenance/admission obligations recur in cross-carrier transport contracts; chronology retained as separate relation

### SLM / Streaming Memory
Tokenizer-free/raw-byte language models, associative memory, ablation, invariants, and resource accounting.
Packed artifact connections: **2**.
Connections:
- **VERIFICATION_METHOD → Orbit / Historical Knowledge Recovery** (medium): SLM reconstruction proposes invariant-aware multi-path verification as a candidate Orbit method
- **MODEL_SYSTEMS_CONVERGENCE → SHADOW** (low): Both investigate bounded model behavior under explicit interventions and preservation tests; no direct ancestry asserted

### Language Structure Workbench
Inspectable language structure, unknown handling, current/audit separation, and optional capability layers.
Packed artifact connections: **1**.
Connections:
- **INTERFACE_METHOD → Orbit / Historical Knowledge Recovery** (high): Workbench reconstruction proposes current-view/audit separation for Orbit
- **SEMANTIC_METHOD_CONVERGENCE → TBCL — Context Language Lab** (medium): Both preserve unknowns and separate structural representation from unsupported semantic claims

### PulseNet / PulseNet GP
Evolving update programs, curvature/sigma/trust/covariance experiments, mutation knowledge, and robustness.
Packed artifact connections: **1**.
Connections:
- **PARALLEL_CURVATURE_USE → Physics / GR–Quantum Seam** (low): Both use curvature language in different domains; relation is parallel mathematical machinery, not causal scientific support
- **OPERATOR_EXPERIMENT_CONVERGENCE → Operator Moonshot** (medium): Both study reusable/update operators with verification, mutation/search, and cost pressure; separate experimental lines

### Latent Dimension Discovery
Observable latent rank, completeness-aware inference, lower bounds, topology/metric probes.
Packed artifact connections: **1**.
Connections:
- **COMPLETENESS_METHOD → Orbit / Historical Knowledge Recovery** (high): Latent Dimension reconstruction proposes lower-bound/completeness discipline for Orbit

### Search / Certify / Recursive Decomposition
Independent Set, separator discovery, boundary quotients, search regimes, certification, and bounded recursion.

### Historical Knowledge Recovery v2
Carrier + relation + context + provenance + uncertainty recovery across languages/cultures.
Connections:
- **CURRENT_IMPLEMENTATION_OF → Historical Knowledge Recovery** (high): running-model export

### RIVIR API / Data Interface
API/data-pool interface work and human-facing access to structured operational data.
Packed artifact connections: **2**.
Connections:
- **APPLICATION_OF_INTERFACE_METHOD → Integrated Research Stack** (medium): RIVIR API work is an applied data/interface branch of input-relation-plan-output handling

### Water-Care Engineering
Minimal-necessity engineering, bounded reachable actions, observation, cost, safety, and maintenance.
Packed artifact connections: **1**.
Connections:
- **APPLICATION_OF_BOUNDED_METHOD → Integrated Research Stack** (high): Water export applies I/R/P/O, minimal necessity, observation, consequence, cost, and safety

### Boundary Quotient / Recursive Decomposition
Exact decomposition through consequential boundary state and cost-gated recursion.

### Computer Mind Lab
Experimental constitution, evidence custody, lesions/counterfactuals, and operational closure.
Packed artifact connections: **1**.
Connections:
- **METHOD_TRANSFER → Operator Moonshot** (high): Full research lineage states Moonshot supplied architecture and Computer Mind supplied evidence constitution

### Search Regime / SEARCH-CERTIFY
Regime recognition, barrier profiles, search/navigation/certification distinctions.

### External / Imported Reference Material
Non-project reference material retained as research input.
Packed artifact connections: **1**.

## Cross-project bridge structure

- **Privacy-Safe Research Library / Float64 Pack** — graph degree 129
- **Pareidolia Guard** — graph degree 46
- **Integrated Research Stack** — graph degree 40
- **Library of Babel Reconstruction** — graph degree 30
- **Physics / GR–Quantum Seam** — graph degree 21
- **Verification / Falsification** — graph degree 19
- **Orbit / Historical Knowledge Recovery** — graph degree 17
- **Faithful Transport** — graph degree 16
- **Cross-Carrier Field / Transform Wave** — graph degree 16
- **Operator Moonshot** — graph degree 15
- **Unresolved Remainder / Completeness** — graph degree 13
- **Provenance & Chronology** — graph degree 12

The high-degree bridge nodes are not automatically the “truest” ideas. They are the operations that recur across the greatest number of otherwise independent research branches.

## Connection topology

```text
                           ┌──────── R³ / evidence discipline ────────┐
                           │                                           │
Preserve / provenance ── One_Level_Up ── Cross-Carrier ── Float64 ── Privacy Pack
          │                │                 │              │
          │                │                 ├── Babel / UOID│
          │                │                 └── Historical Recovery ── Orbit
          │                │                                         │
          ├── Computer Mind ── Operator Moonshot ── Physics          ├── TBCL ← Tiny Babel
          │                         │                 │               ├── SLM verification
          │                         ├── PulseNet       │               ├── Language Workbench
          │                         └── Search/Certify ┴─ recursive decomposition
          │
          ├── Pareidolia Guard ── false-pattern pressure
          ├── Fractal / 4D geometry ── transform / topology carriers
          └── Water + RIVIR ── practical human-facing applications
```

## Important non-merges

- Physics is not evidence for PulseNet, and PulseNet curvature is not evidence for spacetime curvature; their connection is mathematical/experimental parallelism only.
- R³ is a method layer, not scientific evidence for any project.
- Orbit organizes/retrieves carriers; it does not inherit the authority of the projects it indexes.
- Float64 coordinates carry exact bytes/addresses; they do not supply semantics.
- Tiny Babel is TBCL genesis evidence, but TBCL is independently governed.
- Operator Moonshot is a predecessor to the One_Level_Up handoff, not inherited authority for every later project.
- Reconstructed context never overrides primary artifacts.

## Machine-readable graph

`CONNECTED_RESEARCH_GRAPH.json` contains every privacy-safe corpus artifact as a node, its project assignment, shared-operation hubs, typed cross-project relations, evidence UOIDs, and terminal privacy/source-unavailable exclusions.
