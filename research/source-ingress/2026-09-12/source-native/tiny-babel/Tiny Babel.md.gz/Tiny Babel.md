# Source-Native Reconstruction — Tiny Babel

**Reconstruction date:** 2026-09-06  
**Historical role:** predecessor/source project; not current Orbit authority.

## Source-native identity

Tiny Babel's inspected confirmed line used a finite synthetic compositional subject:

- 3 Shelves
- 512 Books
- 512 Pages
- 514 Paragraphs
- 518 semantic Sentence leaves
- exhaustive resolver domain: all 65,536 `int8^2` queries
- representation-independent subject commitment:
  `0ea008abe80c1bc05dff9a2dafe91213320e00213ff6affd4dac4ad9db3dd26e`

The governing historical rule was that implementation mechanisms were replaceable when their obligations could be transported while the verified compositional subject remained protected.

## Historical results and corrections

The Factored 001 line preserved the subject while reorganizing structural representation from 4,623 to 48 bytes and the worker lookup bound from 519 to 11, with zero resolver mismatches across the exhaustive finite domain.

Later Precise Surfaces work further reduced carriers and explicitly corrected several overinterpretations. It retained failure history externally, separated structural linkage from semantic evidence, and stated that strict improvement was not global minimality.

The exact index was eventually removable as a storage/speed tradeoff in this bounded family. Its removal was not a universal improvement claim.

## Succession boundary

TBCL later forked from Tiny Babel. Tiny Babel remained genesis evidence and a case study rather than TBCL's governing ontology. TBCL subsequently showed that Tiny Babel hierarchy traversal and its packed exact index were not necessary for the inherited frozen resolver slice.

This does not invalidate Tiny Babel's historical mechanisms. It bounds their necessity to the obligations and subject on which they were earned.

## Comparison to current Orbit

Checked against:

- `/Orbit Lab/CURRENT.md`
- Master 2.0
- Lazy but Loving Master Plan 2.2
- Master Concrete Obligation 2.4
- Master Implementation 2.6
- TW1 ACCESS3
- Historical Context Ingress Gate

Candidate relation:

`verified subject / obligation != implementation carrier`

A carrier, hierarchy, index, or organization may change when an appropriate comparison establishes that the protected subject and consequential behavior survive.

## Relation classification

`CURRENT_REINFORCEMENT`

Reason: current Orbit already requires exact source/provenance handles, treats compression as admissible only when protected outcomes survive comparison, preserves source/history, and refuses global-minimality inference from bounded reduction.

No new Orbit runtime machinery is earned by this pass.

## Preservation boundary

Tiny Babel remains historical/source-native evidence. Its 512-Book ontology, historical Master authority, old next actions, learner/potential mechanisms, and exact-index choices do not become current Orbit instructions.
