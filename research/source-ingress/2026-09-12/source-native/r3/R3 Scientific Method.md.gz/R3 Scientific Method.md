# Source-Native Reconstruction — R³ Scientific Method

**Reconstruction date:** 2026-09-06  
**Native role:** method/orchestration layer; not evidence authority and not a store of project conclusions.

## Native identity

The current inspected R³ root contains `SKILL.md` version 1.3.0 and `AGENT.md`.

Its own authority separation is explicit:

`Skill stores method; Agent executes method; Evidence decides truth.`

The Skill's bootstrap rule says method-only artifacts must not embed project conclusions, PASS/FAIL results, favored theories, current gates, or project-specific evidence.

## Native methodological boundaries

Load-bearing distinctions include:

- witnessed obligation-relevant distinctions before named mechanisms;
- `W_hat != W_other` unless frozen-scope equivalence is actually proved;
- observation/source exposure distinct from observer interpretation;
- `ACTIVE KNOWLEDGE != PRESERVED EXPERIENCE`;
- reversible evidence when future correction remains open;
- bounded finite tests justify only their tested universe;
- deduction distinct from certification;
- proposal/search distinct from verify/admit;
- unknown/unrepresented does not imply nonexistent/irrelevant.

R³ therefore cannot be used as scientific evidence merely because it prescribes a scientific method.

## Comparison to current Orbit

Checked against the current Orbit checkpoint and Historical Context Ingress Gate.

Candidate relation:

`reconstruction != source` and `method != evidence authority`

Historical/recovered models may locate and structure inquiry, but current use must return to source evidence and the current Orbit operation boundary.

## Relation classification

`CURRENT_REINFORCEMENT`

Reason: Master 2.0 already states `historical recovery != current authority`, `retrieval != proof`, and exact provenance/scope over semantic resemblance. Wave 9's ingress gate now explicitly requires source checking and rejects remembered/recovered context as an authority shortcut.

No new runtime machinery or authority layer is justified.

## Preservation boundary

R³ remains an independent method project. Its method may be consulted where useful, but it does not supersede Orbit's current Master, plan, obligation, routing, ACCESS3 preflight, or promotion authority.
