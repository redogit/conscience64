# Master General Claim-and-Evidence Program
**Version:** 0.1  
**Date:** 2026-09-11  
**Status:** IN_PROGRESS — deliberately incomplete rather than falsely exhaustive

## Goal
Build the strongest defensible general Cross-Carrier research program possible while preserving every consequential distinction between mathematical proof, exhaustive finite verification, independent replication, controlled empirical support, historical/documentary support, designed-but-unrun work, negative evidence, refutation, and unresolved claims.

The program does **not** convert empirical support into theoremhood and does not treat absence from an index as evidence of nonexistence.

## Proposed general object
Let `H` be an admitted hypothesis/system class, `Q : H -> Y` the current obligation-relevant output, `C` a set of admissible carriers/probes, `R_c(F)` the observed response produced when carrier `c` encounters `F`, and `cost(c)` the declared lifecycle cost.

Define observational equivalence:
`F ≡_C G` iff `R_c(F)=R_c(G)` for every `c in C` (or equality in the declared statistical sense for stochastic responses).

Define Q-sufficiency:
`C` is Q-sufficient iff `F ≡_C G => Q(F)=Q(G)` for all admitted `F,G`.

Define a minimum-cost sufficient family when one exists:
`C*_Q ∈ argmin_C Cost(C)` subject to Q-sufficiency.

The aim is not total reconstruction. It is preservation of every distinction that can change `Q`.

## Theorems already available from the definitions

### Theorem 1 — Probe refinement monotonicity
If `C ⊆ D`, then `≡_D` refines `≡_C`.

**Proof.** `F ≡_D G` means agreement under every carrier in `D`. Since every carrier in `C` is also in `D`, `F ≡_C G`. Thus every D-class is contained in a C-class. QED.

### Theorem 2 — Sufficiency monotonicity
If `C` is Q-sufficient and `C ⊆ D`, then `D` is Q-sufficient.

**Proof.** `F ≡_D G` implies `F ≡_C G` by Theorem 1, and Q-sufficiency of `C` gives `Q(F)=Q(G)`. QED.

This is information sufficiency, not economic benefit: extra probes can still cost too much or damage the experiment.

### Theorem 3 — Observational aliasing impossibility
If `F ≡_C G` but `Q(F) != Q(G)`, then no decision rule using only the C-response record can be correct for both.

**Proof.** The rule receives the same record for both and therefore returns the same value for both. The correct Q-values differ, so the common answer fails on at least one. QED.

**Consequence:** convergence is not truth. The lawful output is `UNRESOLVED` unless another discriminating carrier is acquired.

### Theorem 4 — Exact obligation-relative stopping
If Q is constant on each equivalence class induced by C, then C is sufficient to determine Q over the admitted class.

**Proof.** The observed record identifies an equivalence class, and by hypothesis every member has the same Q-value. QED.

**Consequence:** total identification is unnecessary when the obligation is already determined.

### Theorem 5 — Composition of obligation-preserving transforms
If every transform `T_i` preserves the relation “same Q-value,” then `T_n∘...∘T_1` also preserves it.

**Proof.** Apply preservation successively through the composition. QED.

**Consequence:** cross-carrier transport is compositional only when every bridge has an explicit preservation contract.


### Theorem 6 — Linear blind-subspace theorem
Let the admitted system parameter be `theta in R^d`, with linear carrier responses `R_i(theta)=c_i^T theta`. If the carrier span has rank `< d`, then there exists a nonzero vector `v` invisible to every carrier: `c_i^T v=0` for all `i`. Hence `theta` and `theta+v` are observationally equivalent under the entire carrier family. Any obligation `Q` that changes along `v` is therefore not determined by those carriers.

**Proof.** Rank `< d` implies the measurement matrix has a nontrivial nullspace. Choose nonzero `v` in that nullspace. Then every response difference is `c_i^T v=0`. If `Q(theta+v) != Q(theta)`, Theorem 3 applies. QED.

**Exact counterexample recorded:** four integer-valued carriers in `R^5` have rank 4 and exact null vector  
`v=(4/9,-11/9,-1/9,-2/3,1)`.  
All four response differences are exactly zero, while for `Q(theta)=v^T theta`, the difference between `theta=0` and `theta=v` is exactly `85/27`.

Artifact: `GCF_T06_EXACT_FOUR_CARRIER_ALIASING_COUNTEREXAMPLE.json`.


## What these theorems do NOT prove
They do not establish useful low-cost carriers in every domain, universal finite sufficiency, a special role for four carriers, independence from mere convergence, arbitrary physical-field reconstruction, universal historical reconstructibility, reduction of human meaning to a fixed Q, or efficient discovery of sufficient carriers.

## Evidence grades
- `PROVED_ABSTRACT`
- `EXHAUSTIVELY_VERIFIED_FINITE`
- `INDEPENDENTLY_VERIFIED`
- `SUPPORTED_BOUNDED`
- `SUPPORTED_ONE_DOCUMENTED_HISTORICAL_CASE`
- `PASS_SYNTHETIC`
- `DESIGNED_NOT_RUN`
- `NEGATIVE_EVIDENCE`
- `REFUTED_AS_STANDALONE`
- `FALSE_IN_GENERAL`
- `NOT_TESTED / UNSUPPORTED / NOT_ESTABLISHED`

## Current branch evidence map
| ID | Branch | Status | Claim boundary |
|---|---|---|---|
| `GCF-T01` | General Cross-Carrier Backbone | **PROVED_ABSTRACT** | Exact deterministic response semantics over a fixed hypothesis class. |
| `GCF-T02` | General Cross-Carrier Backbone | **PROVED_ABSTRACT** | Fixed hypothesis class, observation semantics, and obligation Q. |
| `GCF-T03` | General Cross-Carrier Backbone | **PROVED_ABSTRACT** | Exact observations; no side information outside C. |
| `GCF-T04` | General Cross-Carrier Backbone | **PROVED_ABSTRACT** | True system lies in admitted hypothesis class; exact response classification. |
| `GCF-T05` | General Cross-Carrier Backbone | **PROVED_ABSTRACT** | Each transform preserves the same declared obligation relation. |
| `CCF-E01` | Cross-Carrier / Polynomial | **SUPPORTED_BOUNDED** | Implemented synthetic polynomial distortion experiment only. |
| `CCF-E02` | Cross-Carrier / Polynomial | **NEGATIVE_EVIDENCE** | Tested radius-prediction panel. |
| `CCF-E03` | Cross-Carrier / Decomposition | **SUPPORTED_BOUNDED** | Tested graph families and cost model. |
| `CCF-E04` | Cross-Carrier / Decomposition | **SUPPORTED_BOUNDED** | Tested graph families. |
| `CCF-E05` | Cross-Carrier / Recursion | **SUPPORTED_BOUNDED** | Recorded held-out recursion-depth panel. |
| `CCF-N01` | Cross-Carrier / Semantic | **REFUTED_AS_STANDALONE** | Tested separator setting. |
| `WAVE-C01` | Cross Carrier Field Wave | **SUPPORTED_RESEARCH_CLAIM_BOUNDED** | Implemented carrier field only; not universal human knowledge transport. |
| `KD-H01` | Historical Knowledge Recovery | **SUPPORTED_ONE_DOCUMENTED_HISTORICAL_CASE** | Antikythera case supports existence, not universal reconstructibility. |
| `TBCL-E01` | TBCL | **EXHAUSTIVELY_VERIFIED_FINITE** | Inherited finite Tiny Babel resolver universe only. |
| `TBCL-E02` | TBCL | **SUPPORTED_BOUNDED** | Environment/implementation-specific; no universal speedup/minimality. |
| `OM-E01` | Operator Moonshot | **MIXED_STRONG_COMPONENT_EVIDENCE** | Owned finite/synthetic domains; claim ladder boundaries apply. |
| `OM-N01` | Operator Moonshot | **NOT_ESTABLISHED** | Cycle 3 failed; no confirmed L0→L1→L2 sequence. |
| `SHADOW-E01` | SHADOW | **SUPPORTED_PARTIAL** | 4/6 first-token cases; no exact termination; search incomplete. |
| `ORBIT-E01` | Orbit | **SUPPORTED_BOUNDED** | 14 integrated decision cases; no global minimality. |
| `HUMAN-D01` | Human / Accessibility | **DESIGNED_NOT_RUN** | No recruitment/run yet; no claim may be promoted. |
| `CCF-U01` | General Cross-Carrier Field Theory | **UNSUPPORTED** | Four is an initial probe budget only. |
| `CCF-U02` | General Cross-Carrier Field Theory | **FALSE_IN_GENERAL** | Without a sufficiency/identifiability condition. |
| `CCF-U03` | General Cross-Carrier Field Theory | **FALSE_AS_STATED** | Echo-change may be a locator; bifurcation needs dynamical validation. |
| `CCF-U04` | General Cross-Carrier Field Theory | **NOT_TESTED** | Optional representation idea only. |

## Generality program

### Route A — Formal sufficiency / quotient theory
1. Extend exact deterministic response equality to stochastic response laws.
2. Define approximate Q-sufficiency with explicit loss, epsilon, and confidence.
3. Prove finite-candidate existence/minimality results for sufficient carrier subsets.
4. Define dominance/deficiency between carrier experiments relative to a declared obligation.
5. Add costs and derive lawful finite-budget stopping rules.
6. Formalize provenance lineage as part of the evidence object.
7. Formalize carrier dependence so multiple outputs are not automatically multiple independent witnesses.

### Route B — Counterexample program
Construct and retain:
- shared-blind-spot carrier families;
- high-amplitude irrelevant modes hiding low-amplitude consequential modes;
- aliased systems with different Q;
- nonstationary systems;
- hysteretic/path-dependent systems;
- adversarial provenance duplication;
- basis-aligned probes whose apparent success comes from answer leakage;
- transforms preserving final output while destroying provenance/reconstructibility.

A general theory survives only if it handles the case or explicitly returns `UNRESOLVED`.

### Route C — Cross-domain replication
Use one frozen claim schema with domain adapters across:
1. graph/decomposition;
2. smooth polynomial/dynamical systems;
3. stochastic dynamical systems;
4. known bifurcation benchmarks;
5. semantic/program transport (TBCL);
6. executable-control modification (SHADOW);
7. organization/retrieval (Orbit);
8. historical reconstruction;
9. multilingual/variant recovery;
10. human accessibility/reconstruction;
11. physical sensing/control where actual measurements exist.

For each domain compare one carrier, multiple correlated carriers, deliberately diverse carriers, random/matched-cost probes, a standard domain baseline, and adaptive obligation-directed selection.

### Route D — Evidence independence and provenance
Every evidence item records source, transform chain, measurement apparatus, software/model/version, shared lineage, raw output, interpretation, uncertainty, failure/timeout/null state, and overturn condition.

### Route E — Prior-art collision
Treat as prior art rather than rename:
- persistent excitation/system identifiability;
- optimal experiment/input design;
- comparison and sufficiency of statistical experiments;
- predictive-state representations;
- bisimulation/behavioral equivalence;
- multi-view learning;
- active learning/information-gain design.

Novelty must be earned in the obligation-relative, cross-carrier, provenance-preserving, cost-bounded combination.

## Current strongest general claim
Across the tested computational and historical surfaces, different carriers can preserve or expose different consequential distinctions. A defensible general framework should reason over observational equivalence classes induced by explicitly identified carrier-response pairs, preserve provenance and failures, acquire additional carriers only when they can change an obligation-relevant distinction, and stop when the obligation is already constant over the remaining admissible equivalence class.

**Status:** synthesis of proved abstract lemmas plus bounded component evidence.  
**Not established:** universal applicability, universal carrier discoverability, universal finite sufficiency, or a physical field law.

## Memory / preservation contract
The durable record is the evidence graph, not unaudited recollection.

For every claim retain:
`Claim -> Scope -> Evidence -> Raw artifact -> Transform history -> Counterevidence -> Status -> Claim ceiling -> Next discriminating test`.

Never overwrite failure with later success.
Never convert `UNKNOWN` to `FALSE`.
Never count copies from one lineage as independent corroboration.
Never promote a designed experiment as if it ran.
Never promote exhaustive finite verification outside its declared finite domain.
Never call convergence truth without an identifiability/sufficiency argument.

## Next discriminating package
1. Prove approximate/stochastic versions of Theorems 1–4.
2. Build the smallest explicit four-carrier aliasing counterexample: all four converge while Q differs.
3. Build a matched-cost benchmark comparing obligation-directed selection with random, magnitude-only, finite-difference/spectral, and active-design baselines.
4. Apply the same frozen claim schema to TBCL, Orbit, SHADOW, graph decomposition, historical recovery, and a dynamical/bifurcation benchmark.
5. Keep HUMAN-01/HUMAN-02 at `DESIGNED_NOT_RUN` until actually executed under their declared ethical and measurement boundaries.
